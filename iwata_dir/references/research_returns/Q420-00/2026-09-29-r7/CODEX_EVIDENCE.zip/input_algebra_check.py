"""Independent local algebra-to-current-code checks, not an E07/GFS replay.

python -B input_algebra_check.py
No acquisition, trajectory integration, calibration, or repository writes.
"""
from pathlib import Path
import sys
import math
import json
import hashlib
from collections import defaultdict
from fractions import Fraction

ROOT = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
sys.path.insert(0, str(ROOT))
from balloon_sim.flight.models import vertical_state, _gas_state, moist_air_density
from balloon_sim.flight.events import BurstEvent
from scipy.optimize import brentq
from scipy.special import gammaln

G, RG = 9.80665, 2077.1
SCALES = (0.75, 1.0, 1.25, 1.5)
AD0 = 2 * G / (1.225 * 25)


def cfg(scale=1, delta=0):
    return {'ascent': {'mode': 'isothermal_buoyancy', 'gas_mass_kg': .5 * scale,
                       'envelope_mass_kg': scale, 'payload_mass_kg': scale + delta,
                       'gas_constant_j_kg_k': RG, 'drag_coefficient': .47 * scale**(1/3)},
            'descent': {'mode': 'constant_cda', 'mass_kg': scale + delta,
                        'drag_area_m2': AD0 * scale}}


samples = [dict(pressure_pa=p, temperature_k=t, specific_humidity_kg_kg=q)
           for p, t, q in [(101800., 278.15, 0.), (50000., 250., .012), (1200., 225., .00002)]]
rows = []
max_residual = 0.
for sample in samples:
    c0 = cfg()
    rho = moist_air_density(**sample)
    v0 = vertical_state(c0, 'ascent', 0, sample)['vertical_speed_m_s']
    d0 = vertical_state(c0, 'descent', 0, sample)['vertical_speed_m_s']
    volume0 = .5 * RG * sample['temperature_k'] / sample['pressure_pa']
    area0 = math.pi * ((3 * volume0 / (4 * math.pi))**(1/3))**2
    for scale in SCALES:
        c = cfg(scale)
        va = vertical_state(c, 'ascent', 0, sample)['vertical_speed_m_s']
        vd = vertical_state(c, 'descent', 0, sample)['vertical_speed_m_s']
        event = BurstEvent('diameter', 8 * scale**(1/3), lambda s: _gas_state(c['ascent'], s))
        expected_event = (6*volume0/math.pi)**(1/3) - 8
        residual = max(abs(va/v0-1), abs(vd/d0-1),
                       abs(event.value(0, sample)/scale**(1/3)-expected_event)/max(1,abs(expected_event)))
        max_residual = max(max_residual, residual)
        edited = cfg(scale, .5)
        edited_va = vertical_state(edited, 'ascent', 0, sample)['vertical_speed_m_s']
        edited_vd = vertical_state(edited, 'descent', 0, sample)['vertical_speed_m_s']
        expected_va2 = v0*v0 - 2*G*.5/(scale*rho*.47*area0)
        expected_vd2 = d0*d0 + 2*G*.5/(scale*rho*AD0)
        assert math.isclose(edited_va**2, expected_va2, rel_tol=2e-14)
        assert math.isclose(edited_vd**2, expected_vd2, rel_tol=2e-14)
        rows.append({'sample': sample, 'scale': scale, 'base_ascent_m_s': va,
                     'base_descent_m_s': vd, 'plus_0_5kg_ascent_m_s': edited_va,
                     'plus_0_5kg_descent_m_s': edited_vd})
assert max_residual < 2e-14

# Both descent inputs use the same supplied weather density in this identity.
density_rows = []
for sample, altitude in zip(samples, (0, 6000, 30000)):
    rho = moist_air_density(**sample)
    cda = cfg()
    rated = {'descent': {'mode': 'rated_speed', 'reference_speed_m_s': 5.,
                        'reference_density_kg_m3': 1.225, 'density_model': 'weather'}}
    exponential = {'descent': {'mode': 'rated_speed', 'reference_speed_m_s': 5.,
                              'scale_height_m': 8400., 'density_model': 'exponential'}}
    cda_v = vertical_state(cda, 'descent', altitude, sample)['vertical_speed_m_s']
    rated_v = vertical_state(rated, 'descent', altitude, sample)['vertical_speed_m_s']
    exp_v = vertical_state(exponential, 'descent', altitude, sample)['vertical_speed_m_s']
    assert math.isclose(cda_v, rated_v, rel_tol=1e-14)
    density_rows.append({'rho_kg_m3': rho, 'altitude_m': altitude, 'constant_cda_m_s': cda_v,
                         'rated_weather_m_s': rated_v, 'rated_exponential_m_s': exp_v})
assert any(abs(r['constant_cda_m_s']-r['rated_exponential_m_s']) > 1 for r in density_rows)

# Exact marginal weights for the scale example, not reconstructed E07 outputs.
joint = [(a, a, Fraction(1,4)) for a in SCALES]
product = [(a, b, Fraction(1,16)) for a in SCALES for b in SCALES]
def marginal(data, coordinate):
    values = defaultdict(Fraction)
    for a,b,w in data:
        values[(a,b)[coordinate]] += w
    return values
assert marginal(joint,0) == marginal(product,0)
assert marginal(joint,1) == marginal(product,1)

def weibull_cv(k):
    return math.sqrt(math.expm1(gammaln(1+2/k)-2*gammaln(1+1/k)))
k = brentq(lambda k:weibull_cv(k)-.1, 1, 100)
lam = 10/math.exp(gammaln(1+1/k))
weibull = {'mean':10, 'cv':.1, 'k':k, 'lambda':lam,
           'central90':[lam*(-math.log(1-u))**(1/k) for u in [.05,.95]]}

# Nominal inverse design uses fixed p,T and Cd; no hidden per-sample knowledge.
sample = samples[0]
def speed(mgas):
    c = cfg()
    c['ascent'].update(gas_mass_kg=mgas, envelope_mass_kg=1, payload_mass_kg=3)
    return vertical_state(c,'ascent',0,sample)['vertical_speed_m_s']
threshold = 4/(RG/287.05-1)
gas = brentq(lambda mass:speed(mass)-5, threshold*1.000001, 5, xtol=1e-14)

source_names = ['balloon_sim/flight/models.py','balloon_sim/flight/config.py','balloon_sim/flight/events.py']
out = {'scope':'Independent local state/algebra check only; no GFS flights or E07 studies replay',
       'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in source_names},
       'I1_state_evaluations':len(rows), 'I1_max_normalized_residual':max_residual,
       'I4_local_edited_speeds':rows, 'descent_identity_and_density_counterexample':density_rows,
       'same_scale_marginals_different_joint':True, 'weibull_example':weibull,
       'nominal_inverse_gas_kg':gas}
target=Path(__file__).with_suffix('.json')
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['I4_local_edited_speeds','source_sha256']},ensure_ascii=False,indent=2))
