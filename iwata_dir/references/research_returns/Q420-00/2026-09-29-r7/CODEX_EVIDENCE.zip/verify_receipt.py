"""Read-only independent verification of the supplied R7 archive and copies."""
import hashlib,json,zipfile
from pathlib import Path,PurePosixPath
P=Path(__file__).resolve().parent
Z=Path('C:/Users/genia/AppData/Local/Temp/codex-file-preview-Wyrjja/Q420_R7_20260929_package.zip')
R=P/'received-package/Q420_CURRENT_RESEARCH'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((R/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
rows=manifest['files']; names=[x['path'] for x in rows]
assert len(names)==len(set(names))==len(set(x.casefold() for x in names))
for row in rows:
 n=row['path']; p=PurePosixPath(n)
 assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n
 raw=(R/n).read_bytes()
 assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],n
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 files=[x for x in z.infolist() if not x.is_dir()]
 expected={'Q420_CURRENT_RESEARCH/'+n for n in names+['MANIFEST_SHA256.json']}
 assert {x.filename for x in files}==expected
 for item in files:
  assert z.read(item)==(P/'received-package'/item.filename).read_bytes(),item.filename
duplicates=[]
for n in ('CODEX_RESEARCH_REPORT.md','READING_AND_EVIDENCE_LOG.md'):
 b=(R/n).read_bytes(); assert b==(Path('C:/Users/genia/Downloads')/n).read_bytes()
 duplicates.append(dict(path=n,bytes=len(b),sha256=sha(b),identical_to_earlier_markdown=True))
out=dict(schema='codex.q420.receipt/1',archive_bytes=Z.stat().st_size,archive_sha256=sha(Z.read_bytes()),archive_files=len(files),manifest_verified_files=len(rows),manifest_sha256=sha((R/'MANIFEST_SHA256.json').read_bytes()),extra_archive_files=[],earlier_markdown=duplicates,basis_commit=manifest['basis_commit'],report_revision=manifest['report_revision'],meaning='CRC, manifest and byte identity only; scientific and operational claims reviewed separately.')
(P/'receipt440.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
