"""Finite local E07 replay; never edit the received package or repository."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "received-package/Q420_CURRENT_RESEARCH"
OUT = ROOT / "e07-local-reproduction"

def write(path, obj):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        f.write("\n")

def hashes():
    return {p.relative_to(PKG).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(PKG.rglob("*")) if p.is_file()}

mode = sys.argv[1]
if mode == "snapshot":
    import numpy
    import scipy
    OUT.mkdir(exist_ok=False)
    write(OUT / "source-before.json", hashes())
    write(OUT / "environment.json", {"python": sys.version, "executable": sys.executable,
          "platform": platform.platform(), "numpy": numpy.__version__, "scipy": scipy.__version__,
          "scope": "Saved-results checks plus 8 flights (family_w and payload), no other integration",
          "source_modifications": [], "network": "Scripts inspected; saved weather only; no provider call"})
    print("Fresh output and source snapshot created", flush=True)
elif mode in ("saved-checks", "family_w", "payload"):
    assert (OUT / "source-before.json").is_file()
    receipt = OUT / (mode + "-receipt.json")
    target = OUT / mode
    assert not receipt.exists() and not target.exists(), "Refuse to overwrite or blindly retry"
    if mode == "saved-checks":
        args = [str(PKG / "verify_current.py"), "--section", "new", "--out", str(target)]
    else:
        args = [str(PKG / "studies/identifiability/code/study.py"), mode, "--out", str(target)]
    command = [sys.executable, "-X", "utf8", "-B", *args]
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUTF8"] = "1"
    start = time.monotonic()
    print("Starting " + mode, flush=True)
    try:
        result = subprocess.run(command, cwd=OUT, env=env, capture_output=True, text=True,
                                encoding="utf-8", timeout=180)
        record = {"command": command, "returncode": result.returncode,
                  "stdout": result.stdout, "stderr": result.stderr,
                  "elapsed_s": time.monotonic() - start, "source_modifications": []}
        write(receipt, record)
        print(json.dumps(record, ensure_ascii=True), flush=True)
        sys.exit(result.returncode)
    except subprocess.TimeoutExpired as exc:
        write(receipt, {"command": command, "timeout_s": 180,
              "stdout": str(exc.stdout), "stderr": str(exc.stderr),
              "elapsed_s": time.monotonic() - start})
        raise
elif mode == "finish":
    before = json.loads((OUT / "source-before.json").read_text(encoding="utf-8"))
    after = hashes()
    write(OUT / "source-after.json", after)
    difference = [p for p in set(before) | set(after) if before.get(p) != after.get(p)]
    write(OUT / "source-integrity.json", {"file_count_before": len(before),
          "file_count_after": len(after), "changed_paths": sorted(difference), "unchanged": not difference})
    assert not difference, difference
    print("All received source files unchanged")
else:
    raise ValueError("Unknown mode")
