import sys, subprocess, json, platform, hashlib, time
from pathlib import Path
import numpy, scipy
r=Path(__file__).resolve().parent
s=r/'received-package'/'Q420_CURRENT_RESEARCH'/'studies'
c=s/'coverage'
out=r/'selected-author-checks'/'coverage-miniforge'
out.mkdir(exist_ok=False)
hashes={str(p.relative_to(c)):hashlib.sha256(p.read_bytes()).hexdigest() for p in c.rglob('*') if p.is_file()}
cmd=[sys.executable,'-B',str(c/'verify_study.py'),'--data',str(c/'data'/'final'),'--output',str(out/'checks.json'),'--r1-cases',str(s/'approximation'/'data'/'experiment'/'cases.csv')]
start=time.monotonic()
x=subprocess.run(cmd,cwd=out,capture_output=True,text=True,timeout=45)
record={'scope':'Author saved coverage checks only; no contour oracle integration or study plot regeneration. Separate existing Python environment after scipy missing in bundled runtime.','python':sys.version,'platform':platform.platform(),'numpy':numpy.__version__,'scipy':scipy.__version__,'command':cmd,'seconds':time.monotonic()-start,'returncode':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'source_study_file_count':len(hashes),'source_unchanged':all(hashlib.sha256((c/p).read_bytes()).hexdigest()==h for p,h in hashes.items()),'source_no_new_files':set(hashes)=={str(p.relative_to(c)) for p in c.rglob('*') if p.is_file()}}
(out/'processes.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
sys.exit(x.returncode)
