# Codexによる第7巡の有限評価・再現証拠

2026-09-29、Q420-00 rev7／0.44。原研究は別の Q420_R7_20260929_package.zip。本ZIPは原研究を訂正しない。
主入口は同じ階層の CODEX_REVIEW.md。input/statistics/provenanceの3レビューと、接続設計の二巡目批評から読む。

E07は8飛行の新規積分と保存結果の再解析。summary一値の丸め差でwrapper exit 1を保持する。
target_frameの改行差、coverageの最初のSciPy不足と別環境での成功を別プロセス票に保持する。
実行前後の原416ファイルhash、環境、コマンド、stdout/stderrを収録。全28飛行/全図/実観測/Windows障害運用の検証ではない。

再実行:
1. この証拠を空の作業ディレクトリへ展開。原研究ZIPをその直下 received-package/ に展開し、received-package/Q420_CURRENT_RESEARCH/ を作る。
2. 実行済みラッパーは当時のまま保存している。P=スクリプト位置を使うものはこの配置に戻れるが、repo/元ZIP/Downloads等の絶対パスがあるスクリプトは、コピーの当該定数を手元の固定版/原本へ置き換える。originalを変更しない。
3. 出力は新しい名前のディレクトリへ変える（e07等は存在済み出力を拒否）。REPRODUCE.mdで各処理の意味を確認する。著者verify_current --section newは全28飛行の再積分ではない。
4. Windowsで実行した核側はPython3.12.12/NumPy2.4.4/SciPy1.17.1。統計の一部はPython3.12.14。環境票を参照。新規の依存インストールは行っていない。
5. input_algebra_check と independent-arithmetic は著者の研究計算をimportしない独立計算。前者は固定された現核に依存する。verify-newlines-and-crossingは有限反例と改行差の判定。

MANIFEST_SHA256.jsonはこのZIPの各memberを検証するための指紋で、自身は含まない。スクリプトに残るローカルパスは再現の来歴であり、全PC・外部サービスの可用性保証ではない。
