"""Independent arithmetic only; no study files, flight solver, or weather fetched."""
from math import exp, sqrt, comb, ceil, log
from statistics import variance, mean
from fractions import Fraction as F
import json
from pathlib import Path
N,m=2048,128
u=[8+4*(i+.5)/N for i in range(N)]
L=[[38500 <= x*T <= 44500 for x in u] for T in (3600,4200)]
R=[[38500 <= x*(exp(2e-5*T)-1)/2e-5 <= 44500 for x in u] for T in (3600,4200)]
dL=[int(b)-int(a) for a,b in zip(*L)]
dR=[int(b)-int(a) for a,b in zip(*R)]
res=[r-l for r,l in zip(dR,dL)]
def simple(a): return (1-m/N)*variance(a)/m
def strata(a): return sum((1/8)**2*(1-16/256)*variance(a[h*256:(h+1)*256])/16 for h in range(8))
def binom_cdf(k,n,p): return sum(comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1))
def p_lower(k,n,alpha):
    lo,hi=0.0,1.0
    for _ in range(100):
        q=(lo+hi)/2
        if binom_cdf(k-1,n,q)>=1-alpha: lo=q
        else: hi=q
    return (lo+hi)/2
out={
  'scope':'Constructed anew from report algebra only; no missing studies or GFS flight claims verified.',
  'finite2048':{
    'counts_L_A_B_R_A_B':[sum(a) for a in L+R],
    'delta_L':mean(dL),'delta_R':mean(dR),
    'sd_pp_direct_srs':100*sqrt(simple(dR)),
    'sd_pp_residual_srs':100*sqrt(simple(res)),
    'sd_pp_direct_stratified':100*sqrt(strata(dR)),
    'sd_pp_residual_stratified':100*sqrt(strata(res)),
    'sd_pp_independent':100*sqrt((1-m/N)*(variance(R[0])+variance(R[1]))/m),
    'excluded_count':sum(not a and not b for a,b in zip(*L)),
    'excluded_R_contribution':sum(dr for a,b,dr in zip(*L,dR) if not a and not b),
    'delta_R_after_dropping_as_zero':sum(dr for a,b,dr in zip(*L,dR) if a or b)/N,
  },
  'nested_table':[{'K':K,'M':int(2400/(20+K)),'SE_pp':100*sqrt((.09+.17/K)/int(2400/(20+K)))} for K in (1,4,6,20,100)],
  'ranks':{'nominal_k':ceil(129*.95),'content_k':next(k for k in range(1,129) if binom_cdf(k-1,128,.95)>=.95),'k126_lower_content':p_lower(126,128,.05),'nmin95':ceil(log(.05)/log(.95)),'nmin24claims':ceil(log(.05/24)/log(.95)),'content_k24':next(k for k in range(1,129) if binom_cdf(k-1,128,.95)>=1-.05/24)},
  'scott_factor_2d':[n**(-1/6) for n in (128,1024)],
  'reviewer_crossed_U_example':{'D_total_var':.26,'W_main_var':.09,'U_main_var':.11,'interaction_var':.06,'M100_K4_nested_variance':.09/100+.17/400,'M100_K4_crossed_variance':.09/100+.11/4+.06/400,'M100_K4_nested_SE_pp':100*sqrt(.09/100+.17/400),'M100_K4_crossed_SE_pp':100*sqrt(.09/100+.11/4+.06/400),'M_infinite_K4_crossed_SE_pp':100*sqrt(.11/4)},
  'moments':{'C1_var':1,'C2_var':.8**2+.2**2,'cov':-.8,'total_var':1+.8**2+.2**2-1.6,'allocation_C1':(1-.8)/.08,'allocation_C2':(.8**2+.2**2-.8)/.08,'flight_time_wind_mean_displacement_km':(1000*20+2000*5)/2/1000,'product_of_means_km':1500*12.5/1000}
}
p=Path(__file__).with_name('independent-arithmetic.json');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
