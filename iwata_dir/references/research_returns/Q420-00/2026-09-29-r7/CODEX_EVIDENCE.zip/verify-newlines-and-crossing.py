import json, hashlib
from pathlib import Path
from fractions import Fraction as F
r=Path(__file__).resolve().parent
base=r/'selected-author-checks'/'target_frame'
data=r/'received-package'/'Q420_CURRENT_RESEARCH'/'studies'/'target_frame'/'data'
out={}
for p in (base/'regenerated').glob('*.json'):
    a=p.read_bytes();b=(data/p.name).read_bytes()
    out[p.name]={'byte_equal':a==b,'json_value_equal':json.loads(a)==json.loads(b),'equal_after_CRLF_to_LF':a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),'new_CRLF':a.count(b'\r\n'),'old_CRLF':b.count(b'\r\n'),'new_bytes':len(a),'old_bytes':len(b),'sha256_new':hashlib.sha256(a).hexdigest(),'sha256_old':hashlib.sha256(b).hexdigest()}
(base/'newline-comparison.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
# Exact independent integration on U's threshold intervals; W is equiprobable.
# Rows: interval probability, D(W=0,U), D(W=1,U).
rows=[(F(1,10),0,0),(F(1,10),-1,0),(F(1,2),0,1),(F(3,10),0,0)]
mu=sum(w*F(a+b,2) for w,a,b in rows)
mu_w=[sum(w*d for w,*ds in rows for d in [ds[j]]) for j in (0,1)]
var_w=sum((v-mu)**2 for v in mu_w)/2
var_u=sum(w*(F(a+b,2)-mu)**2 for w,a,b in rows)
var_d=sum(w*(F(a*a+b*b,2)) for w,a,b in rows)-mu**2
interaction=var_d-var_w-var_u
cross={'method':'Fraction integration over four U intervals, equiprobable W; no research implementation imported','mean':str(mu),'variance_total':str(var_d),'variance_W_main':str(var_w),'variance_U_main':str(var_u),'variance_interaction':str(interaction),'nested_M100_K4_variance':str(var_w/100+(var_d-var_w)/400),'crossed_M100_K4_variance':str(var_w/100+var_u/4+interaction/400)}
(r/'independent-crossed-design.json').write_text(json.dumps(cross,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'newline_comparison':out,'crossed_design':cross},indent=2))
