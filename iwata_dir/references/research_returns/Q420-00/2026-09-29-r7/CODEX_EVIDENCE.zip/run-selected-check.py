"""Finite selected author checks. No network or full study regeneration."""
import sys, subprocess, json, platform, hashlib, time
from pathlib import Path
root=Path(__file__).resolve().parent
pkg=root/'received-package'/'Q420_CURRENT_RESEARCH'
base=root/'selected-author-checks'
base.mkdir(exist_ok=True)
name=sys.argv[1]
out=base/name
out.mkdir(exist_ok=False)
s=pkg/'studies'
if name=='target_frame':
    jobs=[['frame_study.py','--out',str(out/'regenerated')],['verify_frame.py','--data',str(out/'regenerated'),'--out',str(out/'checks.json')]]
    cwdstudy=s/name
elif name=='approximation':
    jobs=[['verify_independent.py','--data',str(s/name/'data'/'experiment'),'--out',str(out/'checks.json')]]
    cwdstudy=s/name
elif name=='coverage':
    jobs=[['verify_study.py','--data',str(s/name/'data'/'final'),'--output',str(out/'checks.json'),'--r1-cases',str(s/'approximation'/'data'/'experiment'/'cases.csv')]]
    cwdstudy=s/name
else: raise ValueError(name)
protected=list(cwdstudy.rglob('*'))
hashes={str(p.relative_to(cwdstudy)):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected if p.is_file()}
record={'name':name,'scope':'Author checks rerun on received saved study data; target_frame alone regenerated as explicit finite definitions. No flight or full contour generation.', 'python':sys.version,'platform':platform.platform(),'jobs':[]}
for args in jobs:
    command=[sys.executable,'-B',str(cwdstudy/args[0]),*args[1:]]
    before=time.monotonic()
    result=subprocess.run(command,cwd=out,capture_output=True,text=True,timeout=45)
    record['jobs'].append({'command':command,'returncode':result.returncode,'seconds':time.monotonic()-before,'stdout':result.stdout,'stderr':result.stderr})
    (out/'processes.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if result.returncode: print(record); sys.exit(result.returncode)
record['source_study_file_count']=len(hashes)
record['source_unchanged']=all((cwdstudy/p).is_file() and hashlib.sha256((cwdstudy/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
record['source_no_new_files']=set(hashes)=={str(p.relative_to(cwdstudy)) for p in cwdstudy.rglob('*') if p.is_file()}
if name=='target_frame':
    record['regenerated_json_bytes_match']={p.name:p.read_bytes()==(cwdstudy/'data'/p.name).read_bytes() for p in (out/'regenerated').glob('*.json')}
(out/'processes.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
