"""Independent JSON/endpoint comparison of eight local flights; no simulation."""
from collections import defaultdict
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "received-package/Q420_CURRENT_RESEARCH"
OUT = ROOT / "e07-local-reproduction"
OLD = PKG / "studies/identifiability"
REPO = Path(r"C:\Users\genia\OneDrive\ドキュメント\00 よく使う\n_名古屋大学\06_Chart\バルーン\Balloon_Sim\2026_Sep_\space-balloon-simulator-jp")

def read(p):
    return json.loads(p.read_text(encoding="utf-8"))

def compare(a, b):
    numeric = defaultdict(lambda: {"different": 0, "max_abs": 0.0, "max_relative": 0.0})
    structural, strings, failed = [], [], []
    def walk(x, y, path=""):
        if isinstance(x, (int, float)) and not isinstance(x, bool) and isinstance(y, (int, float)) and not isinstance(y, bool):
            if x != y:
                key = path.rsplit("/", 1)[-1]
                d = abs(x-y)
                r = d/max(abs(x), abs(y), 1e-300)
                z = numeric[key]
                z["different"] += 1
                z["max_relative"] = max(z["max_relative"], r)
                if d > z["max_abs"]:
                    z.update(max_abs=d, path=path, original=x, local=y)
                if not math.isclose(x, y, rel_tol=1e-10, abs_tol=1e-7):
                    failed.append({"path":path,"original":x,"local":y})
        elif type(x) is not type(y):
            structural.append({"path":path,"original_type":type(x).__name__,"local_type":type(y).__name__})
        elif isinstance(x, dict):
            if x.keys() != y.keys():
                structural.append({"path":path,"keys_original":list(x),"keys_local":list(y)})
            for k in x.keys() & y.keys():
                walk(x[k], y[k], path+"/"+k)
        elif isinstance(x, list):
            if len(x) != len(y):
                structural.append({"path":path,"length_original":len(x),"length_local":len(y)})
            for i, (xx, yy) in enumerate(zip(x, y)):
                walk(xx, yy, path+"/"+str(i))
        elif x != y:
            strings.append({"path":path,"original":x,"local":y})
    walk(a, b)
    return {"numeric_differences_by_field":dict(numeric),"structural_differences":structural,
            "other_differences":strings,"numeric_tolerance_failures":failed,
            "numeric_tolerance":{"relative":1e-10,"absolute":1e-7}}

def en(r):
    p=r["summary"]["landing"]; launch=r["config"]["launch"]
    return [6371000*math.cos(math.radians(launch["latitude_deg"]))*math.radians(p["longitude_deg"]-launch["longitude_deg"]),
            6371000*math.radians(p["latitude_deg"]-launch["latitude_deg"])]

output={"scope":"8 recomputed flights, 3 regenerated saved-result analyses; no other full-flight integrations",
        "saved_analysis":{},"flights":[],"current_code_hash_comparison":{}}
for p in sorted((OUT/"saved-checks/identifiability_analysis").glob("*.json")):
    old=OLD/"analysis"/p.name
    output["saved_analysis"][p.name]={"byte_identical":old.read_bytes()==p.read_bytes(),**compare(read(old),read(p))}

local={}
for group in ("family_w","payload"):
    local[group]=[]
    old_index=read(OLD/"data"/group/"cases.json")
    new_index=read(OUT/group/"cases.json")
    assert old_index==new_index, "Cases and weather fixture must match exactly"
    for i in range(4):
        p=OUT/group/f"case_{i}.json"; old=OLD/"data"/group/p.name
        r=read(p); before=read(old); local[group].append(r)
        burst=next(e for e in r["events"] if e["type"]=="burst")
        output["flights"].append({"group":group,"index":i,"scale":(.75,1,1.25,1.5)[i],
            "byte_identical":p.read_bytes()==old.read_bytes(),"complete":r["complete"],"status":r["status"],
            "burst_time_s":burst["elapsed_s"],"burst_height_m":burst["altitude_m"],
            "landing_time_s":r["summary"]["landing"]["elapsed_s"],"landing_EN_m":en(r),
            "landing_change_from_saved_m":math.dist(en(r),en(before)),**compare(before,r)})
output["payload_max_pair_distance_m"]=max(math.dist(en(a),en(b)) for a,b in itertools.combinations(local["payload"],2))
output["payload_shifts_m"]=[math.dist(en(a),en(b)) for a,b in zip(local["family_w"],local["payload"])]
output["family_max_pair_landing_distance_m"]=max(math.dist(en(a),en(b)) for a,b in itertools.combinations(local["family_w"],2))
output["family_raw_history_max_abs"]={}
for field in ("elapsed_s","latitude_deg","longitude_deg","altitude_m"):
    histories=[r["records"] for r in local["family_w"]]
    assert len(set(map(len,histories)))==1
    output["family_raw_history_max_abs"][field]=max(abs(a[field]-b[field]) for h in histories[1:] for a,b in zip(histories[0],h))

for p in sorted((PKG/"studies/input_weather_storage/sources/balloon_sim").rglob("*.py")):
    rel=p.relative_to(PKG/"studies/input_weather_storage/sources")
    q=REPO/rel
    output["current_code_hash_comparison"][rel.as_posix()]={"same":q.is_file() and p.read_bytes()==q.read_bytes(),"source_sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
with (OUT/"independent-comparison.json").open("x",encoding="utf-8",newline="\n") as f:
    json.dump(output,f,indent=2,sort_keys=True,allow_nan=False);f.write("\n")
print(json.dumps({"saved_analysis":{k:{"byte_identical":v["byte_identical"],"numeric_fields_differing":list(v["numeric_differences_by_field"]),"structural":v["structural_differences"],"other":v["other_differences"],"tolerance_failures":len(v["numeric_tolerance_failures"])} for k,v in output["saved_analysis"].items()},
 "eight_complete":all(x["complete"] for x in output["flights"]),"payload_max_pair_distance_m":output["payload_max_pair_distance_m"],
 "family_raw_history_max_abs":output["family_raw_history_max_abs"],"source_code_matches":all(x["same"] for x in output["current_code_hash_comparison"].values()),
 "flights_structural_differences":sum(len(x["structural_differences"]) for x in output["flights"]),
 "flights_tolerance_failures":sum(len(x["numeric_tolerance_failures"]) for x in output["flights"]),
 "flights_other_differences":[x["other_differences"] for x in output["flights"]]},indent=2))
