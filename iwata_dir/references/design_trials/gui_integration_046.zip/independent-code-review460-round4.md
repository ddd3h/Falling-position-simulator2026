# Independent UI code review — round 4 (0.46)

基準: adopted M420 / PR30 C2 ce6a29accfad6865beca0b2dfe4f414e2bafb81a。対象は共同編集中の frontend source。数値結果・科学モデルは変更していない。読み取りと P460 内の純関数 probe のみ。実ブラウザ受入は root/screens460 が別途実施中。

## 今回確認できた訂正

- `domain.draftMatchesRun` は `Run.spec.submitted_input` の config と weather_source_id を照合する。原入力が取得できない時だけ revision を fallback にする。
- 既存の実計算保存例 950b9982-bbfd-414f-ac53-59f03d703e5c で実関数を読み込み、原入力一致=true、キー順のみ反転=true、上昇率5→6=false、気象source変更=falseを確認。`probe-provenance460-round4.cjs`。
- この保存例について原入力 config と result config の値差は `[]`。今回の即dirtyの原因を「kernel正規化で値が変わったため」と断定してはいけない。旧 JSON.stringify のキー順依存も候補であり、値の差を仮定しない説明が必要。
- 実 controller の conditionSummary を抽出した `probe-comparison460-round4.cjs` は、定速5/6と気象source A/Bをそれぞれ差分として表示する。前巡の両不具合は局所的に修正された。
- UUID候補ID、表示用alias、削除候補へ古い完了結果を再選択しないreducer条件、保存再読込み時のcontroller remount、実record/イベント時刻の保持はコードにある。これを保存再開・複数候補・延期列の実UI受入完了とはしない。

## 第4巡で見つけ、実装者へ直接返した事項

1. **保存viewの等価比較**: `App.keepView` は現値にcodesを保持したまま、codesを含まないsnapshotと比較していた。同じsnapshotでも毎回更新し、map moveendとsyncの往復を生み得る。merge後比較に修正済みのコードを確認した。実UIで静止後に更新を繰返さないことは別途必要。
2. **条件へ戻す**: `App.revert` はresult.configを戻していた。dirtyの正本はsubmitted_inputなので、こちらへ戻すべき。実装者が採用して修正中。今回の保存例の値差はなくても契約上の不整合である。
3. **出力由来/単位の残存**: 実n1のPNG/SVGにも10–90分位帯の注記、KMLのflight-route名に模式AGL、実放球点のfallback説明に人工模型、輪郭が無いKMLにも50/90/95注記が残っていた。実/人工とオブジェクト有無から説明を作るよう依頼。exportOverviewKMLのASL分岐は反映済みを途中確認した。
4. **比較群の気象支持**: `ForecastScreen.displayedSource` はactiveGroup時に候補を見つけられずsources[0]へfallback。2D `drawMap` と `analysisDocument` は一つの矩形を使うので、別の保存気象の候補群を開くと無関係の最初の支持境界を「表示中の固定結果」と説明し得る。表示中結果ごとの支持、または適切に限定して由来を示す処理が必要。
5. **停止runの詳細2D**: `drawMap` 詳細分岐の経路はlanded(t)だけから取り、停止runでは消える。history/3Dで採用したdetailSamplesと一貫させる必要。
6. **停止runの詳細3D**: `analysisDocument` のselection.countはselectedSamplesから1、denominatorはlandedから0となる。`scene3d/src/protocol.js` のcount<=denominatorで拒否される。実モード母数を記録数にし、main/catalogの着地群・平均固定文も訂正が必要。Google接続はこの契約検査に不要。

## 継承/統合の判断

0.40.1の具体的な用途画面と同じ計画・固定結果を結び直す方向は、0.45で効用表だけを継承した状態より意図に近づいている。一方、旧模型の語彙・標本集合・固定グローバル気象場の前提を保持してよいとは限らない。上記はレイアウト改変を要求する指摘ではなく、同じ画面の意味を実データと複数候補へ接続する際の契約訂正である。

全体受入は未完了。特に親条件変更と固定旧結果、異なる保存気象の群比較、停止run詳細、保存→用途切替→再読込み、人工気象→季節handoff→元用途帰還について、実画面の観察とコードの訂正確認を分けて残す。

### 同巡の追加：用途間handoffの反例

7. `App` がseasonSourceだけをmergeし既存tabsを残すため、気象側で新しい地点/年/時刻maskから再handoffすると、initSeasonの新候補をrestoreが旧tabsで上書きする。新来歴表示と旧結果が混在する。`weatherReturn` も旧の別HTMLリンクであり、shellの用途切替へ接続されていなかった。実装者へ返し、「新提案を候補追加し候補に由来を持たせる、復帰は復元だけ、戻りはshell intent」という修正方針の返答を得た。採用方向は妥当だが未確認。追加後に旧候補へ戻ったとき、global seasonSource の新来歴を旧候補へ誤表示しないよう続けて指摘した。

停止詳細protocolは `probe-stopped-protocol460.mjs` で、母数0/count1では拒否、母数1/count1では受理を実関数で確認。これは旧不具合の反証であり、修正後payload生成のE2E証明ではない。
