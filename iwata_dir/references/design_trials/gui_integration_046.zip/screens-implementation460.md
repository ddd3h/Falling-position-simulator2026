# 0.46 frontend 実装・有限受入引継ぎ

2026-09-29 / 担当 screens460。編集範囲 frontend/** のみ。S35事前記録後に実装。backend、Git操作、原ZIPは変更していない。機能照合の追加修復まで完了。現 source は freeze。最終生成物は index-TiNcwLt2.js、index-MuRePXMK.css、leaflet-vh-t_kPv.css。distは登録sourceではなくnpmから再生成する。旧DJXE時点の票は *-before-feature-repair に保持。

## 意図と実体

0.40.1 r2の具体的な画面素材を同一Reactプラットフォームへ取り込み、候補/遅延/概要/詳細/3Dと、気象4画面/季節計画を保持した。全体を別iframeで囲う構成にはしていない。既存のscene3d rendererだけは元のpostMessage境界を維持した。由来・元ZIP SHA・各source枝の対応・npm依存版・旧ファイルの保持理由は frontend/SCREEN_PROVENANCE.md に記載した。

実計算の候補・提出草案・選択固定runは useWorkspace/React が所有し、画面controllerへread-only投影する。controllerは局所描画・選択・視点を持ち、編集は意図callbackでReactへ戻す。実/人工/気象/季節は ui_state の4namespaceへ分け、保存計画のreload時はrestore世代によってmountし直す。人工結果は実結果へ補完しない。季節handoffは既存候補を保持して新規候補を追加し、各候補の元地点/年/時刻帯/季節と戻る先を保持する。

実装入口は App.tsx → ForecastScreen/WeatherScreen → screenScope/runtime → 用途別controller/markup/CSS/helpers。Forecastのprojection.tsが固定result envelopeの元recordsを画面データへ投影する。main.tsxは専用Leaflet stylesheetを先に読み、その後Reactをmountする。Viteはnpm Cesium、現役scene3d、Leaflet相対画像をdistへコピーする。CSSは用途rootへscopeした。旧 MapPanel/HistoryPanel/style.css、forecast/core340.js、scene3d/receipt-status.js は現Appの呼出しから外れているが削除せず保持。

## 修正判断の根拠

独立批評と実画面の反例から、二重state、削除した候補の非同期結果復活、UUID再利用、画面表示符号へのUUID露出、固定結果に草案気象境界が混ざること、比較群の複数固定気象境界、kernel default解決差による偽dirty、戻す操作が解決済みconfigを草案へ返す不整合を修正した。

原recordの不等間隔時刻・相境界・終端を保持し、停止を着地と呼ばず、未破裂を偽時刻で補わない。終端sliderは実終端へ届き、詳細は対象候補/比較群の時間域に限定する。風の欠測を0や人工値で埋めない。n=1で分位域を生成せず、50/90/95の既存コントロールは実n=1では理由付き非表示/無効。実n=1の図/3D/KMLは人工平均や模式AGLの説明を使わず、絶対ASL・原recordを表す。停止詳細も2D・グラフ・3Dへ渡す。

画面寿命ではglobal event/observer/timer/RAF、Plotly、Leaflet、persistent host listenerを解除。partial mount失敗も掃除する。背景OFFの同値textContent書込みをMutationObserverが自己観測して無限反復する実害を除いた。保存したmetric、group/region次ID、人工rN表示IDを復元し、新規作成との衝突を避けた。地理背景OFFの小図/保存metadataは未接続と明記した。real遅延作成は草案のみで計算しないことを画面に記した。

## 自動有限検査

最終 source で TypeScript (tsc -b) exit 0、Vite 8.2.0 build exit 0。

```
RUN v4.1.11
Test Files 3 passed (3)
Tests 24 passed (24)
Start at 2026-09-29 17:38:42 JST
Duration 787ms (transform 209ms, import 566ms, tests 204ms)
```

追加の5試験は screen-contracts.test.ts。元不等間隔record/欠測風/未破裂、submitted_inputとのdirty比較と未取得envelope、削除候補の遅延完了、停止recordの3D protocol/KML absolute ASL、日付付き季節adapterを試験した。さらに現場面/hoverの意味を対象とする2件を追加し、既存17試験と合わせ24件。npm auditは17:16の実行で全severity 0。開発専用Vitest4.1.10のmoderate advisoryを4.1.11へ限定更新した。依存件数113 (prod35/dev78、optional28を含む)。

## 実UIでこの担当が見たもの

API/static http://127.0.0.1:8461/。CUAで実ブラウザ操作。保存やAPIキー入力は行っていない。rootは別tabで実計算/保存を担当。

- 人工予報A/B/G1、候補・概要・経験50/90/95輪郭・停止印・色分けした経路が元の具体的レイアウトで描画された。
- BD8ek_nk: Aから3Dへ移り、2/2候補を受領。キー空、接続試行0。3D側でBを選択し、同じ2Dへ戻ったときB注目・帯・経路・整列した地図を保持。専用Leaflet stylesheetへの変更後、2D復帰のCSS崩れは観測しなかった。Google写真上の再検証ではない。
- 気象の年間4図と季節12月別プロファイルを画面として目視。季節図は共通軸・帯・前後半の色分けを保持。打上げ影響は9地点、矢印RMS幅のカラーバー、選択地点の50/90/95域と分母を保持。
- BD8ek_nk: 北東43.4097N/141.8422E・7月をS1に渡し、南西42.6903N/140.8578E・1月をS2へ追加。S1を消さず双方744標本。S1の「この候補の気象分析へ戻る」は北東7月、S2は南西1月へ戻ることを各々確認。ヘッダ用途往復と新しいhandoffは区別される。
- この操作で人工rNが再採番される反例を発見し修正。最終DJXESdH7ではS1/r1（北東7月）→S2/r2（南西1月）→S1/r1へ戻ることを実UIで確認。dev error logは0。数値と来歴も不変。
- root報告による実計算/保存/障害/気象4画面の受入は本担当の直接確認とは分け、root-review460へ集約する。

## 未確認・残る制約・次判断

- Google写真3Dへの接続、実写真面hover、課金/ネットワーク性能は今回再確認していない。既存接続を自動で作らず、APIキーを読まなかった。GSI背景も本担当では接続していない。
- 気象と季節は日付付き人工fixtureの操作確認で、過去気象DBの実接続、Monte Carloの科学的分散、禁止区域安全評価の完成ではない。実計算は保存GFS・各候補n=1。複数runを合わせて偽の分布にしない。
- 一枚のJS bundleは約6.786MB（gzip2.060MB）でVite大きさwarningあり。気象初回/再mount集計は観測2.2–3.4秒、CUA clickの3秒期限を超えることがあった。次snapshotで正常に応答したが、素早い用途往復の性能を受入済みとはしない。集計を入力署名でcacheし、必要ならworkerへ分けることと用途別遅延importが次の性能課題。
- 旧controllerは用途境界に隔離したが、内部は多数の旧関数を保つ大きな単位。具体的GUI継承を成立させた段階であり、今後入力/結果/図/sceneの責務を現役共通state契約へ沿って段階的に分割する必要がある。全無変更移植や将来構造完成を主張しない。
- Vite dev配信経路はsourceで用意したが、この担当の実画面有限受入はproduction buildをFastAPI static mountした8461で行った。devserverの独立起動受入とは区別する。
- PNG/SVG保存の意味/停止データ接続・unmountガード、KML出所はsource/有限試験で確認。全出力形式のブラウザdownload実物を今回全件目視したとはしない。


## 凍結source照合票

全71ファイル。node_modules/dist/.vite/tsbuildinfo以外のfrontend全実体（非現役の保持sourceも含む）。機械可読票 frontend-source-hashes460.json、実行結果票 frontend-verification-receipt460.json。後者は実際のtool出力を転記した票で、未保存だった生stdoutファイルと偽っていない。

| path | bytes | SHA256 |
|---|---:|---|
| frontend/index.html | 328 | 476fb3952261656e862cf86492a9323c107f46bf92a037bef735cc180f11b59c |
| frontend/package-lock.json | 57935 | 0cada56d14b5d380b45efd184cb0775df1bd1eea636179d53bc8ec3cc66684ac |
| frontend/package.json | 809 | baa2a4511393593f3ea0a19c78fd33d404ccc2ec2859a59cc4799cd366eb8534 |
| frontend/scene3d/fixtures/surface.glb | 3764 | 3311dbaf80d2fe6f8ea62c0c7fb560357880e021369688f4884c4225f3f31805 |
| frontend/scene3d/fixtures/tileset.json | 827 | 2d22e79d51cbc0c4319c877829ad68bec43c799b56a0964621776d9900d00819 |
| frontend/scene3d/index.html | 5007 | f8e12505bb0675755b135f31aea403e402f0461d4c42e9d68532be223c97415f |
| frontend/scene3d/src/band-readout.js | 4259 | 1d110c67ffd90dacbe73d58f3d6f767f55621e1ec5211e631baaecd79b5800fe |
| frontend/scene3d/src/camera-fit.js | 1450 | f9f7a71b93c891680ffe78c85dd9710e7c299c8975c672e2b014975c3950ed49 |
| frontend/scene3d/src/catalog.js | 4496 | 7a330aeb2b1446ee3b6142667e5f0e997b1aadbdce9411673eb772d8544da349 |
| frontend/scene3d/src/colors.js | 1420 | a5ff525de1d31a6eb11540b7f7f82768944928aea969ede971b15863c8c72101 |
| frontend/scene3d/src/fixture.js | 2451 | 14a4aa8e975224fb2ba286175b080e7f33387ae9691f12566728ae52b563d25f |
| frontend/scene3d/src/hover-controller.js | 3769 | 6bc46d66fc09bfcd04337b97a0c32e254a9da0abb19e6811a84966b4fd80b86a |
| frontend/scene3d/src/hover-labels.js | 3713 | 2ebbf8cf40d6149e332600957ac763d442e67caaa2035be5de5f6411c9d9da8e |
| frontend/scene3d/src/main.js | 29821 | 92814a0bf67a4537bb87c5f00bf903af157ccf1a1a0187370eb7a83217e4423a |
| frontend/scene3d/src/overlay-store.js | 1321 | 11a689eb6656043aba39ed77cface29e2b3156035b6b6e039318f3f5749bcd3d |
| frontend/scene3d/src/overlays.js | 2690 | 67dc8e8f5d9a674a94e61fae0f5d3c536cd93532afa92569716d55e6683656a1 |
| frontend/scene3d/src/protocol.js | 6664 | f0d87684edca9fac7a46e3c147f7cfd77345b89e7d2227c65e8e2e7717c9ee9f |
| frontend/scene3d/src/provider.js | 1465 | f6d80bdd90b0b95fdfe4f7cd22a0e6f673510ede74f3f6c31767d43a3c3d0ca2 |
| frontend/scene3d/src/receipt-status.js | 336 | f9512bf09b96c5d9c18cff3329f7565fd7c621caf33bebf50ea90e4901a77466 |
| frontend/scene3d/src/surface-pick.js | 1558 | 9432556b68fbe2d91d1ad6bc0a452de871e98d51fc2028f42735ae4fb74e600a |
| frontend/scene3d/src/surface-session.js | 2525 | f084411d93ea8864ae99c3e0b241f548866e74302443607fb30c4393d83955d2 |
| frontend/scene3d/src/view-memory.js | 1286 | bf46a92a7e0e738fc7b26021c098b291a3dd446f8ca2d08e057672c995aec6ac |
| frontend/scene3d/src/view-stability.js | 2004 | a8dd03a7b0ecf2f7afc5718df56cc90845de0dc1e0f82967d5d041b47ab12658 |
| frontend/scene3d/style.css | 4380 | e6276f940daf172581f0a9e8da6d8c120224e475d12aa5e6b06c9f57d38a4bdd |
| frontend/scene3d/THIRD_PARTY_NOTICES.txt | 67265 | 43cd084226dcfd5151989334f4a62183012ab3e14f6e2a8e60796558d1be3156 |
| frontend/SCREEN_PROVENANCE.md | 5216 | 31de95e59852ed542a5428b7abe5bc46108ac82a337af2e3c12f32dbd1187754 |
| frontend/src/api.ts | 2114 | a471c48acf791d151bd8a3222cc64660e0817ff6b522392265a53c000188fa8d |
| frontend/src/App.tsx | 10543 | 49d5f3e5668a7abe5ffa0505f309d97e9b33d37133886488c57be9097063dd25 |
| frontend/src/ConfigEditor.tsx | 8079 | 6779488a59024a7e07b6410a914579861521d39e034f4361818e7fbd0d9ed7e2 |
| frontend/src/domain.test.ts | 3321 | c96b6229138e1bc6d3d6411c1fae7deb19d8864ce121f205d16a5b75a559e833 |
| frontend/src/domain.ts | 9694 | 36452c6e1c10c93d1d7cd7c53a437e41f3248d854d0d1947b14064ce2a3a61ec |
| frontend/src/HistoryPanel.tsx | 8375 | 25cb7a954f668595bcbeaabb14a0b5a521f15401c0793a44e5db3e310df3c4e5 |
| frontend/src/main.tsx | 781 | 7dc6dc0fc15338dad65f73526ee69b178b40991fcb4c762a5e9d82b339b93889 |
| frontend/src/MapPanel.tsx | 7800 | 31ccdbeb8c9225640484496d764ff7fea46cf950bebddbfff6b1cbde383de5a0 |
| frontend/src/platform.css | 2060 | 4c5ddd0341935ad262021fa2434f9ffd85e3a32c9bf1e6842f2f421e3e050ed5 |
| frontend/src/screen-contracts.test.ts | 7498 | 8aae16533d4168a8542fa1880c946d023bfd2c38c96e43a1cee9a76637b7daca |
| frontend/src/screens/forecast/appearance390.js | 3426 | 6e7a275ba331d7fcab9621c7d325440bb74fa4eb94d22eaf1b69cd276b6dd0a8 |
| frontend/src/screens/forecast/controller.js | 122880 | 5cdd0c3e03bd6768636d305672ecb0347a8950a2566a0181937479b199baa99e |
| frontend/src/screens/forecast/core340.js | 6238 | b9e5417c556b9cf36fbb66e05942b5f3f169ccfc0b774e7e39cde44f0ba9e813 |
| frontend/src/screens/forecast/data.js | 1847561 | 6219c465187c7aeb90e51c1d9d230ecef07466e76a79910611af2aa2eeb3c04a |
| frontend/src/screens/forecast/export390.js | 6039 | fab98920b88d9a841c01d5eec9d660fb9a80dc22bef017bcfa540d68503777b7 |
| frontend/src/screens/forecast/hover-geometry400.mjs | 756 | 70157be56390c1c9cbf743e42e1b4ea39113ba423c9904a01bdc7a5dd32d9602 |
| frontend/src/screens/forecast/hover400.mjs | 3779 | b160235e160ab4ec9fc5011c328f195f59dbb350c2db622e9d97d6b5f0e2e427 |
| frontend/src/screens/forecast/map-style-guard401.js | 9020 | ca04d2952a739f967ecc15b922828a6142b2dd097eccaddd0df737ba338e8dff |
| frontend/src/screens/forecast/markup.html | 15782 | 26ad0ef4f613283ac1e855ef6f93eccafa6971a1a460269257fee30d15b10fd3 |
| frontend/src/screens/forecast/math.js | 5734 | 0db1f087330499b3a419b3a1ca35442b80569fcb0520a6b22bc7ad7772ee5255 |
| frontend/src/screens/forecast/projection.ts | 3618 | 0272e8ec22b096a5bfc6b7d3cfb4065f3fd639df3b0c9a2dee3c31fe87034852 |
| frontend/src/screens/forecast/runtime.ts | 1634 | a4f9e0183650e5b059c436a52347fe3d3d06ffab84f13c35eb412d7ce6a85226 |
| frontend/src/screens/forecast/scene-document.js | 5012 | a9da678a4f496aaaedef6c6eb9d2ef0a9f69ed1716ff9fb0a55cc322ad4299cb |
| frontend/src/screens/forecast/screen.css | 30627 | c7d0ce57b3ca5d7a52c41c704022258b853bb70adee905ed2599d4491d080560 |
| frontend/src/screens/forecast/season-adapter.js | 636 | aa226cf3de83de1611021f060520dd2261c0c0d309331adf8361ff60fc999c37 |
| frontend/src/screens/ForecastScreen.tsx | 7046 | 54a64d346d7ba24653bfc224ded42ebe6840b857cdd0f30d1036f44ad08548f5 |
| frontend/src/screens/lifecycle.ts | 3424 | 4ecd7637c42b89ad89d755cdea9df284d4aa233c29cda857bc49f4a8199ba5c4 |
| frontend/src/screens/shared/band-readout.mjs | 4259 | 1d110c67ffd90dacbe73d58f3d6f767f55621e1ec5211e631baaecd79b5800fe |
| frontend/src/screens/shared/hover-labels.mjs | 3714 | 1222e0ca8347259ab8a613a170764573e47f8a16b611610d25199d72d4d7f59c |
| frontend/src/screens/shared/scene-style.js | 3034 | 53e7dcd64857c55e25ef40e695b8098b8d53f6ce04b50853ff574b7fbb2aaeef |
| frontend/src/screens/vendor.d.ts | 80 | a7a7788ee3041096b3616269970e1fe07c9f45a9385c83d6218273b4bb83b70a |
| frontend/src/screens/weather/controller.js | 46858 | 767e0c855d7f12b8cd837d3da2afbc4a7bbf90bd2abe53bfceda263d65c250e0 |
| frontend/src/screens/weather/direction-key.js | 2859 | 1ceda5de551cbc0c9f8afd9e31d9ee20058108022ffbec1d2b109e80ab7af732 |
| frontend/src/screens/weather/fixture.js | 9940 | 215a94c30db67ee1c166a8649f67b05e677693e7ed5012a9d7155e31eafdac5b |
| frontend/src/screens/weather/impact-map.js | 13451 | 2cff31810b167237554f62636cb0211c87339d37058dce4a5656206b83d7ab40 |
| frontend/src/screens/weather/markup.html | 12372 | d68dfe49a4a3badf584cae2254e77aaacb2b08572f5370c6fba96fc8a870c0a8 |
| frontend/src/screens/weather/runtime.ts | 1163 | 3be5c37814d1066255ecdfb3df8a20c3ab7a305227d4341dc8c5db1cdaad2631 |
| frontend/src/screens/weather/screen.css | 15708 | 544f60afde3d483e234c96d64f787ed92e4a48e40b989d83b3ade59090ef0130 |
| frontend/src/screens/WeatherScreen.tsx | 1159 | e0cbe42b8abc115324ba9fd018e78d2e18a315d32aaa8756cbfe01804983755c |
| frontend/src/style.css | 7840 | 756ebc58dbc3588519839bc705ba6be04aea65d0bdaa8e5386aa8c4037c626c9 |
| frontend/src/useWorkspace.ts | 10424 | 66afc5fb3192431824095642114c0dd81867efee8eefe996c886ca7bb745da77 |
| frontend/src/workspaceState.test.ts | 7836 | 058b194544217e848594440458fc8322c76c5e91861913dc9f4b0a473c28bb1e |
| frontend/src/workspaceState.ts | 5407 | 3f217501801fbe25d6912da918e413ac34c65e852f99f0cbd063986e96fc512b |
| frontend/tsconfig.json | 561 | c9aaee41e2f6ff5e4c63337b35e7836b7de220bc70b2eebcbda2a79fa6551275 |
| frontend/vite.config.ts | 1411 | 80e49c605003213305fb80bfd7b8f6f03ef47669f906533f319be6ab6e7d3eb1 |

## 機能照合を受けた補修

34行の gui-feature-matrix460.md / .json で旧機能・現役入口・未接続・実UI未検証を照合した。漏れは人工候補JSON読込の到達不能と、外部CSSとは別に必要なinline地図故障封じ込めの2件で、root合意後に修復した。real削除の即時undo誤約束も訂正した。新規sourceは増やさず、markup/controller/既存screen契約試験/SCREEN_PROVENANCEの4ファイルを変更。source manifestは71件。

本担当再開後はCUAインベントリが空のため新たな実画面操作を実施できず、rootの別人工tabでの干渉28/60、4点多角形20/60、風2図、End125飛行中0を報告証拠としてmatrixへ反映した。summaryHitsは準備欄を閉じて再確認すると詳細28/60へ直接遷移したというrootの訂正も含む。写真hover/JSON実取込/故障注入等の残検証を省略して完了扱いにはしない。
