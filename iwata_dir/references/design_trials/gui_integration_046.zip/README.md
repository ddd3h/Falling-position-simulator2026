# 0.46 concrete GUI integration evidence

Basis: PR30/0.45 C2 ce6a29accfad6865beca0b2dfe4f414e2bafb81a; adopted main M420.

The working GUI reuses 0.40.1 r2 concrete screen source. Current code is tracked under frontend/backend, original screen ZIP remains unchanged. This archive preserves independent criticism, root real UI observations, limited API/frontend tests, document generation, and fixed real run artifacts.

Status: finite UI acceptance evidence after authorized real and artificial Google photographic 3D connections, before final repository checks/Git save. Actual mouse face-interior/overlap hover is explicitly user-reported. Root inspected visible photos, toggles, band readout and 2D return. No key was read. The isolated CSS browser probe simulates transport and is not a full HTTP/app failure test. Later Git results belong to S35.

Read root-review460.md then screens-implementation460.md and round3/4/5 reviews. A successful pure test is not a browser or scientific acceptance. The intermediate stopped SVG still has the too-wide global time range; the final UI correction limits it to the selected run. Failed attempts and the extra unchanged-input run are retained. No API key, dependency runtime, or SQLite file is included.
