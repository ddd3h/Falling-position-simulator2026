from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(__file__).resolve().parent
S=P/('plan-build-'+sys.argv[1])
assert not S.exists()
(S/'docs').mkdir(parents=True)
(S/'tools').mkdir()
names=['docs/PROJECT_PLAN.md','tools/template.tex','tools/build_docs.py']
for name in names:shutil.copyfile(R/name,S/name)
env=os.environ.copy()
base=Path(r'C:/Users/genia/.local/share/balloon-docs')
env['PATH']=str(base/'pandoc-3.11')+';'+str(base/'TinyTeX/bin/windows')+';'+env['PATH']
env['FONTCONFIG_FILE']=str(base/'fonts.conf')
env['PYTHONUTF8']='1'
env.update(LC_ALL='C',LC_CTYPE='C',LANG='C')
diagnostics=[]
for command in [['pandoc','--version'],['xelatex','--version'],['fc-match','Noto Sans CJK JP'],['fc-match','Noto Sans Mono CJK JP']]:
    command[0]=shutil.which(command[0],path=env['PATH'])
    assert command[0], 'Missing configured runtime executable'
    check=subprocess.run(command,env=env,capture_output=True)
    assert check.returncode==0
    diagnostics.append({'command':command,'stdout':check.stdout.decode('utf-8','replace')})
(S/'diagnostics.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf-8')
assert 'NotoSansCJKjp-Regular.otf' in diagnostics[2]['stdout']
assert 'NotoSansMonoCJKjp-Regular.otf' in diagnostics[3]['stdout']
command=[sys.executable,'-B',str(S/'tools/build_docs.py'),str(S)]
run=subprocess.run(command,env=env,cwd=S,capture_output=True,timeout=550)
(S/'build.stdout').write_bytes(run.stdout)
(S/'build.stderr').write_bytes(run.stderr)
assert run.returncode==0,'Build failed; inspect retained stdout/stderr'
assert b'REVIEW:' not in run.stdout,'Inspect layout warnings'
renderer=r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
render=subprocess.run([renderer,'-r','80','-png',str(S/'docs/PROJECT_PLAN.pdf'),str(S/'page')],capture_output=True,timeout=180)
(S/'render.stderr').write_bytes(render.stderr)
assert render.returncode==0
from pypdf import PdfReader
pdf=PdfReader(S/'docs/PROJECT_PLAN.pdf')
assert len(list(S.glob('page-*.png')))==len(pdf.pages)
for name in names:assert (R/name).read_bytes()==(S/name).read_bytes()
out={name:hashlib.sha256((S/name).read_bytes()).hexdigest() for name in names+['docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf']}
receipt={'schema':'balloon.plan-generation/1','source_copy':str(S),'command':command,'hashes':out,'pages':len(pdf.pages),'build_exit':run.returncode,'render_exit':render.returncode,'pending':'all-page visual review then publication'}
(S/'verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
