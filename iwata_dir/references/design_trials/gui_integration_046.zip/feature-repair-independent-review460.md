# 0.46 TiNcwLt2: two inherited-function repairs

Read-only independent review. Repo sources were not changed. This review concerns the source manifest captured at 2026-09-29T17:44:16+09:00; it is not whole-product approval.

## Result available now

The two omissions are repaired in the active path. Compared with the before-feature-repair manifest, only these four files differ: `frontend/SCREEN_PROVENANCE.md`, `frontend/src/screen-contracts.test.ts`, `frontend/src/screens/forecast/controller.js`, `frontend/src/screens/forecast/markup.html`. All 71 current source hashes match that manifest. `probe-feature-repair460.json` records 85 assertions, **71 of which are file hashes**, not 85 behavioral tests.

### Artificial candidate JSON

- `markup.html:14` places `openLibrary` in candidate management. `controller.js:208` attaches the existing loader to it and hides the entry in real mode. The dialog explicitly distinguishes the legacy artificial candidate format from API projects and fixed real results.
- The actual handler, condition validation, cache/result constructor and candidate constructor were executed in a minimal no-network Node context. Valid fixture JSON added C3 and preserved the supplied artificial conditions. Real-project input, unknown format, `artificial:false`, invalid conditions and invalid JSON were rejected without adding a candidate. A file completion after disposal also added nothing.
- Root separately reported an actual UI import reaching C3/r1 and matching conditions/landing. This report does not independently claim that observation or full chooser/seasonal numeric verification.

### Real deletion text

- `controller.js:108,110` continues to forward real removal to the bridge and now explicitly says that immediate undo is unconnected. Artificial removal still uses the local undo path. The repaired text therefore no longer promises a real operation it cannot perform.
- No new restoration API or deletion acceptance claim is implied. Root's candidate/run lifecycle checks remain the corresponding operational evidence.

### Inline map containment

- `markup.html:1–9` restores the original r2 inline guard. Removing the `.forecast-screen` scope prefix and whitespace yields exactly the same CSS rules as the archived r2 `forecast/index.html`. `ForecastScreen` supplies this ancestor; `runtime.ts` inserts this markup before mounting the controller.
- The clip rule excludes `data-map-style-probe`, but the pane/control invisibility rule does not. This matches `map-style-guard401.js`'s synchronous `computedReady`: it temporarily removes only emergency clipping from the measurement, keeps panes hidden, checks actual map overflow, and restores the marker before an asynchronous continuation. Thus the emergency repair does not itself provide evidence that Leaflet CSS is valid.
- `controller.js:260,267–268,272` connects the guard on initial mounting and 3D return; hover reads require readiness. The standalone guard also checks persisted pageshow. This is not continuous detection of arbitrary CSS mutation at every moment.
- Retry verifies the replacement with the old sheet disabled, restores the **latest** captured view, then commits the new link. Failure rolls back and leaves the notice/hidden panes in place. Retry URL is restricted to a pinned same-origin local Leaflet path. No provider request is introduced by this guard.

## Real computed-style probe: root observation read back

`map-guard-probe460.html` embeds the exact current inline/app/Leaflet CSS and guard implementation in a minimal real DOM. CSP permits inline script/style only, denying images, connections, frames and other resource types. No actual link href/src is assigned: stylesheet transport and load/error events are simulated using EventTarget and local style nodes, in the real vendor-before-app cascade order.

The actual guard mount and browser `getComputedStyle` exercise: initial containment; healthy ready state; absent vendor CSS and failed automatic retry; no retry loop; real map overflow damage concealed by emergency clipping; synchronous probe-marker restoration; latest-view restoration after successful replacement; rejection of two partial stylesheets that would only work together; and manual recovery. Dimensions and unrelated visible content are observed too.

Root copied the final harness to local port 8463, opened it in an isolated inspection tab and captured `#result`. This reviewer read back the complete checks, observations, source hashes and limitations in `map-guard-browser460.json`: **17/17 PASS**. The evidence SHA256 is `f48d6644cd1523ec18c21cf3db19d27bac0e2ca26affa6a12336f981fe3eccc9`. This is root's browser observation independently read back, not a second browser run by this reviewer. Manifest: `map-guard-probe460-manifest.json`. Tested HTML SHA256: `a7530c2acb697bbb93df0534e35bece94b5019763b22dd4c7b4bb15ba416ff88`.

In the failure states the actual computed pane/control visibility was `hidden`, map overflow remained `hidden`, the notice was `grid`, map dimensions stayed 640×320 and unrelated content remained visible. During the overflow fault's synchronous readiness probe, the underlying map overflow was measured as `visible` while panes stayed hidden; the temporary marker was subsequently absent. After success, panes/controls were visible and the notice was absent. The test also rejected the complementary partial stylesheet replacement and recovered through a later full replacement.

This PASS proves neither real HTTP stylesheet delivery nor the application's complete 3D→2D cycle. Those remain separate root observations. The fixture probe does not call Google or touch the connected tabs. Within the requested two repairs and deletion-text correction, this bounded review found no remaining source blocker and requests no further source change.
