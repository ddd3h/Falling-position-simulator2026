# 第3巡：0.46 統合コードの独立批評（修正前観測）

2026-09-29。基準はPR30 C2、対象はその後の編集中frontend。読取りのみ、実ブラウザは未操作。screens460/rootへ各発見を直接送付済み。指摘後に並行修正され得るため、下記行番号はこの巡の読取り位置。修正済みとは扱わない。

## 全体評価

0.40.1の用途別DOM/CSS・候補/延期/共有地図・詳細・気象4画面を具体素材にする方向へ戻った。実候補の正本をuseWorkspaceへ置くcallback境界、人工用途の別namespaceもコードに現れた。一方、旧人工表示の関数を実データへ接続した結果、入力差・時間・来歴・保存復元の意味を誤る箇所が残る。画面が戻ったことだけで本移行は受け入れられない。

## 実害がある指摘

### 1. 実モデル差が「相違なし」になる（P1）

`forecast/controller.js:167–179` conditionSummary は旧人工条件のmodel名/質量/径/日時等を列挙し、realConfigの上昇率、破裂高度、下降係数を見ない。上昇率5対6 m/s、その他同一の比較を `P460/probe-comparison460.cjs` で現実装関数から実行し、different=[] を再現した。主要なモデル比較の判断を誤らせる。実modeは固定resultの全入力差を意味あるラベル/単位付きで読める必要がある。

同時にprojection.conditionsがpayload_mass_kg未設定を0へ変換し、質量入力不要の定速モデルを「0.0 kg」と説明していた。未設定/未使用を0へ置換しない。

### 2. 候補IDの再利用で旧結果が別候補へ混入する（P1）

`App.tsx:16` newId は現在候補にない最小C番号を選ぶ。計算中C1削除→新しいC1作成→旧C1の完了で、workspaceReducerの「candidateが現在存在する」というguardは通る。UUID等の非再利用IDか、保存run/削除履歴を含めた永続counterが必要。ラベルは短い連番でもよいが識別子と分ける。

### 3. 保存計画の再読込が人工/気象/季節画面へ反映されない（P1）

WeatherScreenのmount effectはbackgroundのみ、ForecastScreen人工restoreはmodeのみが依存。画面表示中に保存reloadしてもcontrollerは未保存の状態を維持し、次操作で読戻した保存状態へ古いviewを再送する。loadGeneration等の明示復元トークンを使い、通常onView echoと外部再読込を区別する必要。

App.proposalの古いhandoffが `p.proposal || p.saved.seasonSource` で保存元来歴より優先される経路もある。

### 4. 固定結果の支持境界が草案の別気象へ変わる（P1）

ForecastScreen.bounds/weatherTextは候補の現在weather_source_idを参照する。旧実結果を保ったまま草案の場を変更すると、結果とは別場の範囲/有効時刻を地図に表示する。表示結果の固定weather_snapshotと草案の取得予定を区別する必要。

### 5. 実履歴の保存物・3D/KMLの由来が人工のまま（P1）

controller.saveGraphは実modeでも「人工標本の操作模型」「人工場・人工履歴」「balloon-037」を書く。scene-documentは実routeに「相別進行率を揃えた平均形状。実時間の一飛行ではない。」を付ける。さらにrelativeToGround前提を実高度の定義へ無条件転用する。実入力/原結果/表示上の内挿の区別をsnapshotに持ち、そこから図・KML・3Dを一貫して説明する必要。

### 6. 延期子が正しく計算されても「変更前」のまま（P2）

controller.draftForは実modeでも親draftからshiftLaunch(date/timeだけ)を作り、realConfig内のUTC時刻を更新しない。cacheKeyはrealConfigを使うため子結果と一致しない。実modeではReactで解決済のt.draftをそのまま使うべきで、controllerに再解決責務を残さない。

### 7. 原イベント・停止結果が表示/保存から落ちる（P1/P2）

- timeSliderはmax=125固定。長い実飛行の後半を選べない。
- projection.sampleは1分gridへ投影し、historyTracesは整数分かつtime<durationのみ描く。分内破裂や最終着地/停止の原時刻・高度を落とす。
- graphSnapshotはlandedのみを選ぶため、停止詳細を画面で修復しても保存図は空になる。
- 詳細drawMapもlandedのみから経路を作る分岐が残る。
- 欠測windをNumber(null)=0/Math.hypot(null,null)=0へ変える経路がある。停止後を着地済みと表す定型句も再評価が必要。

## 次巡で確認すること

上記の修正をコードで再読し、特に「候補ID非再利用」「保存reloadの復元」「実モデル差表示」「表示中結果の気象支持」「図保存の由来」を優先して反証する。全図の視覚品質・Google実写真・科学的妥当性は本読解で受け入れたことにしない。

## 修正の途中確認（第4巡、同日）

コード追読で以下の修正を確認：IDはUUID非再利用、実mode draftForは投影済草案を保持、reloadのrestoration tokenで各画面を再mount、古いproposal stateは撤去、表示場は固定weather_snapshot参照、実履歴は原recordsを保持しhistoryAt/realHistoryTracesへ分岐。質量未設定を0とする変換も撤去された。

`probe-comparison460-round4.cjs` で再実行し、上昇率5/6 m/sは差分表へ出るようになった。一方、同一configでweatherIdだけgfs-A/gfs-Bとした例はdifferent=[]のまま。この反例をscreens460へ送った。

追加した反例：
- UUIDを旧t.id表示へ直接流すと、候補タブや親子系列が36文字の内部IDで圧迫される。識別子と人間向け符号/名称を分ける必要。
- stopped-before-burstなのにprojectionがburst=last.elapsed_sを補い、associationが破裂時刻/着地までと呼ぶ。未発生イベントはnull/未定義とし停止理由を別に読むべき。
- 図保存の主タイトルは実modeへ分岐したが、10–90分位という旧注釈、scene/KMLの人工平均経路・相対高度の定義は一括でなく出力ごとの確認が必要。

この節も途中観測である。実UI・図保存・保存後復元の受入を完了扱いにしない。
