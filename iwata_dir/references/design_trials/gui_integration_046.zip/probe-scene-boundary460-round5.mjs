import {pathToFileURL} from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
const load=async p=>import(pathToFileURL(path.resolve(p)));
const scope={window:{},document:{}};
for(const file of ['frontend/src/screens/shared/scene-style.js','frontend/src/screens/forecast/scene-document.js','frontend/src/screens/forecast/export390.js'])(await load(file)).install(scope);
const {validatePayload}=await load('frontend/scene3d/src/protocol.js');
const t={candidateId:'C1',resultId:'R1',parentId:null,delayMinutes:0,label:'停止した記録',available:true,visible:true,focused:true,color:'#006f8b'};
const sample={id:'trial1',status:'stopped',lat:33.9,lon:135.3};
const supports=[{label:'保存場A',ring:[[135,33],[136,33],[136,34],[135,34]]},{label:'保存場B',ring:[[140,42],[142,42],[142,44],[140,44]]}];
const logs=[];
for(const selected of [true,false]){
 const context={kind:'detail',activeCandidateId:'C1',selection:{sampleIds:selected?['trial1']:[],count:selected?1:0,denominator:1},contours:'none'};
 const input={real:true,context,cases:[{catalog:t,classification:{hits:[],hitDetails:{}},landed:[],samples:[sample],ellipses:[],origin:[33.8,135.2],routes:selected?[{phase:'up',color:'#1472b9',points:[[33.8,135.2],[33.9,135.3]],heights:[.05,1.2]}]:[]}],bands:[],showHits:true,zones:[],supports,supportDefinition:'固定保存場の支持'};
 const doc=scope.window.BJP_SCENE_DOCUMENT.build(input);
 const payload={...doc,artificial:false,snapshotId:'probe-'+selected,collectionKey:'probe',context,geojson:{type:'FeatureCollection',features:doc.features},camera:{center:[135.2,33.8],bounds:[135,33,142,44]}};
 validatePayload(payload);
 const full=scope.window.BJP_SCENE_DOCUMENT.build(input,{allObjects:true});
 const kml=scope.window.BJP_EXPORT.output({...full,title:'保存GFS n=1',description:'保存された実記録'});
 const observed={selected,protocolAccepted:true,stops:doc.features.filter(f=>f.properties.kind==='stop').length,supportLabels:doc.features.filter(f=>f.properties.kind==='support-boundary').map(f=>f.properties.label),absoluteKML:kml.includes('<altitudeMode>absolute</altitudeMode>'),incorrectAGL:kml.includes('模式AGL'),incorrectArtificial:kml.includes('人工の操作模型'),falseContours:kml.includes('輪郭は50%')};
 if(observed.stops!==(selected?1:0)||observed.incorrectAGL||observed.incorrectArtificial||observed.falseContours)throw Error('unexpected '+JSON.stringify(observed));
 logs.push(observed);
}
console.log(JSON.stringify(logs,null,2));
fs.writeFileSync('C:/Users/genia/AppData/Local/Temp/balloon-gui-460/probe-scene-boundary460-round5.json',JSON.stringify(logs,null,2));
