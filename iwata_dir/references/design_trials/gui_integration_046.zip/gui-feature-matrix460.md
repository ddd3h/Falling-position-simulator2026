# 0.40.1 r2 → 0.46 機能照合表

比較原本: references/design_trials/hover_surface_pick_correction_0401.zip（SHA8356df3cc8f2184d5418fe3d84d1e1d274b7646f3b81be6210c07094b3d7a214）内 workflow-ui-0401。現役: frontend/**（修復build index-TiNcwLt2.js）。2026-09-29 screens460再開調査。

「移植済」は処理/DOM/依存が現役呼出へ接続しているというsource照合の結果で、「この版で全操作の実画面確認が終わった」と同義ではない。下表では意図的未接続と実UI未検証を別に書く。既存人工データの統計図/面/hoverを今回移植することと、実気象のMC・安全性を完成させることを区別する。

**確定した漏れ2件を修復**: F15 人工候補JSONの読込入口、F20 2D復旧guardのinline CSS。root合意により同じbuildへ集約した。X02のreal削除dialogは固定結果を保持し、即時取消は未接続だと明示した。人工undoは維持する。24有限試験pass、実写真hover/JSON実読込等の実UI受入は下表の未検証と区別する。

**3D接続寿命**: 同じForecast内の2D/3D往復はiframe保持。real↔人工・季節/気象への用途移動・計画reloadはkey/effect cleanupによりiframeを破棄する。接続済tab2で切り替えない。rootは別人工tabを用意。今回rendererをshell寿命へ移す変更はしない。

**今回のツール制約**: 再開後のこのsubagent CUAは旧browserId1が利用不可、cua.getState()はapps/browsers空。接続tabへ触れずsource調査を継続した。本表の実UI観測は前担当ターンで行ったBD8/DJXEの結果と明示したroot報告に限る。新しい実操作を行えたとは記載していない。

機械的補助: gui-feature-dom-functions460.json はforecast旧182IDのうち専用linkへ意図的移動したleafletStyle以外を保持（初回欠落したmapDisplayGuardStyleは復元）、weather63/63ID保持、旧app全named functionを現controllerが保持することを示す。scene3dの17JS実体は全て存在、14は元byte同一。catalog/main/protocolだけ実n1接続の変更。gui-feature-scene-files460.json。これらの数合わせは意味/操作の完全性の証明ではない。

| ID | 旧模型の機能 | 現役の状態 | 変更・未接続の境界 | 検査証拠/未検証 |
|---|---|---|---|---|
| F01 | 50/90/95%輪郭と注目候補の輪郭間面 | 移植済 | 人工fixtureと季節で描画。real n=1では標本不足を明示し生成しない（意図的未接続） | BD8/DJXEで面・輪郭・候補切替を目視。現モジュールの3分位面と重なりhoverを2追加試験で確認。実MCの分散ではない |
| F02 | 複数候補・色・表示/非表示・候補複製 | 移植済 | realはReactが候補所有、人工はcontroller所有。表示符号とUUIDを分離 | 人工A/B・3D側B選択→2D共有を実UI確認。全menu分岐は未検証 |
| F03 | 遅延列・親子従属・時差順rail・表示/追従 | 移植済 | realは草案作成後に明示計算、人工は旧再計算。設定された候補間の時間内挿を実装するものではない | rootが親+30/60分の実候補継承を確認。人工全時差/独立化/解除は未検証 |
| F04 | 比較群の作成/所属変更/重ね履歴/帯の切替 | 移植済 | 結果を混ぜず重ねる。realは固定configと固定weatherの差を表示 | root実4候補比較、前担当G1表示。人工群編集/凡例全分岐は未検証 |
| F05 | GeoJSON/KML複数入力・穴/MultiPolygon・読込失敗 | 移植済 | ローカルPolygonのみ。NetworkLink/非zero高度/巨大入力等を拒否 | source照合。今回ブラウザで実ファイルchooserからの取込は未検証 |
| F06 | 禁止域セット名/個別レベル/色/表示/削除/セット出力 | 移植済 | 非表示でも判定対象、施設名とレベルを保持 | rootが人工領域追加/ID復元を検査中。個別編集/出力の全形式は未検証 |
| F07 | 禁止域との点干渉・全着地/干渉/非干渉/停止数 | 移植済 | 着地点と領域の包含だけ。停止を非干渉に数えない。実n1でも同じ有限包含 | rootのDJXE人工UI: 領域2件、A干渉28/60=46.7%、停止4を実表示。実運用安全判定・経路交差は未接続 |
| F08 | 干渉群の詳細・特徴と全体の比較 | 移植済 | 詳細の選択IDを干渉群に切替。因果の確証ではなく標本の条件差 | rootのDJXE人工UI: 準備欄を閉じた概要の28干渉ボタンから詳細28/60へ直接遷移を確認。初回の準備欄解釈は訂正 |
| F09 | 2D面・輪郭・禁止領域の名称hover/重なり上限 | 移植済 | pointermove/260ms静止。表示した面/線のみ。最大2対象+他件数 | 現2D/3D共通意味の単位試験で面内candidate+region、重なり重複抑制、非表示除外を確認。実カーソルhoverは今回root検査待ち |
| F10 | 3D面・輪郭・禁止領域hover/重複しない名称 | 移植済 | 写真表面を再描画後にpickするr2 barrierを保持。接続は手動のみ | 旧写真hover受入は過去証拠。今回写真3Dはrootが別人工tabで検証予定 |
| F11 | 詳細で全選択/一点/多角形/干渉・非干渉選択 | 移植済 | 人工は着地群、real全記録は停止も含む。多角形の着地点選択は旧仕様通り | rootのDJXE人工UI: 全60→干渉28、多角形4点で20/60へ選択し履歴線/帯が更新。一点選択は未検証。real停止全記録はroot確認 |
| F12 | 高度/累積移動/東北変位/水平・鉛直速度履歴 | 移植済 | 人工平均+10–90%帯。real元record・相別線・不等間隔・終端を保持 | root実高度/鉛直/比較、人工多角形選択20/60の東北変位線/帯を目視。人工全縦軸の表示は未検証 |
| F13 | 時刻slider・位置・風速頻度/風配・終了除外 | 移植済 | realの記録風がない所は欠測。人工風の補完をしない。detail対象のduration | root実終端飛行中0、DJXE人工風2図・時刻60→End125で飛行中0を確認。全状態は未検証 |
| F14 | 履歴/風速/風配PNG・SVG図保存 | 移植済 | 固定snapshotから出力。real説明はn1/元record、人工説明は平均・分位帯 | exportコード/固定snapshot構造を確認。今回6形式download実物の目視は未検証 |
| F15 | 候補人工JSONの保存と再読込 | 漏れを修復 | 人工候補管理に旧JSON読込dialogへの入口を復元。API正本計画/固定実結果とは別物であると明記。realでは非表示 | TiNcwLt2へ修復build済。source/tsc/build確認。実ファイルchooserからの読込はroot検査待ち |
| F16 | 分析地図KML：輪郭/面/軌道/投影幕/領域/表示状態 | 移植済 | 人工相平均/AGL定義保持、real元record/absoluteASL。KMLは表示資料 | 停止realKML unit test。全人工表示枝・他viewer読戻しは未検証 |
| F17 | 地図の高さ：画面自動/drag/上下/Home | 移植済 | 手動240–1800px、視点を保持してinvalidateSize | 前担当自動高さと2D復帰の目視。drag/keyboard全操作は未検証 |
| F18 | 放球地点：座標/地図仮点/確定/取消/drag分離 | 移植済 | realはReact configへ反映、人工は旧draft。移動dragと明示指定モードを分離 | 季節9地点/座標選択と引継ぎ確認。予報任意地図clickは今回未検証 |
| F19 | 背景地図/写真・出典・失敗・再読込み | 移植済・初期接続変更 | 既定は未接続で、明示選択後のみGSIへ要求。旧常時要求を避ける変更 | 背景未接続の描画を確認。GSI接続の実表示はroot検査例許可内だけ |
| F20 | Leaflet CSS破損の封じ込め/再読込/復帰 | 漏れを修復 | head由来inline CSSをforecast-rootへscopeしmarkupへ復元。pane封じ込め・notice・retryを外部CSS欠落時も保持 | TiNcwLt2へ修復build済。正常2D復帰は前版で確認、CSS故障注入の実UI検査は未検証 |
| F21 | 同一画面の2D↔3D・注目/表示共有・接続保持 | 移植済 | 同じForecast instance内iframeを保持。データmode/用途/計画reloadはunmountする | 人工未接続A→B3D選択→2Dを実UI。写真接続はroot担当。mode切替で接続保持しないことを優先通知 |
| F22 | 3D視点：移動/回転/zoom/範囲/保存/復帰 | 移植済 | Google接続前は視点保存無効、キーは保存しない | 原module byte確認。今回写真操作・視点復元はroot待ち |
| F23 | 3D点/輪郭/面/禁止域切替・クリック帯読取 | 移植済 | 人工50/90/95面の分類と実表面pick。realn1には分位面なし | 2追加試験で3分位面/輪郭リングと2D/3Dの面内・重なり・非表示意味を確認。実写真toggle/読取はroot待ち |
| W01 | 共通年月範囲・JST時刻マスク・件数・再集計 | 移植済 | 人工2020–2025の暦日標本。実過去気象DB・一般地域取得は未接続 | 初期集計を目視。年月/時刻全組合せは未検証 |
| W02 | 年間高度構造4図・四分期/半月・共通尺度 | 移植済 | 平均風速/来向/定常度/地点幅、欠測/低R凡例を保持 | rootと前担当が4図配置/凡例を実表示確認。入力切替全件は未検証 |
| W03 | 月別高度プロファイル12枚/半月中央値/分位帯 | 移植済 | 灰p10–p90、前後半色・共通軸。実気象ではない | 前担当/Rootが12枚を目視 |
| W04 | 風配：元格子点・圧力/概算高度・月/半月/季節 | 移植済 | 16来向×速度階級、静穏分母、共通半径尺度・ページング | source照合。風配図の地点dialog/全grain実操作は未検証 |
| W05 | 地域差：平均風/定常度・高度・尺度・共通凡例 | 移植済 | 地理背景未接続時にも色/矢印/凡例を描画、背景未接続表示へ訂正 | rootが地域12図と凡例を実表示確認 |
| W06 | 打上げ影響：N地点密度/任意地点/季節/分位域 | 移植済 | 平均到達矢印RMS色、選択点50/90/95%、Nは人工気象格子密度と別 | 前担当NE/SW各地点と7月/1月、744標本を実UI確認 |
| W07 | 標本軌道群/平均経路の重ね表示 | 移植済 | 人工履歴を地表へ描画、施設との交差判定は未接続 | source照合。全標本線toggle描画は今回未検証 |
| W08 | 季節計画handoff/複数提案/候補別の元画面復帰 | 移植済・共通基盤接続変更 | 旧URL別画面から同一projectの用途slotへ。新提案は既存候補保持して追加 | BD8/DJXE NE7月/SW1月の2候補と各復帰、r1/r2不変を実確認 |
| W09 | 気象各図を単独SVG保存（条件・図・背景・凡例） | 移植済 | 背景OFFなら背景画像なしとmetadataへ記載。接続時は表示範囲を埋込取得 | source照合。4用途+風配派生のdownload実物は今回未検証 |
| X01 | 保存計画のreloadと各用途状態・結果復元 | 接続改修 | 実計画APIと人工candidateJSONを別入口にする。旧画面の見た目を置換する目的ではない | root実metric/time/run/障害再試行、前担当用途往復確認 |
| X02 | 候補削除/解除/取消・元に戻す | 移植済（一部real接点未接続） | 人工の直後undoを保持。realは草案から外して固定runを保持、即時取消は未接続とdialogへ明示。新しいrealundoAPIは今回追加しない | 接点の誤約束をTiNcwLt2で訂正。人工undo/real削除後復帰の実操作は未検証 |

## source 対応

| ID | 原本の根拠 | 現役の根拠（frontend/src/screens基点。ただしscene3dはfrontend基点） |
|---|---|---|
| F01 | forecast/app.js drawMap; shared/scene-style.js bands | forecast/controller.js drawMap; shared/scene-style.js |
| F02 | forecast/app.js renderPrimaryCandidates, caseMenu, appearance390.js | forecast/controller.js 同名関数; appearance390.js; App action |
| F03 | forecast/app.js renderDelays,applyDelays,renderFamilyComparison | forecast/controller.js 同名; App resolved/delays |
| F04 | forecast/app.js startGroup,historyFigure,conditionSummary | forecast/controller.js 同名; group ui_state |
| F05 | forecast/app.js zoneFile; core340.js parseKML | forecast/controller.js zoneFile/parseKML; math.js |
| F06 | forecast/app.js renderLayers,layerMenu,saveZones; appearance390.js | forecast/controller.js 同名; appearance390.js |
| F07 | forecast/app.js classification,summaries,drawMap | forecast/controller.js 同名; shared scene-style.classify |
| F08 | forecast/app.js summaryHits,selectHits,association | forecast/controller.js 同名 |
| F09 | forecast/hover400.mjs,hover-geometry400; shared/hover-labels | forecast/hover400.mjs と shared同関数 |
| F10 | scene3d/src/hover-controller,hover-labels,surface-pick,surface-session | scene3d/src 同名17実体中14が元byte同一 |
| F11 | forecast/app.js openDetail,startPolygon,selectAll | forecast/controller.js 同名 |
| F12 | forecast/app.js historyTraces/historyFigure | forecast/controller.js historyTraces/realHistoryTraces |
| F13 | forecast/app.js drawPositions,windStatistics,renderWind | forecast/controller.js 同名+historyAt |
| F14 | forecast/app.js graphSnapshot/saveGraph | forecast/controller.js graphSnapshot/saveGraph |
| F15 | forecast/app.js saveCandidate/openLibrary/loadFile | forecast/controller.js 同名; markup library |
| F16 | forecast/scene-document.js,export390.js; app saveOverviewKML | forecast/scene-document.js,export390.js/controller |
| F17 | forecast/app.js sizeComparisonMap,mapResizeHandle | forecast/controller.js 同名; ui_state.mapHeight |
| F18 | forecast/app.js setLocation,confirmLocation,map click | forecast/controller.js 同名; ConfigEditor bridge |
| F19 | forecast/app.js baseLayer; weather impact-map | forecast/controller.js baseLayer; weather impact-map |
| F20 | forecast/index.html mapDisplayGuardStyle; map-style-guard401.js | main.tsx leafletStyle; forecast/markup.html inline mapDisplayGuardStyle; map-style-guard401.js |
| F21 | forecast/app.js scene3dSnapshot/receive; scene3d/main.js | forecast/controller.js 同名; scene3d/main |
| F22 | scene3d main,camera-fit,view-memory,view-stability | scene3d 同名 |
| F23 | scene3d main,overlays,band-readout | scene3d 同名 |
| W01 | weather/app.js rebuild/apply; fixture.js | weather/controller.js / fixture.js |
| W02 | weather/app.js annual; direction-key.js | weather/controller.js annual; direction-key.js |
| W03 | weather/app.js profile/monthly | weather/controller.js 同名 |
| W04 | weather/app.js roseCounts/rose/miniMap/openPointDialog | weather/controller.js 同名 |
| W05 | weather/app.js spatialMap/spatial | weather/controller.js 同名 |
| W06 | weather/app.js landing/trialData; impact-map.js | weather/controller.js と impact-map.js |
| W07 | weather/impact-map.js routes/buildScene | weather/impact-map.js 同名 |
| W08 | weather/app.js handoff; forecast initSeason | WeatherScreen/runtime→App→ForecastScreen＋season-adapter |
| W09 | weather/app.js exportSVG/exportStandalone/save | weather/controller.js 同名 |
| X01 | 旧単独模型JSON+URL/内部state | App/ui_state namespaces/useWorkspace restoration |
| X02 | forecast/app.js removeIds/undoRemoval/detach | forecast/controller.js 同名; realはApp action |

## 無課金の別人工タブで残る代表行程

1. 共通の準備→二つの人工領域→概要の干渉数と面→干渉群詳細→非干渉/全着地/一点/多角形。全選択へ戻せるか確認。
2. 時刻バーを動かし風速/風配と飛行中分母、5縦軸、比較群の凡例表示/帯切替。6形式PNG/SVGの代表として履歴SVGと風配PNGを保存実物で確認。
3. 候補JSON保存→復元入口→同条件/結果の読戻し、別形式JSON拒否。共通API計画保存はしない。
4. 地図高さkeyboard/drag、自動復帰、仮放球点取消/確定、候補複製と遅延30/60分、親入力変更後の子旧結果と明示更新。
5. 風配の地点選択/圧力/半月ページ、地域差定常度/尺度、軌道toggle、気象SVG保存。
6. 写真3Dはroot管理の別人工tabで、注目面/禁止域内/重なり/輪郭のみのhover、表示toggle、視点保存/戻す、2D復帰の整列を確認。根拠なく接続済realtabを切り替えない。


## 修復検査の追記

最終 build TiNcwLt2 (Vite 8.2.0 / 52 modules / 1.93s / exit0)。修復後24試験 (3 files) pass。追加2件は実際のscene-documentと2D/3D hover resolverを通し、50/90/95面、面内と禁止領域の重なり、重複同一領域、非表示除外を検査した。実写真のsurface-pickや実マウスを代替する証拠ではない。試験後の差分は人工JSON入口の配置調整と出典記録だけで、これらを含む最終buildを実施した。
