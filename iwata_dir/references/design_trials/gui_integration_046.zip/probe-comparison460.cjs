const fs=require('node:fs');
const vm=require('node:vm');
const code=fs.readFileSync('frontend/src/screens/forecast/controller.js','utf8');
const context=vm.createContext({modelLabel:{simple:'定上昇率'},periodLabel:p=>String(p)});
vm.runInContext(code.slice(code.indexOf('function sameConditionValue('),code.indexOf('function renderComparisonConditions(')),context);
const config=rate=>({launch:{time_utc:'2026-09-24T00:00:00Z',latitude_deg:34,longitude_deg:136,altitude_m:20},ascent:{mode:'constant_speed',speed_m_s:rate},burst:{mode:'altitude',altitude_m:30000},descent:{mode:'rated_speed',reference_speed_m_s:5}});
context.tabs=[5,6].map((rate,i)=>({id:'C'+(i+1),result:{conditions:{realConfig:config(rate),model:'simple',origin:[34,136],date:'2026-09-24',time:'09:00',mass:0,forecast:'same-gfs',burstDiameter:null}}}));
const observed=vm.runInContext('conditionSummary(tabs)',context);
console.log(JSON.stringify({probe:'real ascent speed 5 versus 6',expectedDifferentField:'ascent.speed_m_s',observed},null,2));
