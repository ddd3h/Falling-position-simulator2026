# Independent UI code review — round 5 (0.46)

基準: M420 / PR30 C2 ce6a29accfad6865beca0b2dfe4f414e2bafb81a。読み取りとP460内のprobeだけを実施。実ブラウザ操作はroot/screens担当。本記録の「コード修正確認」「純関数確認」を実UI合格と読み替えない。

## 今巡の主要発見と訂正

### 気象画面切替の自己観測ループ

weather/controller.jsの背景OFF分岐が毎回map-status.textContentを書き、同じmainのsubtree/childListを監視するMutationObserverがmapStatusを再呼出しする。既存signatureガードより前でreturnする分岐だった。コード上、無限microtaskが成立し、通常の用途切替を受け入れられない強い不具合である。screensへ即時返却し、同一textなら代入しない修正を確認した。

実際のCUA renderer crashのJS stackは取得されていない。この発見を「crashの全原因を実証」とはしない。修正後の気象画面切替/操作の継続で実害解消を確認する必要がある。

React側はmerge後stable比較、既存IDへのalias二重設定抑制、sync中のchanged抑制が入っている。同一snapshotでの無条件setProjectループは読解範囲では見つからなかった。Leaflet moveendは発生し得るが内容が同一ならkeepViewが止める。

### 保存後の識別子再利用

controller.restoreがnextCandidateだけを復元し、nextGroup=2/nextLayer=1を初期値に戻すため、G2/L1保存後の新規追加でIDが衝突する経路を検出。比較所属/領域参照へ実害があるため修正必須と返却。現在は両counterを既存最大ID+1へ設定するコードを確認した。

### CSSスコープ化の置換誤り

.prep-bodyのbody部分まで&に置換された.prep-&が2箇所あり、markupに対応していなかった。現在はprep-bodyへ訂正済みを確認。

## 第4巡からの訂正確認

- 実停止run詳細: 2D経路入力がdetailSamplesへ、詳細母数が記録数へ、3Dの停止点は選択IDだけへ変わった。
- supports配列により実画面の可視候補ごとの固定weather_snapshot境界を渡す処理が入り、単一sources[0]へ常に縮退する比較概要を訂正した。詳細単候補も固定結果のsourceを使う。graphだけのgroup詳細ではmap非表示なので、表示されないfallbackを主なブロッカーとはしていない。
- 実PNG/SVG/KMLの説明にn=1、原record、ASLが入り、人工/模式AGL/不存在の分位域の残文が訂正された。
- 季節handoffはpendingProposalを受け、新しいS候補を既存候補へ追加、sourceを候補へ保持、消費後pending=null。単に用途へ戻る際は既存slotを復元する。
- 季節候補の年/時刻/地点表示はactive候補の条件、気象へ戻るactionはその候補source.returnStateを使う。旧別HTMLへの遷移を共通shellへ接続した。
- 実timeSliderはstep=anyとなった。原recordの終了時刻へ到達する実操作は別途確認が必要。
- renderHistory/slider/refreshのdisposedガードとscopeのlistener/timer/observer回収はある。renderWindのawait後とmount部分失敗のcleanupについて最小の補完を実装者へ返した。ブラウザ停止の原因としての実証はしていない。

## 局所実行の証拠

`probe-scene-boundary460-round5.mjs` は現役scene-document→protocol/exportを連結した。

- 実停止1件を選択: protocol受理、stop点1、支持場A/Bの2境界名維持、KML absolute ASL。
- 選択解除: protocol受理、stop点0。空選択へ旧停止点を混入しない。
- 両方: 人工模型/模式AGL/実在しない50%輪郭の注記を出さない。

結果: `probe-scene-boundary460-round5.json`。これは人工の小さな契約入力による表示接点確認で、科学計算やGoogle画像接続を実施した証拠ではない。

## 有限の残受入（増殖させない）

1. **用途切替と復元**: 保存real詳細→気象（背景OFF）→4用途の操作→予報へ戻る。画面が応答し続け、旧real入力/結果と人工viewが相互上書きされない。初期map-status自己ループの再発をここで確認する。
2. **実履歴表示**: 保存済み着地1件と停止1件で、2D詳細経路・相/原イベント・終了時刻slider・停止理由が対応する。n=1へ分位帯を作らず、図/KML保存の説明も対応する。追加の物理モデル採用は不要。
3. **比較/延期と保存再開**: 親+延期列+独立候補を作り、親編集後も表示する旧結果が固定される。異なる保存場の可視候補は各支持を表示する。groupと領域を保存→再開後、新規追加して既存IDを壊さない。
4. **季節の問を維持**: 気象で年/時刻mask/地点/時期A→季節候補追加→戻る→異なるB→追加。A/Bの由来・条件が別々に残り、各候補から対応する気象分析へ戻れる。保存再開後も再提案が勝手に重複しない。
5. **失敗と寿命**: 描画途中の用途切替と、保存/読込みの失敗時に現状態を失わないことを一度ずつ確認する。既に検証済みの同一障害を理由なく繰返さない。

受入を止めるべきなのはクラッシュ、保存ID衝突、別データへの誤接続、実n1への人工数値混入などの実装不具合である。実過去場、モンテカルロ、誤差分布、分位域、科学的安全評価が未実装であること自体を今回の不合格理由へすり替えない。既存の具体的画面を人工用途として保持することと、実装済みn1の接点を訂正することは両立する。
