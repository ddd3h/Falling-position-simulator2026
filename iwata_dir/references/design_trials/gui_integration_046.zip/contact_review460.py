from pathlib import Path
from PIL import Image,ImageDraw
import sys
folder=Path(sys.argv[1]);pages=sorted(folder.glob('page-*.png'))
for start in range(0,len(pages),4):
    group=pages[start:start+4]
    width=max(Image.open(p).width for p in group);height=max(Image.open(p).height for p in group)
    canvas=Image.new('RGB',(width*2,height*2+44),'#c7cbd0')
    d=ImageDraw.Draw(canvas)
    for index,path in enumerate(group):
        im=Image.open(path);x=(index%2)*width;y=(index//2)*(height+22)
        d.text((x+8,y+3),path.name,fill='black');canvas.paste(im,(x,y+22))
    out=folder/f'contact-{start+1:02}-{start+len(group):02}.png';canvas.save(out)
print('\n'.join(str(p) for p in sorted(folder.glob('contact-*'))))
