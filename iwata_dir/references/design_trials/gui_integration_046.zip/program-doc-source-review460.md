# Program guide / implementation notes source check (0.46)

Read-only review by ui_continuity_review. Compared current PROGRAM_GUIDE.tex (17 pages by root build), IMPLEMENTATION_NOTES.md, current frontend source, and P460/basis-C2. PDF visual acceptance remains root's evidence; this review checks semantic source correspondence.

## Changes needed

1. `docs/IMPLEMENTATION_NOTES.md:71`: the current screen cursor does not use `domain.ts pointAt`. The active route is `forecast/projection.ts sample` and `forecast/controller.js historyAt`; pointAt remains used by the retained 0.45 MapPanel/HistoryPanel. Name the active route. Note that e/n and cumulative horizontal distance are display quantities computed with the launch-latitude local plane conversion; raw numerical result records remain unchanged.
2. `docs/IMPLEMENTATION_NOTES.md:57,67`: replace the solely directional description of ui_state with the implemented ownership boundary: App/useWorkspace owns the saved project, controllers own live view state and return snapshots per namespace. For season handoff, new pendingProposal appends a candidate and is consumed, while returning restores the saved slot; tabs carry their own source/returnState. Keep actual UI acceptance separate in S35. This prevents a future maintainer from recreating the already observed new-proposal/old-view overwrite bug.
3. `docs/IMPLEMENTATION_NOTES.md:75`: include `frontend/src/screen-contracts.test.ts`, which now checks active record projection, stopped 3D protocol, ASL export and the scoped seasonal fixture. domain/workspace tests alone no longer describe the current display contract test entrypoints.
4. `docs/PROGRAM_GUIDE.tex:224`: replace the ambiguous reference to the '0.45 comparison map' with the current `screens/forecast` rendering path. Page 5 correctly marks MapPanel/HistoryPanel as retained old components, but this later wording can send a reader back to them as the active map.

No other false hierarchy/call/HTTP/state ownership assertion was found in the selected frontend and service diagrams. The diagram explicitly acknowledges large controllers and untyped bridge/scope debt. Current tree and postMessage renderer relationship agree. The old style.css, core340.js and receipt-status.js treatment is also recorded in frontend/SCREEN_PROVENANCE.md; a pointer is sufficient, rather than duplicating that full list in every diagram.

## THEORY retention

SHA256 comparison with P460/basis-C2:
- balloon_sim: all 20 Python files identical; no added Python files.
- docs/THEORY_GUIDE.tex, .pdf, .txt: identical.

Keeping THEORY at its actual scientific revision is appropriate. The current work changes UI/service connections and view-derived quantities, not the accepted integration or physics equations. Explain display conversion and explicitly artificial seasonal calculations in implementation/provenance material; do not silently promote them into the scientific theory guide.
