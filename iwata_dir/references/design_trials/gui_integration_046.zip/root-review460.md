# Root review 0.46 (in progress)

Basis: PR30 C2 ce6a29accfad6865beca0b2dfe4f414e2bafb81a, all 166 registered local files matched fixed blobs before edits. Original screen ZIP r2 SHA256 8356df3cc8f2184d5418fe3d84d1e1d274b7646f3b81be6210c07094b3d7a214.

## Original screen observation

Unmodified forecast/weather/scene3d/shared extracted to comparison401. Local port 8463 blocks external requests by CSP. Missing background tiles in these observations are intentional; this is not a test of background availability. No Google connection or key read.

- Forecast: horizontal candidate/group navigation, focused candidate summary/actions above a full-width common map, adjustable map height, compact counts below. Detailed screen keeps selected map and elapsed-time history together with return and selection controls.
- Weather annual: common target and four purposes remain visible, four plots organised around the question of season/height wind strength and direction coherence.
- Seasonal distributions: twelve monthly profiles on common axes, time-grain and wind-rose alternatives. This concrete composition is materially more useful than one generic chart selector.
- Regional differences: twelve spatial panels, a shared pressure slider and explicit color scale, direction/coherence alternatives.
- Launch impact: shared map on the left, selected point and statistics/action on the right, month slider and launch-location choice. The next action builds a seasonal plan from that context.

## Backend evidence

- Full backend/tests/test_application.py: 13 passed, one upstream Starlette/AnyIO deprecation warning, 12.46s; backend-all-first.log.
- Added independent saved-project examples cover four candidates with parent/delays and separate view namespaces, persistence after restart, missing/cyclic parent, unbound delay, nonfinite view, and keeping previous saved state after rejection. Static app test covers scene3d, Cesium workers and unknown API 404.
- Sandbox temp/worker Pipe permission failures are retained in first/second logs; same isolated tests/startup succeeded with approved escalation. No weaker validation substituted.

## Integration inspection (not acceptance)

- First build reached Vite success but browser was blank: original map-style guard expected an old stylesheet element. Next build found the element but still rejected its old fixed URL. Screens implementer corrected the current bundle contract while retaining computed-style/2D restoration protection.
- Build index-BlWlAipP.js first rendered the recognisable forecast layout. Empty real project is deliberate; explanatory text still implied old two-candidate example and empty creation path was obscure. Returned for correction.
- Created Wakayama candidate through common preparation, changed ascent to constant 5 m/s through existing input drawer, submitted one real run from that drawer. Completion and downstream display still being checked.
- Input drawer rendered duplicate candidate-name inputs; public display exposed internal UUID, and some artificial-model wording remained in real weather support explanation. Returned for correction; do not claim UI accepted.
- Root identified one-minute resampling of original irregular records, misplaced end time and phase/event losses in projection. Implementer changed to original records; downstream history consumers still require review/actual operation.

Independent critique and root observations supplement tests. No original screen scientific assumption is adopted because its layout was retained. Source/build hashes and final accepted observations will be recorded after fixes.

## Root real UI round 2 (observed, candidate not yet accepted)

- Latest DiD0ARA0 restored saved real detail without the previous null-result crash. End key reaches the exact 144.1200614634075-minute record and reports flying 0. Saving a vertical-speed metric restored the underlying metric but not its selector label; screens corrected that DOM synchronization in ZyFGkJOw.
- Duplicated candidate 1 through the inherited candidate drawer, edited ascent 5 to 6 m/s, submitted run 2ac1a1c5-4168-4820-838a-549fccf7a5ba and observed landed 34.2640 N,135.7610 E versus 5 m/s run 950b9982-bbfd-414f-ac53-59f03d703e5c at34.3199 N,135.8393 E. This verifies connection, not scientific accuracy.
- Created +30/+60-minute children from candidate2, changed parent ascent to5.5 and submitted parent/children. UI shows parent12:30 and children13:00/13:30 with5.5 m/s inherited. Earlier6 m/s result remains selectable. Four candidates coexist and save/reload.
- Created comparison G2 using candidates3,1,2. Detail shows separate phase-styled histories, no statistical band, and identifies actual differing launch time and ascent speed. Visual screenshot reviewed.
- Date-time fill alone changed native DOM but did not update React draft in CUA; normal ArrowUp/ArrowDown did update draft correctly. An extra run of the old12:30 input resulted from the first attempted fill. Do not claim this establishes a human-input defect; records retain that attempt. Confirmed draft17:30 then submitted to exercise temporal-support stop.


## Connected photographic 3D and bounded acceptance

User entered the Map Tiles API key into the current 0.46 UI. Root did not read the value. On bundle index-DJXESdH7.js, the photographic mesh and real n=1 projected route/endpoints rendered. Root observed zoom, left-drag movement, remembered-view restoration, +30-minute focus and +60-minute visibility toggle. Returning to 2D preserved both choices; GSI tiles and route remained aligned and the zoom control worked without the old tile fragmentation. Reopening 3D retained the connection. Focusing the stopped run then returning to 2D preserved its original ID, landed0/1 and stopped1. Connection-attempt display remained1 throughout; this is not a Google billing measurement. The connected page was retained.

Evidence images: photo3d-connected460.png and photo3d-return2d460.png. No secret appears in either screenshot. The selector attempt for a +30 button using checkbox role timed out; DOM inspection identified an aria-pressed button and the normal button action succeeded. One wheel page zoomed much closer than intended, and the remembered view restored correctly. Neither event is hidden as a successful first attempt.

Limits: this real n=1 example has no quantile surfaces or forbidden regions, so their hover was not retested on photographs. Right-drag rotation was not exercised by the available tool. No claim of scientific accuracy, complete Monte Carlo/meteorology, billing totals, arbitrary screen sizes or complete export-rendering acceptance.

The bounded integrated GUI path now supports recognisable concrete screens, actual input/result comparisons, delayed children, stopped-result distinction and save/reload/restart recovery. Weather and seasonal fixture paths remain labelled artificial. Large bundle/first weather render latency and full statistical integration remain follow-up work; final repository checks and Git save follow separately.


## Fixture GUI parity follow-up (DJXE, before two source recovery fixes)

Root used a separate tab without saving over the real test project. Added two artificial forbidden-region files: A has60/64 landed,28 hits (46.7%),4 stopped. Summary hit button opens region preparation; detailed selection is reached from the candidate detail. Selected all60 then the28-hit group, opened wind-speed and16-sector wind-direction distributions and visually checked their plots alongside altitude history and bands. SliderEnd moved to125min with0 flying/28 selected. Switched to position, drew a four-point polygon, accepted20/60 landed, then selected east/north displacement; route/points and four phase/direction history curves with bands updated. ExportedPNG and opened it as an image: title, conditions,20 selected,125min,region2 and artificial provenance are readable. Evidence fixture-polygon-detail460.png,fixture-polygon-export460.png,fixture-export460.json. No API key or external background request was made in this fixture tab.

Independent source-parity review found two omissions despite earlier build/tests: legacy artificial-candidate JSON read UI had become unreachable, and inline Leaflet CSS-failure containment had not migrated. Both were returned for repair before claiming the screen migration finished. This illustrates why retaining functions/IDs or passing isolated tests is not sufficient acceptance.


Correction to the preceding summary-button interpretation: with common preparation closed, the visible28-hit button directly opens detail with28/60 selected. Source handler also calls openDetail. The first click while preparation was expanded did not establish this transition; attributing that to a deliberate preparation-opening function was incorrect. A later read of nonexistent #selectionSummary timed out after the button action, but the fresh DOM confirmed successful detail navigation. Height keyboard adjustment changed321px to281px and the Auto button restored automatic mode.


## Final GUI recovery and user mouse evidence

Independent 34-feature source matrix identified and repaired unreachable artificial JSON import and missing inline map-style failure containment; misleading real-delete immediate-undo wording was also corrected without claiming the real undo exists. 24 tests/TypeScript/build passed. Final source bundle TiNcwLt2 differs from Bvh in import-button placement. Root imported the exported artificial JSON on Bvh and observed a new C3 preserving r1, conditions,60/64 landed and the same landing mean. File chooser tool call returned only after a long wait; actual successful restoration was verified separately from tool completion.

On finalTi user-connected artificial photo3D, root observed A/B50/90/95 bands, forbidden regions and ground routes, toggled points and both face types, focusedB and observed corresponding fill/legend. Clicking a photographed location returned A50–90 band. User explicitly reported all three actual mouse-hover checks OK: A face interior, forbidden-region face interior, overlapping faces with both names in one tooltip and no repeated region name. This is user-reported real mouse evidence, not a root synthetic-hover test. B→2D retained r2 and3/60 hits, click hits opened3-sample detail, then overview→3D retained connection-attempt1. There are two separate authorized connected tabs (real and artificial), not a single total request. Root never read a key. Initial full-screen capture was auto-review-rejected for potential key field; read-only isVisible confirmed key entry false and the retry then succeeded. No security or approval rule was disabled.

This finite migration acceptance preserves the concrete old purposes/screens and repairs detected omissions; it does not certify all34 functions in every state or complete real MC/past-data/scientific validity. Remaining whole-mode remount/connection lifetime and real immediate undo boundaries are documented. The two connected tabs remain alive for user review.


## Isolated CSS containment acceptance

Root opened final a7530c2a harness on local8463 in a separate tab and read PASS17 from #result. Actual current CSS, minimal DOM, computed styles and guard were exercised; transport/link events simulated, no Google or other external requests. map-guard-browser460.json retains the full result and source hashes. This complements the actual 3D-to-2D return above, not a full HTTP/Leaflet-failure test. Savehelper was read end to end: fixed221 paths, external bare only, fixed parent lease, all blob readback and original938-file .git comparison. No main/public write is authorized.
