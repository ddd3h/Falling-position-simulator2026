from pathlib import Path
import hashlib, json, re

P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-gui-460')
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
paths={
 'markup':'frontend/src/screens/forecast/markup.html',
 'guard':'frontend/src/screens/forecast/map-style-guard401.js',
 'appcss':'frontend/src/screens/forecast/screen.css',
 'vendor':'frontend/node_modules/leaflet/dist/leaflet.css',
}
data={k:(R/v).read_text(encoding='utf-8') for k,v in paths.items()}
inline=re.search(r'<style id="mapDisplayGuardStyle">([\s\S]*?)</style>',data['markup']).group(1)
guard=data['guard'].replace('export function install(scope)', 'function install(scope)',1)
def safe(s): return s.replace('</script', '<\\/script')
meta={k:{'path':v,'sha256':hashlib.sha256((R/v).read_bytes()).hexdigest()} for k,v in paths.items()}
script=Path(P/'map-guard-probe460-body.js').read_text(encoding='utf-8')
html='''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'none'; connect-src 'none'; frame-src 'none'; object-src 'none'; font-src 'none'; base-uri 'none'; form-action 'none'">
<title>0.46 F20 isolated computed-style probe</title>
<style>body{font:14px/1.45 system-ui;margin:20px}pre{white-space:pre-wrap}#probeMapHost{width:640px}#result{max-width:1000px}.test-note{padding:8px;background:#eef}</style>
</head><body><h1>F20 isolated computed-style probe</h1>
<p class="test-note">No external resources. Current source inline CSS, app CSS, Leaflet CSS and guard are embedded. Link transport is simulated; computed styles, visibility, layout, and the actual guard mount are real browser DOM. This is not a full application or Google test.</p>
<div id="probeMapHost" class="forecast-screen"><div id="map" class="leaflet-container" data-map-display="checking" style="position:relative;width:640px;height:320px"><div class="leaflet-pane"><div class="leaflet-tile-container"><img class="leaflet-tile" alt="local tile rectangle" style="width:256px;height:256px;background:#aac"></div></div><div class="leaflet-control-container">Map controls</div><div id="mapDisplayNotice" role="status"><p id="mapDisplayText">checking</p><button id="mapDisplayRetry" disabled>retry</button></div></div><p id="outsideMap">Unrelated content remains visible.</p></div>
<pre id="result">RUNNING</pre><script>const SOURCE_META='''+json.dumps(meta,ensure_ascii=False)+''';
const INLINE_CSS='''+safe(json.dumps(inline))+''';
const APP_CSS='''+safe(json.dumps(data['appcss']))+''';
const VENDOR_CSS='''+safe(json.dumps(data['vendor']))+''';\n'''+guard+'\n'+script+'</script></body></html>'
out=P/'map-guard-probe460.html'
out.write_text(html,encoding='utf-8',newline='\n')
(P/'map-guard-probe460-manifest.json').write_text(json.dumps({'html':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'sources':meta,'transport':'simulated no network; no real link href or src is assigned','oracle':'actual source mount, real DOM computed styles in browser','not_claimed':['full app rendering','live CSS HTTP retrieval','3D return','Google tiles']},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'html':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
