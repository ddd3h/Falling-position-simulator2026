const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const ts=require(path.resolve('frontend/node_modules/typescript'));
const domain={exports:{}};
vm.runInNewContext(ts.transpileModule(fs.readFileSync('frontend/src/domain.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,{exports:domain.exports,module:domain});
const code=fs.readFileSync('frontend/src/screens/forecast/controller.js','utf8');
const context=vm.createContext({...domain.exports,bridge:{real:true},modelLabel:{simple:'定上昇率'},periodLabel:p=>String(p)});
vm.runInContext(code.slice(code.indexOf('function sameConditionValue('),code.indexOf('function renderComparisonConditions(')),context);
const config=rate=>({launch:{time_utc:'2026-09-24T00:00:00Z',latitude_deg:34,longitude_deg:136,altitude_m:20},ascent:{mode:'constant_speed',speed_m_s:rate},burst:{mode:'altitude',altitude_m:30000},descent:{mode:'rated_speed',reference_speed_m_s:5}});
const conditions=(rate,weatherId)=>({realConfig:config(rate),weatherId,model:'simple',origin:[34,136],date:'2026-09-24',time:'09:00',mass:null,forecast:weatherId,burstDiameter:null});
for(const [label,inputs]of [['ascent difference',[[5,'gfs-A'],[6,'gfs-A']]],['weather difference',[[5,'gfs-A'],[5,'gfs-B']]]]){
 context.tabs=inputs.map(([rate,weather],i)=>({id:'C'+i,result:{conditions:conditions(rate,weather)}}));
 console.log(JSON.stringify({label,observed:vm.runInContext('conditionSummary(tabs)',context)},null,2));
}
