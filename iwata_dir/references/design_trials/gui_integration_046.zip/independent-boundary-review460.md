# 0.46 第2巡：共通shell・命令controller・API保存の境界

読解対象：`screens-plan460.md`、旧forecast/app.js/ weather/app.js、現行 `frontend/src/useWorkspace.ts`、`workspaceState.ts`、`backend/contracts.py`、application.pyのProject保存入口。2026-09-29。編集はレビュー記録のみ。

## 判断

具体DOM/CSSを素材にし、命令controllerを画面rootに閉じ込める方針は可能。ただし画面を一つのshellへ載せるだけでは共通projectへ統合したことにならない。最大のリスクは、旧controllerの `tabs[].draft/result/results` とReact側の候補・固定runがそれぞれ書込み可能になること。

実modeではuseWorkspaceが候補/草案/選択した固定runを所有し、旧controllerへ描画用投影を渡す。controllerから戻すのは編集/候補追加/延期/結果選択等の意図とする。map位置・hover・未確定の囲みはcontrollerの局所状態でもよい。人工予報・季節・気象は別namespaceに保存する。これをscreens460へ提案し、採用するとの回答を受領した。

## 計画段階で見つけた具体的な接点

| 旧/現コード | 反証 | 必要な修正 |
|---|---|---|
| 旧forecast `initSeason` (207) は tabs/groups を初期化 | 気象→季節へ入ったら予報計画が消える | 用途ごとの状態を保持し、季節handoffを既存予報の全置換にしない。気象の元母集団/図状態へ戻れること |
| 旧 `applyDelays` (97) は `commitResults` を即時実行 | 延期列の編集だけで実計算を大量送信 | 候補差分の作成と計算送信を分ける。明示実行の対象を表示 |
| 親の草案から子を動的導出 | 親変更で子の既計算条件も書換わる | 子草案の解決・revision更新と、固定runの条件を分ける。後者を変更しない |
| 旧document/windowリスナ、bodyclass、タイマ、map/Plotly | route往復・React再mountで二重反応や古いrootへ描画 | mount/dispose所有者を明確にし、global listener・observer・タイマ・描画instanceを回収。bodyclassも画面rootへ局所化 |
| 現workspaceReducer `result/complete` | 計算中候補を削除後、完了時に比較選択へrunが復活 | 結果保存は保つが、存在しない候補の結果で現在の表示選択を更新しない。候補削除と画面選択を独立扱い |
| ui_stateへ任意objectを保存 | 人工結果が実run参照と同じ名前空間で復元される | schema/version、実予報・人工予報・気象・季節の識別を持つ。実結果を二重保存しない |

## backend契約への限定批評

- `max_length=2` の除去は適切。二条件は初回受入例であり製品の上限ではない。
- Candidate `parent_id/delay_minutes` は、保存関係のメタデータなのか実入力を解決する命令なのか明示が必要。materialized configを保存する方式なら、親編集と子config/revision更新を一つのproject変更にし、遅れ分だけ以外の差分が意図せず残らないようにする。
- 親存在、自己親、循環、delay値との整合は保存時に有限に確認。候補ID重複は現application.pyに既に検査がある。
- 延期のUI上の12時間上限を科学的/気象的制約へ昇格させない。気象valid間隔で放球時刻を丸めない。
- 共通projectのui_stateはviewを戻すためのもの。旧人工結果を実計算runへ取り込む迂回路にしない。

## 次巡のコード/実画面で調べること

1. 予報の候補を編集し、気象4画面→季節→予報へ戻って入力・固定結果・地図位置を照合する。
2. 実計算n=1と人工分散を往復し、点/輪郭/風分布/図保存の出所を照合する。
3. 親の入力を変え、未計算の子草案と旧子結果を同時に読む。延期追加のみではjobが増えないこと。
4. 計算中候補を削除し完了を待つ。結果保存と画面選択の意味が分かれること。
5. routeを何度か往復し、操作1回でcallback1回、元画面のUI/plot/3D状態へ不要な処理が届かないこと。

本記録は計画の批評であり実装成功の証拠ではない。

## Backend差分の追読

主担当によるcontracts/applicationの変更後を読んだ。候補数の2上限撤去、親/遅れのoptional追加、親存在・循環・重複比較・有限JSONの検査、ui_stateの追加は上記の境界に沿う。保存から計算を起動する処理は増えていない。現在の変更にblocking指摘はない。

ただしparent/delayが妥当でもmaterialized configが親とは別場所/別モデルの草案であることは許容される（未完草案の保存として妥当）。したがって画面で「時刻だけが違う」と説明する根拠は、関係メタデータ単独ではなく、FEで同期した草案と実際の固定run条件である。この点をrootへ返した。
