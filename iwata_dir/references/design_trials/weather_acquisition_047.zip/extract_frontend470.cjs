// Registered frontend syntax only; adapted from P460/extract_frontend460.cjs.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=process.argv[2],manifest=process.argv[3],out=process.argv[4];
const ts=require(path.join(root,'frontend/node_modules/typescript'));
const names=JSON.parse(fs.readFileSync(manifest,'utf8')).files.map(r=>r.path);
const rows=names.map(rel=>{
 const p=path.join(root,rel),raw=fs.readFileSync(p),row={path:rel,source_sha256:crypto.createHash('sha256').update(raw).digest('hex'),bytes:raw.length};
 if(/\.(?:tsx?|m?js)$/.test(p)){
  const source=ts.createSourceFile(p,raw.toString('utf8'),ts.ScriptTarget.Latest,true);
  row.imports=[];row.top_level_declarations=[];row.parse_diagnostics=source.parseDiagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,' '));
  for(const n of source.statements){
   if((ts.isImportDeclaration(n)||ts.isExportDeclaration(n))&&n.moduleSpecifier&&ts.isStringLiteral(n.moduleSpecifier))row.imports.push(n.moduleSpecifier.text);
   if((ts.isFunctionDeclaration(n)||ts.isClassDeclaration(n)||ts.isInterfaceDeclaration(n)||ts.isTypeAliasDeclaration(n)||ts.isModuleDeclaration(n))&&n.name)row.top_level_declarations.push({name:n.name.getText(source),kind:ts.SyntaxKind[n.kind],line:source.getLineAndCharacterOfPosition(n.getStart(source)).line+1,end_line:source.getLineAndCharacterOfPosition(n.end).line+1});
  }
 }
 return row;
});
fs.writeFileSync(out,JSON.stringify({typescript_version:ts.version,method:'TypeScript createSourceFile syntax only over frontend-source470.json registered paths; no application execution, runtime binding or type checking',files:rows},null,2)+'\n');
process.stdout.write(JSON.stringify({files:rows.length,modules:rows.filter(r=>r.imports).length,parse_errors:rows.flatMap(r=>r.parse_diagnostics||[]).length})+'\n');
