# 0.47 実装差分への批評・第2巡（途中）

sourceは実装中。以下は読取による反例評価であり、実UIを実行した証拠ではない。source編集・Git・外部取得は行っていない。

## CW03: 経度表現と有限座標（修正依頼済み）

`weatherAcquisition.ts/sourceApplicationIssue` は保存場の `lon=[339,341]` と候補経度 `-20` を直接比較して域外としている。既存 `fields.py:154` は `lon+360/lon-360` の同値表現が支持内なら受け入れるため、実場で計算可能なのに画面で適用不能となる。継ぎ目跨ぎの補間を加えるのでなく、同じ支持判定の表現を合わせる必要がある。また候補緯度/経度がNaNなら大小比較がすべてfalseになり、現在の同関数を通る。日時/最大時間と同様に有限性を明示検査する。

## CW01/CW02: family選択と適用（操作接点の実装待ち）

`familyCandidates` と `applyCandidateWeather` は選択親の子孫を含む。一方、子だけ選べるUIなら子のweatherだけを書き換え、親子の保存契約を破る可能性がある。親限定選択、親familyへの正規化、又は独立化を明示する操作で閉じる必要がある。新取得場の `default_config:null` を検知し、既存候補に適用させるAppのガードは暗黙の機体置換を防いでいる。

## CW08: モデル方式往復の草案（進展と残る反例）

`switchModel` は有効configと非選択cacheを分け、密度則の補助値を方式別に保持する。最大飛行時間の入力も追加され、必要窓の判断へ接続できる。`detach` は親のcacheを子へ移す。一方、延期子から独立した比較案を複製すると通常子自身のcacheはなく、親が持つ非選択方式の入力を失う。複製時も所有元のcacheを取得すると、detatchとの行程が揃う。

いずれも担当へ具体反例を送信済み。修正後に同じ関数・操作対象へ戻って再評価する。

読取source hash frontend/src/weatherAcquisition.ts: `234eec27775ad9395feb266d7b12c0c8790c4b26ff89c0d89eb2de8487f4a481`。

読取source hash frontend/src/modelDrafts.ts: `bc58b100d46e356aabfdb0c77f6de59f9e5693328f7c51dde85edcde7d89de82`。

読取source hash frontend/src/App.tsx: `22b8a35c905f9e06a68f4e070c70048dff235dfabab07090a2a02b35205512a2`。

読取source hash frontend/src/ConfigEditor.tsx: `46e7bce7df3de921d1e8497622ef07e268dc73d9cac304ec10ab368eab4e814a`。
