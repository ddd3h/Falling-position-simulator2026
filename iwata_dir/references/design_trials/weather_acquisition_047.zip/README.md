# 0.47: actual GFS preparation and preserved planning UI

Basis: private PR30/0.46 C2 2436152f815a20573e6eca7badedc958c18efe48; adopted main M420.

Start with root-review470.md and the independent critique rounds. The archive contains original NOMADS inventory responses, six GRIB files, normalized completed asset and provenance, exact local API responses, a fixed n=1 run, UI observations, source fingerprints and generated-guide evidence. No credential, browser profile, dependency environment or running database is included.

This is a pre-save evidence snapshot. Repository-wide regression, management checks and Git save/readback belong to later S36 entries. Earlier failed/limited observations are not promoted to acceptance. PowerShell-converted JSON diagnostics are intentionally excluded from the original HTTP evidence.

The guide and real acquired field do not complete real Monte Carlo dispersion, past-weather analysis, scientific accuracy, or flight safety evaluation. New seven-time delay plan was deliberately not downloaded; the prior six-time asset and explicit support rejection are the tested result. Old 8461 photographic 3D tabs remained open without new connection/key reading.

Raw transfer totals and the gateway interval are measurements of this finite sequence, not universal availability or performance guarantees. Source-index extraction is a structural aid, not independent semantic acceptance. Original .git additions were diagnosed separately and never silently adopted as a new baseline.
