from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

root=Path(__file__).parent
target=root/'api-evidence470'
target.mkdir(exist_ok=True)
endpoints={'sources':'weather-sources','acquisitions':'weather-acquisitions','inventories':'weather-inventories',
           'project':'project','result':'runs/66bfa1b1-df37-4cb0-9b6c-43c5692d1af8/result'}
manifest={}
values={}
for name,endpoint in endpoints.items():
    with urllib.request.urlopen('http://127.0.0.1:8471/api/v1/'+endpoint,timeout=20) as response:
        raw=response.read()
    (target/(name+'.json')).write_bytes(raw)
    manifest[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'endpoint':endpoint}
    values[name]=json.loads(raw)
source=next(s for s in values['sources']['sources'] if s.get('kind')=='acquired_gfs')
provenance=source['metadata']['provenance']
intervals=[(datetime.fromisoformat(b['started_at_utc'])-datetime.fromisoformat(a['completed_at_utc'])).total_seconds()
           for a,b in zip(provenance,provenance[1:])]
summary={'observed_at_utc':datetime.now(timezone.utc).isoformat(),'responses':manifest,
         'raw_bytes':sum(p['bytes'] for p in provenance),'raw_files':len(provenance),
         'minimum_between_fetch_seconds':min(intervals),'intervals_seconds':intervals,
         'source_id':source['id'],'minimum_top_geometric_m':source['support']['minimum_top_geometric_m'],
         'valid_times_utc':source['valid_times_utc'],'status':values['result']['result']['status'],
         'result_summary':values['result']['result']['summary'],
         'gas_mass_kg':values['result']['result']['config']['ascent']['gas_mass_kg'],
         'acquisition_states':[(a['state'],a['reused'],a['progress']['bytes_downloaded']) for a in values['acquisitions']['acquisitions']]}
(target/'receipt.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('responses','result_summary')},ensure_ascii=False,indent=2))
