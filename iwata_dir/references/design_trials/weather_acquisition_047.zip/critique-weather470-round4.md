# 0.47 独立批評・第4巡（修正への再評価）

第3巡の反例へ戻り、同じ責務・操作のsourceを読み直した。以下はsource評価と試験内容の読解であり、この担当によるブラウザ操作・新規HTTP・pytest実行ではない。

## sourceで閉じた反例

- **CW09**: WeatherPreparationのplanEpochが、新しい計画作成/取得履歴選択を始めた後の旧初回復元応答を破棄する。初回一覧も、既に届いた新項目を上書きしないmergeになった。
- **CW10**: forecastValidTimesがrunとlead_hoursから実valid時刻を作り、画面は要求窓と別の欄に両端・全時刻を表示する。任意放球日時を時間格子へ丸めず、内挿の両端を取得する意味が可視化される。
- **CW11**: Dependencies.missingの型と表示がbackendの{name,message}へ揃った。前提不足の名前と理由を読むことができる。
- **CW01/CW02追補**: acquisitionとweather適用は共通candidateFamilyを使い、親/子で支持検査と実変更集合が食い違わない。通常UIの親限定表示とは別に、保存された子IDを受けた経路も揃った。
- **CW12**: 未完了HTTPのin_flightを保存し、次のprocessがOSlockを取った後に改めて10秒待つ。read1を用い、monotonic総経過90秒をread前後に点検し、socket timeoutを30秒とする。読み終わり/DNSを強制割込するhard deadlineではなく、ここを保証したと表現しない。
- **CW13**: 失敗時に現在のpartial bytesを再計数し、今回受信量とretained量をfailure票/progressへ戻す。次のresume予算を圧迫した理由が失敗した試行にも残る。
- **CW14**: ASSETの完成markerはUUID.partialへwrite/fsyncしてからrenameする。書込み途中の停止は未完成partialとして残り、正常markerと取り違えない。
- **CW15**: retryは同一cacheのactiveがあれば409で拒否し、完成assetがあればhash照合後に同じjobをreused/completedとする。旧attempt履歴を保持し、新しいHTTPを重ねない。

## 試験内容との対応

`tests/test_gfs_acquisition.py`の未完了owner/slow-stream試験はCW12、partial bytes試験はCW13、既知rawprefix再利用・orphan保持/予算試験はCW05/06を狙っている。`backend/tests/test_weather.py`のlater completed asset再利用はCW15、partial marker中断→retryはCW14に対応する。frontendのacquisition.test.tsは親子集合・model往復・有限入力・経度同値・valid時刻・API明示要求を扱う。これらを実UIやHTTP実績へ拡大しない。

## 最終同期を依頼した二点

1. 完成asset再利用時にもprogressを0/Nや旧失敗途中状態のままにせず、completed=N、今回download=0、再利用bytesの意味を揃える。完了という文章と進捗barの矛盾を避ける。
2. 新規inventory原文保存でfolder.mkdirがrefresh lock取得後かつtry外にある。作成失敗時にもfinallyでlockを解放するよう、処理をtry内へ置く。失敗を直した次の操作が永久に「処理中」扱いされないことが狙いである。

## 実UIでなお問い直す行程

取得中に候補日時や延期列を変えた人は、古い計画で勝手に計算されず、編集した条件を残したまま「何を取り直すか」が分かる必要がある。取得完了後の明示適用と旧結果の関係も同様で、地図の旧軌道・旧気象支持と、次に取得する橙色境界が同一物として見えてはいけない。ここは関数の検査だけでは判定できず、根拠やラベルを読みながら一連の操作を観察する必要がある。

また、今の段階でユーザーが得るのは任意放球時刻/延期/取得範囲を自分の条件へ接続した実GFSの決定論的結果である。モデル往復で草案を失わなくなったことは原フィードバックの一部を満たすが、製品・充填量からの入力経路、原始変数の分布/相関と実MC、過去場・季節解析の実データ接続は残る。既存GUIを保った上でこれらへ進めるという長期目的を、今回n=1の有限受入で終了したことにしない。

## 後続の限定同期を再読した結果

`WeatherService._reuse_progress` は completed_files=total_files、今回の bytes_downloaded=0、bytes_reused=保存raw provenanceのbytes総和、bundle_bytes_reused=正規化gzipサイズへ整理され、submit/retry両方から使われる。API票にも定義が追記された。refresh_inventoryのmkdirはtry内へ入り、failure票の保存がOSErrorでもfinallyがlockを解放する。第4巡末尾で依頼した二点のsource修正を確認した。実UIのprogress描画や実ディスク障害をこの担当が実行した意味ではない。
