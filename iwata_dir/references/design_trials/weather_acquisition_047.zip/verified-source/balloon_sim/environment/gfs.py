"""Explicit bounded GFS acquisition, product validation and raw replay.

Only this provider adapter performs HTTP or imports ecCodes/NumPy. Offline field
queries do not depend on it. Replay validates the original bytes before decoding.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import urllib.parse
import uuid
from .fields import WeatherError, SCHEMA, _utc, _number, _bracket, geometric_to_geopotential
from .bundle import WeatherField
from .storage import read_json, write_bundle
from .gfs_contract import LEVELS_HPA, LEADS, FILTER_URL, UPPER_KEYS
from .nomads import NomadsGateway, check_cancel

MAX_DECODE_BYTES=536870912


def estimate_decode_bytes(spec):
    """Conservative admission estimate, not an RSS bound or compressed size."""
    b=spec["bounds"]
    cells=(round((b["east"]-b["west"])*4)+1)*(round((b["north"]-b["south"])*4)+1)
    return 64*1024*1024+(len(LEVELS_HPA)*len(UPPER_KEYS)+6)*cells*len(spec["lead_hours"])*192


def _decoder_identity():
    # Import before contacting the provider, including the native ecCodes check.
    import eccodes as ec
    import numpy as np
    return {"eccodes":ec.__version__,"eccodes_api":str(ec.codes_get_api_version()),
            "numpy":np.__version__,"decoder_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

def _request(request):
    if not isinstance(request,dict):
        raise WeatherError("INVALID_REQUEST","object required")
    allowed={"run_utc","start_utc","end_utc","bounds","max_bytes"}
    if set(request)-allowed or allowed-{"max_bytes"}-set(request):
        raise WeatherError("INVALID_REQUEST","run_utc,start_utc,end_utc,bounds; optional max_bytes")
    run,start,end=(_utc(request[k]) for k in ("run_utc","start_utc","end_utc"))
    if run.hour not in (0,6,12,18) or (run.minute,run.second,run.microsecond)!=(0,0,0):
        raise WeatherError("INVALID_RUN",run)
    if not run<=start<=end<=run+timedelta(hours=384):
        raise WeatherError("INVALID_WINDOW","must fit fixed run 0..384h")
    bounds=request["bounds"]
    if not isinstance(bounds,dict) or set(bounds)!={"west","east","south","north"}:
        raise WeatherError("INVALID_BOUNDS","west/east/south/north required")
    b={k:_number(v,k) for k,v in bounds.items()}
    if not (-90<=b["south"]<b["north"]<=90 and -180<=b["west"]<b["east"]<=360
            and b["east"]-b["west"]<360):
        raise WeatherError("INVALID_BOUNDS","ascending, nonseam rectangle required")
    if b["west"]<0:
        if b["east"]>0:
            raise WeatherError("UNSUPPORTED_SEAM","split acquisition across zero longitude")
        b["west"]+=360; b["east"]+=360
    b={k:(math.floor(v*4)/4 if k in ("west","south") else math.ceil(v*4)/4) for k,v in b.items()}
    maximum=request.get("max_bytes",50_000_000)
    if type(maximum) is not int or not 1024<=maximum<=50_000_000:
        raise WeatherError("INVALID_BYTE_LIMIT","1024..50000000")
    schedule=tuple(run+timedelta(hours=h) for h in LEADS)
    left=min(i for i,w in _bracket(schedule,start,"TIME_OUT_OF_RANGE"))
    right=max(i for i,w in _bracket(schedule,end,"TIME_OUT_OF_RANGE"))
    return {"run_utc":run.isoformat(),"start_utc":start.isoformat(),"end_utc":end.isoformat(),
            "bounds":b,"max_bytes":maximum,"lead_hours":list(LEADS[left:right+1])}


def _url(spec,lead):
    run=_utc(spec["run_utc"])
    query={"file":f"gfs.t{run:%H}z.pgrb2.0p25.f{lead:03d}",
           "dir":f"/gfs.{run:%Y%m%d}/{run:%H}/atmos", "subregion":""}
    query.update({"lev_"+str(n)+"_mb":"on" for n in LEVELS_HPA})
    query.update({"lev_surface":"on","lev_2_m_above_ground":"on","lev_10_m_above_ground":"on"})
    query.update({"var_"+v:"on" for v in ("HGT","TMP","UGRD","VGRD","SPFH","PRES")})
    b=spec["bounds"]
    query.update(leftlon=b["west"],rightlon=b["east"],bottomlat=b["south"],toplat=b["north"])
    return FILTER_URL+"?"+urllib.parse.urlencode(query)


def _download(url,path,remaining,*,cancel=None):
    path=Path(path)
    if path.exists():
        raise WeatherError("OUTPUT_EXISTS",path)
    partial=path.with_name(path.name+"."+uuid.uuid4().hex+".partial")
    info=NomadsGateway().download_to(url,partial,remaining,cancel)
    with partial.open("rb") as stream:
        if stream.read(4)!=b"GRIB":
            raise WeatherError("NOT_GRIB","response retained for diagnosis")
    # Only a complete, bounded response becomes a reusable raw file.
    partial.rename(path)
    return {**info,"file":path.name}


def decode_gfs(paths, specification, provenance):
    """Deterministic raw-GRIB replay; validate product/grid/field/run metadata."""
    import eccodes as ec
    import numpy as np
    spec=specification
    run=_utc(spec["run_utc"])
    all_fields={name:[] for name in UPPER_KEYS.values()}
    all_surface={name:[] for name in ("geopotential_height_gpm","pressure_pa","temperature_2m_k",
                 "specific_humidity_2m_kg_kg","eastward_wind_10m_m_s","northward_wind_10m_m_s")}
    grid=None; summaries=[]
    surface_keys={("orog","surface",0):("geopotential_height_gpm","m"),
                  ("sp","surface",0):("pressure_pa","Pa"),
                  ("2t","heightAboveGround",2):("temperature_2m_k","K"),
                  ("2sh","heightAboveGround",2):("specific_humidity_2m_kg_kg","kg kg**-1"),
                  ("10u","heightAboveGround",10):("eastward_wind_10m_m_s","m s**-1"),
                  ("10v","heightAboveGround",10):("northward_wind_10m_m_s","m s**-1")}
    units={"gh":"gpm","t":"K","u":"m s**-1","v":"m s**-1","q":"kg kg**-1"}
    if len(paths)!=len(spec["lead_hours"]):
        raise WeatherError("RAW_COUNT_MISMATCH","one raw file per planned valid")
    for path,lead in zip(paths,spec["lead_hours"]):
        arrays={}; surfaces={}; message_count=0
        with Path(path).open("rb") as stream:
            while True:
                handle=ec.codes_grib_new_from_file(stream)
                if handle is None: break
                try:
                    get=lambda key:ec.codes_get(handle,key)
                    valid=run+timedelta(hours=lead)
                    checks={"edition":2,"centre":"kwbc","stepUnits":1,
                            "gridType":"regular_ll","dataDate":int(run.strftime("%Y%m%d")),
                            "dataTime":int(run.strftime("%H%M")),"validityDate":int(valid.strftime("%Y%m%d")),
                            "validityTime":int(valid.strftime("%H%M")),"stepType":"instant",
                            "iDirectionIncrementInDegrees":0.25,"jDirectionIncrementInDegrees":0.25,
                            "numberOfMissing":0,"uvRelativeToGrid":0}
                    for key,value in checks.items():
                        if get(key)!=value: raise WeatherError("GRIB_METADATA_MISMATCH",f"{Path(path).name}:{key}")
                    lat=ec.codes_get_array(handle,"latitudes"); lon=ec.codes_get_array(handle,"longitudes")
                    ys=np.unique(lat); xs=np.unique(lon)
                    expected_y=np.arange(spec["bounds"]["south"],spec["bounds"]["north"]+0.125,0.25)
                    expected_x=np.arange(spec["bounds"]["west"],spec["bounds"]["east"]+0.125,0.25)
                    if not np.array_equal(ys,expected_y) or not np.array_equal(xs,expected_x):
                        raise WeatherError("GRIB_GRID_MISMATCH","requested rectangle not returned")
                    order=np.lexsort((lon,lat)); shape=(len(ys),len(xs))
                    if len(order)!=shape[0]*shape[1] or len(set(zip(lat.tolist(),lon.tolist())))!=len(order):
                        raise WeatherError("GRIB_GRID_MISMATCH","duplicated or incomplete coordinates")
                    values=ec.codes_get_values(handle)[order]
                    if not np.isfinite(values).all(): raise WeatherError("MISSING_DATA",Path(path).name)
                    key=(get("shortName"),get("typeOfLevel"),get("level"))
                    if key[0] in UPPER_KEYS and key[1]=="isobaricInhPa" and key[2] in LEVELS_HPA:
                        if get("units")!=units[key[0]] or key in arrays:
                            raise WeatherError("GRIB_FIELD_MISMATCH",key)
                        arrays[key]=values.reshape(shape).tolist()
                    elif key in surface_keys:
                        name,unit=surface_keys[key]
                        if get("units")!=unit or name in surfaces:
                            raise WeatherError("GRIB_FIELD_MISMATCH",key)
                        # GFS orog is WMO discipline0/category3/number5:
                        # geopotential height, despite ecCodes unit label 'm'.
                        if key[0]=="orog" and (get("discipline"),get("parameterCategory"),get("parameterNumber"))!=(0,3,5):
                            raise WeatherError("GRIB_FIELD_MISMATCH","orography parameter")
                        surfaces[name]=values.reshape(shape).tolist()
                    # Filter level/variable cross-products also return e.g. surface T;
                    # they are validated for grid/time but explicitly not substituted.
                    message_count+=1; grid=(ys.tolist(),xs.tolist())
                finally:
                    ec.codes_release(handle)
        expected={(name,"isobaricInhPa",level) for name in UPPER_KEYS for level in LEVELS_HPA}
        if set(arrays)!=expected or set(surfaces)!=set(all_surface):
            raise WeatherError("MISSING_GRIB_FIELDS",f"upper:{sorted(expected-set(arrays))}; surface:{set(all_surface)-set(surfaces)}")
        for short,name in UPPER_KEYS.items():
            all_fields[name].append([arrays[(short,"isobaricInhPa",p)] for p in LEVELS_HPA])
        for name in all_surface:
            all_surface[name].append(surfaces[name])
        summaries.append({"file":Path(path).name,"messages":message_count,"lead_hours":lead})
    metadata={"source":"NOAA NCEP GFS pgrb2.0p25 via NOMADS GRIB filter", "run_utc":spec["run_utc"],
              "request":deepcopy(spec),"provenance":deepcopy(provenance),"raw_summary":summaries,
              "decoder":{"eccodes":ec.__version__,"eccodes_api":ec.codes_get_api_version(),"numpy":np.__version__},
              "interpolation":"per-column linear geopotential height and log pressure; then horizontal/time linear values",
              "surface_bridge":"Each column first above-ground pressure level to surface pressure / 2m T,q / 10m u,v. T,q and wind held below their anchors. Terrain stencil uses explicit surface clamp below a contributing column ground. No log-law or thermal boundary-layer resolution.",
              "vertical_wind":"not acquired or applied; horizontal advection only",
              "limitations":["coarse GFS terrain, not a fine DEM","no forecast accuracy validation","no longitude seam interpolation"]}
    bundle={"schema":SCHEMA,"metadata":metadata,"axes":{"time_utc":[(run+timedelta(hours=h)).isoformat() for h in spec["lead_hours"]],
            "pressure_pa":[p*100 for p in LEVELS_HPA],"latitude_deg":grid[0],"longitude_deg":grid[1]},
            "fields":all_fields,"surface":all_surface}
    field=WeatherField(bundle)
    if min(v for a in all_fields["geopotential_height_gpm"] for row in a[-1] for v in row)<geometric_to_geopotential(30000):
        raise WeatherError("INSUFFICIENT_TOP","30000 geometric metres not supported everywhere")
    return bundle


def replay_gfs(acquisition_dir, output_path):
    """Hash-check saved raw inputs and re-decode without any network access.

    An existing output is refused. Current decoder/library versions are recorded;
    bit-identical output is expected only with the same decoder versions.
    """
    directory=Path(acquisition_dir)
    spec=read_json(directory/"request.json")
    if not isinstance(spec,dict):
        raise WeatherError("INVALID_REQUEST","saved request must be an object")
    validated=_request({k:v for k,v in spec.items() if k!="lead_hours"})
    if validated!=spec:
        raise WeatherError("REQUEST_MISMATCH","saved schedule differs from request")
    provenance=read_json(directory/"provenance.json")
    if not isinstance(provenance,list):
        raise WeatherError("PROVENANCE_MISMATCH","saved provenance must be an array")
    if len(provenance)!=len(spec["lead_hours"]):
        raise WeatherError("RAW_COUNT_MISMATCH","incomplete acquisition")
    paths=[]; total=0
    for item,lead in zip(provenance,spec["lead_hours"]):
        if not isinstance(item,dict) or not {"file","url","bytes","sha256"}<=set(item):
            raise WeatherError("PROVENANCE_MISMATCH","incomplete raw entry")
        if item["file"]!=f"f{lead:03d}.grib2" or item["url"]!=_url(spec,lead):
            raise WeatherError("PROVENANCE_MISMATCH","filename or source URL")
        path=directory/item["file"]
        data=path.read_bytes(); total+=len(data)
        if len(data)!=item["bytes"] or hashlib.sha256(data).hexdigest()!=item["sha256"]:
            raise WeatherError("RAW_HASH_MISMATCH",path.name)
        if total>spec["max_bytes"]:
            raise WeatherError("DOWNLOAD_LIMIT","saved raw bytes exceed request limit")
        paths.append(path)
    target=Path(output_path)
    if target.exists():
        raise WeatherError("OUTPUT_EXISTS",target)
    write_bundle(target,decode_gfs(paths,spec,provenance))
    return target


def acquire_gfs(request, output_dir, *, resume=False, progress=None, cancel=None):
    """Download one fixed run and complete scheduled time window, bounded to50MB.

    Existing output is refused unless resume is explicit. Resume reuses only
    complete raw files with matching request, URL and hash; partial bytes remain
    separate and count against the total raw byte budget. No retry/run fallback
    is implicit. Cancellation is cooperative between reads and before decoding.
    """
    spec=_request(request)
    directory=Path(output_dir)
    existed=directory.exists()
    if existed and not resume: raise WeatherError("OUTPUT_EXISTS",directory)
    if estimate_decode_bytes(spec)>MAX_DECODE_BYTES:
        raise WeatherError("DECODE_MEMORY_LIMIT","Estimated working memory exceeds the 512 MiB admission limit.")
    decoder=_decoder_identity()
    directory.mkdir(parents=True,exist_ok=resume)
    def save(name,value):
        temporary=directory/(name+"."+uuid.uuid4().hex+".tmp")
        with temporary.open("x",encoding="utf-8") as stream:
            json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary,directory/name)
    if existed:
        if read_json(directory/"request.json")!=spec:
            raise WeatherError("REQUEST_MISMATCH","Resume cannot change the fixed request.")
        if not (directory/"decoder.json").exists() or read_json(directory/"decoder.json")!=decoder:
            raise WeatherError("DECODER_CHANGED","Resume requires the same decoder; preserve old raw data for explicit replay.")
        provenance=read_json(directory/"provenance.json") if (directory/"provenance.json").exists() else []
    else:
        save("request.json",spec)
        save("decoder.json",decoder)
        provenance=[]
        save("provenance.json",provenance)
    if not isinstance(provenance,list) or len(provenance)>len(spec["lead_hours"]):
        raise WeatherError("PROVENANCE_MISMATCH","Invalid completed raw entries.")
    paths=[]; reused=0; downloaded=0
    for item,lead in zip(provenance,spec["lead_hours"]):
        if not isinstance(item,dict) or item.get("file")!=f"f{lead:03d}.grib2" or item.get("url")!=_url(spec,lead):
            raise WeatherError("PROVENANCE_MISMATCH","Completed entries must be the exact schedule prefix.")
        path=directory/item["file"]
        data=path.read_bytes()
        if len(data)!=item.get("bytes") or hashlib.sha256(data).hexdigest()!=item.get("sha256") or data[:4]!=b"GRIB":
            raise WeatherError("RAW_HASH_MISMATCH",path.name)
        paths.append(path); reused+=len(data)
    # Incomplete bytes are retained for diagnosis, never silently re-used or deleted.
    for lead in spec["lead_hours"][len(paths):]:
        orphan=directory/f"f{lead:03d}.grib2"
        if orphan.exists():
            # A crash may occur after the raw rename and before its receipt.
            # Without a receipt do not trust/reuse it; preserve it as partial.
            orphan.rename(orphan.with_name(orphan.name+"."+uuid.uuid4().hex+".partial"))
    retained=sum(p.stat().st_size for p in directory.glob("*.grib2.*.partial"))
    remaining=spec["max_bytes"]-reused-retained
    def report(phase,lead=None):
        if progress:
            progress({"phase":phase,"completed_files":len(paths),"total_files":len(spec["lead_hours"]),
                      "bytes_downloaded":downloaded,"bytes_reused":reused,"retained_partial_bytes":retained,"lead":lead})
    target=directory/"weather.json.gz"
    if target.exists():
        if len(paths)!=len(spec["lead_hours"]) or not (directory/"receipt.json").exists():
            raise WeatherError("INCOMPLETE_PUBLICATION","Existing bundle has no complete receipt; inspect before retry.")
        receipt=read_json(directory/"receipt.json")
        if hashlib.sha256(target.read_bytes()).hexdigest()!=receipt.get("bundle_sha256"):
            raise WeatherError("BUNDLE_HASH_MISMATCH",target.name)
        report("completed")
        return target
    try:
        check_cancel(cancel)
        for lead in spec["lead_hours"][len(paths):]:
            report("downloading",lead)
            check_cancel(cancel)
            path=directory/f"f{lead:03d}.grib2"
            info=_download(_url(spec,lead),path,remaining,cancel=cancel)
            remaining-=info["bytes"]; downloaded+=info["bytes"]; provenance.append(info); paths.append(path)
            save("provenance.json",provenance)
            report("downloading",lead)
        check_cancel(cancel)
        report("decoding")
        bundle=decode_gfs(paths,spec,provenance)
        check_cancel(cancel)
        temporary=directory/("weather."+uuid.uuid4().hex+".json.gz.partial")
        write_bundle(temporary,bundle)
        save("receipt.json",{"bundle":target.name,"bundle_sha256":hashlib.sha256(temporary.read_bytes()).hexdigest(),
                            "downloaded_bytes":downloaded,"reused_bytes":reused,"retained_partial_bytes":retained,
                            "raw_files":len(paths)})
        temporary.rename(target)
        report("completed")
        return target
    except Exception as exc:
        current_retained=sum(p.stat().st_size for p in directory.glob("*.grib2.*.partial"))
        downloaded+=max(0,current_retained-retained)
        retained=current_retained
        save("failure.json",{"type":type(exc).__name__,"detail":str(exc),"completed_raw_files":len(paths),
                             "bytes_downloaded":downloaded,"bytes_reused":reused,"retained_partial_bytes":retained})
        report("cancelled" if getattr(exc,"code",None)=="ACQUISITION_CANCELLED" else "failed")
        raise
