"""HTTP-independent application service: drafts, immutable runs and one worker."""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
import copy
import json
import multiprocessing
import os
from pathlib import Path
import threading
import uuid

from balloon_sim.environment.storage import read_json
from balloon_sim.flight.config import FlightError, validate_config
from balloon_sim.environment.fields import _utc
from datetime import timedelta

from .contracts import ProjectUpdate, RunRequest
from .errors import ServiceError
from .storage import canonical, digest, file_hash, open_registry, publish_result, read_result, utc_now, write_new_json
from .worker import REPO_ROOT, execute_run, source_snapshot
from .weather.service import WeatherService


def default_data_dir():
    configured = os.environ.get("BALLOON_DATA_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share")))
    return base / "BalloonSimulator" / "state"


class ApplicationService:
    """Own one local state directory. Call start/close or use the context manager.

    At most one running flight and max_queued waiting flights. A separate server
    instance must use a different state directory; the process lock enforces it.
    """

    def __init__(self, data_dir=None, *, max_queued=4, weather_options=None):
        self.data_dir = Path(data_dir or default_data_dir()).resolve()
        if not isinstance(max_queued, int) or max_queued < 1:
            raise ValueError("max_queued must be a positive integer")
        self.max_queued = max_queued
        self._guard = threading.RLock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._executor = None
        self._thread = None
        self._db = None
        self._lock_file = None
        self._sources = {}
        self._source_errors = []
        self._snapshot = None
        self.weather = WeatherService(self.data_dir, on_source=self._register_weather_source,
                                      source_guard=self._assert_source_current,
                                      **(weather_options or {}))

    def _acquire_directory(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._lock_file = (self.data_dir / "service.lock").open("a+b")
        self._lock_file.seek(0)
        if os.name == "nt":
            import msvcrt
            if os.fstat(self._lock_file.fileno()).st_size == 0:
                self._lock_file.write(b"0")
                self._lock_file.flush()
            self._lock_file.seek(0)
            try:
                msvcrt.locking(self._lock_file.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                self._lock_file.close()
                self._lock_file = None
                raise RuntimeError("state directory is already in use") from None
        else:
            import fcntl
            try:
                fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                self._lock_file.close()
                self._lock_file = None
                raise RuntimeError("state directory is already in use") from None

    def start(self):
        with self._guard:
            if self._db is not None:
                return self
            self._acquire_directory()
            try:
                self._db = open_registry(self.data_dir)
                self._db.execute("UPDATE jobs SET state='interrupted',finished_at=?,error=? WHERE state IN ('queued','running')",
                                 (utc_now(), canonical({"code": "RESTART_INTERRUPTED", "message": "Previous execution did not finish; no automatic resubmission."})))
                self._db.commit()
                self._snapshot = source_snapshot()
                self._load_sources()
                self.weather.start()
                sources, errors = self.weather.source_records()
                for source in sources:
                    self._register_weather_source(source)
                self._source_errors.extend(errors)
                self._stop.clear()
                self._executor = ProcessPoolExecutor(max_workers=1, mp_context=multiprocessing.get_context("spawn"))
                self._thread = threading.Thread(target=self._dispatch, name="balloon-job-dispatch", daemon=True)
                self._thread.start()
            except BaseException:
                self.weather.close()
                if self._db:
                    self._db.close()
                self._db = None
                self._lock_file.close()
                self._lock_file = None
                raise
        return self

    def close(self):
        self.weather.close()
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join()  # Running work finishes; there is no false immediate cancellation.
        if self._executor:
            self._executor.shutdown(wait=True, cancel_futures=True)
        with self._guard:
            if self._db:
                self._db.close()
                self._db = None
            if self._lock_file:
                self._lock_file.close()
                self._lock_file = None

    def __enter__(self):
        return self.start()

    def __exit__(self, *args):
        self.close()

    def _load_sources(self):
        definitions = [("wakayama", "和歌山・保存GFS例", "wakayama-isothermal.json"),
                       ("hokkaido", "北海道・保存GFS例", "hokkaido-simple.json")]
        self._sources = {}
        self._source_errors = []
        for name, label, example in definitions:
            path = REPO_ROOT / "references" / "flight_fixture" / (name + "-weather.json.gz")
            source_id = name + "-gfs-fixture"
            try:
                # An unavailable or malformed source must not block result reopening.
                bundle = read_json(path)
                axes, metadata = bundle["axes"], bundle["metadata"]
                snapshot = {
                    "id": source_id, "label": label, "sha256": file_hash(path), "bytes": path.stat().st_size,
                    "kind": "fixture",
                    "run_utc": metadata.get("run_utc"), "valid_times_utc": axes["time_utc"],
                    "bounds": {"lat": [min(axes["latitude_deg"]), max(axes["latitude_deg"])],
                               "lon": [min(axes["longitude_deg"]), max(axes["longitude_deg"])],
                               "pressure_pa": [min(axes["pressure_pa"]), max(axes["pressure_pa"])]},
                    "metadata": metadata}
                default_config = validate_config(read_json(REPO_ROOT / "examples" / example))
                canonical(snapshot)
                self._sources[source_id] = {"path": path, "snapshot": snapshot, "default_config": default_config}
            except (OSError, ValueError, KeyError, TypeError) as exc:
                self._source_errors.append({"id": source_id, "label": label, "code": "SOURCE_UNAVAILABLE", "message": str(exc)})

    def _register_weather_source(self, source):
        with self._guard:
            self._sources[source["snapshot"]["id"]] = source

    def _assert_source_current(self):
        try:
            current = source_snapshot()
        except Exception as exc:
            raise ServiceError(409, "SOURCE_CHANGED", "Application source or environment cannot be verified; restart before new work.") from exc
        if self._snapshot is None or current != self._snapshot:
            raise ServiceError(409, "SOURCE_CHANGED", "Application source or environment changed after startup; restart before new work.")

    def weather_sources(self):
        with self._guard:
            return {"sources": [copy.deepcopy({**s["snapshot"], "default_config": s["default_config"]}) for s in self._sources.values()],
                    "source_errors": copy.deepcopy(self._source_errors)}

    def submit(self, request):
        request = RunRequest.model_validate(request).model_dump()
        try:
            request_hash = digest(request)
        except (ValueError, TypeError) as exc:
            raise ServiceError(422, "INVALID_JSON", "Input must contain finite JSON values.") from exc
        with self._guard:
            previous = self._db.execute("SELECT id,request_hash FROM runs WHERE client_request_id=?", (request["client_request_id"],)).fetchone()
            if previous:
                if previous["request_hash"] != request_hash:
                    raise ServiceError(409, "REQUEST_ID_CONFLICT", "This request ID already refers to different input.")
                return self._acceptance(previous["id"])
            source = self._sources.get(request["weather_source_id"])
            if source is None:
                raise ServiceError(422, "UNKNOWN_WEATHER_SOURCE", "Select an available saved weather source ID.")
            try:
                config = validate_config(request["config"])
            except FlightError as exc:
                raise ServiceError(422, exc.code, str(exc)) from exc
            if source["snapshot"].get("kind") == "acquired_gfs":
                times = source["snapshot"]["valid_times_utc"]
                launch = _utc(config["launch"]["time_utc"])
                end = launch + timedelta(seconds=config["integration"]["max_duration_s"])
                if launch < _utc(times[0]) or end > _utc(times[-1]):
                    raise ServiceError(422, "WEATHER_WINDOW_UNSUPPORTED", "The selected field must support launch through the full integration duration; re-plan after time or delay edits.")
            self._assert_source_current()
            if file_hash(source["path"]) != source["snapshot"]["sha256"]:
                raise ServiceError(409, "WEATHER_CHANGED", "Saved weather changed; restart and inspect its identity.")
            queued = self._db.execute("SELECT count(*) FROM jobs WHERE state='queued'").fetchone()[0]
            if queued >= self.max_queued:
                raise ServiceError(429, "QUEUE_FULL", "The finite waiting queue is full; no run was created.")
            run_id, job_id = str(uuid.uuid4()), str(uuid.uuid4())
            spec = {"schema": "balloon.run/1", "run_id": run_id, "trial_id": run_id + ":1", "n": 1, "weight": 1,
                    "submitted_input": request, "config": config, "weather_snapshot": copy.deepcopy(source["snapshot"]),
                    "source_snapshot": copy.deepcopy(self._snapshot)}
            fixed = {"config": config, "weather_snapshot": spec["weather_snapshot"], "source_snapshot": self._snapshot}
            spec["frozen_input_hash"] = digest(fixed)
            folder = self.data_dir / "specs" / run_id
            folder.mkdir()
            write_new_json(folder / "config.json", config)
            spec["config_file_sha256"] = file_hash(folder / "config.json")
            write_new_json(folder / "run.json", spec)
            with self._db:
                self._db.execute("INSERT INTO runs VALUES (?,?,?,?,?,NULL,NULL)", (run_id, request["client_request_id"], request_hash, canonical(spec), utc_now()))
                self._db.execute("INSERT INTO jobs VALUES (?,?,'queued',NULL,NULL,NULL)", (job_id, run_id))
            self._wake.set()
            return self._acceptance(run_id)

    def _row(self, run_id):
        row = self._db.execute("SELECT r.*,j.id AS job_id,j.state,j.started_at,j.finished_at,j.error FROM runs r JOIN jobs j ON r.id=j.run_id WHERE r.id=?", (run_id,)).fetchone()
        if not row:
            raise ServiceError(404, "RUN_NOT_FOUND", "Run does not exist.")
        return row

    def _summary(self, row):
        spec = json.loads(row["spec"])
        request = spec["submitted_input"]
        return {"run_id": row["id"], "job_id": row["job_id"], "state": row["state"],
                "label": request["label"], "candidate_id": request["candidate_id"], "candidate_revision": request["candidate_revision"],
                "weather_source_id": request["weather_source_id"], "created_at": row["created_at"],
                "result_available": row["result_path"] is not None and row["state"] == "completed",
                "cancellable": row["state"] == "queued", "frozen_input_hash": spec["frozen_input_hash"],
                "error": json.loads(row["error"]) if row["error"] else None}

    def _acceptance(self, run_id):
        detail = self._summary(self._row(run_id))
        return {key: detail[key] for key in ("run_id", "job_id", "state", "frozen_input_hash")}

    def list_runs(self):
        with self._guard:
            rows = self._db.execute("SELECT id FROM runs ORDER BY created_at DESC,id DESC").fetchall()
            return {"runs": [self._summary(self._row(row["id"])) for row in rows]}

    def get_run(self, run_id):
        with self._guard:
            row = self._row(run_id)
            return {**self._summary(row), "spec": json.loads(row["spec"]), "started_at": row["started_at"], "finished_at": row["finished_at"]}

    def get_result(self, run_id):
        with self._guard:
            row = self._row(run_id)
            if not row["result_path"] or row["state"] != "completed":
                raise ServiceError(409, "RESULT_NOT_AVAILABLE", "This run has no committed result.")
            spec = json.loads(row["spec"])
            try:
                result = read_result(self.data_dir, row["result_path"], row["manifest_hash"], run_id)
            except (ValueError, OSError, KeyError) as exc:
                raise ServiceError(500, "RESULT_INTEGRITY_ERROR", "Saved result failed integrity verification.") from exc
            return {"run_id": run_id, "trial_id": spec["trial_id"], "n": 1, "weight": 1,
                    "weather_snapshot": spec["weather_snapshot"], "source_snapshot": spec["source_snapshot"], "result": result}

    def cancel(self, run_id):
        with self._guard:
            row = self._row(run_id)
            if row["state"] != "queued":
                raise ServiceError(409, "NOT_CANCELLABLE", "Only waiting work can be cancelled; running computation cannot be stopped here.")
            with self._db:
                self._db.execute("UPDATE jobs SET state='cancelled',finished_at=? WHERE run_id=?", (utc_now(), run_id))
            return self.get_run(run_id)

    def get_project(self):
        with self._guard:
            row = self._db.execute("SELECT * FROM projects WHERE id='default'").fetchone()
            return {"revision": row["revision"], "project": json.loads(row["document"])}

    def save_project(self, update):
        update = ProjectUpdate.model_validate(update).model_dump(by_alias=True)
        project = update["project"]
        try:
            canonical(project)  # reject NaN/Infinity even in incomplete drafts
        except (ValueError, TypeError) as exc:
            raise ServiceError(422, "INVALID_JSON", "Draft must contain finite JSON values.") from exc
        with self._guard:
            current = self.get_project()
            if update["expected_revision"] != current["revision"]:
                raise ServiceError(409, "PROJECT_REVISION_CONFLICT", "Draft changed since it was read; reload before saving.")
            if len({c["id"] for c in project["candidates"]}) != len(project["candidates"]):
                raise ServiceError(422, "DUPLICATE_CANDIDATE", "Candidate IDs must be unique.")
            by_id = {c["id"]: c for c in project["candidates"]}
            for candidate in project["candidates"]:
                parent_id = candidate["parent_id"]
                if parent_id is None:
                    if candidate["delay_minutes"] is not None:
                        raise ServiceError(422, "INVALID_DELAY_PARENT", "A delay requires a parent candidate.")
                    continue
                if parent_id not in by_id or candidate["delay_minutes"] is None:
                    raise ServiceError(422, "INVALID_DELAY_PARENT", "A dependent candidate needs an existing parent and an explicit delay.")
                seen = {candidate["id"]}
                while parent_id is not None:
                    if parent_id in seen:
                        raise ServiceError(422, "CYCLIC_CANDIDATES", "Dependent candidates must not form a cycle.")
                    seen.add(parent_id)
                    parent = by_id.get(parent_id)
                    if parent is None:
                        raise ServiceError(422, "INVALID_DELAY_PARENT", "The parent chain contains a missing candidate.")
                    parent_id = parent["parent_id"]
            if len(set(project["compare_run_ids"])) != len(project["compare_run_ids"]):
                raise ServiceError(422, "DUPLICATE_COMPARISON", "A fixed result can only appear once in a comparison.")
            for run_id in project["compare_run_ids"]:
                row = self._row(run_id)
                if row["state"] != "completed" or not row["result_path"]:
                    raise ServiceError(409, "COMPARISON_RESULT_NOT_READY", "Comparison selections require committed results; the previous selection was kept.")
            with self._db:
                self._db.execute("UPDATE projects SET revision=revision+1,document=? WHERE id='default'", (canonical(project),))
            return self.get_project()

    def _dispatch(self):
        while not self._stop.is_set():
            with self._guard:
                row = self._db.execute("SELECT r.id,r.spec FROM runs r JOIN jobs j ON r.id=j.run_id WHERE j.state='queued' ORDER BY r.created_at,r.id LIMIT 1").fetchone()
                if row:
                    with self._db:
                        self._db.execute("UPDATE jobs SET state='running',started_at=? WHERE run_id=?", (utc_now(), row["id"]))
            if not row:
                self._wake.wait(0.25)
                self._wake.clear()
                continue
            run_id, spec = row["id"], json.loads(row["spec"])
            try:
                source = self._sources[spec["weather_snapshot"]["id"]]
                future = self._executor.submit(execute_run, spec, str(source["path"]),
                                               str(self.data_dir / "specs" / run_id / "config.json"),
                                               str(self.data_dir / "staging" / run_id))
                completion = future.result()
                if completion["run_id"] != run_id:
                    raise ValueError("worker returned a different run")
                path, marker_hash = publish_result(self.data_dir, run_id, spec)
                with self._guard, self._db:
                    self._db.execute("UPDATE runs SET result_path=?,manifest_hash=? WHERE id=?", (path, marker_hash, run_id))
                    self._db.execute("UPDATE jobs SET state='completed',finished_at=? WHERE run_id=?", (utc_now(), run_id))
            except Exception as exc:
                error = {"code": "EXECUTION_FAILED", "message": str(exc)}
                with self._guard, self._db:
                    self._db.execute("UPDATE jobs SET state='failed',finished_at=?,error=? WHERE run_id=?", (utc_now(), canonical(error), run_id))
