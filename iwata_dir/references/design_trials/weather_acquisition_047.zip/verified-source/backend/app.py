"""FastAPI transport and optional built frontend; no scientific computation here."""
from contextlib import asynccontextmanager
import os
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .application import ApplicationService, ServiceError
from .contracts import ProjectUpdate, RunRequest
from .worker import REPO_ROOT
from .weather.contracts import AcquisitionRequest, InventoryRefresh, WeatherPlanRequest


def create_app(data_dir=None, *, weather_options=None):
    service = ApplicationService(data_dir, weather_options=weather_options)

    @asynccontextmanager
    async def lifespan(app):
        service.start()
        try:
            yield
        finally:
            service.close()

    app = FastAPI(title="Balloon Simulator local application", version="0.47.0", lifespan=lifespan)
    app.state.service = service

    @app.middleware("http")
    async def json_mutations(request: Request, call_next):
        if request.url.path.startswith("/api/") and request.method in {"POST", "PUT"}:
            content_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
            if content_type != "application/json":
                return JSONResponse(status_code=415, content={"error": {"code": "JSON_REQUIRED", "message": "Use application/json."}})
        return await call_next(request)

    @app.exception_handler(ServiceError)
    async def service_error(request: Request, exc: ServiceError):
        return JSONResponse(status_code=exc.status, content={"error": {"code": exc.code, "message": str(exc)}})

    @app.get("/api/v1/health")
    def health():
        return {"status": "ok", "version": "0.47.0", "workers": 1, "max_queued": service.max_queued}

    @app.get("/api/v1/weather-sources")
    def weather_sources():
        return service.weather_sources()

    @app.get("/api/v1/weather-status")
    def weather_status():
        return service.weather.status()

    @app.post("/api/v1/weather-inventories/refresh")
    def refresh_weather_inventory(request: InventoryRefresh):
        return service.weather.refresh_inventory(request.model_dump())

    @app.get("/api/v1/weather-inventories")
    def weather_inventories():
        return service.weather.list_inventories()

    @app.get("/api/v1/weather-inventories/{identity}")
    def weather_inventory(identity: str):
        return service.weather.get_inventory(identity)

    @app.post("/api/v1/weather-plans", status_code=201)
    def plan_weather(request: WeatherPlanRequest):
        return service.weather.plan(request.model_dump())

    @app.get("/api/v1/weather-plans/{identity}")
    def weather_plan(identity: str):
        return service.weather.get_plan(identity)

    @app.post("/api/v1/weather-acquisitions", status_code=202)
    def acquire_weather(request: AcquisitionRequest):
        return service.weather.submit(request.model_dump())

    @app.get("/api/v1/weather-acquisitions")
    def weather_acquisitions():
        return service.weather.list_jobs()

    @app.get("/api/v1/weather-acquisitions/{identity}")
    def weather_acquisition(identity: str):
        return service.weather.get_job(identity)

    @app.post("/api/v1/weather-acquisitions/{identity}/cancel")
    def cancel_weather(identity: str):
        return service.weather.cancel(identity)

    @app.post("/api/v1/weather-acquisitions/{identity}/retry", status_code=202)
    def retry_weather(identity: str):
        return service.weather.retry(identity)

    @app.post("/api/v1/runs", status_code=202)
    def submit(request: RunRequest):
        return service.submit(request.model_dump())

    @app.get("/api/v1/runs")
    def runs():
        return service.list_runs()

    @app.get("/api/v1/runs/{run_id}")
    def run(run_id: str):
        return service.get_run(run_id)

    @app.get("/api/v1/runs/{run_id}/result")
    def result(run_id: str):
        return service.get_result(run_id)

    @app.post("/api/v1/runs/{run_id}/cancel")
    def cancel(run_id: str):
        return service.cancel(run_id)

    @app.get("/api/v1/project")
    def project():
        return service.get_project()

    @app.put("/api/v1/project")
    def save_project(request: ProjectUpdate):
        return service.save_project(request.model_dump(by_alias=True))

    dist = Path(os.environ["BALLOON_FRONTEND_DIST"]).expanduser().resolve() if os.environ.get("BALLOON_FRONTEND_DIST") else REPO_ROOT / "frontend" / "dist"
    if (dist / "index.html").is_file():
        for name in ("assets", "scene3d", "cesium"):
            if (dist / name).is_dir():
                app.mount("/" + name, StaticFiles(directory=dist / name, html=True), name=name)

        @app.get("/")
        def index():
            return FileResponse(dist / "index.html")
    else:
        @app.get("/", response_class=HTMLResponse)
        def not_built():
            return "<h1>Frontend is not built</h1><p>Run npm ci and npm run build in frontend, then restart this server.</p><p>API: <a href='/docs'>/docs</a></p>"
    return app
