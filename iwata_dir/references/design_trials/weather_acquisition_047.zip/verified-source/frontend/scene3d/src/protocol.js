import {fitBoundsDistance} from './camera-fit.js';
export const SCHEMA='bjp-scene3d-v2';
export const KINDS=['landing','contour','contour-band','region','mean-route','mean-landing','launch','stop','support-boundary'];
const id=v=>(typeof v==='string' && v.length>0) || (typeof v==='number' && Number.isFinite(v));
const coord=c=>Array.isArray(c)&&c.length===2&&Number.isFinite(c[0])&&Number.isFinite(c[1])&&Math.abs(c[0])<=180&&Math.abs(c[1])<=90;
function require(ok,message){if(!ok)throw new Error(message);}
function line(cs,min=2){require(Array.isArray(cs)&&cs.length>=min&&cs.every(coord),'座標列は有限の経度・緯度で指定してください');}
function polygon(rs){require(Array.isArray(rs)&&rs.length>0,'輪郭のリングがありません');for(const r of rs){line(r,4);require(r[0][0]===r.at(-1)[0]&&r[0][1]===r.at(-1)[1],'輪郭は閉じている必要があります');}}
export function validatePayload(raw){
 const p=structuredClone(raw);require(p&&id(p.snapshotId)&&typeof p.artificial==='boolean','結果出所と snapshotId が必要です');
 require(typeof p.collectionKey==='string'&&p.collectionKey.length>0,'結果集合の同一性がありません');
 require(['overview','detail'].includes(p.context?.kind),'概要または詳細の文脈が必要です');
 require(Array.isArray(p.candidates)&&p.candidates.length>0,'候補catalogがありません');
 const keys=new Map(),ids=new Set();for(const c of p.candidates){require(id(c.candidateId),'候補IDがありません');require(!ids.has(c.candidateId),'候補IDが重複しています');ids.add(c.candidateId);require(typeof c.available==='boolean'&&typeof c.visible==='boolean'&&typeof c.focused==='boolean','候補の計算・可視・注目状態がありません');require(c.available?id(c.resultId):c.resultId===null,'計算状態と結果IDが一致しません');require(c.parentId===null||id(c.parentId),'親IDが不正です');require(Number.isFinite(c.delayMinutes)&&c.delayMinutes>=0,'遅延値が不正です');keys.set(JSON.stringify([c.candidateId,c.resultId]),c);}
 require(p.candidates.filter(c=>c.focused).length<=1,'注目候補が複数あります');
 if(p.context.kind==='overview')for(const c of p.candidates){const seen=new Set([c.candidateId]);let parentId=c.parentId;while(parentId!==null){require(ids.has(parentId)&&!seen.has(parentId),'親子関係が不正です');seen.add(parentId);parentId=p.candidates.find(x=>x.candidateId===parentId).parentId;}}
 require(p.geojson?.type==='FeatureCollection'&&Array.isArray(p.geojson.features),'GeoJSON FeatureCollection が必要です');
 for(const f of p.geojson.features){const g=f.geometry,k=f.properties?.kind;require(f.type==='Feature'&&g,'geometry がありません');require(KINDS.includes(k),'未定義の表示種別です');
  const types={landing:['Point'],'mean-landing':['Point'],launch:['Point'],stop:['Point'],contour:['Polygon','MultiPolygon'],'contour-band':['Polygon','MultiPolygon'],region:['Polygon','MultiPolygon'],'support-boundary':['Polygon','MultiPolygon'],'mean-route':['LineString']};require(types[k].includes(g.type),'表示種別とgeometryが一致しません');
  if(!['region','support-boundary','launch'].includes(k)){const c=keys.get(JSON.stringify([f.properties.candidateId,f.properties.resultId]));require(c&&c.available&&(p.context.kind==='detail'||c.visible),'表示対象外の候補・結果が含まれています');if(k==='contour-band')require(c.focused&&p.context.kind==='overview','分位帯は概要の注目候補だけです');}
  if(g.type==='Point')require(['landing','mean-landing','launch','stop'].includes(k)&&coord(g.coordinates),'点の座標が不正です');
  else if(g.type==='LineString'){require(k==='mean-route'||k==='contour','線の種別が不正です');line(g.coordinates);}
  else if(g.type==='Polygon')polygon(g.coordinates);
  else if(g.type==='MultiPolygon'){require(g.coordinates.length>0,'空のMultiPolygonです');g.coordinates.forEach(polygon);}
  else throw new Error('未対応のgeometryです: '+g.type);
  if(k==='contour'||k==='contour-band')require([.5,.9,.95].includes(f.properties.level),'輪郭水準は50/90/95%を指定してください');
  if(k==='contour-band'){const lo={0.5:0,0.9:.5,0.95:.9};require(f.properties.lowerLevel===lo[f.properties.level],'分位帯の下限が一致しません');require(Number.isFinite(f.properties.fillOpacity)&&f.properties.fillOpacity>=0&&f.properties.fillOpacity<=1,'帯の不透明度が不正です');}
 }
 require(coord(p.camera?.center),'camera.center は [経度,緯度] が必要です');
 const b=p.camera.bounds;require(Array.isArray(b)&&b.length===4&&b.every(Number.isFinite)&&b[0]<b[2]&&b[1]<b[3]&&coord([b[0],b[1]])&&coord([b[2],b[3]]),'camera.bounds が不正です');
 if(p.context?.kind==='detail'){const ctx=p.context,s=ctx.selection;require(p.candidates.length===1&&p.candidates[0].candidateId===ctx.activeCandidateId&&p.candidates[0].available,'詳細の対象候補が一致しません');require(s&&Array.isArray(s.sampleIds)&&Number.isInteger(s.count)&&s.count===s.sampleIds.length&&s.count>=0&&Number.isInteger(s.denominator)&&s.count<=s.denominator,'詳細の選択数とIDが一致しません');const selected=new Set(s.sampleIds);require(selected.size===s.count,'詳細の選択IDが重複しています');const points=p.geojson.features.filter(f=>(f.properties.kind==='landing'||(!p.artificial&&f.properties.kind==='stop')));require(points.length===s.count&&points.every(f=>selected.has(f.properties.sampleId)),'詳細の選択集合と落下点が一致しません');require(ctx.contours==='none'&&!p.geojson.features.some(f=>['contour','contour-band'].includes(f.properties.kind)),'2D詳細にない輪郭が含まれています');}
 return p;
}
export function receipt(p){return {schema:SCHEMA,snapshotId:p.snapshotId,collectionKey:p.collectionKey,context:structuredClone(p.context),candidates:p.candidates.map(c=>({candidateId:c.candidateId,resultId:c.resultId,parentId:c.parentId,delayMinutes:c.delayMinutes,available:c.available,visible:c.visible,focused:c.focused,pending:c.pending===true,shownLandingCount:c.shownLandingCount??null})),featureCounts:Object.fromEntries(KINDS.map(k=>[k,p.geojson.features.filter(f=>f.properties.kind===k).length])),camera:structuredClone(p.camera),artificial:p.artificial,recalculated:false,projectionTarget:'3D Tiles surface; actual provider state is separate'};}
export function cameraFor(p,viewport){return {lng:p.camera.center[0],lat:p.camera.center[1],height:0,distance:fitBoundsDistance(p.camera.bounds,p.camera.center,viewport),heading:0,pitch:-48,roll:0};}
