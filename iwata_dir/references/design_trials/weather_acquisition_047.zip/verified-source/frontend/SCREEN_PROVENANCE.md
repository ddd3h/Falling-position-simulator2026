# 0.47 画面の出典と現役化境界

元資料は `references/design_trials/hover_surface_pick_correction_0401.zip`（SHA256 `8356df3cc8f2184d5418fe3d84d1e1d274b7646f3b81be6210c07094b3d7a214`）内の `workflow-ui-0401/`。原ZIPは変更しない。完成していた用途別の画面配置、候補と延期列、概要から選択詳細、気象の4画面、季節計画、2Dと3Dの関係を具体的なDOM/CSS/描画として引き継ぐ。

## 現役ソースの対応

| 元資料内の実体 | 現役の実体 | 変更する境界 |
|---|---|---|
| forecast/index.html, style.css | src/screens/forecast/markup.html, screen.css | 共通headerをAppへ。rootスコープのCSS。実入力と保存気象の専用portal |
| forecast/app.js, core340.js | src/screens/forecast/controller.js | coreの宣言を同じcontrollerのlexical scopeへ統合。実モードではReactのreadonly投影と操作意図を使う |
| forecast/data.js, math.js, season-adapter.js | 同名のsrc/screens/forecast/下 | 人工例だけの計算経路。install(scope)で局所依存にする |
| forecast/scene-document.js, export390.js, appearance390.js, map-style-guard401.js, hover400.mjs, hover-geometry400.mjs | 同名のsrc/screens/forecast/下 | 実結果の出所、ASL、停止点、スコープ寿命と独立した固定Leaflet stylesheetの検証へ適応 |
| weather/index.html, style.css, app.js | src/screens/weather/markup.html, screen.css, controller.js | 共通shell、保存した分析条件、季節提案への受渡し |
| weather/fixture.js, direction-key.js, impact-map.js | 同名のsrc/screens/weather/下 | 実過去場へ接続済みと扱わず人工例を保持。0.47では通常地図を初期表示し、写真へ切替 |
| shared/scene-style.js, hover-labels.mjs, band-readout.mjs | src/screens/shared/下 | 2D/3D/出力の共通表示定義 |
| scene3d/index.html, style.css, src/*, fixtures/* | frontend/scene3d/下 | 既存rendererのiframe境界を保持。人工/実source flag、原実軌道、停止群を受領 |

Reactの `App` / `useWorkspace` が実候補、草案、固定runの選択、保存計画の正本。`ForecastScreen`→`projection`→controllerはその読取投影で、controllerは再び候補を勝手に計算・上書きしない。controllerから編集・候補追加・延期作成・実行・削除・復元の意図をAppへ返す。map視点、選択ID、色、表示状態はcontrollerの局所状態を `ui_state.forecast_real` へ保存する。

`forecast_fixture` / `weather_fixture` / `season_fixture` は同じ保存計画の別namespace。実の風や履歴の欠測を人工データで補完しない。実n=1では原recordの不等間隔時刻、相境界、着地/停止を保持し、50/90/95%域は標本不足のため生成しない。季節・気象の操作画面は人工例であり、実再解析統計への接続は未完了。

## 配布と依存

`npm ci` のlockfileでLeaflet 1.9.4、Plotly 4.1.1、Cesium 1.145.0を固定。旧ZIPのvendor巨大bundleを別に複製せずnpmの同版を使用する。`vite.config.ts` がbuild時に `frontend/scene3d`→`<build.outDir>/scene3d`、npm Cesium build→`<build.outDir>/cesium`、Leaflet画像→`<build.outDir>/assets/images` を生成し、Python APIが同URLで配信する。Google写真タイルとキーは保存しない。写真接続は手動操作であり、自動で再接続しない。

`scene3d/THIRD_PARTY_NOTICES.txt` は当該固定npmパッケージのLICENSEとCesium ThirdParty情報を収録する。旧ZIPの説明だけを現パッケージのライセンス根拠にしない。

## 保持する旧実体

0.45の `src/MapPanel.tsx`, `src/HistoryPanel.tsx`, `src/style.css` は比較用の過去実装として保持されるが、現 `App`/`main` からimportされない。`src/screens/forecast/core340.js` は元分割の照合用保持で、現controllerでは同内容を同一scopeへ統合して使う。`scene3d/src/receipt-status.js` は旧rendererの受領状態補助で現importなし。これらを現役の画面依存として構造図へ描かない。

本資料は出典・所有境界を示す。操作行程の受入と未確認はS35および主担当の検証記録に戻る。


## 機能照合後の補修

0.40.1 r2の画面機能を照合し、旧headにあった `mapDisplayGuardStyle` を予報markup内のrootスコープinline CSSへ復元した。これはLeaflet stylesheetの再取得とは別に、CSS故障中のpane不可視化と画面外への流出防止を担う。人工候補JSONの保存は旧処理を保持し、候補管理の「人工候補JSONを開く」から旧形式を復元する。共通APIの計画・実固定結果の読込とは区別する。

同じForecast画面での2D/3D往復はrenderer iframeと接続を保持する。一方、実/人工の表示データ切替、気象/季節への用途変更、保存計画reloadでは画面をunmountするため3D接続も終了する。接続を保ったままこれらを切り替えられるとは扱わない。人工候補の削除直後undoは保持し、実候補では固定runを残して草案から外す。実候補の即時undoは未接続と表示する。

## 0.47 実取得と条件編集の接点

旧画面の共通準備に `WeatherPreparation` をportalとして置く。保存した配布一覧を明示更新し、初期時刻を固定、候補familyの放球〜最大飛行時間から取得計画を作り、進捗・取消・再試行を経て完成気象を明示適用する。`weatherAcquisition` はこのAPI形と入力/適用前の必要条件を扱い、`api` が実APIへ送る。`useWorkspace.refreshSources` は源一覧だけを更新し、草案・固定run・表示選択をreloadしない。取得する気象の有効時刻はrun+leadから示す。地図の橙破線は取得計画、灰破線は表示結果の保存気象で、人工分散とは別の情報である。

`ConfigEditor` は現在選択中の科学入力をCandidate.configに置く。非選択方式の編集値は `ui_state.forecast_real.editor_models[candidateId]` へ保持し、`modelDrafts` の純粋な切替関数で退避/復元する。AppはconfigとこのUI値を一つの更新として保存する。既存保存計画に退避値がない場合、別方式は初期値から始める。取得フォーム・選択plan/job IDは同namespaceのweatherPreparationへ置き、計画内容/取得状態の正本はAPIに保存される。

通常地図stdを初期表示し、noneを製品選択肢から除いた。地図の通信失敗は背景の案内と再試行に局在させ、計算結果/入力/領域/3D接続を再作成しない。用途の終了後に古いタイルや気象図用画像の応答が新画面へ書き込まないよう寿命・世代で破棄する。Google写真3Dの接続方法・キー寿命は変更しない。0.47の有限検査と実操作はS36に記録する。

共通準備は地図を覆う旧絶対配置から通常の文書flowへ変更し、気象/禁止領域を切り替える。気象の取得条件・固定計画・取得適用は表示段階のみを切り替え、DOMと入力を維持する。全段に取得状況の短い表示を残し、取得完了だけでは段階遷移・候補適用を起こさない。地図での確認は準備を畳み、run/必要窓/新旧境界の区別と条件へ戻る入口を地図側に残す。これは実取得行程を成熟画面へ接続するための面積・導線変更であり、候補や分散の表示構造を再発明する変更ではない。
