import {Component,useEffect,useRef,useState} from 'react';
import {useWorkspace} from './useWorkspace';
import {ForecastScreen} from './screens/ForecastScreen';
import {WeatherScreen} from './screens/WeatherScreen';
import {stableString,jstInputToUtc} from './domain';
import {applyCandidateWeather,type ModelDrafts} from './modelDrafts';
import type {Candidate,Project} from './domain';
import './platform.css';

class ScreenBoundary extends Component<{children:any},{error:string}>{state={error:''};static getDerivedStateFromError(error:unknown){return {error:error instanceof Error?error.message:String(error)};}render(){return this.state.error?<div className="platform-error" role="alert"><b>画面処理を停止しました。</b><p>{this.state.error}</p><p>入力と固定結果は共通の計画に保持しています。上部から別の用途へ移動するか、保存した計画を読み直してください。</p></div>:this.props.children;}}

type Place='forecast_real'|'forecast_fixture'|'weather_fixture'|'season_fixture';
export function App(){
 const ws=useWorkspace(),ref=useRef(ws);ref.current=ws;
 const [place,setPlace]=useState<Place>('forecast_real'),[library,setLibrary]=useState(false);
 const ui=ws.project.ui_state??{};
 function update(project:Project){ref.current.setProject(project);ref.current={...ref.current,project};}
 function keepView(key:Place,value:any){const current=ref.current.project;const nextView={...current.ui_state?.[key],...value};if(stableString(current.ui_state?.[key])===stableString(nextView))return;update({...current,ui_state:{...current.ui_state,schema:'balloon.ui/1',[key]:nextView}});}
 useEffect(()=>{if(ws.loading)return;const current=ref.current.project,view=current.ui_state?.forecast_real??{},codes={...view.codes};let changed=false;for(const c of current.candidates)if(!codes[c.id]){codes[c.id]='候補'+(Object.keys(codes).length+1);changed=true;}if(changed){const alias=(id:string)=>codes[id]??id;keepView('forecast_real',{codes,active:alias(view.active),groups:(view.groups??[]).map((g:any)=>({...g,members:g.members.map(alias)})),colors:Object.fromEntries(Object.entries(view.colors??{}).map(([id,v])=>[alias(id),v])),visibility:Object.fromEntries(Object.entries(view.visibility??{}).map(([id,v])=>[alias(id),v]))});}},[ws.loading,ws.restoration,ws.project.candidates]);
 function resolved(children:Candidate[],parent:Candidate){return children.map(c=>c.parent_id===parent.id?{...c,revision:c.revision+1,weather_source_id:parent.weather_source_id,config:{...structuredClone(parent.config),launch:{...parent.config.launch,time_utc:new Date(Date.parse(parent.config.launch.time_utc)+(c.delay_minutes??0)*60000).toISOString()}}}:c);}
 function change(candidate:Candidate,models?:ModelDrafts){const current=ref.current.project;const view=current.ui_state?.forecast_real??{};update({...current,candidates:resolved(current.candidates.map(c=>c.id===candidate.id?candidate:c),candidate),...(models?{ui_state:{...current.ui_state,forecast_real:{...view,editor_models:{...view.editor_models,[candidate.id]:models}}}}:{})});}
 function newId(_candidates:Candidate[]){return 'C-'+crypto.randomUUID();}
 function action(type:string,data:any){
  const current=ref.current.project,c=current.candidates.find(x=>x.id===data.id);
  if(type==='save'){void ref.current.save();return;}
  if(type==='weather-return'){if(data.source?.returnState)keepView('weather_fixture',data.source.returnState);setPlace('weather_fixture');return;}
  if(type==='library'){setLibrary(true);return;}
  if(type==='config'){change(data.candidate,data.models);return;}
  if(type==='weather-apply'){update(applyCandidateWeather(current,data.ids,data.sourceId));return;}
  if(type==='run'){if(c){void ref.current.start(c);for(const child of current.candidates.filter(x=>x.parent_id===c.id))void ref.current.start(child);}return;}
  if(type==='rename'&&c){change({...c,label:data.name,revision:c.revision+1});return;}
  if(type==='edit'&&c){const config=structuredClone(c.config);if(data.key==='origin'){config.launch.latitude_deg=data.value[0];config.launch.longitude_deg=data.value[1];}change({...c,config,revision:c.revision+1});return;}
  if(type==='add'||type==='duplicate'){
   const source=data.source??ref.current.sources.find(s=>s.id===c?.weather_source_id)??ref.current.sources[0];if(!source){ref.current.setMessage('保存気象を読み込んでから候補を追加してください。');return;}
   const id=newId(current.candidates),config=structuredClone(c?.config??source.default_config);if(config)delete config.label;
   if(!config){ref.current.setMessage('新しい取得場は既存候補へ適用してください。放球・モデル条件を自動で作りません。');return;}
   const next:Candidate={id,label:c?c.label+' の比較案':'新しい候補',revision:1,weather_source_id:source.id,config};
   update({...current,candidates:[...current.candidates,next],ui_state:{...current.ui_state,forecast_real:{...current.ui_state?.forecast_real,editor_models:{...current.ui_state?.forecast_real?.editor_models,[id]:structuredClone(current.ui_state?.forecast_real?.editor_models?.[c?.parent_id??c?.id??'']??{})},codes:{...current.ui_state?.forecast_real?.codes,[id]:'候補'+(Object.keys(current.ui_state?.forecast_real?.codes??{}).length+1)},active:'候補'+(Object.keys(current.ui_state?.forecast_real?.codes??{}).length+1),detail:false}}});return;
  }
  if(type==='detach'&&c){change({...c,parent_id:null,delay_minutes:null,revision:c.revision+1},structuredClone(current.ui_state?.forecast_real?.editor_models?.[c.parent_id??'']??{}));return;}
  if(type==='delays'&&c){
   const delays:number[]=data.delays;let candidates=current.candidates.filter(x=>x.parent_id!==c.id||delays.includes(x.delay_minutes??-1));
   for(const delay of delays)if(!candidates.some(x=>x.parent_id===c.id&&x.delay_minutes===delay)){const id=newId(candidates);candidates.push({...structuredClone(c),id,label:c.label+' ＋'+delay+'分',revision:1,parent_id:c.id,delay_minutes:delay});}
   candidates=resolved(candidates,c);
   const ids=new Set(candidates.map(x=>x.id));const view=current.ui_state?.forecast_real??{};const codes={...view.codes};for(const child of candidates)if(!codes[child.id])codes[child.id]='候補'+(Object.keys(codes).length+1);const aliases=new Set(candidates.map(x=>codes[x.id]??x.id));
   update({...current,candidates,compare_run_ids:current.compare_run_ids.filter(id=>ids.has(ref.current.runs.find(r=>r.run_id===id)?.candidate_id??'')),ui_state:{...current.ui_state,forecast_real:{...view,codes,groups:(view.groups??[]).map((g:any)=>({...g,members:g.members.filter((id:string)=>aliases.has(id))}))}}});
   ref.current.setMessage('延期候補の草案を作りました。親の「この条件で計算」で親と延期列を実行します。旧結果は保持しています。');return;
  }
  if(type==='remove'){
   const removed=new Set(data.ids);const candidates=current.candidates.filter(x=>!removed.has(x.id)&&!removed.has(x.parent_id));const ids=new Set(candidates.map(x=>x.id));const view=current.ui_state?.forecast_real??{};const aliases=new Set(candidates.map(x=>view.codes?.[x.id]??x.id));
   update({...current,candidates,compare_run_ids:current.compare_run_ids.filter(id=>ids.has(ref.current.runs.find(r=>r.run_id===id)?.candidate_id??'')),ui_state:{...current.ui_state,forecast_real:{...view,active:aliases.has(view.active)?view.active:(view.codes?.[candidates[0]?.id]??candidates[0]?.id??''),detail:false,groups:(view.groups??[]).map((g:any)=>({...g,members:g.members.filter((id:string)=>aliases.has(id))})).filter((g:any)=>g.members.length>0)}}});return;
  }
  if(type==='revert'&&c){const run=ref.current.runs.find(r=>r.candidate_id===c.id&&current.compare_run_ids.includes(r.run_id)),result=run&&ref.current.results[run.run_id];if(result)change({...c,revision:c.revision+1,config:structuredClone(run.spec?.submitted_input.config??result.result.config),weather_source_id:run.spec?.submitted_input.weather_source_id??run.weather_source_id??c.weather_source_id});}
 }
 const real=place==='forecast_real';
 return <><header className="platform-header"><div><b>BALLOON LAB</b><span>{place==='weather_fixture'?'気象の性質':place==='season_fixture'?'季節の打上げ計画':'打上げ計画'} <small>0.47 開発版</small></span></div><nav><button className={place.startsWith('forecast')?'active':''} onClick={()=>setPlace('forecast_real')}>打上げ計画</button><button className={place==='weather_fixture'?'active':''} onClick={()=>setPlace('weather_fixture')}>気象を分析</button><button className={place==='season_fixture'?'active':''} onClick={()=>setPlace('season_fixture')}>季節計画</button><button onClick={()=>setLibrary(true)}>保存結果を開く</button><button disabled={ws.loading||ws.saving} onClick={()=>void ws.save()}>{ws.saving?'保存中…':ws.dirty?'計画を保存 ●':'計画を保存'}</button></nav></header>
 <div className="platform-status"><label>表示するデータ <select value={place==='forecast_real'?'real':'fixture'} disabled={!place.startsWith('forecast')} onChange={e=>setPlace(e.target.value==='real'?'forecast_real':'forecast_fixture')}><option value="real">固定GFS・実計算 n=1</option><option value="fixture">画面確認用の人工データ</option></select></label><span role="status">{ws.loading?'保存状態を読込中':ws.saving?'保存中':ws.dirty?'未保存の変更あり':'保存済み'}</span>{ws.message&&<details><summary>処理の通知</summary>{ws.message}</details>}</div>
 {ws.error&&<div className="platform-error" role="alert">{ws.error}<button onClick={()=>void ws.load()}>保存状態を読み直す</button></div>}
 <ScreenBoundary key={place+ws.restoration}>{ws.loading?<p role="status">保存された入力・画面・結果を読み込んでいます。</p>:place==='weather_fixture'?<WeatherScreen key={String(ws.restoration)} saved={ui.weather_fixture} onView={v=>keepView('weather_fixture',v)} background={true} handoff={p=>{keepView('season_fixture',{pendingProposal:p});setPlace('season_fixture');}}/>:<ForecastScreen key={place+ws.restoration} workspace={ws} mode={real?'real':place==='season_fixture'?'season':'fixture'} saved={ui[place]} proposal={null} onView={v=>keepView(place,v)} action={action}/>}</ScreenBoundary>
 {library&&<dialog className="platform-library" open><h2>保存した計画と固定結果</h2><p>保存草案と表示する結果の組合せを共通の計画へ保存します。人工画面の状態は別の名前空間で保持します。</p><button onClick={()=>{setLibrary(false);void ws.load();}}>保存した計画を読み直す</button><button onClick={()=>setLibrary(false)}>閉じる</button>{ws.runs.filter(r=>r.result_available).map(r=><p key={r.run_id}><b>{r.label??r.candidate_id}</b> · 計算時の版{r.candidate_revision} <button disabled={!ws.project.candidates.some(c=>c.id===r.candidate_id)} onClick={()=>{void ws.selectResult(r.run_id,r.candidate_id!);setPlace('forecast_real');setLibrary(false);}}>この固定結果を表示</button></p>)}</dialog>}
 </>;
}
