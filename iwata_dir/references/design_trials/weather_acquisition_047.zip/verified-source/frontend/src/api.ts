import type {Inventory,AcquisitionRequest,AcquisitionPlan,AcquisitionJob,Dependencies} from './weatherAcquisition';
import type {
  Project,
  ResultEnvelope,
  Run,
  WeatherSource,
  Candidate,
} from "./domain";

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch("/api/v1" + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  let data: unknown;
  try {
    data = await response.json();
  } catch {
    throw new ApiError(
      "サービスから読める応答がありません。接続を確認してください。",
      response.status,
    );
  }
  if (!response.ok) {
    const d = data as { detail?: unknown; error?: unknown };
    throw new ApiError(
      typeof d.detail === "string"
        ? d.detail
        : JSON.stringify(d.detail ?? d.error ?? data),
      response.status,
    );
  }
  return data as T;
}
export const api = {
  inventories:()=>request<{inventories:Inventory[]}>('/weather-inventories'),
  refreshInventory:(body:{run_utc?:string;run_limit?:number})=>request<Inventory>('/weather-inventories/refresh',{method:'POST',body:JSON.stringify(body)}),
  weatherPlan:(body:AcquisitionRequest)=>request<AcquisitionPlan>('/weather-plans',{method:'POST',body:JSON.stringify(body)}),
  getWeatherPlan:(id:string)=>request<AcquisitionPlan>('/weather-plans/'+encodeURIComponent(id)),
  acquisitions:()=>request<{acquisitions:AcquisitionJob[]}>('/weather-acquisitions'),
  acquisition:(id:string)=>request<AcquisitionJob>('/weather-acquisitions/'+encodeURIComponent(id)),
  acquireWeather:(planId:string,requestId:string)=>request<AcquisitionJob>('/weather-acquisitions',{method:'POST',body:JSON.stringify({plan_id:planId,client_request_id:requestId})}),
  cancelAcquisition:(id:string)=>request<AcquisitionJob>('/weather-acquisitions/'+encodeURIComponent(id)+'/cancel',{method:'POST',body:'{}'}),
  retryAcquisition:(id:string)=>request<AcquisitionJob>('/weather-acquisitions/'+encodeURIComponent(id)+'/retry',{method:'POST',body:'{}'}),
  weatherStatus:()=>request<{dependencies:Dependencies;max_queued:number;workers:number}>('/weather-status'),
  weather: () =>
    request<{
      sources: WeatherSource[];
      source_errors?: {
        id: string;
        label?: string;
        code: string;
        message: string;
      }[];
    }>("/weather-sources"),
  project: () => request<{ revision: number; project: Project }>("/project"),
  save: (revision: number, project: Project) =>
    request<{ revision: number; project: Project }>("/project", {
      method: "PUT",
      body: JSON.stringify({ expected_revision: revision, project }),
    }),
  runs: () => request<{ runs: Run[] }>("/runs"),
  run: (id: string) => request<Run>("/runs/" + encodeURIComponent(id)),
  result: (id: string) =>
    request<ResultEnvelope>("/runs/" + encodeURIComponent(id) + "/result"),
  start: (candidate: Candidate, clientRequestId: string) =>
    request<Run>("/runs", {
      method: "POST",
      body: JSON.stringify({
        client_request_id: clientRequestId,
        candidate_id: candidate.id,
        candidate_revision: candidate.revision,
        label: candidate.label,
        weather_source_id: candidate.weather_source_id,
        config: candidate.config,
      }),
    }),
};
