import {useEffect,useRef,useState} from 'react';
import {api} from './api';
import {jstLabel,stableString} from './domain';
import type {Candidate,WeatherSource} from './domain';
import {acquisitionRequest,familyCandidates,sourceApplicationIssue,forecastValidTimes} from './weatherAcquisition';
import type {AcquisitionForm,AcquisitionJob,AcquisitionPlan,Inventory,Dependencies} from './weatherAcquisition';

type Step='input'|'plan'|'job';
type Saved={step?:Step;preview?:{bounds:{west:number;east:number;south:number;north:number};stale:boolean;status:string;planId:string;runUtc?:string;windowStart?:string;windowEnd?:string};form?:AcquisitionForm;planId?:string;jobId?:string;requestId?:string;requestPlanId?:string};
type Props={candidates:Candidate[];sources:WeatherSource[];saved?:Saved;onState:(v:Saved)=>void;refreshSources:()=>Promise<WeatherSource[]>;apply:(ids:string[],sourceId:string)=>void;add:(source:WeatherSource)=>void;active?:Candidate;sourceWarnings?:string[];focusPreview:()=>void};
const phaseNames:Record<string,string>={queued:'待機',running:'取得中',cancelling:'取消処理中',completed:'取得完了',failed:'取得失敗',cancelled:'取消済',interrupted:'中断'};
const issueNames:Record<string,string>={RUN_NOT_OBSERVED:'選択した初期時刻は、この保存一覧では配布を確認できません。',REQUIRED_LEADS_NOT_LISTED:'必要な時刻のファイルが配布一覧にありません。別の初期時刻へ自動変更はしません。',DEPENDENCIES_UNAVAILABLE:'気象を解読するための依存ライブラリが不足しています。',MEMORY_BUDGET_EXCEEDED:'推定作業メモリが上限を超えます。取得範囲や飛行時間窓を見直してください。'};
const sourceHeight=(s:WeatherSource)=>{const h=(s.support as {minimum_top_geometric_m?:number}|undefined)?.minimum_top_geometric_m;return typeof h==='number'&&Number.isFinite(h)?`取得場上端の最小値 ${(h/1000).toFixed(2)} km ASL（全格子・全時刻）`:null;};
const mb=(bytes:number)=>Number.isFinite(bytes)?(bytes/1000000).toLocaleString('ja-JP',{maximumFractionDigits:1})+' MB':'—';
const message=(e:unknown)=>e instanceof Error?e.message:String(e);
const ongoing=(j:AcquisitionJob|null)=>!!j&&['queued','running','cancelling'].includes(j.state);

export function WeatherPreparation(props:Props){
 const seed=props.active??props.candidates[0],launch=seed?.config.launch??props.sources.find(s=>s.default_config)?.default_config?.launch;
 const [saved,setSaved]=useState<Saved>(()=>props.saved??{}),savedRef=useRef(saved),latest=useRef(props);latest.current=props;
 const [form,setForm]=useState<AcquisitionForm>(()=>props.saved?.form??{inventoryId:'',runUtc:'',fixedRun:'',latitude:launch?.latitude_deg??33.8,longitude:launch?.longitude_deg??135.4,halfWidth:50,halfHeight:50,maxMB:50,memoryMB:268.435456,targetIds:props.candidates.filter(c=>!c.parent_id).map(c=>c.id)});
 const formRef=useRef(form);formRef.current=form;
 const [inventories,setInventories]=useState<Inventory[]>([]),[jobs,setJobs]=useState<AcquisitionJob[]>([]),[job,setJob]=useState<AcquisitionJob|null>(null),[plan,setPlan]=useState<AcquisitionPlan|null>(null);
 const [step,setStep]=useState<Step>(()=>props.saved?.step??'input');
 const [busy,setBusy]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[dependencies,setDependencies]=useState<Dependencies|null>(null);
 const life=useRef(0),alive=useRef(false),announced=useRef(new Set<string>()),selectedJob=useRef(''),planEpoch=useRef(0);
 function remember(patch:Partial<Saved>){const next={...savedRef.current,...patch};savedRef.current=next;setSaved(next);latest.current.onState(next);}
 function go(next:Step){setStep(next);remember({step:next});}
 function edit(patch:Partial<AcquisitionForm>){const next={...formRef.current,...patch};formRef.current=next;setForm(next);remember({form:next});setNotice('');}
 function acceptJob(next:AcquisitionJob){selectedJob.current=next.acquisition_id;setJob(next);setJobs(old=>[next,...old.filter(j=>j.acquisition_id!==next.acquisition_id)]);remember({jobId:next.acquisition_id});}
 async function perform<T>(label:string,operation:()=>Promise<T>,accept:(value:T)=>void){
  const generation=life.current;setBusy(label);setError('');
  try{const value=await operation();if(alive.current&&generation===life.current)accept(value);}
  catch(e){if(alive.current&&generation===life.current)setError(message(e));}
  finally{if(alive.current&&generation===life.current)setBusy('');}
 }
 useEffect(()=>{
  alive.current=true;const generation=++life.current,restorePlanEpoch=planEpoch.current;
  void Promise.all([api.inventories(),api.acquisitions(),api.weatherStatus()]).then(async ([a,b,c])=>{
   if(!alive.current||generation!==life.current)return;setInventories(old=>[...old,...a.inventories.filter(i=>!old.some(x=>x.inventory_id===i.inventory_id))]);setJobs(old=>[...old,...b.acquisitions.filter(j=>!old.some(x=>x.acquisition_id===j.acquisition_id))]);setDependencies(c.dependencies);
   const initial=latest.current.saved,j=b.acquisitions.find(j=>j.acquisition_id===initial?.jobId);if(j&&!selectedJob.current){selectedJob.current=j.acquisition_id;setJob(j);}
   if(initial?.planId){const p=await api.getWeatherPlan(initial.planId);if(alive.current&&generation===life.current&&restorePlanEpoch===planEpoch.current)setPlan(p);}
  }).catch(e=>{if(alive.current&&generation===life.current)setError(message(e));});
  return()=>{alive.current=false;life.current++;};
 },[]);
 useEffect(()=>{
  if(!ongoing(job))return;let current=true,timer:ReturnType<typeof setTimeout>;
  const poll=async()=>{try{const next=await api.acquisition(job!.acquisition_id);if(!current||selectedJob.current!==job!.acquisition_id)return;acceptJob(next);if(ongoing(next))timer=setTimeout(poll,900);}catch(e){if(current)setError('取得状況を読めません。取得の再送はしていません。'+message(e));}};
  timer=setTimeout(poll,500);return()=>{current=false;clearTimeout(timer);};
 },[job?.acquisition_id,job?.state,job?.attempt]);
 useEffect(()=>{
  if(job?.state!=='completed'||announced.current.has(job.acquisition_id))return;
  announced.current.add(job.acquisition_id);let current=true;
  void latest.current.refreshSources().then(()=>{if(current)setNotice('取得が完了しました。候補の入力と表示中の計算結果は変更していません。適用先を確認してください。');}).catch(e=>{if(current)setError('保存気象一覧を更新できません。'+message(e));announced.current.delete(job.acquisition_id);});
  return()=>{current=false;};
 },[job?.acquisition_id,job?.state]);

 const family=familyCandidates(props.candidates,form.targetIds),inventory=inventories.find(i=>i.inventory_id===form.inventoryId);
 let request:ReturnType<typeof acquisitionRequest>|null=null,requestError='';try{request=acquisitionRequest(form,props.candidates);}catch(e){requestError=message(e);}
 const stale=!!plan&&(!request||stableString(plan.request)!==stableString(request));
 useEffect(()=>{if(plan)remember({preview:{bounds:plan.normalized_request.bounds,stale,status:plan.status,planId:plan.plan_id,runUtc:plan.normalized_request.run_utc,windowStart:plan.required_window.start_utc,windowEnd:plan.required_window.end_utc}});},[plan,stale]);
 const validTimes=plan?forecastValidTimes(plan):[];
 const sameAcquisition=!!(plan?.cache_key&&job?.cache_key&&plan.cache_key===job.cache_key);
 const jobPlanLabel=!plan?'保存した取得':job?.plan_id===plan.plan_id?'表示中の固定計画の取得':sameAcquisition?'同じ取得内容の保存処理':'別の固定計画の取得（前回・履歴）';
 const completed=job?.state==='completed'?props.sources.find(s=>s.id===job.weather_source_id):undefined;
 const applyIssue=sourceApplicationIssue(completed,family);
 const number=(key:'latitude'|'longitude'|'halfWidth'|'halfHeight'|'maxMB'|'memoryMB',label:string)=> <label>{label}<input type="number" step="any" value={Number.isFinite(form[key])?form[key]:''} onChange={e=>edit({[key]:e.target.value===''?NaN:Number(e.target.value)})}/></label>;
 async function refreshInventory(){
  let run:string|undefined;try{if(form.fixedRun){const d=new Date(form.fixedRun+'Z');if(!Number.isFinite(d.valueOf()))throw Error('初期時刻をUTCで入力してください。');run=d.toISOString();}}catch(e){setError(message(e));return;}
  const selectedBefore=[formRef.current.inventoryId,formRef.current.runUtc];
  await perform('配布一覧を確認中',()=>api.refreshInventory(run?{run_utc:run}:{run_limit:2}),value=>{
   setInventories(old=>[value,...old.filter(x=>x.inventory_id!==value.inventory_id)]);
   // Refresh is an explicit selection of a new observed inventory; retain a still-available run.
   const previous=formRef.current.runUtc;if(selectedBefore[0]===formRef.current.inventoryId&&selectedBefore[1]===previous)edit({inventoryId:value.inventory_id,runUtc:value.runs.some(r=>r.run_utc===previous)?previous:value.runs[0]?.run_utc??''});
   setNotice('配布元の一覧を保存しました。ファイル名の観測で、データ内容の検査は取得時に行います。');
  });
 }
 async function makePlan(){if(!request)return;planEpoch.current++;const captured=structuredClone(request);await perform('取得計画を作成中',()=>api.weatherPlan(captured),value=>{setPlan(value);remember({planId:value.plan_id});go('plan');});}
 async function start(){if(!plan||stale||plan.status!=='ready')return;const id=savedRef.current.requestPlanId===plan.plan_id&&savedRef.current.requestId?savedRef.current.requestId:crypto.randomUUID();remember({requestId:id,requestPlanId:plan.plan_id});await perform('取得を開始中',()=>api.acquireWeather(plan.plan_id,id),value=>{acceptJob(value);go('job');});}
 async function selectJob(selected:AcquisitionJob){planEpoch.current++;await perform('保存した取得状態を読込中',async()=>({job:await api.acquisition(selected.acquisition_id),plan:await api.getWeatherPlan(selected.plan_id)}),value=>{acceptJob(value.job);setPlan(value.plan);remember({planId:value.plan.plan_id});go('job');});}

 return <section className="weather-preparation"><h2>予報気象を準備する</h2><p className="muted">使う予報の初期時刻を固定し、対象候補と延期列の飛行時間を含めて取得します。取得と候補への適用は別の操作です。</p>
  <nav className="weather-steps" aria-label="気象を準備する行程">{([['input','1 取得条件'],['plan','2 固定計画'],['job','3 取得・適用']] as [Step,string][]).map(([id,label])=><button type="button" key={id} data-weather-step={id} aria-current={step===id?'step':undefined} onClick={()=>go(id)}>{label}{id==='plan'&&stale?' · 入力変更あり':''}</button>)}</nav>
  {job&&<div className="weather-job-summary"><span>{jobPlanLabel} · <b>{phaseNames[job.state]??job.state}</b> · {job.progress.completed_files}/{job.progress.total_files}ファイル · {job.reused?'保存資産を再利用 · ':''}新規取得 {mb(job.progress.bytes_downloaded)}{job.state==='completed'?' · 候補への適用は明示操作':''}</span><button onClick={()=>go('job')}>取得状況へ</button></div>}
  <details className="saved-weather"><summary>保存済みの気象 · {props.sources.length}件</summary>{props.sources.map(s=><div className="weather-source" key={s.id}><b>{s.label??s.id}</b><small>{s.run_utc?jstLabel(s.run_utc):'初期時刻なし'} · {s.kind==='acquired_gfs'?'取得したGFS':'保存例'}</small>{sourceHeight(s)&&<small>{sourceHeight(s)}</small>}{s.default_config&&<button onClick={()=>props.add(s)}>この保存例から候補を作る</button>}<button disabled={!family.length||!!sourceApplicationIssue(s,family)} onClick={()=>{props.apply(form.targetIds,s.id);setNotice('選択した候補と延期子へ保存気象を適用しました。物理条件と旧結果は保持しています。');}}>選択候補へ適用</button>{family.length>0&&sourceApplicationIssue(s,family)&&<small>{sourceApplicationIssue(s,family)}</small>}</div>)}<button disabled={!!busy} onClick={()=>void perform('保存気象一覧を更新中',props.refreshSources,()=>setNotice('保存気象一覧だけを更新しました。入力と比較結果は保持しています。'))}>保存気象一覧を更新</button></details>
  <div className="weather-input-stage" hidden={step!=='input'}><fieldset><legend>使う予報を選ぶ</legend><div className="weather-fields"><label>調べる初期時刻（任意・UTC）<input type="datetime-local" step="3600" value={form.fixedRun} onChange={e=>edit({fixedRun:e.target.value})}/><small>空欄なら直近の配布候補2件を確認します。</small></label><button disabled={!!busy} onClick={()=>void refreshInventory()}>配布一覧を更新</button></div>
   <label>保存した一覧<select value={form.inventoryId} onChange={e=>{const i=inventories.find(i=>i.inventory_id===e.target.value);edit({inventoryId:e.target.value,runUtc:i?.runs[0]?.run_utc??''});}}><option value="">一覧を選ぶ</option>{inventories.map(i=><option key={i.inventory_id} value={i.inventory_id}>{jstLabel(i.observed_at_utc)} に観測 · {i.runs.length}初期時刻</option>)}</select></label>
   <label>使用する初期時刻（UTC）<select value={form.runUtc} onChange={e=>edit({runUtc:e.target.value})}><option value="">初期時刻を選ぶ</option>{inventory?.runs.map(r=><option key={r.run_utc} value={r.run_utc}>{r.run_utc} · 配布名を確認 {r.available_leads.length}時刻</option>)}</select></label><small>最新の全世界予報を保証する一覧ではありません。選択した初期時刻から別のrunへ自動で切り替えません。</small>
  </fieldset>
  <fieldset><legend>対象候補と取得範囲</legend><div className="weather-targets">{props.candidates.filter(c=>!c.parent_id).map(c=><label key={c.id}><input type="checkbox" checked={form.targetIds.includes(c.id)} onChange={e=>edit({targetIds:e.target.checked?[...form.targetIds,c.id]:form.targetIds.filter(id=>id!==c.id)})}/>{c.label} <small>延期子{familyCandidates(props.candidates,[c.id]).length-1}件を含む</small></label>)}{!props.candidates.length&&<p>保存例から候補を作り、放球日時とモデル条件を入力してください。</p>}</div>
   {family.length>0&&<><p className="family-window-summary">独立候補 {family.filter(c=>!c.parent_id).length}件＋延期 {family.filter(c=>c.parent_id).length}件 · {family.every(c=>Number.isFinite(Date.parse(c.config.launch.time_utc))&&Number.isFinite(Number(c.config.integration?.max_duration_s??14400)))?`${jstLabel(new Date(Math.min(...family.map(c=>Date.parse(c.config.launch.time_utc)))).toISOString())} ～ ${jstLabel(new Date(Math.max(...family.map(c=>Date.parse(c.config.launch.time_utc)+Number(c.config.integration?.max_duration_s??14400)*1000))).toISOString())}`:'日時・飛行時間を確認してください'}</p><details><summary>全対象の放球・飛行上限・高度条件を見る（閉じても全件を計画に含む）</summary><table><thead><tr><th>対象</th><th>放球 JST</th><th>最大飛行時間</th><th>高度の条件</th></tr></thead><tbody>{family.map(c=><tr key={c.id}><td>{c.label}</td><td>{jstLabel(c.config.launch.time_utc)}</td><td>{Number(c.config.integration?.max_duration_s??14400)/3600} h</td><td>{c.config.burst.mode==='altitude'?Number(c.config.burst.altitude_m)/1000+' km ASLで破裂':'径破裂 · 到達高度は事前未確定'}</td></tr>)}</tbody></table></details></>}
   <div className="weather-fields">{number('latitude','取得中心 緯度 °N')}{number('longitude','取得中心 経度 °E')}{number('halfWidth','東西の片幅 km')}{number('halfHeight','南北の片幅 km')}</div><button disabled={!props.active} onClick={()=>props.active&&edit({latitude:props.active.config.launch.latitude_deg,longitude:props.active.config.launch.longitude_deg})}>注目候補の放球点を中心にする</button>
   <details><summary>取得量の上限</summary><div className="weather-fields">{number('maxMB','転送上限 MB')}{number('memoryMB','推定作業メモリ上限 MB')}</div></details>
   <button disabled={!!busy||!request} onClick={()=>void makePlan()}>取得計画を確認</button>{requestError&&<small>{requestError}</small>}
  </fieldset></div>
  <div hidden={step!=='plan'}>{!plan&&<p>取得条件を入力して「取得計画を確認」を押すと、丸めた範囲・時間窓・取得量がここに表示されます。<button onClick={()=>go('input')}>取得条件へ</button></p>}
  {plan&&<fieldset className="acquisition-preview"><legend>固定した取得計画</legend>{stale&&<p className="notice">候補の時間窓または取得条件が、この計画の作成後に変わりました。取得を始める前に計画を作り直してください。</p>}<dl><dt>初期時刻 UTC</dt><dd>{plan.normalized_request.run_utc}</dd><dt>必要な飛行時間窓</dt><dd>{jstLabel(plan.required_window.start_utc)} ～ {jstLabel(plan.required_window.end_utc)}</dd><dt>取得する気象の有効時刻</dt><dd>{validTimes.length?`${jstLabel(validTimes[0])} ～ ${jstLabel(validTimes.at(-1)!)}`:'—'}<details><summary>全{validTimes.length}時刻</summary>{validTimes.map(t=><div key={t}>{jstLabel(t)}</div>)}</details></dd><dt>格子へ外向きに丸めた範囲</dt><dd>{plan.normalized_request.bounds.south}–{plan.normalized_request.bounds.north}°N / {plan.normalized_request.bounds.west}–{plan.normalized_request.bounds.east}°E</dd><dt>地図での確認</dt><dd><button onClick={props.focusPreview}>取得範囲を地図で確認</button> 橙色の破線が取得計画。計算結果に使用した気象の境界とは区別します。</dd><dt>必要予報時間</dt><dd>{plan.normalized_request.lead_hours.join(', ')} h</dd><dt>取得量の見積り</dt><dd>{plan.estimate.grid_points.toLocaleString()}格子点 × {plan.estimate.time_count}時刻 · 配列 {mb(plan.estimate.float64_bytes)} / 作業メモリ推定 {mb(plan.estimate.estimated_working_memory_bytes)}<br/>転送上限 {mb(plan.estimate.max_download_bytes)}（転送量の実測値ではありません）</dd></dl>
   {plan.missing_leads.length>0&&<p role="alert">配布未確認の予報時間: {plan.missing_leads.join(', ')} h</p>}{plan.issues.map((issue,i)=><p key={i} role="alert">{issueNames[issue.code]??issue.message} ({issue.code})</p>)}<p>{stale?'現在の入力とは異なる計画です。取得を始めるには計画を作り直してください。':plan.status==='ready'?'この計画は取得を開始できます。':'この計画では取得を開始できません。'} 取得後も、軌道が領域や時間・高度支持を外れる場合は停止します。指定した破裂高度まで飛べることを保証する判定ではありません。</p><button className="primary" disabled={!!busy||stale||plan.status!=='ready'||dependencies?.available===false} onClick={()=>void start()}>この固定計画で気象を取得</button>
  </fieldset>}
  </div>
  {dependencies&&!dependencies.available&&<p role="alert">取得の前提が不足: {dependencies.missing.map(d=>d.name+': '+d.message).join(' / ')}</p>}
  <div hidden={step!=='job'}>{!job&&<p>まだ取得を開始していません。固定計画を確認した上で開始してください。<button onClick={()=>go('plan')}>固定計画へ</button></p>}
  {job&&<fieldset className="acquisition-progress"><legend>取得状況と適用</legend><p>{jobPlanLabel}{plan&&job.plan_id!==plan.plan_id&&!sameAcquisition?'。この完了表示は、現在表示している計画を取得済みという意味ではありません。':''}</p><b>{phaseNames[job.state]??job.state} · 試行{job.attempt}{job.reused?' · 検査済み資産を再利用':''}</b><p>{{queued:'待機中',downloading:'気象ファイルを取得',decoding:'物理量を解読・検査',completed:'保存済み',reused:'保存資産を再利用'}[job.progress.phase]??job.progress.phase} · {job.reused?'完成した資産を再利用':`${job.progress.completed_files}/${job.progress.total_files}ファイル`} · 新規{mb(job.progress.bytes_downloaded)} / 再利用{mb(job.progress.bytes_reused)}</p><progress max={Math.max(1,job.progress.total_files)} value={job.state==='completed'?Math.max(1,job.progress.total_files):job.progress.completed_files}/>{job.error&&<p role="alert">{job.error.message} ({job.error.code})</p>}<div className="row"><button disabled={!!busy||!job.cancellable} onClick={()=>void perform('取消を要求中',()=>api.cancelAcquisition(job.acquisition_id),acceptJob)}>取得を取り消す</button><button disabled={!!busy||!job.retryable} onClick={()=>void perform('取得を再試行中',()=>api.retryAcquisition(job.acquisition_id),acceptJob)}>同じ計画を再試行</button><button disabled={!!busy} onClick={()=>void perform('状況を確認中',()=>api.acquisition(job.acquisition_id),acceptJob)}>状況を確認</button></div>{job.state==='completed'&&<>{completed&&sourceHeight(completed)&&<p>{sourceHeight(completed)}</p>}<p>適用先: {family.map(c=>c.label).join('・')||'未選択'}。現在の物理条件を保ち、使う気象だけを変更します。</p><button className="primary" disabled={!!applyIssue||!!busy} onClick={()=>{if(completed){props.apply(form.targetIds,completed.id);setNotice('完成した気象を選択候補と延期子へ適用しました。再計算は明示操作で行います。');}}}>完成した気象を選択候補へ適用</button>{applyIssue&&<p>{applyIssue}</p>}</>}</fieldset>}
  {jobs.length>0&&<details><summary>保存した取得履歴 · {jobs.length}件</summary>{jobs.map(j=><p key={j.acquisition_id}>{phaseNames[j.state]} · {j.acquisition_id.slice(0,8)} <button disabled={!!busy} onClick={()=>void selectJob(j)}>この取得を確認</button></p>)}</details>}
  </div>
  {props.sourceWarnings?.map((text,i)=><p role="alert" key={i}>{text}</p>)}
  {busy&&<p role="status">{busy}…</p>}{error&&<p role="alert">{error}</p>}{notice&&<p role="status">{notice}</p>}
 </section>;
}
