import { useEffect,useMemo,useRef,useState } from 'react';
import { createPortal } from 'react-dom';
import { mountForecast } from './forecast/runtime';
import { projectTabs } from './forecast/projection';
import { stableString,draftIssue } from '../domain';
import { ConfigEditor } from '../ConfigEditor';
import { WeatherPreparation } from '../WeatherPreparation';
import type { Candidate } from '../domain';

type Props={workspace:any;mode:'real'|'fixture'|'season';saved:any;proposal:any;onView:(view:any)=>void;action:(type:string,payload:any)=>void};
export function ForecastScreen(props:Props){
 const host=useRef<HTMLDivElement>(null),runtime=useRef<any>(null),current=useRef(props),suppress=useRef(false);current.current=props;
 const [active,setActive]=useState(''),[ready,setReady]=useState(false);
 useEffect(()=>{
  setReady(false);let disposed=false;
  const p=current.current;
  const sources=p.workspace.sources;
  const displayedSources=()=>{const ws=current.current.workspace,view=current.current.saved??{},rt=runtime.current,active=rt?.state.active;const detailIds=rt?.state.groups.find((g:any)=>g.id===active)?.members??[active];const candidates=ws.project.candidates.filter((c:any)=>rt?.state.detail?detailIds.includes(view.codes?.[c.id]??c.id):view.visibility?.[view.codes?.[c.id]??c.id]!==false);const sources=candidates.flatMap((c:any)=>{const run=ws.runs.find((r:any)=>r.candidate_id===c.id&&ws.project.compare_run_ids.includes(r.run_id));const fixed=run&&ws.results[run.run_id]?.weather_snapshot;return fixed?[fixed]:[];});if(!sources.length){const c=ws.project.candidates.find((c:any)=>(view.codes?.[c.id]??c.id)===active);const draft=ws.sources.find((s:any)=>s.id===c?.weather_source_id)??ws.sources[0];if(draft)sources.push(draft);}return [...new Map(sources.map((s:any)=>[String(s.sha256??s.id),s])).values()] as any[];};
  const supports=()=>displayedSources().filter(s=>s.bounds).map(s=>({label:String(s.label??s.id),bounds:[[s.bounds.lat[0],s.bounds.lon[0]],[s.bounds.lat[1],s.bounds.lon[1]]]}));
  const bounds=()=>{const b=supports();return b.length?[[Math.min(...b.map(s=>s.bounds[0][0])),Math.min(...b.map(s=>s.bounds[0][1]))],[Math.max(...b.map(s=>s.bounds[1][0])),Math.max(...b.map(s=>s.bounds[1][1]))]]:[[33,135],[35,137]];};
  const climate=p.saved?.pendingProposal||p.saved?.seasonSource;
  const search=p.mode==='season'?'?mode=season'+(climate?'&climate='+encodeURIComponent(JSON.stringify(climate)):''):'';
  const bridge={real:p.mode==='real',location:{search,origin:location.origin,protocol:location.protocol},bounds,supports,acquisitionPreview:()=>current.current.saved?.weatherPreparation?.preview,
   weatherText:()=>displayedSources().map(s=>`${s.label??s.id} · ${s.bounds?.lat.join('–')}°N / ${s.bounds?.lon.join('–')}°E · 有効UTC ${s.valid_times_utc?.join(' / ')??'来歴を確認'}`).join(' ｜ ')||'保存気象を確認中',
   changed:(view:any)=>{if(disposed||suppress.current)return;setActive(view.active);current.current.onView(view);},
   action:(type:string,payload:any)=>{const codes=current.current.saved?.codes??{},resolve=(id:string)=>Object.keys(codes).find(k=>codes[k]===id)??id;current.current.action(type,{...payload,...(payload.id?{id:resolve(payload.id)}:{}),...(payload.ids?{ids:payload.ids.map(resolve)}:{})});}};
  suppress.current=true;
  try{runtime.current=mountForecast(host.current!,bridge);if(p.mode!=='real'){if(p.saved?.pendingProposal){const generated=runtime.current.snapshot(),old=p.saved.tabs??[],item=generated.tabs[0];if(!item)throw Error('季節提案を作成できません。気象の元条件を保持しています。');let number=1;while(old.some((t:any)=>t.id==='S'+number))number++;item.id='S'+number;item.source=climate;if(item.result)item.result={...item.result,id:'r'+(1+Math.max(0,...old.map((t:any)=>Number(String(t.result?.id??'').replace(/^r/,''))||0)))};runtime.current.restore({...p.saved,tabs:[...old,item],active:item.id,detail:false,selected:[],seasonSource:climate});}else runtime.current.restore(p.saved);runtime.current.refresh();}setActive(runtime.current.state.active);setReady(true);}finally{suppress.current=false;}
  if(p.saved?.pendingProposal)current.current.onView({...runtime.current.snapshot(),pendingProposal:null});
  return()=>{disposed=true;runtime.current?.dispose();runtime.current=null;};
 },[props.mode]);
 const signature=useMemo(()=>stableString([props.workspace.project.candidates,props.workspace.project.compare_run_ids,props.workspace.results]),[props.workspace.project.candidates,props.workspace.project.compare_run_ids,props.workspace.results]);
 useEffect(()=>{const rt=runtime.current;if(!rt||props.mode!=='real')return;suppress.current=true;try{rt.sync(projectTabs(props.workspace.project.candidates,props.workspace.runs,props.workspace.results,props.workspace.project.compare_run_ids,props.saved),props.saved);setActive(rt.state.active);}finally{suppress.current=false;}},[signature,ready,props.saved]);
 const c=props.workspace.project.candidates.find((c:Candidate)=>(props.saved?.codes?.[c.id]??c.id)===active),input=host.current?.querySelector('#realInputs'),source=host.current?.querySelector('#realWeather');
 const ownRuns=props.workspace.runs.filter((r:any)=>r.candidate_id===c?.id&&r.result_available),selected=ownRuns.find((r:any)=>props.workspace.project.compare_run_ids.includes(r.run_id));
 return <><div className="forecast-screen" ref={host}/>{ready&&props.mode==='real'&&input&&c&&createPortal(<div className="connected-inputs"><p className="muted">草案 版{c.revision} · {c.parent_id?`親 ${props.saved?.codes?.[c.parent_id]??c.parent_id}から＋${c.delay_minutes}分`:'独立候補'}</p>{c.parent_id?<p>共通の入力は親候補を編集します。</p>:<><ConfigEditor candidate={c} sources={props.workspace.sources} models={props.saved?.editor_models?.[c.id]} onChange={(next,models)=>props.action('config',{candidate:next,models})}/><button onClick={()=>runtime.current.startLocation()}>地図で放球点を指定</button></>}<button className="primary" disabled={!!props.workspace.pending[c.id]||!!draftIssue(c.config)} onClick={()=>props.action('run',{id:c.parent_id||c.id})}>{props.workspace.pending[c.id]||'この条件で計算'}</button>{draftIssue(c.config)&&<p role="alert">{draftIssue(c.config)}</p>}<p>{selected?`地図は計算時の版${selected.candidate_revision}（n=1）を表示。入力を変えても旧結果を保持します。`:'まだ計算結果がありません。'}</p><label>表示する固定結果<select value={selected?.run_id??''} onChange={e=>props.workspace.selectResult(e.target.value,c.id)}><option value="" disabled>結果を選ぶ</option>{ownRuns.map((r:any)=><option key={r.run_id} value={r.run_id}>版{r.candidate_revision} · {r.run_id.slice(-12)}</option>)}</select></label></div>,input)}{ready&&props.mode==='real'&&source&&createPortal(<WeatherPreparation sourceWarnings={props.workspace.sourceWarnings} focusPreview={()=>runtime.current.fitAcquisition()} candidates={props.workspace.project.candidates} sources={props.workspace.sources} active={c} saved={props.saved?.weatherPreparation} onState={value=>current.current.onView({weatherPreparation:value})} refreshSources={props.workspace.refreshSources} apply={(ids,sourceId)=>props.action('weather-apply',{ids,sourceId})} add={source=>props.action('add',{source})}/>,source)}</>;
}
