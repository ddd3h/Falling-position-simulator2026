import {useEffect,useRef} from 'react';
import {mountWeather} from './weather/runtime';
export function WeatherScreen({saved,onView,handoff,background}:{saved:any;onView:(v:any)=>void;handoff:(v:any)=>void;background:boolean}){
 const host=useRef<HTMLDivElement>(null),current=useRef({onView,handoff});current.current={onView,handoff};
 useEffect(()=>{const locationState=saved?'?restore='+encodeURIComponent(JSON.stringify({kind:'synthetic-climate-proposal',returnState:saved})):'';const runtime=mountWeather(host.current!,{location:{search:locationState,origin:location.origin},background,handoff:(p:any)=>current.current.handoff(p)});let alive=true;const element=host.current!;const capture=()=>queueMicrotask(()=>{if(alive)current.current.onView(runtime.snapshot());});element.addEventListener('click',capture);element.addEventListener('change',capture);element.addEventListener('input',capture);return()=>{alive=false;element.removeEventListener('click',capture);element.removeEventListener('change',capture);element.removeEventListener('input',capture);runtime.dispose();};},[background]);
 return <div ref={host} className="weather-screen"/>;
}
