import { useEffect, useReducer, useRef, useState } from "react";
import { api, ApiError } from "./api";
import { stableString } from "./domain";
import type { Candidate, Project, Run, WeatherSource } from "./domain";
import {
  initialState,
  RunWatchOwners,
  SubmissionIntents,
  workspaceReducer,
} from "./workspaceState";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const errorText = (e: unknown) => (e instanceof Error ? e.message : String(e));
const stateLabel: Record<string, string> = {
  queued: "待機中",
  running: "計算中",
  completed: "計算終了",
  failed: "計算失敗",
  cancelled: "取消済み",
  interrupted: "中断",
};

export function useWorkspace() {
  const [state, dispatch] = useReducer(
    workspaceReducer,
    undefined,
    initialState,
  );
  const current = useRef(state);
  current.current = state;
  const [restoration,setRestoration]=useState(0);
  const [sources, setSources] = useState<WeatherSource[]>([]);
  const [sourceWarnings, setSourceWarnings] = useState<string[]>([]);
  const [loading, setLoading] = useState(true),
    [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(""),
    [error, setError] = useState("");
  const [pending, setPending] = useState<Record<string, string>>({});
  const epochs = useRef<Record<string, number>>({}),
    requestIds = useRef(new SubmissionIntents());
  const watching = useRef(new RunWatchOwners()),
    loadGeneration = useRef(0),
    alive = useRef(true);
  const dirty = state.savedSignature !== stableString(state.project);

  async function watch(
    run: Run,
    candidateId: string,
    epoch: number,
    generation: number,
    intent: "complete" | "restore" = "complete",
  ) {
    if (!watching.current.acquire(run.run_id, generation)) return;
    try {
      while (alive.current && generation === loadGeneration.current) {
        run = await api.run(run.run_id);
        if (!alive.current || generation !== loadGeneration.current) return;
        dispatch({ type: "polled", run });
        setPending((old) => ({
          ...old,
          [candidateId]: stateLabel[run.state ?? "queued"] ?? String(run.state),
        }));
        if (run.result_available) {
          const result = await api.result(run.run_id);
          if (!alive.current || generation !== loadGeneration.current) return;
          dispatch({
            type: "result",
            run,
            result,
            candidateId,
            epoch,
            intent,
          });
          setMessage(
            `${run.label ?? candidateId} の計算を保存しました。${result.result.status === "landed" ? "着地" : "停止: " + result.result.stop_reason?.code}。待機中に表示結果を選び直した場合、その選択を保ちます。`,
          );
          return;
        }
        if (run.state === "completed")
          throw Error(
            "計算は終了しましたが結果を取得できません。旧結果を保持しています。",
          );
        if (["failed", "cancelled", "interrupted"].includes(run.state ?? ""))
          throw Error(
            `${stateLabel[run.state!]}: ${JSON.stringify(run.error ?? "")}。表示中の旧結果は保持しています。`,
          );
        await sleep(800);
      }
    } catch (e) {
      if (alive.current && generation === loadGeneration.current)
        setError(errorText(e));
    } finally {
      watching.current.release(run.run_id, generation);
      if (alive.current && generation === loadGeneration.current)
        setPending((old) => {
          const next = { ...old };
          delete next[candidateId];
          return next;
        });
    }
  }

  const sourceGeneration=useRef(0);
  async function refreshSources() {
    const sourceEpoch=++sourceGeneration.current,generation=loadGeneration.current;
    const weather=await api.weather();
    if(alive.current&&generation===loadGeneration.current&&sourceEpoch===sourceGeneration.current){setSources(weather.sources);setSourceWarnings((weather.source_errors??[]).map(e=>`${e.label??e.id}: ${e.message}`));}
    return weather.sources;
  }
  async function load() {
    sourceGeneration.current++;
    const generation = ++loadGeneration.current;
    setLoading(true);
    setPending({});
    setSaving(false);
    setError("");
    try {
      const [weather, saved, available] = await Promise.all([
        api.weather(),
        api.project(),
        api.runs(),
      ]);
      if (!alive.current || generation !== loadGeneration.current) return;
      epochs.current = {};
      setRestoration(generation);
      setSources(weather.sources);
      setSourceWarnings(
        (weather.source_errors ?? []).map((e) => `${e.label??e.id}: ${e.message}`),
      );
      dispatch({
        type: "restore",
        project: saved.project,
        revision: saved.revision,
        runs: available.runs,
      });
      const selected = await Promise.allSettled(
        saved.project.compare_run_ids.map(async (id) => {
          const [run, result] = await Promise.all([
            api.run(id),
            api.result(id),
          ]);
          return { run, result };
        }),
      );
      if (!alive.current || generation !== loadGeneration.current) return;
      selected.forEach((item, i) => {
        if (item.status === "fulfilled")
          dispatch({
            type: "result",
            ...item.value,
            candidateId: item.value.run.candidate_id ?? "",
            epoch: 0,
            intent: "restore",
          });
        else
          setError((old) =>
            [
              old,
              `結果 ${saved.project.compare_run_ids[i]} を読めません: ${errorText(item.reason)}。草案と読めた結果は保持しています。`,
            ]
              .filter(Boolean)
              .join("\n"),
          );
      });
      setMessage(
        saved.project.candidates.length
          ? "保存した草案と比較を開きました。実行中の処理は状態だけを確認し、再送しません。"
          : "保存GFSから候補を作り、条件・延期時刻を比較できます。",
      );
      const activeByCandidate = new Map<string, Run>();
      for (const run of available.runs
        .filter((r) => ["queued", "running"].includes(r.state ?? ""))
        .sort((a, b) =>
          String(a.created_at ?? "").localeCompare(String(b.created_at ?? "")),
        ))
        if (run.candidate_id) activeByCandidate.set(run.candidate_id, run);
      for (const [candidateId, run] of activeByCandidate) {
        dispatch({ type: "accepted", run, candidateId });
        void watch(run, candidateId, 0, generation, "restore");
      }
    } catch (e) {
      if (alive.current && generation === loadGeneration.current)
        setError(errorText(e));
    } finally {
      if (alive.current && generation === loadGeneration.current)
        setLoading(false);
    }
  }
  useEffect(() => {
    alive.current = true;
    void load();
    return () => {
      alive.current = false;
      loadGeneration.current++;
    };
  }, []);
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => {
      if (dirty && !loading) e.preventDefault();
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty, loading]);

  async function selectResult(id: string, candidateId: string) {
    const generation = loadGeneration.current;
    const epoch = (epochs.current[candidateId] =
      (epochs.current[candidateId] ?? 0) + 1);
    dispatch({ type: "selection_requested", candidateId, epoch });
    try {
      const [run, result] = await Promise.all([api.run(id), api.result(id)]);
      if (alive.current && generation === loadGeneration.current)
        dispatch({
          type: "result",
          run,
          result,
          candidateId,
          epoch,
          intent: "select",
        });
    } catch (e) {
      if (alive.current && generation === loadGeneration.current)
        setError(errorText(e));
    }
  }
  async function start(candidate: Candidate) {
    const captured = structuredClone(candidate),
      generation = loadGeneration.current;
    const requestId = requestIds.current.forAttempt(captured);
    const epoch = epochs.current[candidate.id] ?? 0;
    setPending((old) => ({ ...old, [candidate.id]: "送信中" }));
    setError("");
    try {
      const run = await api.start(captured, requestId);
      requestIds.current.acknowledge(captured, requestId);
      if (!alive.current || generation !== loadGeneration.current) return;
      dispatch({ type: "accepted", run, candidateId: candidate.id });
      await watch(run, candidate.id, epoch, generation);
    } catch (e) {
      if (e instanceof ApiError)
        requestIds.current.reject(captured, requestId, e.status);
      if (alive.current && generation === loadGeneration.current) {
        setError(errorText(e));
        setPending((old) => {
          const next = { ...old };
          delete next[candidate.id];
          return next;
        });
      }
    }
  }
  async function save() {
    const captured = structuredClone(current.current.project),
      revision = current.current.revision,
      generation = loadGeneration.current;
    setSaving(true);
    setError("");
    try {
      const saved = await api.save(revision, captured);
      if (!alive.current || generation !== loadGeneration.current) return;
      dispatch({ type: "saved", project: captured, revision: saved.revision });
      setMessage(
        "草案と表示中の固定結果の組合せを保存しました。同じ保存先のサービスを再起動しても比較を開けます。",
      );
    } catch (e) {
      if (alive.current && generation === loadGeneration.current)
        setError(
          errorText(e) +
            " 編集中の条件は保持しています。別画面の保存と競合した場合、その内容を確認してください。",
        );
    } finally {
      if (alive.current && generation === loadGeneration.current)
        setSaving(false);
    }
  }
  return {
    ...state,
    restoration,
    runs: Object.values(state.runs),
    sources,
    sourceWarnings,
    loading,
    saving,
    message,
    error,
    pending,
    dirty,
    setProject: (project: Project) => dispatch({ type: "project", project }),
    updateCandidate: (candidate: Candidate) =>
      dispatch({ type: "candidate", candidate }),
    setMessage,
    load,
    refreshSources,
    selectResult,
    start,
    save,
  };
}
