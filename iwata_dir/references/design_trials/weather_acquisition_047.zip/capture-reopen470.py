from pathlib import Path
from urllib.request import urlopen
import json,hashlib,datetime
P=Path(__file__).resolve().parent;O=P/'reopen-evidence470';O.mkdir(exist_ok=False)
rows={}
for name,endpoint in [('health','health'),('project','project'),('sources','weather-sources'),('acquisitions','weather-acquisitions'),('result','runs/66bfa1b1-df37-4cb0-9b6c-43c5692d1af8/result')]:
 with urlopen('http://127.0.0.1:8471/api/v1/'+endpoint) as r:raw=r.read()
 (O/(name+'.json')).write_bytes(raw);rows[name]={'endpoint':endpoint,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
prior=json.loads((P/'api-evidence470/receipt.json').read_text())
assert rows['result']['sha256']==prior['responses']['result']['sha256']
project=json.loads((O/'project.json').read_bytes())['project']
assert len(project['candidates'])==3
assert all(c['config']['ascent']['gas_mass_kg']==.52 for c in project['candidates'])
jobs=json.loads((O/'acquisitions.json').read_bytes())['acquisitions']
assert len(jobs)==2 and all(j['state']=='completed' for j in jobs)
receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'responses':rows,'result_bytes_equal_before_restart':True,'candidates':3,'gas_mass_kg_all':.52,'acquisition_jobs_unchanged_count':2,'ui_observations':{'build':'C4UQJMm0','save_reload_twice':'saved','necessary_delay_window_jst':'2026-09-30 12:30 to 17:30','new_plan_valid_hours_jst':'12,13,14,15,16,17,18','new_plan_not_acquired':True,'old_six_time_asset_apply_disabled_for_60_minute_delay':True},'limits':['UI observations are root operation records, not inferred from API response hashes.','This is n=1 and artificial test input, not a validated flight forecast.']}
(O/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'result_unchanged':True,'jobs':len(jobs),'candidates':len(project['candidates'])}))
