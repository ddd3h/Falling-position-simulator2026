# 0.47 独立批評・第3巡（実装中の反例と再読）

この票は source の読取りに基づく。実UI、実HTTP、復号の科学的精度を検証した票ではない。担当へ反例を送り、修正後に同じ操作・関数へ戻って再評価する。source編集・Git操作・外部取得は行っていない。

## 第2巡の反例へ戻った結果

- `sourceApplicationIssue` に経度の ±360 同値表現と有限座標検査が追加された。既存数値核と同じ地点を画面だけで拒否する問題、および NaN の比較がすり抜ける問題への修正を読取確認した。
- 子候補を複製するとき、App は `c.parent_id ?? c.id` から方式別草案をコピーするようになった。親に保持された未選択モデル入力を複製で失う反例に対応している。
- UIの適用対象は親候補のみとなり、`applyCandidateWeather` は祖先と子孫を含む集合へ正規化する。acquisition側の支持検査も同じ集合にすべきという追加反例を担当へ送った。通常UIで親だけ選べることと、保存状態の子IDを読み戻す場合の契約は区別する。
- 配布一覧の更新完了時は、開始時の inventory/run 選択がまだ同じ場合だけ新しい一覧へ切り替える。通信待ちの途中で選んだ別の一覧を上書きしない修正を読取確認した。

## 新しく見つけた操作・意味の反例

### CW09: 同一mount内の遅延復元応答

WeatherPreparation の初回 effect が P0 を復元中に新計画 P1 を作ると、P0 の遅い応答が setPlan し得る。life generation は unmount への対策であり、同一mount内の新操作との順序を識別しない。計画選択のepochまたは開始時ID照合によって旧復元応答を破棄する修正を依頼した。

### CW10: 必要な飛行窓と取得するvalid時刻

preview は `normalized_request.start/end` を「取得する気象の時刻」としていた。しかしその値は任意の要求窓であり、実取得は `run_utc + lead_hours` の内挿用両端を含む。例えば 04:17–08:17 の飛行窓と 04:00–09:00 の取得時刻は別である。実valid時刻列を表示し、必要窓との違いを保つよう依頼した。

### CW11: 前提不足の説明

backend の dependencies.missing は `{name,message}` の列だが、frontendの旧型/string joinでは `[object Object]` と表示される。依存不足の名前・理由を読める形にする修正を依頼した。

## 共通HTTP・raw再開の反例

### CW12: 90秒socket timeoutと総経過時間

urllib timeoutは各socket操作の待ち時間であり、小量の応答が継続すれば総時間90秒を保証しない。100秒予約だけではprocess中断後の間隔説明も閉じない。親担当はこれを採用し、in_flight記録／前回未完了時の10秒待ち、read1とmonotonic総時間点検、30秒socket timeoutへ修正予定と返答した。DNSを含む厳密なhard deadlineではないという限界を保持する。修正版の再読は未了。

### CW13: 途中失敗のbytes表示

acquire_gfs の `downloaded` は _download の正常return後だけ増える。失敗時に保存されたpartial bytesは開始時のretainedにも含まれないため、途中で20MBを受信してもUIが新規0MBと表示し得る。次のresumeではpartialを予算へ含めているが、失敗した現在試行のprogressにも保存partial量を戻す必要がある。親担当へ通知した。

## backend公開と再利用の反例

### CW14: ASSET.json 書込み途中の中断

_publish は最終名 ASSET.json へ直接 write_new_json する。processが書込み中に終了すると、再起動後の明示retryは exists→read_json で破損markerに当たり、検査済みbundleがあっても再開不能となる。完成markerを独立partialへfsync後atomic昇格する案をbackend担当へ通知した。破損を公開しないことと、正当な途中状態から復旧できることは別の受入条件である。

### CW15: 旧失敗jobのretryと既存の完成asset

失敗Aの後に同じcache_keyのBを新規submitして完成させ、Aをretryすると、retryが既存asset/activeを見ず再queueする。submit経路はcacheを再利用するため、明示retry経路も同じ再利用方針で閉じる必要がある。backend担当へ通知した。

## 今回確認できた良い境界と限界

計画は候補親と延期子の最大飛行時間を包絡し、取得完了は候補を自動更新しない。適用は物理入力を保った別操作であり、旧runはweather_snapshotを保持する。完成assetだけがsourceへ登録され、一覧のGET／計画／polling／旧結果再閲覧は外部HTTPを起こさない。計画readyは取得開始可であって全飛行・全高度支持の保証ではない。30kmの最低支持能力と任意の径破裂モデルの到達高度を混同しない。

ここまでで acquisition n=1 段階を長期goalの完了とは扱わない。将来の同じprimitive標本を用いたモデル比較、50/90/95%分散、禁止域群、過去場の対象窓と欠測の扱いは引き続き独立の未完工程である。
