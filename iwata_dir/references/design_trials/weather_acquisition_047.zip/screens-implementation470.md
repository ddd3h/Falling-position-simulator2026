# 0.47 frontend 引継ぎ（初回実UI前）

基準C2 `2436152f815a20573e6eca7badedc958c18efe48`。frontend担当。APIは `weather-api470.md` の具体契約に合わせる。新規sourceは `src/WeatherPreparation.tsx`、`src/weatherAcquisition.ts`、`src/modelDrafts.ts`、`src/acquisition.test.ts` の4件。

## 実現する行程

旧成熟GUIの「共通の準備」内のrealWeatherへ取得フォームを置いた。既存の候補/延期/詳細/3Dを別UIへ置換していない。配布一覧の明示更新、固定run選択、候補familyと最大飛行時間、中心/東西南北片幅、外向き格子丸め後の計画、取得進捗・取消・同計画再試行、完成気象の明示適用を実APIへ接続した。

APIの保存一覧・保存job読取りは外部気象取得を起動しない。最新runへ勝手に切替しない。計画は要求時刻窓と実valid時刻（run+lead）を別々に表示する。計画bboxは橙破線、表示済み固定結果の気象支持は従来の灰破線。取得完成は候補/結果を変えず、明示適用が現選択familyの weather_source_id のみを更新する。親の適用は従属延期子へ波及し、独立している非対象は変更しない。後で入力が変わった場合は時刻/地点の必要条件を再確認する。高さ支持や全軌道の保証とはしない。

新取得sourceはdefault_config:nullのため物理入力を作らず、保存例から作成した既存候補へ適用する。新規取得source一覧のrefreshはuseWorkspaceのsource stateだけを更新し、project、比較run、草案、画面をreloadしない。送信のclient_request_idは同じplanの不確実再送に再利用。過去jobの状態照会とcancel/retryは別API操作。

## 入力と寿命の境界

方式別入力はmodelDraftsの純粋関数で退避/復元し、Appがconfigとui_stateを1回で更新。上昇/破裂/降下と降下密度則を保持。子の複製/独立化は親の退避値を引き継ぐ。計算へ非選択方式の値を混ぜない。max_duration_sの編集入口を時間hで追加し、取得windowにも同じ秒値を用いる。

取得中のユーザー編集を応答で戻さない。配布更新中の選択変更を保持、古い保存planの遅延応答はplanEpochで破棄。pollは選択jobとmountの寿命を照合。source刷新もworkspaceのload世代を照合。計画と現在入力の不一致は取得開始前に表示し、古いplanでの開始を無効にする。

背景stdを初期選択とし、noneを製品optionから削除。地図通信失敗は地図内の案内・背景だけのretryとして扱い、計算/入力/領域/3Dを再作成しない。古いタイルlayerのcallbackは世代で破棄。WeatherのImage probeも用途終了後にDOMへ書き込まないようguard/handler解除を追加（この1件は初回D0871PlB buildの後、次buildへ含める）。

## 有限検査

- TypeScript `tsc -b` exit0。
- Vitest4.1.11、4 files/35 tests pass。2026-09-29 20:22:55 JST、860ms。
- 追加11試験: 方式復元/JSON保存cache/非選択値の除外、密度則、family適用の固定結果・独立候補保持、延期を含むwindow、実valid時刻、NaN/空対象拒否、経度±360/有限座標/現在window再確認、実APIendpoint/method/bodyとidempotent再送。fetchはmockで外部要求0。
- 初回build `P470/dist/assets/index-D0871PlB.js`、`index-BpVUpfZQ.css`。55modules、Vite8.2.0、3.43s。単一大bundleのwarningあり。
- viteのsceneAssetsコピー先が元はhardcoded frontend/distだったため、resolved build.outDirへ修正した。旧8461配信物は423実体のpath/bytes/hashが前後一致（old-dist-unchanged470.json）。
- この担当は8461/Googleキー/接続タブを操作せず、新8471の実UIもまだ見ていない。実UI検査はrootが担当し、結果を分けて記録する。build結果・試験stdoutはfrontend-verification470.json。

## 未確認と次の受入

rootの8471で、取得中に候補/日時を編集→完成後も旧結果/旧支持が維持→新気象を明示適用→再計算、という連続行程を確認する。丸め後範囲と旧支持を人が区別できるか、時間/量/不足が判断に足りるかを評価する。ネットワーク障害時に背景だけ失敗して結果が残ること、UIの数値保持と保存/reloadも実操作で確認する。科学的MC、過去場解析、取得の全地域/高度保証の完成とは扱わない。

## 初回実UIからの修正（第2build）

rootの実画面 `preparation-before470.png` と独立批評で、取得フォームが旧overlayの左列へ詰まり、禁止域用の右空白と地図の細帯化を招いたことを確認。共通準備を通常の文書flowと用途切替へ改めた。気象側は取得条件/固定計画/取得適用を必要な段だけ示し、DOM/stateを保持。取得状況の要約は他段にも残り、完了だけで段階移動・候補適用しない。対象familyの必要窓を要約し、子別の高度/最大時間は詳細へ置く。地図確認はprepを畳む→fit/scroll→runと必要窓・計画の古さ・新旧境界の識別→条件へ戻る、という行程にした。

実計算注記は『最新予報ではない』から、選んだ初期時刻を固定し自動更新しない運用の説明へ訂正。ConfigEditorの0.52→方式往復についてroot初読に一瞬0.5という疑いがあったが、棚再表示時にDOM value/attributeとも0.52保持を確認したとの報告。静的読解でも更新後configをcacheする接点に直接の反例はなく、この疑いだけに基づく修正は入れていない。有限実UIの続検査はroot票へ戻る。

第2build: `index-BMDw0KtO.js` / `index-C4PprrKc.css`、55 modules、Vite 8.2.0、2.49秒。tsc exit0、35 tests/4 files PASS（20:34:29 JST、855ms）。exact stdoutは `frontend-layout-verification470.json`。前build後のWeather Image probe寿命対策も含む。旧frontend/distをbuild先にしない同じresolved outDir経路。実UIはrootの8471で評価待ち、freezeではない。

## 表示の意味と保存再開の再評価

取得中の状態表示はplan/jobを同一と仮定しない。job.plan_id一致、別plan_idだがcache_key一致、別取得内容の前回jobを区別する。再利用時は0 MBだけを出さず『保存資産を再利用・新規取得』を明示。現在の入力から古くなったplanは、開始ボタン無効と同じ理由を本文にも表示する。旧job/sourceを現在候補へ使う明示操作は保つ。

rootの同build再開確認に先立ち、GET /project revision3をread-onlyで調べた。旧保存には preparationTab と preview.runUtc/windowStart/windowEnd が無く、新build初回表示がそれらを補いdirtyになる経路を確認（saved-project-normalization470.json）。この補完は UI 値のみであり、科学config・runは変更しない。dirtyを一律無視する変更はしていない。同build保存/reloadでも繰返すかはrootが実UIで確認する。

表示修正後buildは `index-C4UQJMm0.js` / `index-C3AMpl9j.css`（55 modules、1.86秒）。TypeScript exit0、exact出力frontend-final-build470.json。ロジック試験は直前35件PASSを参照し、文言/CSSの変更で同じ試験を無意味に反復しない。frontend-source470.json は75実体（基準71＋新規4、変更15）のSHA256票、frontend-index470.jsonは同じ75pathに限定した構文抽出（59 modules、parse error0）。P460 extractorの全directory走査ではruntimeまで494件拾うため、同じcreateSourceFile方式を登録予定集合に限定。実行/型結合/実UI確認の代用ではない。

P470 build後も旧frontend/dist423実体のpath/bytes/hashは一致（old-dist-unchanged470.json）。8461・Google接続・キーは操作していない。新実UIスクリーンショットpreparation-after470.pngを本担当も目視し、取得条件/対象窓と範囲の同時把握、無関係な禁止域空白の解消を確認した。計算精度、MC、過去解析、全地点支持、Google写真の新規確認はこの変更の受入へ含めない。

## 有限受入とbuild hookの修復完了

rootからC4UQJMm0の同build保存/reloadを2回行い『保存済み』復帰、恒常dirty無しの報告を受領。前回別計画job/再利用新規0 MB/+60分候補の支持不足と適用無効を同画面で確認した（old-job-current-plan470.png、独立批評も同じ観察状態を確認）。新7時刻planは取得しておらず追加HTTPを増やしていない。旧保存の新UI字段補完による一度のdirtyと、恒常的な未保存化を区別した。

source_filesの突合で、VitestがoutDirをdummy-non-existing-folderへ設定するためsceneAssets.closeBundleが419配布資産をrepo内へコピーしたことを発見。配布先resolved outDir対応の副作用であり、実装者が見落とした生成境界である。freeze例外としてroot許可後、copyはconfig.command==='build'時だけとし、devのCesium middlewareを維持した。rootが419件とpytest cache4件を全hash付きでP470へ可逆退避（generated-preservation470.json）、その後35 tests PASS（20:57:12 JST、812 ms）でdummy/cacheとも再生成なし。通常buildも成功（C4UQJMm0/C3AMpl9j不変、1.91秒）、tsc PASS。exact出力 frontend-build-hook-repair470.json。source75実体と構文/索引のvite hashを更新し再freeze。

INDEXのみ編集の追加担当として0.47 IMPLEMENTATION_INDEXを同期。33 Python modules、hash変更11件/維持22件、frontend75件/59 modules、20 HTTP入口。acquire_gfsのkeyword-only3引数とcreate_app.weather_options署名を反映し、reviewed_inとpublic再exportは維持。既存未変更kernelの字句edge132件を保持し、変更moduleを有限AST解決したedge208件を更新。thread/acquirer/on_source/Reactの所有をmanual dataflowへ分け、dynamic束縛や実行受入の完全call graphと扱わない。根拠 index470-evidence.json、登録目的/依存はnewassets470.json・existing-assets470-proposal.jsonへ分離しHEALTH/CONTRACT未編集。
