# 0.47 first acquisition stage: root review

2026-09-29. Fixed comparison: private PR30/0.46 C2 `2436152f815a20573e6eca7badedc958c18efe48`; adopted main M420 remains separate. This is the first stage of S36, not completion of the simulator or the active development goal.

## Intended use and judgment

Keep the concrete forecast/planning screens developed through 0.40.1 and integrated in 0.46. A user needs to prepare a forecast covering the launch and potential delays, continue considering vehicle/model conditions while acquisition runs, apply a fixed field deliberately, and compare/reopen fixed results without silent replacement. A fetch button or a landed n=1 is insufficient for the eventual dispersion/forbidden-region/causal-diagnosis use.

Root inspected the running 8471 application, using a deliberately artificial Wakayama launch condition and actual public GFS subset. Independent reviewer rounds 1–8 challenged time support, UI restoration races, candidate families, retry/cache identity, partial transfer accounting, publication crash paths, preparation layout and API documentation. Mechanical passes are recorded separately from these judgments.

## Actual UI and service observations

- Explicit inventory observation found 2026-09-29 06/00 UTC runs. Selected 06, arbitrary-minute launch 30 September 03:30 UTC, 4-hour integration limit; planned/obtained valid 03–08 UTC in six hourly files.
- Center 33.8 N/135.2 E with 180/90 km cardinal half-widths gave outward-rounded bounds 32.75–34.75 N,133.25–137.25 E. Six raw files total 374827 bytes; each successive fetch began at least 10.002197 seconds after prior completion. Accepted field minimum top across all columns/times 48285.043946515194 geometric m.
- While acquisition ran, gas mass was edited to 0.52 kg. Isothermal→constant-speed→isothermal and candidate switches preserved it. An immediate pre-paint DOM value initially suggested a reset; a later full DOM observation and frozen flight input contradicted that hypothesis, so no speculative reset fix was made.
- Completion refreshed available sources without replacing the candidate's old field. Explicit apply retained the 0.52 kg. Run `66bfa1b1-df37-4cb0-9b6c-43c5692d1af8` landed after 8211.664065 seconds. The original result bytes/hash matched exactly after service restart and reopening.
- Replanning the same request and submitting acquisition reused the completed asset, with zero new download bytes. Adding +30/+60 minute children extended the necessary interval to 08:30 UTC and planned seven valid times through 09 UTC. This new plan was not downloaded. The old six-time field cannot cover the +60-minute child's full integration window, and the apply button was disabled with that reason.
- New plan versus previous completed job and raw reuse versus new-transfer-zero are visibly distinguished. A stale plan is disabled, and its prose no longer claims it can start.
- Same-build project save/reload twice returned `saved`. The initial old-build→new-build dirty state was limited to new view-context fields; API evidence and source reading did not show scientific input or result replacement.

`api-evidence470` contains original HTTP response bytes for the acquisition/flight; `reopen-evidence470` is a later separate observation. Earlier PowerShell-converted diagnostic JSON is excluded as original evidence because it converted timestamp representations. UI claims above are operation observations, not inferences from response hashes alone.

## Rejected layout and corrected boundary

The first acquisition form inherited a compact overlay with excessive empty width and a long crowded form. Root and the critic found it unsuitable for a multi-step task involving a map. The accepted finite revision uses normal document flow, weather/forbidden-area purpose switches, three acquisition stages, persistent progress and an explicit map-check/return path. Inputs/jobs stay mounted across stage switches. `preparation-before470.png`, `preparation-after470.png`, `plan-map-loaded470.png`, and `old-job-current-plan470.png` show the relevant states, not all responsive/device cases.

The source inventory caught Vite asset copying into Vitest's `dummy-non-existing-folder`. The plugin now copies only on build. Four pytest-cache files and 419 generated asset files were identified, hash-manifested, reversibly moved to external P470 storage, and checked unchanged. No ignore rule was widened. Subsequent frontend tests did not recreate them; old running frontend/dist 423 files remained byte-identical.

## Documentation and remaining limits

PROGRAM uses actual module hierarchy and explicit cross-boundary calls; root independently viewed pages 2,3,6,8,11 and the document agent viewed all 19 final pages. The API notes were checked against implementation and corrected for exact UI namespace, list/detail integrity checks, enclosing time interval, SOURCE_CHANGED versus DECODER_CHANGED, plan-stale criteria, and complete-asset reuse versus raw re-decode. Generated docs, source/API index, commands, environment guide and S36 play distinct roles.

Single-field n=1 does not produce the user's required 50/90/95% ensemble regions. Real MC, causal analysis from forbidden-region groups, primitive vehicle inputs/distributions, past-weather and long-term statistics remain work. Memory admission estimate (97.2 MB) is not measured process RSS nor a hard limit; observed process peak (151396352 bytes) covers a different scope. Coarse GFS ground and a numeric landing are not validated terrain contact or predictive accuracy. No new Google connection/key read was used in this stage. Frontend bundle-size warning remains; this stage does not establish general startup/performance bounds.

Repository-wide regression, final management checks, commit/push/PR update and fixed readback must be reported from their later actual receipts. Nothing in this pre-save evidence claims those actions are already complete.
