# 元Git追加実体の限定独立診断

固定C2 `2436152f815a20573e6eca7badedc958c18efe48` の登録sourceに対し、未同定だった完全blob 7件すべてが **CRLFをLFへ置換した全bytes** と一致した。原sourceとの直接byte一致ではない。

| 追加blob | 一致した固定source | 原bytes → LF bytes | CRLF数 |
|---|---|---:|---:|
| `2dbdbdd902ab92cbad7a47e63edc86a12721f8b5` | `frontend/src/screens/weather/markup.html` | 12372 → 12361 | 11 |
| `3aa5c469a675a621b42b4f804ae357e10888e1d9` | `frontend/tsconfig.json` | 561 → 533 | 28 |
| `598c50e3d90b610784ed9fb93c2d22b464409bc7` | `frontend/SCREEN_PROVENANCE.md` | 5216 → 5177 | 39 |
| `65951c93493a8592d64e632c59725cfadb46aa9b` | `frontend/package-lock.json` | 57935 → 56283 | 1652 |
| `7484465656eeeab9ddb1f9d34728a57db4a5c523` | `frontend/scene3d/index.html` | 5007 → 4998 | 9 |
| `8a6fd9b2016e8ad9ff74c0e20eba1b1cc015683e` | `frontend/src/screens/forecast/markup.html` | 15782 → 15760 | 22 |
| `aa8e113685dafe3e44dc1699086f38a500afe403` | `frontend/package.json` | 809 → 777 | 32 |

各baselineは固定C2のGit blob SHA1・SHA256・sizeへ再照合。追加blobは完全zlib終端・header・declared size・object名SHA1を独立照合し、CRLF→LF以外の変換なしで全payload一致を確認した。現在登録sourceも読取時点では同じ対応を確認したが、並行開発中のsourceを凍結した意味ではない。

元`.git`は旧1011実体の変更/削除0、追加111の集合も一次診断と一致。独立読取の前後で全1122実体のpath/hashが一致し、HEADファイルも旧票と同じ。既知103blobと未完ZIP prefix1の中身の再診断は今回の7件診断とは別で、一次担当の票に帰属する。

生成主体は未特定。Gitの改行正規化と整合するが、実行processの証明にはしない。削除、元Git編集、新snapshot採用は行っていない。秘密値・任意payload本文は出力していない。

全hashと照合方法は `independent-git-delta470.json` に保持。
