# 0.47 Weather API contract (implementation target)

Base `/api/v1`; JSON mutations; errors use existing `{error:{code,message}}`.
UTC accepts `Z` or `+00:00`, rejects nonzero offsets. No arbitrary URL/file input.

## Inventory (explicit external communication)

`POST /weather-inventories/refresh` body `{run_utc?:string|null, run_limit?:number}`.
`run_limit` default 2, maximum 4. Without run_utc, observe the latest available NOMADS directory entries; with run_utc, observe only that fixed run. This is a bounded synchronous action; may take tens of seconds due to the shared provider gateway.
Returns `{inventory_id, observed_at_utc, product:"gfs.pgrb2.0p25", selection:"latest_observed"|"fixed_run", runs:[{run_utc,available_leads:[0,1,...],complete_lead_set:boolean}], observations:[{url,bytes,sha256,started_at_utc,completed_at_utc,...}]}`. Completeness refers to filenames, never accepted GRIB contents. No latest-global guarantee; only supplied observed directories.
Original responses are saved under `raw_directory` (relative to state root). Each observation has a relative `file`; `manifest_sha256` fixes the inventory manifest. GET detail and plan creation verify saved manifest/raw responses. A failed refresh keeps its partial observation directory and failure record, without publishing a complete inventory.
`GET /weather-inventories` -> `{inventories:[snapshot,...]}`; `GET /weather-inventories/{id}` -> snapshot. GET never makes external requests.

## Fixed acquisition plan

`POST /weather-plans` body:
```json
{
  "inventory_id":"uuid", "run_utc":"2026-09-29T00:00:00Z",
  "region":{"kind":"center","latitude_deg":43.0,"longitude_deg":141.0,"half_width_km":100.0,"half_height_km":100.0},
  "candidate_windows":[{"candidate_id":"C1","launch_time_utc":"2026-09-29T04:17:00Z","max_duration_s":14400.0}],
  "end_margin_s":0.0, "max_bytes":50000000, "max_memory_bytes":268435456
}
```
Alternative region: `{kind:"bounds",west:140,east:143,south:41,north:45}`. Center uses GeographicLib WGS84 cardinal destinations, then outward 0.25 degree grid rounding. Current unsupported seam/pole regions reject explicitly.
Returns `{plan_id,created_at,status:"ready"|"unavailable",request,normalized_request:{run_utc,start_utc,end_utc,bounds,max_bytes,lead_hours},required_window:{start_utc,end_utc},inventory_observed_at_utc,missing_leads,issues:[{code,message}],estimate:{grid_points,time_count,scalar_values,float64_bytes,estimated_working_memory_bytes,max_memory_bytes,max_download_bytes,download_bytes_exact:false},dependencies:{available,versions,missing},cache_key}`.
Plan is persisted and immutable. Coverage is the union of candidate flight windows (launch through max_duration plus end_margin), not launch alone. No run fallback. Estimated memory is conservative admission control, not measured RSS or a precision guarantee.
`GET /weather-plans/{id}` returns plan. No network.

## Acquisition jobs

`POST /weather-acquisitions` body `{plan_id,client_request_id}` -> 202 full job.
`GET /weather-acquisitions` -> `{acquisitions:[job,...]}`.
`GET /weather-acquisitions/{id}` -> job.
`POST /weather-acquisitions/{id}/cancel` body `{}` -> current job (running cancellation is cooperative; may return cancelling until stopped).
`POST /weather-acquisitions/{id}/retry` body `{}` -> 202 same job with incremented attempt; only failed/cancelled/interrupted. Validates frozen plan/decoder and complete saved raw files before reusing. No automatic restart/retry.

Job fields: `{acquisition_id,plan_id,state:"queued"|"running"|"cancelling"|"completed"|"failed"|"cancelled"|"interrupted",attempt,created_at,started_at,finished_at,progress:{phase,completed_files,total_files,bytes_downloaded,bytes_reused},weather_source_id:string|null,reused:boolean,cancellable:boolean,retryable:boolean,error:{code,message}|null}`.
Complete asset reuse sets completed_files=total_files, bytes_downloaded=0, bytes_reused=sum(saved raw provenance bytes); separate bundle_bytes_reused is the normalized gzip size. Retry may complete immediately by reusing a later completed identical asset; an identical active job returns 409 rather than duplicating downloads. Retry history is kept in optional previous_attempts.
One acquisition at a time, finite waiting queue (4). Existing flight worker remains separate. Same request ID is idempotent; conflicting body returns 409. Complete identical request+decoder asset is reused after hash verification. Existing active identical acquisition is returned without launching another download. Partial files never enter the source list.

## Existing source/run connection

`GET /weather-sources` keeps existing shape. Completed acquired assets appear with immutable `id`, label, SHA, bytes, run_utc, valid_times_utc, bounds, metadata, `kind:"acquired_gfs"`, `default_config:null`. Fixtures keep their config and gain `kind:"fixture"`.
Acquired snapshots also contain `support:{minimum_top_geometric_m,ground_model:"coarse_gfs_orography",full_flight_guaranteed:false}`. This is inspected field capacity, not a promised burst height/full trajectory support. At run submission the server checks the current launch through actual integration.max_duration_s against the selected acquired field; unsupported edits return WEATHER_WINDOW_UNSUPPORTED (422).
Acquisition completion **does not edit a candidate**. UI explicitly applies weather_source_id to selected candidate and increments its revision; its other physical inputs stay unchanged. Existing run POST uses this ID as before; old run/input/source snapshots remain immutable. `default_config:null` is intentional: do not fabricate launch altitude/model from newly acquired weather.
`GET /weather-status` -> `{dependencies,max_queued,workers:1}`. No network.

Artificial weather/seasons/MC remain marked artificial and are not replaced with this deterministic GFS n=1 path. Parent/child delay relationships and project UI state keep their existing contracts.

New mutations compare Python source/environment against the running application's startup snapshot. SOURCE_CHANGED (409, or job failed) requires restart. Acquisition progress and completion repeat the check; diagnostic bytes remain, but new assets are not registered on mismatch. Saved GETs, cancellation, and idempotent readback of an already accepted client request remain available. This is before/after drift detection, not an atomic filesystem lock or hot reload.
