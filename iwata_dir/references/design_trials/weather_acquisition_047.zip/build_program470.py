"""Build only the edited PROGRAM_GUIDE into a fresh P470 directory; never publish."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

R = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P = Path(__file__).resolve().parent
tag = sys.argv[1]
S, O = P / ('program-source470-'+tag), P / ('program-build470-'+tag)
assert not S.exists() and not O.exists(), 'Use a fresh build tag; preserve earlier evidence'
source = R / 'docs/PROGRAM_GUIDE.tex'
body = source.read_text(encoding='utf-8')
assert '[更新:0.47.0]' in body and 'WEB-WEATHER' in body and 'WEB-PREPARATION' in body
expected_pages = sum(line.startswith('\\Page{') for line in body.splitlines())
S.joinpath('docs').mkdir(parents=True)
shutil.copyfile(source, S / 'docs/PROGRAM_GUIDE.tex')
env = os.environ.copy()
env['PATH'] = r'C:/Users/genia/.local/share/balloon-docs/TinyTeX/bin/windows' + ';' + env['PATH']
env['FONTCONFIG_FILE'] = r'C:/Users/genia/.local/share/balloon-docs/fonts.conf'
env['PYTHONUTF8'] = '1'
cmd = [sys.executable, '-B', str(R / 'tools/build_guides.py'), str(S), '--output-dir', str(O), '--guide', 'PROGRAM_GUIDE']
result = subprocess.run(cmd, cwd=R, env=env, capture_output=True, timeout=580)
(P / ('program-build470-'+tag+'-driver.stdout')).write_bytes(result.stdout)
(P / ('program-build470-'+tag+'-driver.stderr')).write_bytes(result.stderr)
assert result.returncode == 0, 'Build failed; inspect driver/pass logs'
renderer = r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
render_cmd = [renderer, '-r', '100', '-png', str(O / 'PROGRAM_GUIDE.pdf'), str(O / 'page')]
rendered = subprocess.run(render_cmd, capture_output=True, timeout=180)
(O / 'render.stdout').write_bytes(rendered.stdout)
(O / 'render.stderr').write_bytes(rendered.stderr)
assert rendered.returncode == 0, 'Render failed'
assert source.read_bytes() == (S / 'docs/PROGRAM_GUIDE.tex').read_bytes(), 'TeX changed during build'
from pypdf import PdfReader
reader = PdfReader(O / 'PROGRAM_GUIDE.pdf')
pngs = sorted(O.glob('page-*.png'))
assert len(pngs) == len(reader.pages) == expected_pages
report = {'root': str(R), 'source_copy': str(S), 'build': str(O),
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'build_command': cmd, 'render_command': render_cmd, 'pages': len(reader.pages),
          'rendered_pages': [p.name for p in pngs], 'build_exit': result.returncode,
          'render_exit': rendered.returncode,
          'pending': 'Visual review; root alone decides PDF/txt publication and management updates'}
(O / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(report, ensure_ascii=False))
