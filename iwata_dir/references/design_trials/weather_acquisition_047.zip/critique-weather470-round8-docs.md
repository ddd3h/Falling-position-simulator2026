# 第8巡：操作・実装資料と源実体の限定照合

対象は0.47追加の取得準備、GFS再開、COMMANDS C-04/C-09、BUILD冒頭、およびPROGRAMの新しい枝。全既存資料・科学式の再受入ではない。源は編集せず、主担当へ具体的訂正を返した。

## 誤った保証や名前を渡さないための指摘

1. 保存namespaceは `ui_state.forecast_real.weatherPreparation`。Saved型はWeatherPreparation、transportはweatherAcquisition、App/ForecastScreenが接続。架空のweather_preparationを削る。
2. inventoryの一覧はDB読出し。manifest/raw照合は詳細取得・計画作成。全一覧を検証済としない。
3. required_windowは親子各窓の最早開始～最遅終了＋marginの包絡区間。離れた窓の間も含むため集合の和という記述を改める。
4. 起動source/Python/NumPy/SciPy差のSOURCE_CHANGEDと、固定planの復号器差DECODER_CHANGEDを分ける。再起動が後者を自動解消するわけではない。
5. 再計画は取得条件・対象時間窓の変更で必要。ガス量等の物理編集で一律に旧計画を無効化しない。明示適用はsource IDとcandidate revisionを進める。
6. raw全数だけなら再復号、完成bundle＋receiptがある場合はhash検査後に再利用。完了provenanceは失敗partialの全メタデータまで保証しない。

上記のNOTES初回訂正を実読し主要な差の解消を確認した。続けてCOMMANDSへ、事前拒否はfailure.json/出力directory生成より前の場合があること、SOURCE_CHANGED後もdecoder変更なら再計画が必要なこと、現行0.47/S36への入口訂正を返した。これら後続訂正の確定は主担当が行う。

PROGRAMでは fixture がApplicationService._load_sources、完成assetがWeatherService.source_recordsから親へ合流する責務と、inventory/planは同期APIで専用threadは取得job以降という区別を返した。図担当が修正を報告。全19頁の視覚受入は図担当/主担当の別証拠。

## UIの再評価

old-job-current-plan470.pngを表示して読んだ。『別の固定計画の取得（前回・履歴）』、現在計画の取得済表示ではない説明、新規0 MB/再利用0.4 MB、＋60分候補の時間支持外と適用無効が同じ画面で読める。第7巡の新planと旧completed混同はこの観察状態では解消。全状態/実マウス/再読後dirtyの独立検証までは行っていない。

## 管理補助候補

metadata470.pyは固定221sourceから既存460補助を移行して作成のみ。basis receipt全体の元.git差とsource一致を区別し、Git受入へ拡張しない。PLAN/THEORY6bytes保持、schema/policy/guard不変、明示新assets/既存proposalのSHA、rootのscope別own/dependency digestと根拠を要求する。新S36を登録しS35は先頭data-activity current→historyの一箇所以外のown本文/登録を保持する。BOOTSTRAPはroot所有なので確認印も外側proposalだけ返す。newassets未確定時点ではproposal hash未設定で実行拒否。補助自体をimport/実行せず、AST構文のみ確認した。
