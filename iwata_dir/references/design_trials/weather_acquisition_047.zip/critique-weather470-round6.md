# 0.47 独立批評・第6巡（実行証拠と新構成source）

## 実機能行程の証拠との関係

主担当が保存した api-evidence470/receipt.json と原応答5本（sources/acquisitions/inventories/project/result）をこの担当が読取り、全5本のbytes/SHA一致を再計算した。resultのlanded/gas_mass_kg=0.52、result weather SHAとsource SHAの同一性、保存候補source、初回374827bytes/再利用0bytesの2jobが同一sourceを指すことを読取確認した。これは保存された証拠の照合であり、この担当が新たに実HTTPやUI操作を行ったという意味ではない。

主担当によるモデル往復・途中編集・完了時の非自動適用の実UI観察は、数値的な終状態と区別する。旧D0871PlBでの有限機能行程が成立したことは、新共通準備レイアウトの視覚的受入を意味しない。

## BMDw0KtOへつながる限定改善のsource再読

- 共通準備の用途を気象/禁止領域で切り替え、通常文書flowへ変更した。
- 気象の取得条件/固定計画/取得適用はhiddenによる切替で、入力・plan・jobを保持する。
- 親と延期の総数・最早放球〜最遅終了の窓を表に先立って要約し、子別の高度や飛行上限はdetailsで確認できる。detailsを閉じても計算対象から除かれない。
- 地図確認は準備を畳む→fit/scroll、地図上の計画要約から条件段へ戻る。新取得の橙破線と旧固定結果の支持範囲を区別する。
- jobの短い状態は各気象段に共通して残り、完了だけで自動の画面遷移/候補適用を行わない。

第5巡の原因へ戻った修正であり、候補/比較/詳細/地図全体を作り直す変更ではない。新スクリーンショットの評価は未了。

## 残る局所反例

旧screen.cssの汎用 `.notice{height:26px;overflow:hidden}` が、取得計画staleの新p.noticeにも適用される。狭幅や改行で『計画を作り直す』理由が切れる可能性があるため、気象準備内だけheight:auto/overflow:visibleとする案を担当へ通知した。主担当の新UI行程でstale状態も見て、この表示を有限確認する必要がある。

## source起動guardの追加読解

backend担当から依頼された起動source照合を読んだ。新規取得/計画/worker進捗・前後を停止する一方、GET・取消・同一client IDの既存job読戻しは維持する境界が適切である。原文/rawを保持し、source不一致をfailureとする処理も確認した。_publishがgzip読込と場全体検査を含むため、そのreturn後からasset DB insert前にもう一度source照合を置く案を通知した。瞬間的なあらゆるfilesystem変更を厳密排除する保証とは扱わず、長い処理の前後を揃えるための指摘である。
