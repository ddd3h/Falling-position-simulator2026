# Frontend 0.47 着手前の読み取り調査

基準 C2 `2436152f815a20573e6eca7badedc958c18efe48`。ここでは source を変更せず、8461 のタブ・サーバー・build を操作していない。root の API 契約待ち。

## 地図の通常利用を初期状態へ戻す

目的は背景接続の手順を製品操作として負わせず、地名・道路・写真と軌道/領域を同時に読めること。通信失敗を計算結果の喪失や再計算と結び付けない。

1. `forecast/markup.html` の `#baseLayer` から `none` を除き、std を初期選択、photo を切替候補として残す。`forecast/controller.js:baseLayer` の none 製品分岐を除く。旧保存値 none/不明値は復元入口で std へ正規化する。現在 `snapshot/restore` は basemap を保存していないため、用途往復・計画復元で明示選択を維持したい場合は `ui_state` の同じ用途viewへ std/photo だけを保存する。
2. App の `background=false` と「地理院の背景へ接続」checkbox を通常製品導線から除き、WeatherScreen/runtime の背景有効を標準にする。weather の `geoFrame`、impact-map の `setBase` は既存タイル経路を使用。画面を描く必要がある範囲だけ要求し、Google写真3Dの接続許可やキー寿命には変更を加えない。
3. Forecast の `#mapLoadNotice` は既に tileerror で地図内の案内を出し、計算候補/履歴/領域を別layerとして保持する。しかし tile callback が古い layer のまま残る可能性があり、背景切替/再試行の世代と現在layerを照合し、dispose後・旧世代のイベントは無視する。現在累積 ok/bad を持つため、retry は当該タイルlayerの再取得に限定して数え直す。
4. 地図取得エラーの案内は「標準地図/写真の一部を取得できません。計算結果は保持しています。再試行」で地図に局在させる。mapを作り直したり、全画面の読直し・計画loadを求めたりしない。Map Tiles API/3Dのセッションを巻き込まない。
5. Weather は既に表示範囲単位の `mapStatus/retryMaps` と画像失敗時の非表示を持つ。ON/OFF接続説明を削る一方、失敗・取得中・成功の出典とretryは維持。`impact-map`も同様。SVG出力は取得成功の背景のみを埋込み、失敗時に背景を取得済みと偽らない。
6. 無通信試験が必要なときは開発・試験の注入境界でタイル要求をstub/遮断する。製品選択肢へ `none` を残して試験事情を利用者へ転嫁しない。検査で実GSI要求が発生する場合の許可範囲はrootのS36手順に従う。

有限受入: std初期表示/写真切替、tile全失敗/一部失敗でも同じ固定run・入力・領域・グラフ保持、retry成功、切替前layerの遅い失敗通知を無視、2D→3D→2Dで背景選択と整列保持。既存CSS故障guardは通信失敗と別経路のまま保持する。

## ConfigEditor の方式切替で値を保持する

現在 `ascent`、`burst`、`descent`、`descent.density_model` のselectで毎回literal初期値へ置換する。最後の注意書きも値消失を仕様化している。比較のため往復する操作で自分の入力を失うため、表示の移植を超えて入力接点で直す必要がある。

推奨は **有効な科学入力はCandidate.config、選択していない方式の編集値は候補別UI下書き** に分けること。Configに非選択方式のパラメータを混在させず、核/APIへの送信形式を明確に保つ。

- 保存先案: `project.ui_state.forecast_real.editor_models[candidateId]`。component local stateだけに置かない。画面のunmount、候補切替、計画保存/reloadでも保持するため。
- 純粋関数で `(config, cache, section, targetMode) -> {config, cache}` を求める。現在方式の値をcacheへ退避してから、新方式の保存値があれば復元し、初めて選ぶ方式だけ既存初期値を使う。React/Appがconfigとcacheを一つのproject mutationで反映する。ConfigEditorとcontrollerに別正本を作らない。
- ascentはconstant_speed / isothermal_buoyancy、burstはaltitude / diameter、descentはconstant_cda / rated_speedを分ける。rated_speed内のweather / exponentialもそれぞれのreference_density / scale_heightを退避して復元する。共通のreference_speedは方式内で保持する。
- 既存保存計画にcacheがない場合は現在configを初期cacheとして扱う。使ったことのない別方式にユーザーの過去値があると装わない。
- 複製はcacheもdeep-copy、削除はその候補cacheだけ整理。遅延子は親のconfigに従属している間は親の編集cacheを参照または複製し、独立化した時点で子が自身の下書きを所有する。親変更で旧固定runを書き換えない。
- 保存結果から草案へ「戻す」はrunのsubmitted_inputを戻す現在方針を維持し、その選択方式のcacheを更新する。別方式の退避値まで消さない。
- 定速上昇＋径破裂の未対応組合せは今の明示警告を維持する。勝手に径値や上昇モデルを変更しない。開始ボタンはAPI契約に合う入力検査で扱う。
- 「初期値になります」の文言を、方式ごとの入力を保持する説明へ直す。未入力/NaNを0に置換しない。途中の空入力をどこまで保存するかは今回API契約と合わせ、暗黙にnullを科学値として送らない。

有限受入: 入力値を変えて各方式A→B→Aで元の値、候補間切替、用途往復、保存/reload、複製、親/遅延独立化、固定runの不変性、unsupported組合せの表示。方式を戻しただけで変更済みと誤判定しないことも submitted_input 比較で確認する。
