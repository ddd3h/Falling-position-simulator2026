# 0.38 地図外の操作帯・接続表示の独立差分批評

2026-09-26 / weather370。基準C2-370、main M350別。主担当が人工形状を1280×720で視認して見つけた「操作帯が約670px幅で地形を遮る」への修復が対象。新機能・再設計案は追加せず、今回変更された状態表示と接続寿命だけを確認した。

## 判定

sourceではtools/status/mouseguideが地図のmain要素の外に移り、地図の上へposition:absoluteで置く構成がなくなった。接続欄を成功後に畳む処理も、入力と説明だけを対象とし、接続試行数と解除を残している。この構造は、地形を読みながら必要な操作へ戻る目的に沿っている。

有限モックでは **既存接続の描画失敗を新規接続の失敗と混同しない**ことを確認した。接続寿命や利用枠に関する新しい阻害は見つからず、この差分の意味は受入可能。実際の地図面積・折返し・操作帯の占有率は主担当の実画面確認へ分ける。

## 実読と試験

`cesium-probe/index.html`、`style.css` 全文、mainの `updateConnectionLayout`、`background`、成功/失敗、synthetic、ResizeObserverを読んだ。従来の独立モックからDOM/Cesiumの準備だけを再利用し、今回の状態遷移を狭く実行した。既存22条件と意味14条件を件数のために再実行していない。

| 場面 | 確認できたこと |
|---|---|
| 未接続→接続処理中 | 初期入力は見える。開始時は入力を畳み、試行1と解除を残す。helperは明示submitの1回だけ |
| 接続成功→背景表示 | 入力を畳み、接続保持の短い表示と解除を残す |
| 部分的なtile失敗 | 実meshを表示しながら一部欠落を告知する。入力は畳んだままで、再接続を誘わない |
| 既存tilesetの描画失敗・一定時間表示なし | 入力と説明は戻るがconnectはdisabledのまま。「解除後」の説明と既存tilesetを保持。submitを直接呼んでも追加helperなし |
| 既存背景の回復 | 同じ接続で部分表示へ復帰し、入力を再び畳む。新規helperなし |
| 明示解除→次のroot取得が拒否される | 未接続として入力/説明が見え、次の明示再試行が可能。待機やresizeでは自動再試行しない |
| 接続欄の折畳みやcanvasのresize | 同じViewerのresizeと再描画要求のみ。tileset交換・追加helperなし |
| 独立synthetic | Google接続欄を隠し、背景にGoogle接続0を明記。人工tilesetの表示とresizeでGoogle helperは0 |

Google経路は13条件、syntheticは3条件。Googleモックのhelper計2回は、初回と明示解除後に試験で再入力した分で、エラー/resizeによる追加ではない。実Google通信・請求件数を測ったものではない。

## 原票と再現入口

- `layout-state-critic380-google-mock.json`
- `layout-state-critic380-synthetic.json`
- `layout-state-critic380-run.mjs`（実行：引数なし／`synthetic`）
- `prepare-layout-state-critic380.mjs`（既存 `request-budget-mock380.mjs` の準備部から上の有限runnerを再生成）

試験時SHA256：main `78eff0dd940b18a3faa0008d1c4364d565f57a17ad9ad502f9e273b35b4e5d4d`、HTML `f5c30a01b856eb11b9f96835828d38881f08018f94f78107d210f8c19873972b`、CSS `cf835c9a6e7686084a265abf221653e51d935c971f39189c7b60b2279778e0a4`。意味14条件の対象だったview-memory/overlaysとproviderは、その前回受入SHAのままと別途照合した。

## 受入の限界

fake DOM/ResizeObserverなので、実ブラウザで帯が何px占めるか、canvas実面積、実GPUのリサイズ、Google写真での判読は保証しない。部分失敗時に入力を畳み続けるのは意図した区別で、部分欠落の説明を隠す意味ではない。右drag未確認など既存の用途境界もこの配置修復で解消した扱いにしない。実キー・実Googleタブを操作せず、追加の外部接続は行っていない。
