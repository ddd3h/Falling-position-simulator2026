import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import vm from 'node:vm';

// Independent finite lifecycle probe. No SDK, browser, HTTP server or provider network.
const root='C:/Users/genia/AppData/Local/Temp/balloon-design-380';
const source=root+'/cesium-probe/src/';
const checks=[], counts={viewers:0,viewerDestroys:0,googleHelperCalls:0,tilesetDestroys:0,entityAdds:0,entityClears:0};
const turn=()=>new Promise(resolve=>setImmediate(resolve));
const check=(name,fn)=>{fn();checks.push(name);};
const node=id=>({id,value:'',hidden:false,disabled:false,checked:true,textContent:'',dataset:{},style:{setProperty(){}},children:[],clientWidth:1366,clientHeight:650,events:{},addEventListener(type,fn){this.events[type]=fn;},replaceChildren(...items){this.children=items;},append(...items){this.children.push(...items);}});
const nodes=new Map();
const element=id=>{if(!nodes.has(id))nodes.set(id,node(id));return nodes.get(id);};
const bus={},posted=[],pending=[],viewers=[];
const event=()=>({listeners:[],addEventListener(fn){this.listeners.push(fn);},fire(...args){this.listeners.forEach(fn=>fn(...args));}});
const tile=label=>({label,tilesLoaded:true,tileFailed:event(),tileLoad:event(),tileVisible:event(),loadProgress:event(),destroy(){counts.tilesetDestroys++;this.destroyed=true;}});
const C={
 Ion:{defaultAccessToken:'test-placeholder'},
 Math:{toDegrees:x=>x*180/Math.PI,toRadians:x=>x*Math.PI/180},
 Cartesian3:{fromDegrees:(...values)=>values,clone:v=>({...v})},HeadingPitchRange:class{constructor(...values){this.values=values;}},Matrix4:{IDENTITY:'identity'},
 CameraEventType:{WHEEL:1,PINCH:2,RIGHT_DRAG:3,MIDDLE_DRAG:4,LEFT_DRAG:5},KeyboardEventModifier:{CTRL:1},ScreenSpaceEventType:{LEFT_DOUBLE_CLICK:1},
 ClassificationType:{CESIUM_3D_TILE:1},HeightReference:{CLAMP_TO_3D_TILE:1},PolygonHierarchy:class{constructor(positions,holes){this.positions=positions;this.holes=holes;}},
 Color:{WHITE:'white',fromCssColorString(value){return{value,withAlpha(alpha){return{value,alpha};}};}},
 PolylineOutlineMaterialProperty:class{constructor(options){Object.assign(this,options);}},
 createGooglePhotorealistic3DTileset(apiOptions,tilesetOptions){
  counts.googleHelperCalls++;assert.equal(typeof apiOptions.key,'string');assert.equal(apiOptions.onlyUsingWithGoogleGeocoder,true);
  assert.equal(tilesetOptions.maximumScreenSpaceError,8);assert.equal(tilesetOptions.cacheBytes,384*1024*1024);
  let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});pending.push({resolve,reject});return promise;
 },
 Viewer:class{
  constructor(map,options){counts.viewers++;this.options=options;this.useDefaultRenderLoop=true;this.camera={frustum:{fovy:Math.PI/3},positionCartographic:{longitude:0,latitude:0,height:1000},heading:0,pitch:-1,positionWC:{x:1,y:2,z:3},directionWC:{x:0,y:1,z:0},upWC:{x:0,y:0,z:1},lookAt(){},lookAtTransform(){},setView(pose){this.positionWC={...pose.destination};this.directionWC={...pose.orientation.direction};this.upWC={...pose.orientation.up};}};
   this.scene={screenSpaceCameraController:{},renderError:event(),preRender:event(),postRender:event(),requestRender(){},primitives:{items:[],add(item){this.items.push(item);}}};
   this.entities={removeAll(){counts.entityClears++;},add(item){counts.entityAdds++;return item;}};this.screenSpaceEventHandler={removeInputAction(){}};viewers.push(this);
  }
  resize(){counts.resizes=(counts.resizes||0)+1;} destroy(){counts.viewerDestroys++;this.scene.primitives.items.forEach(item=>item.destroy());this.destroyed=true;}
 }
};
const fakeParent={postMessage(message){posted.push(message);}};
globalThis.window={Cesium:C,addEventListener(type,fn){(bus[type]??=[]).push(fn);}};
globalThis.parent=fakeParent;
globalThis.location={protocol:'http:',origin:'http://localhost:mock',search:''};
globalThis.document={getElementById:element,createElement:tag=>node(tag)};
globalThis.devicePixelRatio=1;
const resizeCallbacks=[];globalThis.ResizeObserver=class{constructor(callback){resizeCallbacks.push(callback);}observe(){}};
const send=(type,payload)=>{for(const fn of bus.message||[])fn({source:fakeParent,origin:location.origin,data:{type,schema:'bjp-scene3d-v1',payload}});};
const submit=(value='mock_only_not_a_real_key')=>{element('apiKey').value=value;element('connectForm').events.submit({preventDefault(){}});};
const d=()=>window.SCENE3D_DIAGNOSTICS;
let fakeNow=0;Object.defineProperty(globalThis,'performance',{value:{now:()=>fakeNow},configurable:true});
const synthetic=process.argv[2]==='synthetic';
if(synthetic){globalThis.parent=window;location.search='?probe=synthetic';C.Cesium3DTileset={fromUrl:async()=>tile('synthetic')};}
await import(pathToFileURL(source+'main.js').href+'?layout-state-probe=1');
const {fixture}=await import(pathToFileURL(source+'fixture.js').href);

if(synthetic){
 await turn();
 check('synthetic hides Google input and makes no Google helper attempt',()=>{assert.equal(element('connection').hidden,true);assert.equal(counts.googleHelperCalls,0);assert.equal(d().rootRequestAttempts,0);assert.equal(d().provider,'synthetic-fixture');});
 const v=viewers[0],t=v.scene.primitives.items[0];v.scene.preRender.fire();t.tileVisible.fire();v.scene.postRender.fire();
 check('synthetic visible status explicitly says Google connection zero',()=>{assert.match(element('backgroundStatus').textContent,/Google接続0/);assert.equal(d().googleConnected,false);});
 for(const callback of resizeCallbacks)callback();
 check('synthetic layout resize does not introduce Google usage',()=>{assert.ok(counts.resizes>0);assert.equal(counts.googleHelperCalls,0);assert.equal(viewers.length,1);});
}else{
 check('initial input visible and no automatic Google start',()=>{assert.equal(element('connection').hidden,false);assert.equal(element('keyEntry').hidden,false);assert.equal(counts.googleHelperCalls,0);});
 send('bjp-scene3d-open',fixture());await turn();submit();await turn();
 check('pending connection folds only input, retaining counter and cancel',()=>{assert.equal(element('keyEntry').hidden,true);assert.equal(element('connection').hidden,false);assert.equal(element('disconnect').hidden,false);assert.equal(element('rootCount').textContent,'1');assert.equal(counts.googleHelperCalls,1);});
 const first=tile('first');pending[0].resolve(first);await turn();await turn();
 check('successful connection remains folded without an extra start',()=>{assert.equal(element('keyEntry').hidden,true);assert.equal(element('connect').disabled,true);assert.equal(d().connection,'loading');assert.equal(counts.googleHelperCalls,1);});
 const v=viewers[0];v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('visible background keeps short connection row and explicit release',()=>{assert.equal(d().connection,'visible');assert.equal(element('keyEntry').hidden,true);assert.match(element('connectionState').textContent,/保持/);assert.equal(element('disconnect').hidden,false);});
 element('map').clientHeight=480;for(const callback of resizeCallbacks)callback();
 check('canvas resize after folding resizes same Viewer without a helper call',()=>{assert.ok(counts.resizes>0);assert.equal(viewers.length,1);assert.equal(counts.googleHelperCalls,1);assert.equal(v.scene.primitives.items[0],first);});
 first.tileFailed.fire();v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('partial failure keeps input folded but communicates missing data, never reconnecting',()=>{assert.equal(d().connection,'partial');assert.equal(element('keyEntry').hidden,true);assert.match(element('backgroundStatus').textContent,/一部取得に失敗/);assert.equal(element('connect').disabled,true);assert.equal(counts.googleHelperCalls,1);});
 v.scene.renderError.fire();
 check('render failure shows input/help again but does not permit a second active connection',()=>{assert.equal(d().connection,'error');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,true);assert.match(element('connectionState').textContent,/解除後/);assert.equal(v.scene.primitives.items[0],first);});
 submit();await turn();
 check('submit after active-render failure cannot create another Google helper call',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(viewers.length,1);});
 fakeNow=16001;v.scene.preRender.fire();v.scene.postRender.fire();
 check('no visible tiles after wait is unavailable, input restored but active connect stays disabled',()=>{assert.equal(d().connection,'unavailable');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,true);assert.equal(counts.googleHelperCalls,1);});
 v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('existing background recovers and folds help without reconnect',()=>{assert.equal(d().connection,'partial');assert.equal(element('keyEntry').hidden,true);assert.equal(counts.googleHelperCalls,1);});
 element('disconnect').onclick();
 check('deliberate disconnect restores input and permits a later explicit attempt',()=>{assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,false);assert.equal(element('disconnect').hidden,true);assert.equal(d().connection,'disconnected');assert.equal(counts.googleHelperCalls,1);});
 submit();await turn();pending[1].reject({statusCode:403});await turn();await turn();
 check('initial-root refusal differs from active-render failure and allows explicit retry',()=>{assert.equal(d().connection,'error');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,false);assert.equal(element('connectionState').textContent,'未接続');assert.equal(counts.googleHelperCalls,2);});
 for(const callback of resizeCallbacks)callback();await turn();
 check('resize or waiting after root refusal does not silently retry',()=>{assert.equal(counts.googleHelperCalls,2);});
}
const hashes={};for(const file of [source+'main.js',root+'/cesium-probe/index.html',root+'/cesium-probe/style.css'])hashes[file.slice(root.length+1)]=createHash('sha256').update(await readFile(file)).digest('hex');
const output={method:'Narrow delta review using actual main source, fake DOM/Cesium/clock/ResizeObserver. No Google or browser.',mode:synthetic?'synthetic':'google-mock',checks,counts,hashes,limits:['Does not prove viewport bounds, readable map area, real browser resize or photo quality.','Google helper attempts only; not HTTP or billing count.','Existing 22 lifecycle and 14 semantic checks preserved separately; not rerun here.']};
await writeFile(root+'/reviews/layout-state-critic380-'+(synthetic?'synthetic':'google-mock')+'.json',JSON.stringify(output,null,2)+String.fromCharCode(10));console.log(JSON.stringify(output));
