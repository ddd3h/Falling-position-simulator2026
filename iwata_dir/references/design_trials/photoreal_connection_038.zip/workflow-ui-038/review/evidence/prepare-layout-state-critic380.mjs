import {readFile,writeFile} from 'node:fs/promises';
const root='C:/Users/genia/AppData/Local/Temp/balloon-design-380';
const previous=await readFile(root+'/reviews/request-budget-mock380.mjs','utf8');
let setup=previous.slice(0,previous.indexOf("check('startup"));
setup=setup.replace('globalThis.ResizeObserver=class{observe(){}};', 'const resizeCallbacks=[];globalThis.ResizeObserver=class{constructor(callback){resizeCallbacks.push(callback);}observe(){}};');
setup=setup.replace('resize(){} destroy(){','resize(){counts.resizes=(counts.resizes||0)+1;} destroy(){');
setup=setup.replace("await import(pathToFileURL(source+'main.js').href+'?independent-budget-probe=1');", `let fakeNow=0;Object.defineProperty(globalThis,'performance',{value:{now:()=>fakeNow},configurable:true});
const synthetic=process.argv[2]==='synthetic';
if(synthetic){globalThis.parent=window;location.search='?probe=synthetic';C.Cesium3DTileset={fromUrl:async()=>tile('synthetic')};}
await import(pathToFileURL(source+'main.js').href+'?layout-state-probe=1');`);
const cases=String.raw`
if(synthetic){
 await turn();
 check('synthetic hides Google input and makes no Google helper attempt',()=>{assert.equal(element('connection').hidden,true);assert.equal(counts.googleHelperCalls,0);assert.equal(d().rootRequestAttempts,0);assert.equal(d().provider,'synthetic-fixture');});
 const v=viewers[0],t=v.scene.primitives.items[0];v.scene.preRender.fire();t.tileVisible.fire();v.scene.postRender.fire();
 check('synthetic visible status explicitly says Google connection zero',()=>{assert.match(element('backgroundStatus').textContent,/Google接続0/);assert.equal(d().googleConnected,false);});
 for(const callback of resizeCallbacks)callback();
 check('synthetic layout resize does not introduce Google usage',()=>{assert.ok(counts.resizes>0);assert.equal(counts.googleHelperCalls,0);assert.equal(viewers.length,1);});
}else{
 check('initial input visible and no automatic Google start',()=>{assert.equal(element('connection').hidden,false);assert.equal(element('keyEntry').hidden,false);assert.equal(counts.googleHelperCalls,0);});
 send('bjp-scene3d-open',fixture());await turn();submit();await turn();
 check('pending connection folds only input, retaining counter and cancel',()=>{assert.equal(element('keyEntry').hidden,true);assert.equal(element('connection').hidden,false);assert.equal(element('disconnect').hidden,false);assert.equal(element('rootCount').textContent,'1');assert.equal(counts.googleHelperCalls,1);});
 const first=tile('first');pending[0].resolve(first);await turn();await turn();
 check('successful connection remains folded without an extra start',()=>{assert.equal(element('keyEntry').hidden,true);assert.equal(element('connect').disabled,true);assert.equal(d().connection,'loading');assert.equal(counts.googleHelperCalls,1);});
 const v=viewers[0];v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('visible background keeps short connection row and explicit release',()=>{assert.equal(d().connection,'visible');assert.equal(element('keyEntry').hidden,true);assert.match(element('connectionState').textContent,/保持/);assert.equal(element('disconnect').hidden,false);});
 element('map').clientHeight=480;for(const callback of resizeCallbacks)callback();
 check('canvas resize after folding resizes same Viewer without a helper call',()=>{assert.ok(counts.resizes>0);assert.equal(viewers.length,1);assert.equal(counts.googleHelperCalls,1);assert.equal(v.scene.primitives.items[0],first);});
 first.tileFailed.fire();v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('partial failure keeps input folded but communicates missing data, never reconnecting',()=>{assert.equal(d().connection,'partial');assert.equal(element('keyEntry').hidden,true);assert.match(element('backgroundStatus').textContent,/一部取得に失敗/);assert.equal(element('connect').disabled,true);assert.equal(counts.googleHelperCalls,1);});
 v.scene.renderError.fire();
 check('render failure shows input/help again but does not permit a second active connection',()=>{assert.equal(d().connection,'error');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,true);assert.match(element('connectionState').textContent,/解除後/);assert.equal(v.scene.primitives.items[0],first);});
 submit();await turn();
 check('submit after active-render failure cannot create another Google helper call',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(viewers.length,1);});
 fakeNow=16001;v.scene.preRender.fire();v.scene.postRender.fire();
 check('no visible tiles after wait is unavailable, input restored but active connect stays disabled',()=>{assert.equal(d().connection,'unavailable');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,true);assert.equal(counts.googleHelperCalls,1);});
 v.scene.preRender.fire();first.tileVisible.fire();v.scene.postRender.fire();
 check('existing background recovers and folds help without reconnect',()=>{assert.equal(d().connection,'partial');assert.equal(element('keyEntry').hidden,true);assert.equal(counts.googleHelperCalls,1);});
 element('disconnect').onclick();
 check('deliberate disconnect restores input and permits a later explicit attempt',()=>{assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,false);assert.equal(element('disconnect').hidden,true);assert.equal(d().connection,'disconnected');assert.equal(counts.googleHelperCalls,1);});
 submit();await turn();pending[1].reject({statusCode:403});await turn();await turn();
 check('initial-root refusal differs from active-render failure and allows explicit retry',()=>{assert.equal(d().connection,'error');assert.equal(element('keyEntry').hidden,false);assert.equal(element('connect').disabled,false);assert.equal(element('connectionState').textContent,'未接続');assert.equal(counts.googleHelperCalls,2);});
 for(const callback of resizeCallbacks)callback();await turn();
 check('resize or waiting after root refusal does not silently retry',()=>{assert.equal(counts.googleHelperCalls,2);});
}
const hashes={};for(const file of [source+'main.js',root+'/cesium-probe/index.html',root+'/cesium-probe/style.css'])hashes[file.slice(root.length+1)]=createHash('sha256').update(await readFile(file)).digest('hex');
const output={method:'Narrow delta review using actual main source, fake DOM/Cesium/clock/ResizeObserver. No Google or browser.',mode:synthetic?'synthetic':'google-mock',checks,counts,hashes,limits:['Does not prove viewport bounds, readable map area, real browser resize or photo quality.','Google helper attempts only; not HTTP or billing count.','Existing 22 lifecycle and 14 semantic checks preserved separately; not rerun here.']};
await writeFile(root+'/reviews/layout-state-critic380-'+(synthetic?'synthetic':'google-mock')+'.json',JSON.stringify(output,null,2)+String.fromCharCode(10));console.log(JSON.stringify(output));
`;
await writeFile(root+'/reviews/layout-state-critic380-run.mjs',setup+cases);
console.log('Prepared finite state runner from existing mock setup; application source unchanged.');
