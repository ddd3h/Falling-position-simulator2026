# 近接した対象の見直しと輪郭判読性 — 実装前レビュー

2026-09-26 / needs360_metadata。rootの実Google観察と自己批評に対する検討。ここに書いた新しい操作はこの記録時点では未実装。実キーの取得・再接続・旧liveセッションreloadはしていない。

rootは既存の同一Google接続で、人工禁止領域2面とA28/B3の干渉点を重ね、道路/林縁/建物の近接確認で内外関係が読める用途価値を観察した。一方、90/95%の細いcyan系輪郭が写真に埋もれ、接近で交点が端へ寄ると全地域resetしかなく、同じ箇所を見直す負担があるとの批評を受けた。

## 輪郭のハロー

まず輪郭だけへ標準 `PolylineOutlineMaterialProperty` の単色暗い縁取りを追加する案が小さい。明暗2重描画・独自shader・軌道範囲の面は先取りしない。候補色と50/90/95の芯の幅を保ち、写真との区切りだけを加える。

実読した固定Cesium engine26.3.0（CesiumJS1.145.0）の `Shaders/Materials/PolylineOutlineMaterial.glsl` は、芯幅を `v_width - outlineWidth` とする。従って既存の芯幅4/2.5/1.2pxを維持する案は、総width6/4.5/3.2px、outlineWidth2px（左右およそ1px）である。既存widthのままoutlineだけ指定すると、最細線の芯が消え得る。アンチエイリアスや画面解像度で実際の判読性は変わるので、数字だけで受入しない。

`GroundPolylinePrimitive.js` は material のshader sourceと `v_width` を通す経路を持つ。`PolylineOutlineMaterialProperty.js` の公開プロパティは color/outlineColor/outlineWidth。公式 [PolylineOutlineMaterialProperty](https://cesium.com/learn/cesiumjs/ref-doc/PolylineOutlineMaterialProperty.html) は参照先であり、今回の具体的式の根拠は取得済み固定npm sourceの実読である。Google写真上での実確認は、明るい道路・暗い樹冠・赤い禁止面との重なりを同じ対象で比較する。ハローが地物の細部を隠す場合は幅を下げ、単に太いほど良いとしない。

## 明示的な視点の記憶

「この視点を覚える」「覚えた視点へ」の2操作は目的に合う。cameraの `positionWC` / `directionWC` / `upWC` をcloneしてbrowser memoryに一つ保持し、既存cameraの `setView` で戻す。tileset作り直し・root再取得・統計計算・地表高度取得は不要。物理地物の保存や地図データのexportにもならない。

親の `scene3dSnapshot()` は `snapshotId:'scene-'+Date.now()` としており、同じ結果の再入でもIDが変わる。snapshotId単独で覚えた視点を捨てる設計は、2D往復の使い方に合わない。候補/結果ID、元GeoJSON、detailの選択文脈が同じなら保持し、対象集合が変われば無効化する案がよい。2Dcameraの範囲変更だけでは削除せず、覚えた視点へ戻るのはユーザーの明示操作にする。別結果へ自動でジャンプしない。

全地域へ戻る既存ボタンも残す。操作履歴undoや複数bookmarkの保存・共有を今回の必要として増やさない。記憶前の復帰ボタンはdisabledにし、「視点を覚えました」「対象集合が変わったので視点記憶を解除」の短い状態表示で関係を説明する。

## 確認する反例

- 95%線の芯が縁取りに食われず、候補A/Bと50/90/95が読めるか。
- 屋根・林縁・道路との交点がハローで覆われ、位置を読み違えないか。
- 視点を覚える→自由に寄る/回す→戻すで同じworld poseへ戻るか。
- 同じ結果の2D往復では保持し、別の選択群/結果では古い視点を取り違えないか。
- 覚える/戻す/2D往復でGoogle helper呼出しが増えないか。

人工箱のfixtureでpose/描画経路と数値不変を試せるが、実写写真に輪郭が埋もれる問題の最終評価はGoogleの同じ対象で行う。ユーザーが述べた「影」は任意の案として残し、今回の必須実装に広げない。

## 採用・反例修復の追記

上の検討後、rootが輪郭の暗haloと一時視点を採用し、実装した。PolylineOutlineMaterialPropertyの標準経路だけを使用し、輪郭の元の色芯4/2.5/1.2pxを維持する。視点記憶はcameraのworld position/direction/upのclone一つ、保存も復帰もGoogle helperを呼ばない。108項目の無キーsource検査にmaterialと復帰座標、clone、同一性を含めた。

初版はcandidates/context/geojson全量を比較していた。weather370の独立批評で、候補名だけの変更と同一選択群の経過時刻/metric変更でも記憶が消える反例が再現した。rootは「同じ地上の対象を見直す」目的へ戻し、この反例の修復を採用した。失敗票は `view-memory-critic380-initial.json` に保持する。

実際のforecast送出sourceを読み、候補名はcandidate.label、領域名はfeature.properties.labelへ入り、地上平均経路は選択群全履歴から求められてtime/metricのみに依存しないことを確認した。修正版は候補/result ID、確率の意味・件数、文脈kind/active/選択IDsと分母/輪郭、全geometryと表示種別・各対象ID・水準・phase・分類・定義を固定する。transport情報、2Dcamera、見出し、注記、表示名、time/metric/view、色/focused、領域の編集版番号は同一性から除く。配列の並び・座標列の厳密比較は残し、幾何的な同値まで推測しない。別result/候補/選択/禁止形状なら解除し、A→B→Aで古い記憶を蘇らせない。

新しいruntimeの実物観察はrootの独立synthetic tabで行う。実Googleの旧tabはreloadせず、そこで未実装のhalo/視点記憶が使えたとは記録しない。再確認票と実画面観察は実装報告へ帰属を分けて追記する。
