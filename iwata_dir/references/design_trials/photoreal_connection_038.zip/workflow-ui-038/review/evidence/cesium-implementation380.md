# 0.38 写真3D接続候補の実装記録

2026-09-26 / needs360_metadata。前半の調査は `../google3d-connection-review380.md`、独立用途批評は `connection-critic380.md`。ここは後続の採用候補と実装状態を更新する記録。

## 今回作ったもの

主担当の追加指示に従い、Navara独自shader改造ではなく **CesiumJS 1.145.0 + Google raw Photorealistic 3D Tiles** を先に小実装した。必要なキーは Navara の Google 公式例と同じ Map Tiles API 用。Google Maps JS Demo Key は別製品の無課金代案として残し、三つの engine を同時に本実装していない。0.37 の凍結 source/runtime/ZIP と元repo.git は変更していない。

source：`../cesium-probe/`。配布候補：`../release/workflow-ui-038/scene3d/`。ライブラリは公式 npm registry から版固定で取得し、依存 script は実行せずに導入した。npm package は Cesium 1.145.0、engine 26.3.0、widgets 16.2.0、Apache-2.0。ライセンス全文と第三者一覧は runtime に保持。ライセンスは Google 地図の使用条件と別。

Google helper の実 source `createGooglePhotorealistic3DTileset.js` は explicit key を Resource の query に渡し、key が未指定なら ion に分岐する。そのため本実装は空キーを前段で拒否し、ion token を使用しない。viewer は basemap/terrain/geocoder を自動接続せず、key を入れる前に Google を取得しない。source は read-only に確認し、SDKの改変はしていない。

## 点・線・面の経路

公式 [PolylineGraphics](https://cesium.com/learn/cesiumjs/ref-doc/PolylineGraphics.html) は ground line の classification を terrain/3D Tiles/both に指定できる。[PolygonGraphics](https://cesium.com/learn/cesiumjs/ref-doc/PolygonGraphics.html) も ground polygon の classification と hole hierarchy を持つ。本実装は Entity API の既存経路を使い、Vector Tile draping tutorial を inline GeoJSON に無条件転用していない。

点は固定 npm source `HeightReference.js` の `CLAMP_TO_3D_TILE`、tileset は `enableCollision:true`。線は `clampToGround:true` と `CESIUM_3D_TILE`。禁止領域の面は height/extrudedHeight なしの ground polygon と同 classification。元のリング/穴・標本ID・候補ID・結果IDを保持し、独自の高さ推定・mesh抽出・統計計算を追加しない。遮蔽無視の常時最前面描画は採用していない。

この経路が写真meshの特定の屋根や林縁で読みやすいかはまだ実画像の確認を待つ。完全な連続面投影を新たな絶対要件にはせず、点・輪郭と周辺地物が同じ対象として読め、必要な詳細を自由に見て戻れるかで評価する。

## 同じ集合と操作

0.37 の受渡し schema を継承する。overview は表示中の集合、detail は active 候補と選択標本、0選択は0点、輪郭なしを保持。元 GeoJSON の SHA256 を非秘密 diagnostics に残す。平均経路は地表参照線であり飛行高度ではない。

camera の初期距離は実 canvas の縦横比と Cesium の垂直 FOV を使う。mouse は公開 `ScreenSpaceCameraController` 設定を使い、左dragで移動、右dragで回転/傾き、wheel/pinchで距離。既存engineの衝突回避を有効にし、近接下限1m、遠方4地球半径を設定。数値設定だけで自由操作が成立したとは扱わず、連続拡大・注目点変更・戻りを現物で確認する。

## キー・通信・利用枠

フォームsubmit後は入力欄を空にする。keyは関数引数/SDK内部の実行時メモリのみ。URL query入力・ブラウザストレージ・設定ファイル・結果・診断へ保存しない。SDKの Google query URL は通信に必要だが、raw URL/例外全文を観察ログへ保存しない。SDK `tileFailed` は listener がない場合 URL を console へ出すため、専用 listener で件数だけを記録する。

明示connectまでGoogleリクエストなし。同時connecting/既存tileset時は二重connect拒否。snapshot替えと往復は同じtilesetを保持。失敗/期限切れで自動root再取得を行わない。ページ再読込・解除後の接続だけが新しい試行になる。カウンターはアプリの root 取得開始試行数であり請求確定数や月残量ではない。

parentの `bjp-scene3d-pause/resume` に対応し、隠れている間は既存viewerの render loop を停止する。既に開始した通信/処理の完了までは残り得る。再開時は同じviewerとtilesetを使う。root response/session URLをディスクへ保存して再利用する構成にはしない。

## 検査と観察の帰属

- 初回の Node 変換確認は、0.37由来color moduleがThree.jsへ依存しており失敗した。pure sRGB HSL変換へ修復し、候補と地物で共通利用した。実接続前の失敗で、Google取得はゼロ。
- `cesium-unit380.json` に59assert成功を保存。geometry不変、ID、穴、50/90/95線幅、hex/rgb/hsl、詳細0選択、キー欄消去、非秘密エラー分類、空キー拒否を検査した。
- `make-fixture.mjs` は自作の屋根/段差/地面だけの glb/3D Tilesを生成。96頂点・48三角形。Googleデータは含まない。`?probe=synthetic` は独立tabのみで作動し、親からの実結果を人工集合へ置換しない。
- 担当CUAから独立fixtureを新しいiabで開く試行は `Browser is not available: iab` で不成立だった。root側の実IABは利用でき、主担当がキー入力画面と2候補受領を既に視認している。担当surface不在をアプリ不具合と数えない。
- rootはユーザー自身のkey入力を待つ同一IABセッションを保持中。こちらからそのtabのキーを取得・読出し・再接続・reloadしていない。実Google接続、料金枠確認、屋根/林縁/自由操作/復帰の画像観察はrootの実績を別に追記する。

この記録時点でGoogleに実接続したという主張はしていない。入力口・provider・同一集合adapter・既存mesh投影APIを準備し、秘密なしの有限検査を終えた段階である。

## 接続後の追記（主担当の観察に帰属）

上記初回記録の後、rootから、利用者が入力したkeyで実IABのGoogle接続が成功したと連絡を受けた。主担当は北海道の写真背景、2候補21地物/6輪郭、Google/Airbus credit、接続試行1回を視認した。wheelで接近し過ぎた後に離れ、畑・道路・樹木meshが見える距離へ戻れた。一方、点/輪郭と屋根の同位置関係はこの報告時点では未評価。担当がGoogleを再接続した結果ではなく、rootの同一実セッションの観察である。

その実セッションをreloadせず、今後の入口用sourceだけ次を修復した。overviewの「0点」を「干渉表示点 0／輪郭あり」に分け、点の表示条件と全着地輪郭を混同しない。detailは「選択着地点」、人工fixtureは「人工表示点」とする。footerの「画面を閉じる」は「ページを閉じる・再読込・接続解除」へ限定し、分析へ戻るだけでは同じ接続を保持すると明記した。

独立の費用/通信批評を受け、有効snapshot未受領・受領エラー時は新規Google接続を UI と handler/connect 関数で禁止した。不正payload受領で既存tilesetを破棄しない。修復後も59assertを再実行して成功。追加のlifecycle mock検査は weather370 の `request-budget-critic380.md` と対応JSONへ帰属させる。

## 保存候補の再現確認

packaged source を `P380/rebuild-check/source/cesium-probe/` へコピーし、固定lockから再導入して59assert、人工fixture生成、buildを別ディレクトリで実行した。最初に試した offline install は pnpm の registry metadata 不在で失敗した。通常の `--frozen-lockfile --ignore-scripts` では30依存の supply-chain policy 検査を通過し、インストールに成功。ポリシーを無効化したり依存版を変えたりしていない。

独立再生成 runtime と初回保存候補の **408全ファイル（inventory自身を含む）、22,850,679 bytesがSHA256まで一致**した。tree receipt hash は `c383984fb0e5632695fe51c478d7c21522d5c519bd8911465e2879a7c49922bd`。この初回明細は後のfixture修復時に `cesium-rebuild380-before-fixturefix.json` へ保持した。runtimeのNavara/0.37 import・bundle混在は検出されず、sourceのnode_modulesを配布へ含めない。再現確認でGoogleへの接続は行っていない。

### 人工fixtureの実表示で見つかった失敗

上の59項目と再現一致は描画を保証しなかった。rootが別hidden IABで人工fixtureを開いたところ、5点だけが黒背景に出て、人工屋根・輪郭・面が表示されないことを確認した。初回は未合格として保持する。HTTP公開JSON/GLBは共に200で、ファイル不足ではなかった。

担当が固定Cesium sourceを追い、`Cesium3DTilesetBaseTraversal.selectTiles` が root の親error由来SSEを閾値比較して早期returnすることを確認した。人工tileset最上位の `geometricError:0` がこの門を通れず、leaf GLBを要求する前に省略されていた。最上位は「全600mモデルを省く誤差」として600、leafの誤差は0に修復。Google provider/mainを変えず、人工fixtureだけを修正した。

実Cesiumの `Cesium3DTile.prototype.getScreenSpaceError` で、旧0のSSEが0となる反例と、修復値が観察距離で閾値4を超えることを追加検査し、61項目成功を `cesium-unit380-fixturefix.json` に保存した。修復前の再現一致記録は `cesium-rebuild380-before-fixturefix.json` へ保持。修復後の人工形状実表示はrootの再観察を待ち、Google実セッションはreloadしない。

その後rootはsyntheticだけを再読込し、屋根/段差、3種類の線幅のcyan輪郭、平均経路、赤い領域面、小さな穴、5点を視認した。線をOFFにしても赤面の中央穴が残ることを確認。Google接続は0。黒画面修復は実描画で確認できた。上下移動/zoomの用途評価はこの連絡時点で継続中。

fixtureの中央65m棟には3点と平均経路・赤面および穴、北西42m棟には90/95輪郭、東25m段差には1点が重なる配置を使う。これにより点/線/面と屋根・垂直壁の表示関係を小さい範囲で試せる。一方、規則的な人工箱は実写meshの樹冠/林縁、写真テクスチャ、LOD、鮮度を試すものではない。Googleで同じ対象の詳細を見る評価を代替しない。表示数のUI語は「地物」から「表示要素」へ改めた。

fixture修復と表示語修正を含む最新sourceで独立再生成をやり直し、**408全runtimeファイル・22,850,687 bytes・全SHA256一致**を確認した。最新tree receipt hashは `b19ceaf3af45c179fa7166545d3515b23030b2b792afe9c917c02d855160dbaa`、明細は `cesium-rebuild380.json`。Google観察に使ったセッションのmainは古いままであり、この再現一致をそのまま修正版のGoogle実接続実績と呼ばない。

### 接近して同じ対象を見直す改善

後続のroot実Google観察では、人工禁止領域2面、A28/B3の干渉点を同じ接続へ重ね、道路/林縁/建物に接近して内外を読む用途価値を確認した。一方、細い90/95%のcyan輪郭が写真に埋もれ、拡大で注目交点が画面端へ流れると全地域resetしかなく見直しが不便だった。これは接続成功だけでは見つからない用途の問題であり、`inspection-ui-review380.md` で案を問い直した後、rootが採用した範囲を実装した。

輪郭だけに標準暗halo（総幅6/4.5/3.2、outline2、色芯4/2.5/1.2）を加え、経路/禁止境界を変えない。world camera poseをmemoryに一つ覚える/戻す2操作を加え、別集合で解除する。初版の同一性が表示名や経過時刻の変更でも解除する反例はweather370が再現し、rootの採否に従って同じ地上対象に必要なID/選択/分母/形状/分類等の比較へ限定修復した。失敗2件を含む初回票を保持し、成功票で置き換えない。

担当source検査は `cesium-unit380-displayrefine.json` の108 assertions成功。実Cesium materialの型・芯幅・候補色、点線面とID不変、poseのcloneと復帰、候補名/time/metricだけの維持、結果/候補/選択/分母/輪郭/領域穴の変更時解除等を確認した。独立通信mockはweather370の22条件、意味反例は同担当の14条件へ帰属する。いずれもGoogle通信なしで、実WebGLや写真上の細部判読性を証明したとは扱わない。

この修復前の再現票を `cesium-rebuild380-before-displayrefine.json` に保持した。現在のcode指紋はmain `4e7047dc7272c6b7aeed3155eefb24a11684b84b89efe8c60d74228ee051e058`、view-memory `6b625f48c70eb7c086e6f89e76bdc3986db0e725b98fda9e39396d7d4562806f`、overlays `0f9d09a87cd6abe2c439a216973d6d3c640bb72add311be8dd2d3c4b060ab51c`。人工fixtureの新表示と操作はrootが観察し、実Google旧セッションは保持して余分なroot要求を発行しない。

rootは新syntheticでhaloの95%芯も見え、太さ順を保つことを視認した。一方、1280×720では新操作欄が地図上の人工形状と重なり、接続後も不要なキー欄/長文が上部を占有することを指摘した。自由な近接確認を妨げる配置を修復し、操作/状態/マウスguideを地図外へ移した。操作は細い1行、狭幅は内部横scrollとし、canvas内にはライセンスcredit以外の独自操作欄を重ねない。

接続処理中と成功後のloading/visible/partialでは入力と長文だけを畳み、試行数/解除を常に残す。未接続/error/unavailableでは入力説明を戻し、既存tilesetがある場合はconnectを無効のまま維持する。人工fixtureではGoogle入力自体を隠し、背景状態にGoogle接続0を明示する。通信/providerの寿命を変えない配置修復である。このmain指紋は `78eff0dd940b18a3faa0008d1c4364d565f57a17ad9ad502f9e273b35b4e5d4d`。rootが実Google接続を明示解除し、未接続/背景消失/キー再入力案内と試行1保持を視認した後の修正版なので、これを実Googleで再接続したとの記録にはしない。利用者のCloudキー無効化確認は担当が認証値を調べて代行する対象ではない。

収録sourceを独立コピーへ更新し、変更していないpackage/lockによる既存の固定依存導入を使って108assert、人工fixture再生成、buildを再実行した。runtimeはinventory自身込み **409ファイル、22,854,988 bytes、全SHA256一致**。tree receipt SHA256は `4e92d076c8ebc46e62e0ef14a6861ab4c54972a50368827fff6f2de7d098f9eb`、最終明細は `cesium-rebuild380.json`。再現確認のGoogle通信0。ソース/配布物の一致を接続後の実写評価の代わりにはしない。

`root-live-observation380.md` の後続実績を実読した。主担当は人工fixtureで視点を覚え、0.25page相当の接近を行ってから復帰ボタンを押し、元の全体表示へ戻る操作を視認した（Google0）。haloと記憶復帰はこの人工表示での確認であり、Google写真上のhalo効果や右dragを確認済みに広げない。同報告に実Googleの60→0選択、2D復帰、禁止領域近接、接続解除の観察条件が記録されている。

最終配置に対するweather370の独立差分報告 `layout-state-critic380.md` と原票を実読した。Googleモック13条件と人工fixture3条件で、接続中の試行/解除、成功後の入力折畳み、既存tileset失敗時の説明復帰とconnect禁止、root拒否時の明示再試行、partial/resize時の追加helperなしを確認している。前版の通信22条件・意味14条件は件数のために再実行せず原票を保持し、対象view-memory/overlays/providerのSHA不変を照合した。新配置の独立票と2本の証拠scriptもsourceへ同梱する。fake DOMで実画面の面積を保証したとは扱わない。

主担当から最終synthetic配置の実測を受けた。1280×720で操作帯はy132/高さ38px、地図はy194.6/高さ459px、接続入力は非表示、Google0であり、操作帯が地図に重ならない。覚える→zoom→戻るも実操作で確認した。ここまでの独立担当のbuild/testと人工fixtureはGoogle接続を行っていない。

その後主担当は、通常tabの再読込後に最終layoutでGoogle接続があることを観察したと連絡した。再読込前後で各画面内counterは1だが、新しい開始操作の主体は未確認で、作業全体の累積1を意味しない。最終版での同じ接続を使う後続観察は主担当報告へ帰属させ、初回旧mainセッションと区別して追記する。担当はキー値・Network URLを取得せず、接続操作も行わない。

### 最終版の実Google有限観察（主担当）

主担当は最終layoutの1656×1270画面にある既存Google接続（当該画面counter1）で、視点を覚える→0.65page相当のzoom→覚えた視点へ戻る操作を行い、元の俯瞰への復帰とcounter1維持を視認した。Google写真上に暗halo付き50/90/95輪郭と平均経路が見え、操作帯は地図外にあった。今回は禁止領域なしのA/B概要21表示要素であり、禁止面/穴の実Google観察は初回旧main、人工穴は最終syntheticの別実績とする。

拡大直後には低解像の写真タイルが一時表示され、最薄線と写真の細部判読を全面保証する観察ではない。屋根/樹冠の形状精度、全地域/LOD、右drag、長時間セッション、実際の請求計上は未確認のまま。主担当は最後に接続解除し、未接続表示・背景消失・入力再表示・当該画面counter1を確認した。

再読込前後を通算した接続開始数と、新しい接続開始の操作主体は未検証である。主担当からは追加connectを行っていないと報告された。画面内1を作業全体の累積1や課金1へ読み替えない。担当は今回もGoogle接続を開始せず、認証値・通信URL・タイルを取得/保存しない。最終codeを変更せず、観察帰属と限界を追加した。
