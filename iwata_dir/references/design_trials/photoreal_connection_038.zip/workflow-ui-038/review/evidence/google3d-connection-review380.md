# Google 写真 3D への接続調査と小実証案（0.38 独立作業）

確認日：2026-09-26。担当：needs360_metadata。P370/reviews/3d-round1.md と、凍結した 0.37 の Navara 0.1.1 npm source を再読。0.37 の source・runtime・ZIP・repo は変更していない。以下は公開一次資料の確認と接続実装案であり、Google タイル取得や実画像の評価結果ではない。キー取得、認証値の読出し、規約受諾、課金設定、アカウント作成は未実施。

## 結論

**ユーザーが示した Navara の写真 3D 例と同じ背景へ接続する経路はある。必要なのは Map Tiles API を有効にした、請求設定済み Google Cloud project の API key である。** 既存の GSI 写真＋DEM 試作に Google source を追加する実装は小さく作れる。ただし、背景が建物や樹木を立体表示できたことと、同じ落下分散がその表面へ正しく投影されたことは別に実証する。

Navara の既存 `clampToGround` は Google 建物 mesh を受け面にする証拠がないどころか、今回の source 再読では terrain 用の処理順であることが確認できた。Google 接続後、点・細線・面の屋根/樹冠での結果を見て選ぶ。長い低レベル描画改修へ直ちに進むより、Google Maps JavaScript 3D の `RELATIVE_TO_MESH`、必要なら Cesium を同じ snapshot で対照にするのが有用である。

**無課金で早く用途を試すなら Google Maps JavaScript 3D + 自分の Demo Key が有力。** ただし Navara の raw Tiles 用キーとは別の経路である。ユーザーが Navara 例と同じ方式のキーを準備する場合は、その意図に沿って Navara 接続から小実証する。この判断はエンジン名を守るためではなく、「同じ結果を保ち、細かな施設・地形をマウスで自由に調べて戻る」という用途から行う。

## 1. キーと接続先を混同しない

| 経路 | 2026-09-26 に一次資料で確認した前提 | 今回への意味 |
| --- | --- | --- |
| Navara + Google Photorealistic 3D Tiles | Map Tiles API 有効化、project の billing 有効、API key または OAuth。Navara 公式例は key を付けた Google root tileset URL を source に渡す | ユーザーの提示例と同じ方式。key はブラウザへの提供が必要で、API 制限・利用元制限を伴う設定を使う |
| Google Maps JavaScript 3D + Maps Demo Key | billing 情報なしの無償試作用。Google Account へログインし、Demo Key 規約へ同意して発行 | 自分の Demo Key 発行が必要。サンプルサイトの共有キーをコピーする経路ではない |
| Google Maps JavaScript 3D + 通常キー | Maps JavaScript API と billing を設定した通常の project/key | 既存の適合キーがある場合の選択肢。Map Tiles と API 制限が異なる |

根拠：[Navara の固定公式例](https://github.com/maplibre/navara/blob/6c3a8cd9e214ee61a39ab4cffdb5d9d26c1afda2/web/navara_three/example/pages/examples/tiles-3d/google-photoreal-tiles/main.ts)、[Map Tiles の利用・課金](https://developers.google.com/maps/documentation/tile/usage-and-billing)、[Maps JavaScript のキー取得](https://developers.google.com/maps/documentation/javascript/get-api-key)。固定例の読取根拠は 0.37 調査に保存され、root も本ターン再確認済み。今回こちらの Web tool で固定 GitHub URL を再取得した際は cache miss だったため、それを取得成功として数えていない。

[Demo Key の現行案内](https://developers.google.com/maps/demo-key)は Maps JavaScript の 2D/3D 描画、marker、shape/polyline 等を対応機能に含める。上限到達時はその日の利用が止まり、無償試作自体に課金されない。汎用の案内には固定の数値 quota がなく、限度は変更され得る。AI Studio 等の別チュートリアルにある数値を本経路の保証として転用しない。対応一覧に raw Map Tiles API はなく、Demo Key が Navara の billing 要件を解消すると推定しない。

[Demo Project 規約](https://cloud.google.com/terms/maps-platform/demo-project-terms)は確認時点で 2026-09-13 改定。Google account あたり同時に一つの Demo Project、試験・評価用で production 不可、Google が利用可否と限度を変更し得るとする。本人/組織を代表する同意が必要である。今回は同意も発行もしていない。利用者の契約資格は調べていない。

## 2. Google JS 3D の実装能力と限界

### 地域と自由操作

`Map3DElement` は経緯度を `center` に指定できる。公式例の都市に固定された viewer ではない。Japan は [coverage 表](https://developers.google.com/maps/coverage)で Map Tiles 3D と Maps JavaScript 3D の提供あり。ただし国の印は任意の一本木・施設の mesh、必要な撮影時期、今回の狭い地域の精度を保証しない。実接続時には現在結果の座標を保ったまま対象地域を確認する。

公式 [interaction guide](https://developers.google.com/maps/documentation/javascript/3d/interaction)にはネイティブ gesture、`gestureHandling`、camera の高度/方位/傾き制限がある。全画面の 3D iframe では `greedy` を明示する案がよい。AUTO は iframe 内で cooperative となり、wheel に modifier が必要になり得る。自由 pan/orbit/zoom を提供する能力は確認できた。一方、読んだ 3D guide と二つの codelab には左右ボタン等の厳密な割当表がなく、今回実マウス操作を行っていない。2D vector map の割当を 3D の事実として流用しない。接続後の help 表示と実マウスを照合する。

[3D Map reference](https://developers.google.com/maps/documentation/javascript/reference/3.65/3d-map)の `center.altitude` は海抜 m、`range` は camera と center の距離、`fov` は垂直画角（既定 35°）。`bounds` は camera 移動制限であり fitBounds ではない。初期距離は実 canvas の縦横比と FOV で計算する。`mode` の指定が必要。`minAltitude`/`maxAltitude` 等の公開制約を使い、0.37 の自前 wheel 制御を無条件に移植しない。

### 建物・樹木への点、線、面

[高度 mode](https://developers.google.com/maps/documentation/javascript/3d/altitude-modes)は次を明示する。`CLAMP_TO_GROUND` は建物/植生を除く DTM、`RELATIVE_TO_MESH` は建物・樹木を含む DSM、`ABSOLUTE` は EGM96 の海抜である。落下位置の水平分布を表示する目的には `RELATIVE_TO_MESH` を候補とし、飛行高度や実際の物理衝突を得たと解釈しない。

[draw reference](https://developers.google.com/maps/documentation/javascript/reference/3.65/3d-map-draw)には `Marker3DElement`、`Polyline3DElement`、`Polygon3DElement` と `altitudeMode` がある。現行の線/面には `path`、穴には `innerPaths` を使える。旧 `coordinates`/`outerCoordinates` 等は deprecated。候補の既存色を CSS3 色へ正規化して渡し、50/90/95 の線幅差と点種別を保つ。MultiPolygon は部品へ分け、元 ID を保持する。

**頂点が mesh の高さへ置かれることと、頂点間や面の内部が連続して屋根/樹冠をなぞることは同じでない。** [Google の高度解説](https://developers.google.com/maps/architecture/3d-understand-altitude-modes)と高度 mode の説明は線分が mesh を貫く可能性を示す。`drawsOccludedSegments` は遮蔽された線を見せる機能であり、表面へ沿わせた証明ではない。細分化を使うなら描画専用頂点として元 geometry と分離し、その間隔・個数・LOD 変化を記録する。面全体の drape が要求に届くかは屋根と樹冠で実画像を評価する。ここを API 名だけで達成扱いにしない。

## 3. Navara 0.1.1 source の再確認

実読した npm package は 0.37 に使用した固定 `@navaramap/three@0.1.1`。今回の source 読取対象：`src/mesh/tile/vectorDrapeResolver.ts`、`src/mesh/DrapedMesh.ts`、`src/passes/CustomRenderPass.ts` の render と drape 部、`src/event/feature.ts` の scene 選択、`src/plugins/AttributionPlugin/index.ts` の usage/credit 管理。既存 package/lock の変更なし。

- `vectorDrapeResolver.ts` は clamp vector を terrain tile へ描く仕組みと記述する。
- `CustomRenderPass.ts` は globe を描き、その深度をコピーした後に draped mesh を処理し、その後 MRT と opaque を描く。
- `event/feature.ts` は通常の非 drape feature を MRT に置く。深度を無視する点/text は transparent へ置く。
- `AttributionPlugin` は `3d-tiles` source/layer と `creditLayerId` による動的な著作権表示経路を持つ。

公式対応 source：[VectorDrapeResolver](https://github.com/maplibre/navara/blob/6c3a8cd9e214ee61a39ab4cffdb5d9d26c1afda2/web/navara_three/src/mesh/tile/vectorDrapeResolver.ts)、[CustomRenderPass](https://github.com/maplibre/navara/blob/6c3a8cd9e214ee61a39ab4cffdb5d9d26c1afda2/web/navara_three/src/passes/CustomRenderPass.ts)。URL は旧固定版との対応を示す参照であり、今回の事実確認は手元 npm source から行った。

**推論：** 既存 GeoJSON の `clampToGround:true` だけでは Google 3D Tiles の建物・樹冠へ全形状が投影される保証がない。裸地上の面が後描画の建物で隠れる結果は十分予想される。`pickDepthPosition` に全描画深度を読む経路があっても、それは任意の経緯度へ全輪郭を投影する実装の完成を意味しない。カメラ視線の 2.5D pick、真下への投影、連続面 drape を混同しない。

## 4. キーを保存しない接続案

独立 viewer を P380 に置き、入力欄へ利用者がキーを入れて「接続」した時だけ Google source を作る。初期ロード・解析 snapshot 受信・画面更新だけでは Google へ接続しない。

1. キーは password 欄から関数の局所変数へ取り、欄を直ちに空にする。localStorage/sessionStorage/IndexedDB/cookie、URL の query/hash、HTML data 属性、設定 JSON、環境ファイルへ保存しない。
2. `https://tile.googleapis.com/v1/3dtiles/root.json?key=…` は source に必要な実行時値だけとして組み立て、アプリの診断 object・receipt・snapshot・export へ入れない。公開サンプルの key は読まない/流用しない。
3. エラーは分類と HTTP status のみを保存し、raw URL/例外全文/レスポンス body を観察証拠へ採らない。ブラウザの Network/HAR/trace を無加工で保存しない。第三者ライブラリの raw console 出力も録取前に秘匿化を確認する。
4. 接続解除時に layer/source/view を dispose し、アプリ側の参照を解放する。「完全なメモリ消去」を JS で保証したとは書かない。ブラウザの通信処理には key が渡るため、ブラウザからも不可視という意味ではない。
5. Google logo と現在 tile の attribution を見える状態で維持する。タイルを ZIP/ローカルデータセットへ保存しない。失敗時に GSI の背景へ黙って替えない。

[Map Tiles policies](https://developers.google.com/maps/documentation/tile/policies)を守る表示用途の案であり、Google mesh の高さ/形状を採取して科学入力へ保存する案ではない。キーの API 制限/利用元制限の設定や課金変更は本担当から行わない。

## 5. 小実証の順序と renderer 選択条件

| 段階 | 具体的操作・証拠 | 達成扱いにしないもの |
| --- | --- | --- |
| N1 背景 | 許可された key で Navara source を接続。対象地域の写真 mesh、Google/data attribution、読込/取得不能を画像と状態で確認 | source 作成成功だけ、GSI 背景、別都市を見ただけ |
| N2 同一集合 | 0.37 の `bjp-scene3d-v1` を継承。snapshot/result/candidate/sample IDs、選択 n/N、camera 地域、色、線/面を保持して受領 | 非表示候補/全着地の復活、統計再計算、試験点への置換 |
| N3 投影 | 同一地点で点・輪郭・半透明禁止面を切替。裸地・屋根・樹冠、斜視・真上、LOD 変更で記録。既存 terrain clamp を比較対象として明記 | 見えているだけの常時前面描画、地面の線が建物に隠れているものを mesh 投影成功と呼ぶこと |
| N4 操作 | 左/右 drag、wheel 連続接近/離脱、注目点変更、同じ集合へ戻る。地下/宇宙逸脱、pan 後の支点、近接での可読性を画像で確認 | camera 値だけが変わる、例外 0 だけ |
| N5 復帰 | overview → 同じ表示集合、detail → 選択 3 IDs/0 IDs、分析へ戻る。元の選択/時刻/背景/視点/計算回数を照合 | 3D だけで完結する別サンプル |

N3 が不成立なら、Navara の custom shader を即採用せず次を比較する。Google JS3D は自分の Demo Key が利用可能なら課金情報なしに mesh-relative 表示を試しやすい。CesiumJS + Google raw Tiles は同じ Map Tiles 用キーを使う対照候補で、[Google 3D Tiles quickstart](https://cesium.com/learn/cesiumjs-learn/cesiumjs-photorealistic-3d-tiles/) と [HeightReference](https://cesium.com/learn/cesiumjs/ref-doc/HeightReference.html) に基づく。ただし新ライブラリ接続と描画評価は未実施。最も早く上の N2〜N5 を満たす経路を採用し、Google 背景だけで UI 目的を閉じない。

0.37 の入口から使う接続版を作る際は新 P380 コピーに対して行う。凍結 0.37 へ上書きしない。既存 protocol の科学的境界を保ち、受領前後 geometry の hash/件数を照合する。初期距離は canvas/FOV に基づいて同じ地域を占めるようにする。詳細では既存の選択集合だけを渡し、輪郭なしを保つ。平均経路は地表参照線であり飛行高度として描かない。

## 未確認と今回の実績

公式 Demo Key の無課金経路、Google JS3D の mesh-relative API、Navara 既存 drape の source 上の対象、キーを結果へ混ぜない境界を整理した。現物の Google キー、今回地域の mesh/解像度/撮影時期、投影の見え方、実マウスの割当/安定性は未確認。これらは不可能の証拠ではなく、上の小実証で判定する項目である。今回の作業だけでは Google 実接続済みとは言わない。
