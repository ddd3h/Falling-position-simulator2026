import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import vm from 'node:vm';

// Independent finite lifecycle probe. No SDK, browser, HTTP server or provider network.
const root='C:/Users/genia/AppData/Local/Temp/balloon-design-380';
const source=root+'/cesium-probe/src/';
const checks=[], counts={viewers:0,viewerDestroys:0,googleHelperCalls:0,tilesetDestroys:0,entityAdds:0,entityClears:0};
const turn=()=>new Promise(resolve=>setImmediate(resolve));
const check=(name,fn)=>{fn();checks.push(name);};
const node=id=>({id,value:'',hidden:false,disabled:false,checked:true,textContent:'',dataset:{},style:{setProperty(){}},children:[],clientWidth:1366,clientHeight:650,events:{},addEventListener(type,fn){this.events[type]=fn;},replaceChildren(...items){this.children=items;},append(...items){this.children.push(...items);}});
const nodes=new Map();
const element=id=>{if(!nodes.has(id))nodes.set(id,node(id));return nodes.get(id);};
const bus={},posted=[],pending=[],viewers=[];
const event=()=>({listeners:[],addEventListener(fn){this.listeners.push(fn);},fire(...args){this.listeners.forEach(fn=>fn(...args));}});
const tile=label=>({label,tilesLoaded:true,tileFailed:event(),tileLoad:event(),tileVisible:event(),loadProgress:event(),destroy(){counts.tilesetDestroys++;this.destroyed=true;}});
const C={
 Ion:{defaultAccessToken:'test-placeholder'},
 Math:{toDegrees:x=>x*180/Math.PI,toRadians:x=>x*Math.PI/180},
 Cartesian3:{fromDegrees:(...values)=>values,clone:v=>({...v})},HeadingPitchRange:class{constructor(...values){this.values=values;}},Matrix4:{IDENTITY:'identity'},
 CameraEventType:{WHEEL:1,PINCH:2,RIGHT_DRAG:3,MIDDLE_DRAG:4,LEFT_DRAG:5},KeyboardEventModifier:{CTRL:1},ScreenSpaceEventType:{LEFT_DOUBLE_CLICK:1},
 ClassificationType:{CESIUM_3D_TILE:1},HeightReference:{CLAMP_TO_3D_TILE:1},PolygonHierarchy:class{constructor(positions,holes){this.positions=positions;this.holes=holes;}},
 Color:{WHITE:'white',fromCssColorString(value){return{value,withAlpha(alpha){return{value,alpha};}};}},
 PolylineOutlineMaterialProperty:class{constructor(options){Object.assign(this,options);}},
 createGooglePhotorealistic3DTileset(apiOptions,tilesetOptions){
  counts.googleHelperCalls++;assert.equal(typeof apiOptions.key,'string');assert.equal(apiOptions.onlyUsingWithGoogleGeocoder,true);
  assert.equal(tilesetOptions.maximumScreenSpaceError,8);assert.equal(tilesetOptions.cacheBytes,384*1024*1024);
  let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});pending.push({resolve,reject});return promise;
 },
 Viewer:class{
  constructor(map,options){counts.viewers++;this.options=options;this.useDefaultRenderLoop=true;this.camera={frustum:{fovy:Math.PI/3},positionCartographic:{longitude:0,latitude:0,height:1000},heading:0,pitch:-1,positionWC:{x:1,y:2,z:3},directionWC:{x:0,y:1,z:0},upWC:{x:0,y:0,z:1},lookAt(){},lookAtTransform(){},setView(pose){this.positionWC={...pose.destination};this.directionWC={...pose.orientation.direction};this.upWC={...pose.orientation.up};}};
   this.scene={screenSpaceCameraController:{},renderError:event(),preRender:event(),postRender:event(),requestRender(){},primitives:{items:[],add(item){this.items.push(item);}}};
   this.entities={removeAll(){counts.entityClears++;},add(item){counts.entityAdds++;return item;}};this.screenSpaceEventHandler={removeInputAction(){}};viewers.push(this);
  }
  resize(){} destroy(){counts.viewerDestroys++;this.scene.primitives.items.forEach(item=>item.destroy());this.destroyed=true;}
 }
};
const fakeParent={postMessage(message){posted.push(message);}};
globalThis.window={Cesium:C,addEventListener(type,fn){(bus[type]??=[]).push(fn);}};
globalThis.parent=fakeParent;
globalThis.location={protocol:'http:',origin:'http://localhost:mock',search:''};
globalThis.document={getElementById:element,createElement:tag=>node(tag)};
globalThis.devicePixelRatio=1;
globalThis.ResizeObserver=class{observe(){}};
const send=(type,payload)=>{for(const fn of bus.message||[])fn({source:fakeParent,origin:location.origin,data:{type,schema:'bjp-scene3d-v1',payload}});};
const submit=(value='mock_only_not_a_real_key')=>{element('apiKey').value=value;element('connectForm').events.submit({preventDefault(){}});};
const d=()=>window.SCENE3D_DIAGNOSTICS;
await import(pathToFileURL(source+'main.js').href+'?independent-budget-probe=1');
const {fixture}=await import(pathToFileURL(source+'fixture.js').href);
check('startup and ready signal do not construct Viewer or start Google',()=>{assert.equal(counts.viewers,0);assert.equal(counts.googleHelperCalls,0);assert.equal(d().rootRequestAttempts,0);});
submit();await turn();
check('valid sentinel before any snapshot cannot start a blank connection',()=>{assert.equal(counts.googleHelperCalls,0);assert.equal(counts.viewers,0);assert.equal(element('connect').disabled,true);});
send('bjp-scene3d-open',{snapshotId:'invalid-only'});await turn();submit();await turn();
check('rejected initial snapshot keeps new connection disabled even for valid sentinel',()=>{assert.equal(counts.googleHelperCalls,0);assert.equal(counts.viewers,0);assert.equal(element('connect').disabled,true);assert.ok(d().payloadError);});
send('bjp-scene3d-open',fixture());await turn();
check('valid snapshot clears rejection and enables deliberate connection',()=>{assert.equal(element('connect').disabled,false);assert.equal(d().payloadError,null);});
submit('invalid');await turn();
check('snapshot and invalid input remain unconnected',()=>{assert.equal(counts.googleHelperCalls,0);assert.equal(element('apiKey').value,'');});
submit();await turn();
check('first explicit connect starts one helper attempt',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);assert.equal(d().rootRequestAttempts,1);assert.equal(element('connect').disabled,true);});
submit();await turn();
check('programmatic second valid submit during pending start cannot duplicate it',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);assert.equal(element('apiKey').value,'');});
send('bjp-scene3d-pause');const first=tile('first');pending[0].resolve(first);await turn();await turn();
check('close while connecting retains completed tileset but pauses render loop',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(viewers[0].useDefaultRenderLoop,false);assert.equal(viewers[0].scene.primitives.items[0],first);});
send('bjp-scene3d-open',{snapshotId:'invalid-followup'});await turn();submit();await turn();
check('rejected followup keeps existing tileset and cannot trigger another root attempt',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);assert.equal(first.destroyed,undefined);assert.equal(viewers[0].scene.primitives.items[0],first);assert.equal(element('connect').disabled,true);assert.ok(d().payloadError);});
const changed=fixture();changed.snapshotId='changed-selection';changed.title='changed artificial result';send('bjp-scene3d-open',changed);await turn();send('bjp-scene3d-resume');
check('new snapshot and return resume existing Viewer/tileset without root attempt',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);assert.equal(viewers[0].useDefaultRenderLoop,true);assert.equal(d().snapshot.snapshotId,'changed-selection');assert.equal(viewers[0].scene.primitives.items[0],first);});
element('rememberView').onclick();viewers[0].camera.positionWC.x=99;element('recallView').onclick();
check('local remember/recall restores copied pose without helper or viewer creation',()=>{assert.equal(viewers[0].camera.positionWC.x,1);assert.equal(d().viewRemembered,true);assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);});
const sameSet=structuredClone(changed);sameSet.snapshotId='new-transport-same-set';sameSet.createdAt='later';sameSet.camera.center[0]+=.1;send('bjp-scene3d-open',sameSet);await turn();
check('new transport ID and 2D camera for same set preserve bookmark without reconnect',()=>{assert.equal(d().viewRemembered,true);assert.equal(element('recallView').disabled,false);assert.equal(counts.googleHelperCalls,1);});
const changedSet=structuredClone(sameSet);changedSet.candidates[0].resultId='new-result';for(const f of changedSet.geojson.features)if(f.properties.resultId)f.properties.resultId='new-result';send('bjp-scene3d-open',changedSet);await turn();
check('changed result with reused snapshot ID clears stale view and keeps existing tileset',()=>{assert.equal(d().viewRemembered,false);assert.equal(element('recallView').disabled,true);assert.equal(counts.googleHelperCalls,1);assert.equal(viewers[0].scene.primitives.items[0],first);});
send('bjp-scene3d-open',sameSet);await turn();element('recallView').onclick();
check('return to older set does not resurrect bookmark or create a connection',()=>{assert.equal(d().viewRemembered,false);assert.equal(counts.googleHelperCalls,1);});
submit();element('reset').onclick();element('showPoints').onchange();await turn();
check('connected resubmit, reset and overlay visibility do not reconstruct connection',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(counts.viewers,1);});
first.tileFailed.fire({statusCode:429,message:'mock-secret-error'});viewers[0].scene.renderError.fire(new Error('mock-secret-error'));await turn();
check('tile and render failure do not auto reconnect',()=>{assert.equal(counts.googleHelperCalls,1);assert.equal(d().tileFailureCount,1);assert.equal(JSON.stringify(d()).includes('mock-secret-error'),false);});
element('disconnect').onclick();
check('explicit disconnect disposes active Viewer/tileset',()=>{assert.equal(counts.viewerDestroys,1);assert.equal(first.destroyed,true);assert.equal(d().googleConnected,false);});
submit();await turn();element('disconnect').onclick();submit();await turn();
const stale=tile('stale'),latest=tile('latest');pending[1].resolve(stale);await turn();pending[2].resolve(latest);await turn();await turn();
check('cancel/reconnect race discards stale completion and keeps newest connection',()=>{assert.equal(counts.googleHelperCalls,3);assert.equal(stale.destroyed,true);assert.equal(viewers.at(-1).scene.primitives.items[0],latest);assert.equal(d().rootRequestAttempts,3);});
element('disconnect').onclick();submit();await turn();pending[3].reject({statusCode:403,message:'mock-secret-error'});await turn();await turn();
check('root rejection makes retry available but never starts retry automatically',()=>{assert.equal(counts.googleHelperCalls,4);assert.equal(element('connect').disabled,false);assert.equal(d().connection,'error');assert.equal(JSON.stringify(d()).includes('mock-secret-error'),false);});
submit('invalid');await turn();submit();await turn();pending[4].resolve(tile('retry'));await turn();await turn();
check('valid manually resubmitted key after failure begins exactly one new attempt',()=>{assert.equal(counts.googleHelperCalls,5);assert.equal(d().rootRequestAttempts,5);});
for(const fn of bus.pagehide||[])fn();
check('pagehide releases connection without attempting another',()=>{assert.equal(counts.googleHelperCalls,5);assert.equal(viewers.at(-1).destroyed,true);assert.equal(d().initialized,false);});

// Independently execute the parent iframe lifecycle fragment from its current source.
const forecastPath=root+'/release/workflow-ui-038/forecast/app.js';
const forecast=await readFile(forecastPath,'utf8');
const fragment=forecast.slice(forecast.indexOf('let scene3dPayload='),forecast.indexOf('\ninitSeason();'));
const parentNodes=new Map(),parentMessages=[],parentBus={},parentDocBus={};let srcAssignments=0,seq=0;
const pe=id=>{if(!parentNodes.has(id)){const x=node(id);x.focus=()=>{};x.getAttribute=key=>x[key]||null;parentNodes.set(id,x);}return parentNodes.get(id);};
pe('scene3dPanel').hidden=true;pe('scene3dFrame').contentWindow={postMessage(message){parentMessages.push(message);}};
Object.defineProperty(pe('scene3dFrame'),'src',{get(){return this._src;},set(value){srcAssignments++;this._src=value;}});
const ctx={$,window:{addEventListener(type,fn){(parentBus[type]??=[]).push(fn);}},document:{hidden:false,body:{classList:{add(){},remove(){}}},addEventListener(type,fn){(parentDocBus[type]??=[]).push(fn);}},location:{protocol:'http:',origin:'http://localhost:mock'},scene3dAvailable:()=>true,Date,console};
function $(id){return pe(id);}
vm.createContext(ctx);vm.runInContext(fragment,ctx);ctx.nextSnapshot=()=>({snapshotId:'parent-fixture-'+(++seq)});vm.runInContext('scene3dSnapshot=nextSnapshot;',ctx);
pe('openScene3d').onclick();
for(const fn of parentBus.message||[])fn({source:pe('scene3dFrame').contentWindow,origin:ctx.location.origin,data:{type:'bjp-scene3d-ready',schema:'bjp-scene3d-v1'}});
vm.runInContext('closeScene3d()',ctx);pe('openScene3d').onclick();vm.runInContext('closeScene3d()',ctx);pe('openScene3d').onclick();
ctx.document.hidden=true;for(const fn of parentDocBus.visibilitychange||[])fn();ctx.document.hidden=false;for(const fn of parentDocBus.visibilitychange||[])fn();
check('parent opens once and retains iframe across two close/reopen cycles and tab hide',()=>{assert.equal(srcAssignments,1);assert.equal(parentMessages.filter(m=>m.type==='bjp-scene3d-open').length,3);assert.ok(parentMessages.filter(m=>m.type==='bjp-scene3d-pause').length>=3);assert.ok(parentMessages.filter(m=>m.type==='bjp-scene3d-resume').length>=3);});

const hashes={};for(const file of [source+'main.js',source+'provider.js',forecastPath])hashes[file.slice(root.length+1)]=createHash('sha256').update(await readFile(file)).digest('hex');
const output={method:'Actual source module with fake Cesium/DOM and controllable promises; parent lifecycle fragment with fake iframe. No network or real credential.',checks,counts,parent:{srcAssignments,openSnapshots:parentMessages.filter(m=>m.type==='bjp-scene3d-open').length},hashes,limits:['Counts application helper invocations, not Cesium HTTP requests, tile loads, billable events or provider session expiry.','No browser/WebGL/Google surface, native camera or actual network behavior asserted.','Parent fragment stubs snapshot creation to isolate iframe lifetime; end-to-end graph transfer is outside this test.']};
await writeFile(root+'/reviews/request-budget-mock380.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({success:true,checks:checks.length,counts,parent:output.parent,hashes}));
