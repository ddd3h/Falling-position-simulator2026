# 0.38 写真3D接続候補

同じ `bjp-scene3d-v1` snapshot を CesiumJS 1.145.0 へ描く独立 source。0.37 の Navara/GSI 配布物は変更しない。CesiumJS は Apache-2.0、依存は `pnpm-lock.yaml` に固定。`node_modules` は配布せず、再生成 source と必要な browser build のみを配布候補にする。

Node >=22、pnpm 11.25.0：

```powershell
pnpm install --frozen-lockfile --ignore-scripts
node test.mjs
node make-fixture.mjs
node build.mjs
```

出力は `../release/workflow-ui-038/scene3d/`。親 release を `127.0.0.1:8380` へ HTTP 公開し、`/forecast/` から入る。file:// は対象外。Google 接続は利用者が画面へ Map Tiles API 用 key を入力し、接続ボタンを押したときだけ開始する。キーを環境変数・設定・URL・チャットへ渡す必要はない。HTTP referrer 制限を設定する場合の候補は `http://127.0.0.1:8380/*`。Cloud 設定はこの source から変更しない。

独立人工形状は `/scene3d/index.html?probe=synthetic`。これは局所で生成した屋根/段差/地面、人工の点・輪郭・穴つき領域を使い、Google へは接続しない。Google coverage、写真mesh、樹木の再現を実証するものではない。親 iframe からこの query を指定しても人工集合へ置き換えない。

配布物の `source/cesium-probe/` でbuildした場合は出力先が `../../scene3d/` になる。原証拠を保持するため配布フォルダー全体を別ディレクトリへコピーして実行する。`../reproduction380.md` に手順と観察版の区別を記載する。

## 表示と費用の境界

- Point：`HeightReference.CLAMP_TO_3D_TILE`、通常の深度テスト。点の実高度や屋根捕捉を計算しない。
- Line/ring：`clampToGround:true` と `ClassificationType.CESIUM_3D_TILE`。
- Polygon：ground Entity（height/extrudedHeight を指定しない）と同 classification。穴は `PolygonHierarchy.holes` として保つ。全面的な物理投影成功は実画像評価を待つ。
- 本体の軌道計算を呼ばず、受領した表示集合と ID を変換する。詳細の0選択で点/経路を増やさない。平均経路は地表参照線。
- viewer/tileset は同じ iframe の中に保持する。snapshot の変更、回転/zoom、分析との往復は root を作り直さない。二重connectは拒否し、再接続は明示的な解除/接続のみ。
- `rootRequestAttempts` はこの iframe が始めた接続試行数。Google の確定課金数、月残量、タイルを含む HTTP 総数ではない。root 応答の raw JSON や session URL を保存して再利用しない。生きている tileset を再利用する。
- `bjp-scene3d-pause/resume` を strict origin/source/schema で受け、隠れている間は render loop を止める。既に進行中の通信/処理まで中止したとは言わない。再開は保持した tileset を描く。期限切れ時も自動 root 再取得は行わない。
- API key は入力後に欄を空にし、関数引数/SDK 内メモリでのみ扱う。public diagnostics に viewer/tileset/Resource/URL/例外全文を入れない。`tileFailed` listener は SDK の URL 入り console fallback を抑止する。Network/HAR/trace を無加工で保存しない。
- 地図の著作権は Cesium の公式 Google helper と data credits を維持。`showCreditsOnScreen:true`。住所検索は無効で、他社 geocoder を使わない。Google tiles の保存/export/同梱は行わない。

## 検査状態

`evidence/cesium-unit380-displayrefine.json`：108 assertions 成功。geometry/ID/穴/色/0選択/credential/error、人工tilesetの実Cesium SSE回帰、輪郭material、視点のclone/復帰/集合同一性を含む。ソフトウェアの WebGL 描画、Google タイル受信、利用目的への受入は別の観察証拠で確認する。作業元では対応する証拠は `../reviews/` にある。

輪郭だけに標準の暗いハローを加える。50/90/95の総幅6/4.5/3.2px、outlineWidth2pxで、色の芯4/2.5/1.2pxを保つ。平均経路/禁止領域の境界は従来幅を保つ。細部の可読性は実画面で評価する。

「この視点を覚える」「覚えた視点へ」はworld座標のposition/direction/upをメモリ内に一つ保持する。同じ地上集合の2D往復、経過時刻/指標/表示名だけの変更では保持し、候補・結果ID、対象選択・分母・輪郭水準・禁止形状等が変わると解除する。集合の幾何学的同値まで推定せず、明示した意味要素と座標列を保守的に比較する。覚える/戻るでGoogle接続を追加しない。

操作欄と状態・マウスguideは地図の外に置く。接続処理中/接続成功後は入力と長文を畳み、試行数と解除を残す。error/unavailableは入力説明を戻すが、既存接続の再取得を自動で始めない。人工fixtureではGoogle入力欄を出さず、Google接続0と表示する。

`window.SCENE3D_DIAGNOSTICS` は観察用の非秘密状態。接続状態、受領 receipt、元 GeoJSON SHA256、件数、camera、tiles 数を含む。camera/tiles だけで屋根/林縁の判読性を成功判定しない。`projectionObserved:false` は本 source の自動テストが現物の投影を証明していないことを示す。

失敗した実物と修復前証拠は上書きせず、別の観察ディレクトリへ保存する。ユーザーが入力した key を再取得・読出しする検査を行わない。
