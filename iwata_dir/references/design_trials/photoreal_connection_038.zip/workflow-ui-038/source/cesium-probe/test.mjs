import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import * as C from 'cesium';
import {fixture} from './src/fixture.js';
import {validatePayload,receipt} from './src/protocol.js';
import {overlayEntities} from './src/overlays.js';
import {credentialFromInput,publicFailure,googleTiles} from './src/provider.js';
import {normalizeSceneColor} from './src/colors.js';
import {collectionIdentity,createViewMemory} from './src/view-memory.js';
let checks=0;const eq=(a,b)=>{assert.deepEqual(a,b);checks++;};
const source=fixture(),frozen=JSON.stringify(source),p=validatePayload(source),items=overlayEntities(C,p);
eq(JSON.stringify(source),frozen);eq(items.length,12);eq(items.filter(e=>e.point).length,5);eq(items.filter(e=>e.polyline).length,6);
const polygon=items.find(e=>e.polygon);eq(polygon.polygon.hierarchy.holes.length,1);eq(polygon.polygon.hierarchy.positions.length,5);eq(polygon.polygon.hierarchy.holes[0].positions.length,5);
eq(polygon.polygon.classificationType,C.ClassificationType.CESIUM_3D_TILE);eq('height' in polygon.polygon,false);eq('extrudedHeight' in polygon.polygon,false);
for(const e of items.filter(e=>e.polyline)){eq(e.polyline.clampToGround,true);eq(e.polyline.classificationType,C.ClassificationType.CESIUM_3D_TILE);}
for(const e of items.filter(e=>e.point)){eq(e.point.heightReference,C.HeightReference.CLAMP_TO_3D_TILE);eq(e.point.disableDepthTestDistance,0);}
eq(items.filter(e=>e.properties.kind==='contour').map(e=>e.polyline.width),[6,4.5,3.2]);
for(const [i,e] of items.filter(e=>e.properties.kind==='contour').entries()){eq(e.polyline.material.getType(),'PolylineOutline');const material=e.polyline.material.getValue();eq(material.outlineWidth,2);assert.ok(Math.abs(e.polyline.width-material.outlineWidth-[4,2.5,1.2][i])<1e-12);checks++;eq(material.color.toCssHexString(),normalizeSceneColor(source.candidates[0].color));}
eq(items.find(e=>e.properties.kind==='mean-route').polyline.width,3);eq(items.find(e=>e.properties.kind==='region'&&e.polyline).polyline.width,2);
eq(items.filter(e=>e.point).map(e=>e.properties.sampleId),source.geojson.features.filter(f=>f.geometry.type==='Point').map(f=>f.properties.sampleId));
for(const [input,expected] of [['#abc','#aabbcc'],['rgb(0 255 255)','#00ffff'],['hsl(180,100%,50%)','#00ffff'],['hsl(300 100% 50%)','#ff00ff'],['hsl(188 100% 55%)','#1ae0ff'],['url(no)',null]])eq(normalizeSceneColor(input),expected);
const empty=structuredClone(source);empty.context={kind:'detail',activeCandidateId:'fixture-A',selection:{sampleIds:[],count:0,denominator:5},contours:'none'};empty.geojson.features=empty.geojson.features.filter(f=>f.properties.kind==='region');const emptyItems=overlayEntities(C,validatePayload(empty));eq(emptyItems.filter(e=>e.point).length,0);eq(emptyItems.filter(e=>e.properties.kind==='mean-route').length,0);eq(receipt(empty).featureCounts.contour,0);
const input={value:'offline-sentinel-not-a-real-key'};const key=credentialFromInput(input);eq(input.value,'');eq(key,'offline-sentinel-not-a-real-key');const invalid={value:'https://example.invalid/key'};assert.throws(()=>credentialFromInput(invalid));checks++;eq(invalid.value,'');
eq(publicFailure({statusCode:403,url:'secret',message:'secret'}),{kind:'authorization',status:403,text:'Googleへの接続が拒否されました。キー・Map Tiles APIの有効化・請求設定・利用元制限を確認してください。'});eq(JSON.stringify(publicFailure({message:key})).includes(key),false);
let calls=0,options;const mock={createGooglePhotorealistic3DTileset:async(api,tiles)=>{calls++;eq(api.key,key);options=tiles;return {synthetic:true};}};await googleTiles(mock,key);eq(calls,1);eq(options.enableCollision,true);eq(options.showCreditsOnScreen,true);await assert.rejects(()=>googleTiles(mock,''));checks++;eq(calls,1);
const main=await readFile(new URL('./src/main.js',import.meta.url),'utf8');eq(/localStorage|sessionStorage|indexedDB|document\.cookie/.test(main),false);eq(main.includes('if(connecting||tileset)'),true);eq(main.includes("tileFailed.addEventListener(()=>"),true);eq(main.includes('bjp-scene3d-pause'),true);
const fixtureTiles=JSON.parse(await readFile(new URL('./fixtures/tileset.json',import.meta.url),'utf8'));
const frame={camera:{frustum:new C.PerspectiveFrustum({fov:Math.PI/3,aspectRatio:2,near:1,far:10000})},context:{drawingBufferWidth:1200,drawingBufferHeight:600},mode:C.SceneMode.SCENE3D,pixelRatio:1};
const sse=error=>C.Cesium3DTile.prototype.getScreenSpaceError.call({_tileset:{_scaledGeometricError:error,dynamicScreenSpaceError:false},parent:undefined,_distanceToCamera:1000},frame,true);
eq(sse(0),0);assert.ok(sse(fixtureTiles.geometricError)>4,'Fixture root must pass the actual Cesium SSE gate at its inspection range');checks++;
const memory=createViewMemory(C);eq(memory.has(),false);memory.updateCollection(source);
let restored;const camera={positionWC:new C.Cartesian3(1,2,3),directionWC:new C.Cartesian3(0,0,-1),upWC:new C.Cartesian3(0,1,0),lookAtTransform(m){eq(m,C.Matrix4.IDENTITY);},setView(pose){restored=pose;}};
eq(memory.remember(camera),true);camera.positionWC.x=99;eq(memory.restore(camera),true);eq(restored.destination,new C.Cartesian3(1,2,3));eq(restored.orientation.direction,new C.Cartesian3(0,0,-1));
const sameCollection=structuredClone(source);sameCollection.snapshotId='new-transfer';sameCollection.createdAt='later';sameCollection.camera.center=[138,36];sameCollection.title='changed heading';sameCollection.notes=['different note'];eq(collectionIdentity(source),collectionIdentity(sameCollection));eq(memory.updateCollection(sameCollection),false);eq(memory.has(),true);
const different=structuredClone(source);different.geojson.features[0].properties.level=.9;eq(memory.updateCollection(different),true);eq(memory.has(),false);memory.updateCollection(source);eq(memory.has(),false);eq(memory.restore(camera),false);
memory.remember(camera);const emptyCollection=validatePayload(empty);eq(memory.updateCollection(emptyCollection),true);eq(memory.has(),false);eq(memory.remember({positionWC:{x:NaN,y:0,z:0},directionWC:camera.directionWC,upWC:camera.upWC}),false);
memory.remember(camera);memory.clear();eq(memory.has(),false);
const labelOnly=structuredClone(source);labelOnly.candidates[0].label='renamed candidate';labelOnly.candidates[0].conditions='same result, new annotation';labelOnly.geojson.features.find(f=>f.properties.kind==='region').properties.label='renamed region';eq(collectionIdentity(source),collectionIdentity(labelOnly));
const detail=structuredClone(empty);detail.context.time=0;detail.context.metric='height';detail.context.view='position';const detailUI=structuredClone(detail);detailUI.context.time=20;detailUI.context.metric='speed';detailUI.context.view='history';detailUI.context.selection.meaning='display annotation';eq(collectionIdentity(detail),collectionIdentity(detailUI));
memory.updateCollection(detail);memory.remember(camera);eq(memory.updateCollection(detailUI),false);eq(memory.has(),true);
for(const mutate of [p=>p.candidates[0].candidateId='other',p=>p.candidates[0].resultId='new-result',p=>p.candidates[0].counts.total++,p=>p.candidates[0].probabilityDefinition='changed meaning',p=>p.geojson.features[0].geometry.coordinates[0][0][0]+=.001,p=>p.geojson.features[0].properties.level=.95,p=>p.geojson.features.find(f=>f.properties.kind==='region').geometry.coordinates[1][0][0]+=.001,p=>p.geojson.features.find(f=>f.properties.kind==='landing').properties.sampleId='other-point']){const changed=structuredClone(source);mutate(changed);assert.notEqual(collectionIdentity(source),collectionIdentity(changed));checks++;}
for(const mutate of [p=>p.context.activeCandidateId='other',p=>p.context.selection.sampleIds=['different-id'],p=>p.context.selection.denominator++,p=>p.context.contours='displayed']){const changed=structuredClone(detail);mutate(changed);assert.notEqual(collectionIdentity(detail),collectionIdentity(changed));checks++;}
const result={engine:C.VERSION,checks,pass:true,googleNetwork:false,scope:'Geometry/ID/hole/color/material, camera-memory identity/clone/restore, credential/error boundaries and fixture SSE only. No WebGL or Google mesh claim.'};if(process.argv[2]){const report=resolve(process.argv[2]);await mkdir(dirname(report),{recursive:true});await writeFile(report,JSON.stringify(result,null,2)+'\n');}console.log(JSON.stringify(result));
