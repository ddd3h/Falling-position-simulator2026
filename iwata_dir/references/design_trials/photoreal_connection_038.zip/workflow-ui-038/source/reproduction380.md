# 0.38 写真3Dの再現と検査

`cesium-probe/` は 0.38 写真3D接続候補の再現source、`../scene3d/` はそのbrowser配布物です。CesiumJS 1.145.0 の公式npm版を固定し、lockfileとlicenseを保持しています。Googleのkeyやtileは含みません。旧0.37のNavara bundleはこのscene3dへ混在させていません。

原本の配布物と証拠を上書きしないため、展開した `workflow-ui-038/` 全体を別の作業ディレクトリへコピーし、そちらで実行してください。Node >=22 と pnpm 11.25.0を前提にします。

```powershell
# コピー先の workflow-ui-038/source/cesium-probe で実行
pnpm install --frozen-lockfile --ignore-scripts
node test.mjs
node make-fixture.mjs
node build.mjs
```

このsource配置では build は同じコピー先の `workflow-ui-038/scene3d/` へ出力します。testは既定でstdoutのみ。結果JSONも残す場合は `node test.mjs <新しい結果JSONパス>` とします。元の `evidence/` は書き換えません。`node_modules` は再生成用で、配布ZIPへ追加しません。

`workflow-ui-038/` をローカルHTTPで提供してください。

```powershell
python -m http.server 8380 --bind 127.0.0.1
```

- `/forecast/`：人工解析模型から現在の同じ結果を3Dへ渡します。
- `/scene3d/index.html?probe=synthetic`：自作の人工屋根/段差/地面と人工点・輪郭・穴つき面を使います。Google通信は不要です。Googleの形状・画像・精度を再現した証拠ではありません。
- Google実接続：利用者自身の、Map Tiles API有効・billing設定済みprojectのAPI keyを画面入力して接続します。この手順は新たなroot取得試行になり、Googleの利用枠を消費します。Web利用元制限は `http://127.0.0.1:8380/*` に合わせます。キー発行やCloud設定はこの再現scriptでは行いません。

入力されたkeyは実行中のbrowser/SDK内メモリだけで使用します。入力欄は接続時に空にし、結果/export/診断/ファイルへ入れません。Network/HAR/traceや例外全文を無加工で保存しないでください。利用後のkey無効化は利用者がGoogle側で行います。

明示接続前はGoogleゼロ、二重開始拒否、同じiframe/tileset保持、2D往復とsnapshot変更でroot再取得なし、自動再接続なしです。カウンターはこのiframeのroot取得開始試行であり、請求確定数・月残量・全HTTP数ではありません。隠れ3Dでは親pause/resumeによりrender loopを停止しますが、既に進行中の通信までは取り消しません。

`cesium-probe/evidence/` に108項目の有限検査（点線面変換、ID/穴、人工tileset SSE、halo、視点clone/復帰/集合同一性など）、独立22条件の通信/寿命mockと14条件の意味反例批評、修復前証拠、設計/実装記録を保持します。mockscriptは当時のP380絶対パスを含む証拠プログラムで、そのままどの展開先でも動くとは主張しません。再実行する場合は作業用コピーでパスを合わせ、結果を新しいディレクトリへ出してください。`test.mjs` と3D buildは現在の再現source自身を対象にしています。

さらに配置修復は独立のGoogleモック13＋synthetic3条件で差分確認しました。既存接続の描画失敗を新規root拒否と区別し、折畳み/resizeで接続を作り直さないことが範囲です。既存22＋14票は対応する旧main段階の有限結果として保持し、同一mainへ一括して全条件再実行したとは記録しません。view-memory/overlay/providerはSHA不変を別途照合しています。

初回の実Google画像の観察は主担当が保持した修復前の同一IABセッションで行いました。sourceのmain指紋は修復前mock記録の `b22ae5992042695226784bfa55f925686b254190d994d3e50edaf8b8d758104f`、gate修復時は `4d2a8132dc87d589f889b93551c521bfb2441c28c70c312f30541be53e717daa`。その後の保存版の最終指紋はsource-inventoryと最新mock記録を参照します。初回旧版との対応は観察時期とreloadしていない実績に基づき、browser内script byteを回収した証拠ではありません。保存版ではsnapshot gate、点の意味の表示、footerの接続保持説明、人工fixtureのSSE、輪郭haloと視点記憶等を修復しています。初回セッションはこれらの修復中に再読込せず保持し、観察後に明示解除しました。後続の再読込後観察は下段の別記録です。

主担当はGoogle/Airbus credit付きの北海道meshと2候補/6輪郭を視認し、2D詳細60点との往復で接続試行1を観測しました。さらに人工禁止領域2面とA28/B3の干渉点を重ね、道路/林縁/建物に接近して内外を読む用途価値を確認しました。細い輪郭と同じ注目箇所の見直しには課題があり、後続halo/視点記憶は人工fixtureと無キー検査で修復しています。実写写真の同じ箇所での改善評価や、地域・LOD・操作条件全般の受入まで完了したとは言いません。実接続成功、保存版の無キー検査、用途としての受入を同一視しません。

後続の最終版では、主担当が再読込後の1656×1270画面にあったGoogle接続を使って観察しました。当該画面のcounter1で、禁止領域なしA/B概要21表示要素、halo付き50/90/95輪郭と平均経路、地図外の操作帯を視認し、覚える→0.65page相当zoom→戻るで元の俯瞰とcounter1を確認しました。最後は明示解除し、背景消失・入力再表示を確認しています。拡大直後の低解像タイル、最薄線の細部判読、全地域/LOD、右drag等は全面受入していません。最終版のGoogleで禁止面/穴を再確認したとの記録にはしません。

再読込前後を通算した接続回数と、新しい接続の開始操作主体は未確認です。主担当は追加connectを行っていないと報告しています。各画面counter1を作業全体の累積1や課金1と解釈しないでください。Cloud側キーの無効化は利用者へ依頼された別の操作で、完了を認証値の読出しで確認していません。実Googleの初回旧版と後続最終版、人工fixture、無キーモックの帰属はそれぞれの証拠に分けています。

収録sourceを別の作業コピーへ展開し、固定lock導入→有限assert→人工fixture生成→buildを実行してruntimeを照合しています。`evidence/cesium-rebuild380.json` が最新明細、`-before-fixturefix` と `-before-displayrefine` が修復前明細です。offline installはregistry metadata不足で失敗したため、再現手順は通常のregistry metadata確認を伴う導入を前提にしています。依存scriptとGoogle接続は実行していません。
