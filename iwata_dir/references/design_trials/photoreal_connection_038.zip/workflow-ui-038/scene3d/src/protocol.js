import {fitBoundsDistance} from './camera-fit.js';
export const SCHEMA='bjp-scene3d-v1';
export const KINDS=['landing','contour','region','mean-route','mean-landing','launch','stop','support-boundary'];
const id=v=>(typeof v==='string' && v.length>0) || (typeof v==='number' && Number.isFinite(v));
const coord=c=>Array.isArray(c)&&c.length===2&&Number.isFinite(c[0])&&Number.isFinite(c[1])&&Math.abs(c[0])<=180&&Math.abs(c[1])<=90;
function require(ok,message){if(!ok)throw new Error(message);}
function line(cs,min=2){require(Array.isArray(cs)&&cs.length>=min&&cs.every(coord),'座標列は有限の経度・緯度で指定してください');}
function polygon(rs){require(Array.isArray(rs)&&rs.length>0,'輪郭のリングがありません');for(const r of rs){line(r,4);require(r[0][0]===r.at(-1)[0]&&r[0][1]===r.at(-1)[1],'輪郭は閉じている必要があります');}}
export function validatePayload(raw){
 const p=structuredClone(raw);require(p&&id(p.snapshotId)&&p.artificial===true,'人工模型の snapshotId が必要です');
 require(Array.isArray(p.candidates)&&p.candidates.length>0,'表示候補がありません');
 const keys=new Set();for(const c of p.candidates){require(id(c.candidateId)&&id(c.resultId),'候補ID・結果IDがありません');const k=JSON.stringify([c.candidateId,c.resultId]);require(!keys.has(k),'候補ID・結果IDの組が重複しています');keys.add(k);}
 require(p.geojson?.type==='FeatureCollection'&&Array.isArray(p.geojson.features),'GeoJSON FeatureCollection が必要です');
 for(const f of p.geojson.features){const g=f.geometry,k=f.properties?.kind;require(f.type==='Feature'&&g,'geometry がありません');require(KINDS.includes(k),'未定義の表示種別です');
  const types={landing:['Point'],'mean-landing':['Point'],launch:['Point'],stop:['Point'],contour:['Polygon','MultiPolygon'],region:['Polygon','MultiPolygon'],'support-boundary':['Polygon','MultiPolygon'],'mean-route':['LineString']};require(types[k].includes(g.type),'表示種別とgeometryが一致しません');
  if(!['region','support-boundary','launch'].includes(k))require(keys.has(JSON.stringify([f.properties.candidateId,f.properties.resultId])),'表示対象外の候補・結果が含まれています');
  if(g.type==='Point')require(['landing','mean-landing','launch','stop'].includes(k)&&coord(g.coordinates),'点の座標が不正です');
  else if(g.type==='LineString'){require(k==='mean-route'||k==='contour','線の種別が不正です');line(g.coordinates);}
  else if(g.type==='Polygon')polygon(g.coordinates);
  else if(g.type==='MultiPolygon'){require(g.coordinates.length>0,'空のMultiPolygonです');g.coordinates.forEach(polygon);}
  else throw new Error('未対応のgeometryです: '+g.type);
  if(k==='contour')require([.5,.9,.95].includes(f.properties.level),'輪郭水準は50/90/95%を指定してください');
 }
 require(coord(p.camera?.center),'camera.center は [経度,緯度] が必要です');
 const b=p.camera.bounds;require(Array.isArray(b)&&b.length===4&&b.every(Number.isFinite)&&b[0]<b[2]&&b[1]<b[3]&&coord([b[0],b[1]])&&coord([b[2],b[3]]),'camera.bounds が不正です');
 if(p.context?.kind==='detail'){const ctx=p.context,s=ctx.selection;require(p.candidates.length===1&&p.candidates[0].candidateId===ctx.activeCandidateId,'詳細の対象候補が一致しません');require(s&&Array.isArray(s.sampleIds)&&Number.isInteger(s.count)&&s.count===s.sampleIds.length&&Number.isInteger(s.denominator)&&s.count<=s.denominator,'詳細の選択数とIDが一致しません');const selected=new Set(s.sampleIds);require(selected.size===s.count,'詳細の選択IDが重複しています');const points=p.geojson.features.filter(f=>f.properties.kind==='landing');require(points.length===s.count&&points.every(f=>selected.has(f.properties.sampleId)),'詳細の選択集合と落下点が一致しません');if(ctx.contours==='none')require(!p.geojson.features.some(f=>f.properties.kind==='contour'),'2D詳細にない輪郭が含まれています');}
 return p;
}
export function receipt(p){return {schema:SCHEMA,snapshotId:p.snapshotId,context:p.context?structuredClone(p.context):null,candidates:p.candidates.map(c=>({candidateId:c.candidateId,resultId:c.resultId,shownLandingCount:c.shownLandingCount??null})),featureCounts:Object.fromEntries(KINDS.map(k=>[k,p.geojson.features.filter(f=>f.properties.kind===k).length])),camera:structuredClone(p.camera),artificial:true,recalculated:false,projectionTarget:'3D Tiles surface; actual provider state is separate'};}
export function cameraFor(p,viewport){return {lng:p.camera.center[0],lat:p.camera.center[1],height:0,distance:fitBoundsDistance(p.camera.bounds,p.camera.center,viewport),heading:0,pitch:-48,roll:0};}
