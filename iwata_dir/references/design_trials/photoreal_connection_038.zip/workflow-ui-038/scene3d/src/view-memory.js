// Remember a place for the same ground collection, not a transport/UI snapshot.
// Keep exact geometry/order and the IDs, classification and denominators that
// determine its meaning. Display labels, colors, time/metric/view and camera do
// not change that ground collection. This is not geometric/set equivalence.
const pick=(object,fields)=>Object.fromEntries(fields.filter(k=>object?.[k]!==undefined).map(k=>[k,object[k]]));
export function collectionIdentity(payload){
 const ctx=payload.context;
 return JSON.stringify({
  candidates:payload.candidates.map(c=>pick(c,['candidateId','resultId','probabilityDefinition','counts','shownLandingCount'])),
  context:ctx?{...pick(ctx,['kind','activeCandidateId','contours']),selection:ctx.selection?pick(ctx.selection,['sampleIds','count','denominator']):null}:null,
  geojson:{type:payload.geojson.type,features:payload.geojson.features.map(f=>({type:f.type,geometry:f.geometry,properties:pick(f.properties,['kind','candidateId','resultId','sampleId','regionId','level','phase','count','denominator','interference','selected','definition'])}))}
 });
}
export function createViewMemory(C){
 let identity=null,pose=null;
 const copy=v=>C.Cartesian3.clone(v);
 const finite=v=>v&&[v.x,v.y,v.z].every(Number.isFinite);
 return {
  updateCollection(payload){const next=collectionIdentity(payload),invalidated=identity!==next&&pose!==null;if(identity!==next)pose=null;identity=next;return invalidated;},
  remember(camera){if(!identity||![camera.positionWC,camera.directionWC,camera.upWC].every(finite))return false;pose={position:copy(camera.positionWC),direction:copy(camera.directionWC),up:copy(camera.upWC)};return true;},
  restore(camera){if(!pose)return false;camera.lookAtTransform(C.Matrix4.IDENTITY);camera.setView({destination:copy(pose.position),orientation:{direction:copy(pose.direction),up:copy(pose.up)}});return true;},
  has(){return pose!==null;},
  clear(){identity=null;pose=null;}
 };
}
