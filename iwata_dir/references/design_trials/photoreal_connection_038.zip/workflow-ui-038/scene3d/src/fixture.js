export const FIXTURE_CENTER=[137.036,35.168];
export function fixture() {
  const center=FIXTURE_CENTER,candidateId='fixture-A',resultId='synthetic-surface-380',features=[];
  const at=(east,north)=>[center[0]+east/(111320*Math.cos(center[1]*Math.PI/180)),center[1]+north/111320];
  const ring=(w,s,e,n)=>[[w,s],[e,s],[e,n],[w,n],[w,s]].map(([x,y])=>at(x,y));
  for(const [level,r] of [[.5,40],[.9,75],[.95,105]])features.push({type:'Feature',properties:{kind:'contour',candidateId,resultId,level},geometry:{type:'Polygon',coordinates:[ring(-r,-r,r,r)]}});
  for(const [i,[x,y]] of [[-20,0],[0,0],[20,0],[60,35],[-80,80]].entries())features.push({type:'Feature',properties:{kind:'landing',candidateId,resultId,sampleId:'fixture-'+i},geometry:{type:'Point',coordinates:at(x,y)}});
  features.push({type:'Feature',properties:{kind:'region',label:'人工の穴つき領域'},geometry:{type:'Polygon',coordinates:[ring(-110,-55,110,55),ring(-10,-15,10,15).reverse()]}});
  features.push({type:'Feature',properties:{kind:'mean-route',candidateId,resultId,phase:'down'},geometry:{type:'LineString',coordinates:[at(-120,-70),at(0,0),at(120,70)]}});
  return {snapshotId:'synthetic-surface-fixture380',createdAt:'2026-09-26T00:00:00Z',artificial:true,title:'人工段差・屋根で投影機構を確認（Googleではありません）',candidates:[{candidateId,resultId,label:'人工投影試験 A',color:'hsl(188 100% 55%)',shownLandingCount:5,probabilityDefinition:'機構の試験形状。落下確率を示しません。',counts:{total:5,landed:5,hits:5,stopped:0,unknown:0}}],geojson:{type:'FeatureCollection',features},camera:{center,bounds:[...at(-180,-145),...at(180,145)]},notes:['この背景も点・線・穴つき面も人工です。Google実接続・樹冠再現・写真mesh適合の証明には使いません。']};
}
