import {SCHEMA,validatePayload,receipt} from './protocol.js';
import {fitBoundsDistance,MAX_INSPECTION_DISTANCE} from './camera-fit.js';
import {overlayEntities} from './overlays.js';
import {credentialFromInput,publicFailure,googleTiles} from './provider.js';
import {normalizeSceneColor} from './colors.js';
import {fixture} from './fixture.js';
import {createViewMemory} from './view-memory.js';
const C=window.Cesium,$=id=>document.getElementById(id),map=$('map');
const syntheticProbe=parent===window&&new URLSearchParams(location.search).get('probe')==='synthetic';
const viewMemory=createViewMemory(C);
const diag=window.SCENE3D_DIAGNOSTICS={schema:SCHEMA,engine:'CesiumJS 1.145.0',initialized:false,provider:'none',googleConnected:false,connection:'disconnected',projectionObserved:false,errors:[],cameraMoves:0,rootRequestAttempts:0,rootCounterMeaning:'Explicit application root-load attempts in this iframe; not total HTTP requests or confirmed billable events',paused:false};
let viewer,tileset,payload,epoch=0,receiveError=null,visibleFrame=0,loaded=0,failed=0,pending=0,processing=0,connectedAt=0,lastCamera='',entityItems=[],connecting=false;

function post(type){if(parent!==window)parent.postMessage({type,schema:SCHEMA,snapshotId:payload?.snapshotId},location.protocol==='file:'?'*':location.origin);}
function originAllowed(e){return e.source===parent&&(location.protocol==='file:'?e.origin==='null':e.origin===location.origin);}
function status(text){$('status').textContent=receiveError||text;}
function background(state,text){diag.connection=state;$('backgroundStatus').dataset.state=state;$('backgroundStatus').textContent=text;updateConnectionLayout();}
function updateConnectionLayout(){
 $('connection').hidden=syntheticProbe;
 $('keyEntry').hidden=connecting||(!!tileset&&['loading','visible','partial'].includes(diag.connection));
 $('connectionState').textContent=connecting?'接続処理中（解除で中断）':tileset?(['error','unavailable'].includes(diag.connection)?'接続を保持中・再接続は解除後':'接続を保持中'):'未接続';
}
function updateConnectButton(){$('connect').disabled=connecting||!!tileset||!payload||!!receiveError;}
function updateViewMemoryUI(message){$('rememberView').disabled=!viewer||!tileset;$('recallView').disabled=!viewer||!tileset||!viewMemory.has();diag.viewRemembered=viewMemory.has();if(message)$('viewMemoryStatus').textContent=message;}
function failure(error){const safe=publicFailure(error);diag.errors.push(safe);background('error',safe.text);status(safe.text);}
function destroyView(){++epoch;connecting=false;tileset=null;entityItems=[];if(viewer){viewer.destroy();viewer=undefined;}map.replaceChildren();diag.initialized=false;diag.googleConnected=false;diag.provider='none';$('disconnect').hidden=true;updateConnectButton();updateViewMemoryUI();}
$('back').onclick=()=>{if(parent!==window)post('bjp-scene3d-close');else status('独立確認画面です。分析画面から開くと同じ分析へ戻れます。');};
$('disconnect').onclick=()=>{destroyView();background('disconnected','接続を解除しました。キーの再入力で接続できます。');status('Googleには接続していません。受領した同じ結果は保持しています。');};
function resetCamera(){if(!viewer||!payload)return;const distance=fitBoundsDistance(payload.camera.bounds,payload.camera.center,{width:map.clientWidth,height:map.clientHeight,fov:C.Math.toDegrees(viewer.camera.frustum.fovy),pitch:-48});diag.initialViewport={width:map.clientWidth,height:map.clientHeight,fov:C.Math.toDegrees(viewer.camera.frustum.fovy),distance};viewer.camera.lookAt(C.Cartesian3.fromDegrees(...payload.camera.center),new C.HeadingPitchRange(0,C.Math.toRadians(-48),distance));viewer.camera.lookAtTransform(C.Matrix4.IDENTITY);viewer.scene.requestRender();}
$('reset').onclick=resetCamera;
$('rememberView').onclick=()=>{if(viewer&&tileset&&viewMemory.remember(viewer.camera))updateViewMemoryUI('この視点を覚えました');};
$('recallView').onclick=()=>{if(viewer&&tileset&&viewMemory.restore(viewer.camera)){viewer.scene.requestRender();updateViewMemoryUI('覚えた視点へ戻りました');}};
function applyVisibility(){for(const item of entityItems)item.show=item.point?$('showPoints').checked:item.polygon?$('showRegions').checked:$('showLines').checked;viewer?.scene.requestRender();}
for(const id of ['showPoints','showLines','showRegions'])$(id).onchange=applyVisibility;
function renderSnapshot(reset=true){if(!viewer||!payload)return;viewer.entities.removeAll();const items=overlayEntities(C,payload);entityItems=items.map(item=>viewer.entities.add(item));diag.renderedEntities=items.length;diag.overlayKinds=receipt(payload).featureCounts;applyVisibility();if(reset)resetCamera();status(`同じ結果を表示：${payload.candidates.length}候補・${payload.geojson.features.length}表示要素。`);}
async function accept(raw){let next;try{next=validatePayload(raw);}catch(error){receiveError='受領した結果を表示できません。'+error.message;diag.payloadError=error.message;updateConnectButton();status('');return;}receiveError=null;diag.payloadError=null;const same=payload?.snapshotId===next.snapshotId;payload=next;updateConnectButton();diag.snapshot=receipt(next);$('receipt').textContent=JSON.stringify(diag.snapshot,null,2);$('title').textContent=next.title||'表示中の結果';$('contextSummary').textContent=next.context?.kind==='detail'?`選択 ${next.context.selection.count}/${next.context.selection.denominator} 着地・輪郭なし`:'概要画面で表示していた集合';$('candidates').replaceChildren();for(const c of next.candidates){const el=document.createElement('span');el.className='candidate';el.style.setProperty('--c',normalizeSceneColor(c.color)||'#34c9ff');const pointLabel=next.context?.kind==='detail'?'選択着地点':next.snapshotId==='synthetic-surface-fixture380'?'人工表示点':'干渉表示点';const contourLabel=next.geojson.features.some(f=>f.properties.kind==='contour'&&f.properties.candidateId===c.candidateId)?'輪郭あり':'輪郭なし';el.textContent=`${c.label||c.candidateId} · 結果 ${c.resultId} · ${pointLabel} ${c.shownLandingCount??'?'}／${contourLabel}`;$('candidates').append(el);}$('definition').textContent=next.candidates.map(c=>`${c.label||c.candidateId}：${typeof c.probabilityDefinition==='string'?c.probabilityDefinition:JSON.stringify(c.probabilityDefinition??'未指定')}`).join(' / ');$('notes').textContent=(next.notes||[]).map(n=>typeof n==='string'?n:JSON.stringify(n)).join(' ');$('legend').textContent=(next.context?.contours==='none'?'選択した着地点とその平均経路。輪郭はありません。':'太線50% · 中線90% · 細線95%。')+' 赤面：禁止領域。屋根上の表示は捕捉・衝突予測ではありません。';
 const invalidated=viewMemory.updateCollection(next);updateViewMemoryUI(invalidated?'集合変更のため視点記憶を解除しました':viewMemory.has()?'覚えた視点を保持しています':'視点はまだ覚えていません');
 if(viewer)renderSnapshot(!same);else status('同じ結果を受領しました。キーを入力すると写真3Dへ接続します。');
 if(crypto.subtle){const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(next.geojson)));if(payload===next)diag.geometrySha256=Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');}
}
function pause(value){diag.paused=value;if(viewer){viewer.useDefaultRenderLoop=!value;if(!value){viewer.resize();viewer.scene.requestRender();}}}
window.addEventListener('message',e=>{if(!originAllowed(e)||e.data?.schema!==SCHEMA)return;if(e.data.type==='bjp-scene3d-open')accept(e.data.payload);if(e.data.type==='bjp-scene3d-pause')pause(true);if(e.data.type==='bjp-scene3d-resume')pause(false);});
function createView(){
 C.Ion.defaultAccessToken='';
 viewer=new C.Viewer(map,{baseLayer:false,baseLayerPicker:false,geocoder:false,globe:false,animation:false,timeline:false,homeButton:false,sceneModePicker:false,navigationHelpButton:false,fullscreenButton:false,vrButton:false,infoBox:false,selectionIndicator:false,scene3DOnly:true,requestRenderMode:true,maximumRenderTimeChange:Infinity,skyBox:false,skyAtmosphere:false});
 viewer.resolutionScale=Math.min(devicePixelRatio,1.5)/devicePixelRatio;
 viewer.scene.screenSpaceCameraController.enableCollisionDetection=true;
 viewer.scene.screenSpaceCameraController.minimumZoomDistance=1;
 viewer.scene.screenSpaceCameraController.maximumZoomDistance=MAX_INSPECTION_DISTANCE;
 viewer.scene.screenSpaceCameraController.zoomEventTypes=[C.CameraEventType.WHEEL,C.CameraEventType.PINCH];
 viewer.scene.screenSpaceCameraController.tiltEventTypes=[C.CameraEventType.RIGHT_DRAG,C.CameraEventType.MIDDLE_DRAG,{eventType:C.CameraEventType.LEFT_DRAG,modifier:C.KeyboardEventModifier.CTRL}];
 viewer.scene.screenSpaceCameraController.rotateEventTypes=C.CameraEventType.LEFT_DRAG;
 // Avoid default double-click entity tracking changing the inspection target.
 viewer.screenSpaceEventHandler.removeInputAction(C.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
 viewer.scene.renderError.addEventListener(()=>{diag.errors.push({kind:'render'});background('error','3D描画に失敗しました。分析へ戻るか、接続を解除して再接続してください。');});
 viewer.scene.preRender.addEventListener(()=>{visibleFrame=0;});
 viewer.scene.postRender.addEventListener(()=>{
  const camera=viewer.camera.positionCartographic;const pose={lng:C.Math.toDegrees(camera.longitude),lat:C.Math.toDegrees(camera.latitude),height:camera.height,heading:C.Math.toDegrees(viewer.camera.heading),pitch:C.Math.toDegrees(viewer.camera.pitch)};const key=JSON.stringify(pose);if(lastCamera!==key){diag.camera=pose;diag.cameraMoves++;lastCamera=key;}
  if(!tileset)return;
  diag.tiles={loaded,failed,pending,processing,visibleThisFrame:visibleFrame,tilesLoaded:tileset.tilesLoaded};
  if(visibleFrame>0){background(failed?'partial':'visible',diag.provider==='synthetic-fixture'?'人工3D形状を描画中です。Google接続0・写真や実建物ではありません。':failed?'写真meshを描画中ですが一部取得に失敗しています。未取得を地物なしと判断しないでください。':'Googleの写真meshを描画中です。対象地点の詳細・重なりを画面で確認してください。');}
  else if(performance.now()-connectedAt>15000&&pending===0&&processing===0)background('unavailable','現在の視野に3D形状を表示できません。地域・通信・視点を確認し、「受け取った地域へ」で戻れます。');
 });
 diag.initialized=true;diag.cameraControls={left:'move',right:'orbit/tilt',wheel:'zoom',minDistance:1,maxDistance:MAX_INSPECTION_DISTANCE,collision:true};
 if(payload)renderSnapshot();if(diag.paused)viewer.useDefaultRenderLoop=false;
}
async function connect(key,synthetic=false){if(!payload||receiveError){key=null;status('有効な分析結果の受領を待っています。Googleへの接続は開始しません。');return;}if(connecting||tileset){key=null;status('現在の接続を保持しています。接続先を替えるときは明示的に解除してください。');return;}destroyView();connecting=true;const ownEpoch=epoch;loaded=failed=pending=processing=0;connectedAt=performance.now();diag.provider=synthetic?'synthetic-fixture':'google-photorealistic-3d';diag.errors=[];$('connect').disabled=true;$('disconnect').hidden=false;background('connecting',synthetic?'人工3D形状を準備しています。':'Google写真3Dへ接続しています。');status('3D背景を準備しています。');
 try{createView();if(!synthetic){diag.rootRequestAttempts++;$('rootCount').textContent=String(diag.rootRequestAttempts);}let candidate=synthetic?await C.Cesium3DTileset.fromUrl('./fixtures/tileset.json',{enableCollision:true,maximumScreenSpaceError:4}):await googleTiles(C,key);key=null;if(ownEpoch!==epoch){candidate.destroy();return;}tileset=candidate;connecting=false;
  // A listener prevents the SDK fallback from logging the tile URL (and key).
  tileset.tileFailed.addEventListener(()=>{failed++;diag.tileFailureCount=failed;});
  tileset.tileLoad.addEventListener(()=>{loaded++;});tileset.tileVisible.addEventListener(()=>{visibleFrame++;});tileset.loadProgress.addEventListener((p,n)=>{pending=p;processing=n;});
  viewer.scene.primitives.add(tileset);diag.googleConnected=!synthetic;background('loading',synthetic?'人工3D形状を読み込んでいます。':'Googleへ接続しました。対象地域の写真meshを読み込んでいます。');renderSnapshot();updateViewMemoryUI();viewer.scene.requestRender();
 }catch(error){key=null;if(ownEpoch===epoch){connecting=false;failure(error);updateConnectButton();}}
}
$('connectForm').addEventListener('submit',e=>{e.preventDefault();if(!payload||receiveError){status('有効な分析結果の受領を待っています。Googleへの接続は開始しません。');return;}let key;try{key=credentialFromInput($('apiKey'));}catch(error){status(error.message);return;}connect(key);key=null;});
new ResizeObserver(()=>{if(viewer&&map.clientWidth&&map.clientHeight){viewer.resize();viewer.scene.requestRender();}}).observe(map);
window.addEventListener('error',e=>{diag.errors.push({kind:'script'});status('表示処理に失敗しました。分析へ戻れます。');e.preventDefault();});
window.addEventListener('unhandledrejection',e=>{diag.errors.push({kind:'async'});status('表示処理に失敗しました。分析へ戻れます。');e.preventDefault();});
window.addEventListener('pagehide',()=>{viewMemory.clear();if(viewer)destroyView();});
updateConnectButton();updateViewMemoryUI();updateConnectionLayout();post('bjp-scene3d-ready');
if(syntheticProbe){await accept(fixture());await connect(null,true);}
