# 写真3D操作模型 0.39

固定依存は CesiumJS 1.145.0（Apache-2.0）。Googleタイルをこの配布物へ保存していない。`licenses/`、生成先 `scene3d/CESIUM-LICENSE.md`、`CESIUM-ThirdParty.json` と `THIRD_PARTY_NOTICES.txt` を保持する。

## 再生成

このディレクトリで `pnpm install --frozen-lockfile`、`pnpm test`、`pnpm build` を実行する。packageManagerはpackage.jsonに固定している。buildは `../../scene3d/` へ入口・CSS・src・人工fixture・固定Cesium vendorを複写し、build-inventory.jsonを作る。node_modulesは配布対象ではない。

今回の担当環境では依存を再取得せず、`BJP_CESIUM_DEPENDENCIES` に既存の固定1.145.0を持つnode_modulesディレクトリを指定して、`node test.mjs` / `node build.mjs` を実行した。通常の展開先ではこの変数を省略し、上記lockから再生成する。

模型のルート `workflow-ui-039/` をローカルHTTPで公開して `forecast/` から開く。file://ではmoduleを実行できないためローカルHTTPが必要。独立の `scene3d/index.html?probe=synthetic` は人工の平面・屋根・段差と点/線/穴付き面の機構試験で、Googleへ接続しない。Googleの提供精度・実写真への適合を証明するfixtureではない。

## v2 受渡しと表示

親2Dが候補・結果・選択・可視性・注目の正本。sceneは全catalogと表示geometryを受け、再計算しない。概要のgeometryは可視で計算済みの候補だけ。詳細は現在候補と選択IDだけで、概要の可視フラグがfalseでも当該選択群を描く。詳細から候補/可視状態は編集しない。

概要からの操作は `bjp-scene3d-intent`、schema `bjp-scene3d-v2`、baseSnapshotId、requestId、action `focus` / `visibility`、candidateId、visibilityの場合のvalueで送る。親の確定snapshotとackを待つ。staleや応答未確認で自動再送しない。hidden focusを自動表示せず、塗りなしの理由を明記する。親子一覧で短い遅延値を使い、詳細の単独候補には親を含むfull labelを使う。

経験輪郭の面は親が作る `contour-band` を受け取る。50%内・50–90%間・90–95%間は外周と穴で区切る。OFFになった輪郭をbandの穴の線として描き直さない。確率密度や校正済み予報確率の表示ではない。分位面と禁止領域面は別toggle。禁止色と詳細点の干渉外縁は親のlevel色を使う。

新しいsnapshotだけを理由にカメラをfitしない。初回接続と明示的な地域ボタンはfitする。保存視点は親のcollectionKeyで判定し、表示・注目だけの変化では保ち、結果・領域・選択集合の本質的変更で解除する。埋込み時の出口は親の一つ。2Dへ戻ることは接続解除ではない。

## 接続と表示更新

Googleは有効な結果を受け取り、ユーザーがキーを入力して接続を押すまで呼ばない。キーは入力欄から読み取った直後に空にし、module実行中だけ使う。ストレージ・結果・診断・ログへ保存しない。接続中の二重開始、自動再接続、自動retryを行わない。rootRequestAttemptsは当該iframe内の明示helper開始数であり、HTTP総数・請求確定数・月残量ではない。

同一iframeを保つ2D往復はpause/resumeで、既存Viewer/tilesetを保持する。批評の最初の表示成功を理由に接続を解除しない。ページ/親ページ/iframe再読込、明示解除、終了は接続保持と異なる操作である。

footerの詳細にある「表示改修の確認 → 表示だけ更新」は、同じviewerへ `src/overlays.js`、`src/catalog.js`、`style.css` の新しい版だけを適用する。旧DataSourceを残したまま新しい定義・DOMを準備し、準備失敗時は適用しない。直近の旧layerを保持して描画失敗時の復帰先にする。これらの操作はGoogle helperやhost再読込を呼ばない。

更新対象外はmain host、protocol、provider、HTML入口、補助module、Cesium engine、親forecastコード。対象外のコードをファイルへ保存しても既存liveへ反映されたとは扱わない。キーを保持する公開global handleや、任意URLからのmodule読込口は用意していない。適用版は `SCENE3D_DIAGNOSTICS.presentation`、accepted snapshotとrenderedSnapshotIdは別に記録する。

## 検査の範囲

`test.mjs` はキーなしの純粋検査。v2 catalog/detail/hidden、bandの穴とOFF境界、色と透明度、親のcollectionKeyによる視点、絶対intentのcatalog、overlay準備/差替え/rollback、認証値の非保存と安全なエラー、fixtureのSSEを確認する。0.39第7票は167条件成功。WebGL/写真mesh/利用目的への全般的受入ではない。

`runtime-check.cjs` は担当が初期に行った独立Playwright試験の方法を残す履歴資料である。現在の作業は主担当から「ブラウザー操作はCUAのみ」と指示されており、この経路を再実行しない。実施済みは9条件の局所成功後にiframe待ち条件で停止した版まで。Google0であっても、これを主担当CUAや最新修復後の実物成功として混同しない。

新しい実物確認と受入は主担当のCUA記録を参照する。最初の独立画像ではmesh/点のあとに線と面が準備されたため、最新hostはDataSourceDisplay.readyに応じた準備状態を表示する。ready自体は地物の判読性の証明ではない。

## 近接地点の読取り

短い左クリックで、確定した表示版の注目候補の輪郭区分を地図外の一行へ示す。全体の経験輪郭の区分であり、局所の落下確率密度ではない。公開pickPosition/sampleHeightで現在のmesh位置を確認し、overlayを高さの根拠から除外する。取得不能を95%外にしない。shared境界、穴、非表示帯、詳細/hidden focusを区別し、面をOFFにして読むときはOFFと併記する。

表示変更で古い読取りと小印を消す。drag/右操作/修飾/長押しは読取りにせず、通常の移動操作を保つ。このhostのクリック機能・band-readout.jsは限定表示更新の対象外であり、機能修復のためliveを無断で再読込しない。

表示差替えの失敗時は、形状だけでなく一覧・選択数・説明・表示receiptも旧版へ戻す。acceptedSnapshotId/receivedSnapshotは新受領のまま別に持つ。旧表示と新受領が違う間の操作を止め、未反映を伝える。候補のpendingは入力が既存結果へまだ反映されていない状態として行に表示する。

## 保存前の検査票と観察段階（0.39）

最終sourceの純粋検査は scene-unit390-r7.json の167条件成功。独立担当のクリック読取り反例は weather-band-readout390-evidence/checks-after.json の21条件成功で、修復前の票も保持する。前者は実装側の条件検査、後者は独立したsource反例の再検査であり、いずれもGoogle接続や実meshの視認を含まない。

主担当のCUAでは、読み込み済みの人工3D hostで屋根上の50%内、地面の50–90%間・90–95%間・95%外、空の取得不能を別々に確認し、小印と読取位置の一致を観察した。表示module更新後の人工背景・配置・保存視点ボタンの保持と読取りリセット、pan dragで読取りが勝手に変わらないことも主担当の有限観察である。当時のhostには最新の「クリック地点」接頭辞が未適用だったため、最新hostの全変更をこの観察で検証済みとは扱わない。最後の修飾キー反例の修復は上記167/21条件へ帰属する。Google写真mesh上の適合・実接続数・後続受入は主担当の別記録へ戻す。

保存前の独立再生成は、元のsource/runtimeを置換せず、別作業コピーで固定依存を用いて test → make-fixture → build と全runtimeのbyte照合を行う。結果は reviews/scene-rebuild390-final.json、各コマンドlog、scene-rebuild390-test.json に分離する。この再生成はGoogle無し・ブラウザー無しであり、実表示の追加証拠ではない。source-inventory.jsonは本READMEを含むsourceの全ファイルを記録し、自己だけを除外する。旧0.38由来のinventoryは reviews/source-inventory390-from038.json に元byteのまま保持する。

## 詳細カードの修復（r8）

主担当の同一Google接続での批評を受け、詳細欄を操作のない対象カードへ変更した。概要用の可視チェックとdisabled候補ボタンを外し、候補色・full label・選択 n/N 着地点を示す。選択0を保持し、pendingは前回結果であることを伝える。概要の可視操作、注目、bandLegend、geometry、main/provider/HTML/CSSは変更していない。

第8票 scene-unit390-r8.json は179条件成功。概要の可視状態に左右されない詳細表現、0/少数選択、遅延子の名前、pending、操作callbackなし、受領payload不変を追加確認した。これはキーなしsource検査であり、修復後のGoogle実画面は主担当の後続観察へ帰属する。catalog.jsは「表示だけ更新」の対象で、既存host/providerの再読込を必要としない。

r8変更前のsource/runtime指紋と旧inventoryは reviews/scene-stage390-r8-before.json と reviews/scene-r8-before/ に保持。新しい独立作業コピー rebuild390-r8/ の再生成・byte照合は reviews/scene-rebuild390-r8.json へ記録し、前回scene-rebuild390-final.jsonを上書きしない。
