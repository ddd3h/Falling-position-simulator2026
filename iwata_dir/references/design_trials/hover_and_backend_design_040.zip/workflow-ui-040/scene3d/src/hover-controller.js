import {tooltipPosition,shortenHoverText} from './hover-labels.js';

// One host-owned listener set. Neither the resolver nor a catalog refresh owns
// pointer handlers, credentials, provider lifetime, or scene globals.
export function createHoverController({target,viewport,tooltip,canRead,sample,setTimer=setTimeout,clearTimer=clearTimeout,delay=260}){
 let timer=null,revision=0,destroyed=false;
 const listeners=[];
 function invalidate(){revision++;if(timer!==null)clearTimer(timer);timer=null;tooltip.hidden=true;tooltip.replaceChildren();}
 function show(result,point){
  if(!result?.targets.length)return;
  const doc=tooltip.ownerDocument,rows=[];
  for(const target of result.targets){const row=doc.createElement('div');row.textContent=target.text;rows.push(row);tooltip.append(row);}
  tooltip.setAttribute('aria-label',result.targets.map(t=>t.text).join(' / ')+(result.otherCount?` / 他 ${result.otherCount} 件`:''));
  if(result.otherCount){const row=doc.createElement('div');row.className='hover-other';row.textContent=`他 ${result.otherCount} 件`;tooltip.append(row);}
  const rect=target.getBoundingClientRect(),bounds={left:Math.max(0,rect.left),top:Math.max(0,rect.top),right:Math.min(viewport.innerWidth,rect.right),bottom:Math.min(viewport.innerHeight,rect.bottom)};
  bounds.width=bounds.right-bounds.left;bounds.height=bounds.bottom-bounds.top;
  if(bounds.width<24||bounds.height<24)return;
  tooltip.style.maxWidth=`${Math.min(340,bounds.width-12)}px`;
  tooltip.hidden=false;
  // A very long name must not silently lose its distinguishing tail. Normal
  // names stay complete; only height overflow gets explicit middle ellipsis.
  for(const limit of [120,80,48,24]){if(tooltip.getBoundingClientRect().height<=bounds.height-12)break;rows.forEach((row,i)=>{row.textContent=shortenHoverText(result.targets[i].text,limit);});}
  const size=tooltip.getBoundingClientRect(),position=tooltipPosition(point,size,bounds);
  tooltip.style.left=`${position.left}px`;tooltip.style.top=`${position.top}px`;
 }
 function move(e){
  invalidate();
  if(destroyed||e.pointerType==='touch'||e.buttons||e.ctrlKey||e.altKey||e.shiftKey||e.metaKey||!canRead())return;
  const point={x:e.clientX,y:e.clientY},own=revision;
  timer=setTimer(()=>{timer=null;if(destroyed||own!==revision||!canRead())return;try{const result=sample(point);if(own===revision&&canRead())show(result,point);}catch{invalidate();}},delay);
 }
 function listen(object,name,fn,options){object.addEventListener(name,fn,options);listeners.push(()=>object.removeEventListener(name,fn,options));}
 listen(target,'pointermove',move);
 for(const name of ['pointerdown','pointerup','pointerleave','pointercancel','lostpointercapture','wheel'])listen(target,name,invalidate,{passive:true});
 for(const name of ['blur','resize','scroll','keydown'])listen(viewport,name,invalidate,{passive:true});
 return {invalidate,destroy(){if(destroyed)return;destroyed=true;invalidate();for(const remove of listeners)remove();}};
}
