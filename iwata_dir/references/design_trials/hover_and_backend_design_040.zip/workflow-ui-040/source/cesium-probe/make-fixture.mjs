// Original synthetic geometry. Contains no Google data or credentials.
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const {Cartesian3,Transforms,Matrix4}=process.env.BJP_CESIUM_DEPENDENCIES?await import(pathToFileURL(resolve(process.env.BJP_CESIUM_DEPENDENCIES,'cesium/Source/Cesium.js'))):await import('cesium');
import {FIXTURE_CENTER} from './src/fixture.js';
const positions=[],normals=[],indices=[];
function box(w,s,b,e,n,t){const v=[[w,s,b],[e,s,b],[e,n,b],[w,n,b],[w,s,t],[e,s,t],[e,n,t],[w,n,t]],faces=[[[4,5,6,7],[0,0,1]],[[1,0,3,2],[0,0,-1]],[[0,1,5,4],[0,-1,0]],[[1,2,6,5],[1,0,0]],[[2,3,7,6],[0,1,0]],[[3,0,4,7],[-1,0,0]]];for(const [face,normal] of faces){const start=positions.length/3;for(const i of face){const [x,y,z]=v[i];positions.push(x,z,-y);normals.push(normal[0],normal[2],-normal[1]);}indices.push(start,start+1,start+2,start,start+2,start+3);}}
box(-300,-300,-2,300,300,0);box(-32,-35,0,32,35,65);box(60,-25,0,120,45,25);box(-120,50,0,-55,110,42);
const bytes=[Buffer.from(new Float32Array(positions).buffer),Buffer.from(new Float32Array(normals).buffer),Buffer.from(new Uint32Array(indices).buffer)];
let offset=0;const views=bytes.map((b,i)=>{const v={buffer:0,byteOffset:offset,byteLength:b.length,target:i===2?34963:34962};offset+=b.length;return v;});
const min=[0,1,2].map(i=>Math.min(...positions.filter((_,j)=>j%3===i))),max=[0,1,2].map(i=>Math.max(...positions.filter((_,j)=>j%3===i)));
const gltf={asset:{version:'2.0',generator:'BJP original synthetic surface fixture 380'},buffers:[{byteLength:offset}],bufferViews:views,accessors:[{bufferView:0,componentType:5126,count:positions.length/3,type:'VEC3',min,max},{bufferView:1,componentType:5126,count:normals.length/3,type:'VEC3'},{bufferView:2,componentType:5125,count:indices.length,type:'SCALAR'}],materials:[{pbrMetallicRoughness:{baseColorFactor:[.38,.48,.43,1],metallicFactor:0,roughnessFactor:1},doubleSided:false}],meshes:[{primitives:[{attributes:{POSITION:0,NORMAL:1},indices:2,material:0}]}],nodes:[{mesh:0}],scenes:[{nodes:[0]}],scene:0};
let json=Buffer.from(JSON.stringify(gltf));json=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,0x20)]);const bin=Buffer.concat(bytes),header=Buffer.alloc(12),jh=Buffer.alloc(8),bh=Buffer.alloc(8);header.writeUInt32LE(0x46546c67,0);header.writeUInt32LE(2,4);header.writeUInt32LE(28+json.length+bin.length,8);jh.writeUInt32LE(json.length,0);jh.writeUInt32LE(0x4e4f534a,4);bh.writeUInt32LE(bin.length,0);bh.writeUInt32LE(0x004e4942,4);
await mkdir(new URL('./fixtures/',import.meta.url),{recursive:true});await writeFile(new URL('./fixtures/surface.glb',import.meta.url),Buffer.concat([header,jh,json,bh,bin]));
const transform=Matrix4.toArray(Transforms.eastNorthUpToFixedFrame(Cartesian3.fromDegrees(...FIXTURE_CENTER)));
// Top-level error describes omitting the entire 600 m fixture. A zero here
// causes Cesium's root SSE gate to skip even requesting this leaf's content.
await writeFile(new URL('./fixtures/tileset.json',import.meta.url),JSON.stringify({asset:{version:'1.1',copyright:'Original artificial geometry for BJP renderer testing; not Google imagery'},geometricError:600,root:{boundingVolume:{box:[0,0,32,301,0,0,0,301,0,0,0,35]},geometricError:0,refine:'REPLACE',transform,content:{uri:'surface.glb'}}},null,2)+'\n');
console.log(JSON.stringify({fixture:'original-synthetic',vertices:positions.length/3,triangles:indices.length/3,bytes:28+json.length+bin.length}));
