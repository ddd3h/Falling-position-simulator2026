import assert from 'node:assert/strict';
import {createViewStability,publicViewPose} from './src/view-stability.js';
import {createHoverController} from './src/hover-controller.js';

export function runViewStabilityTests(){
 let checks=0;const eq=(a,b)=>{assert.deepEqual(a,b);checks++;};
 const pose={position:[4e6,3e6,3e6],direction:[0,0,-1],up:[0,1,0],fov:Math.PI/3,aspect:1.8};
 const tracker=createViewStability();eq(tracker.ready(1000),false);eq(tracker.observe(pose,10),true);eq(tracker.ready(269),false);eq(tracker.ready(270),true);
 // A camera moveStart that never receives moveEnd is deliberately irrelevant.
 // Repeated numerical jitter must not reset the time of visual rest.
 for(let i=1;i<=100;i++){const p=structuredClone(pose);p.direction[0]=i*2.22e-16;p.up[2]=-i*3.13e-16;p.position[0]+=(i%2?1:-1)*1e-7;assert.equal(tracker.observe(p,10+i*16),false);}
 checks++;eq(tracker.ready(1610),true);eq(tracker.status(1610).changes,1);
 // Small changes accumulate against the significant anchor, not the last frame.
 const slow=createViewStability();slow.observe(pose,0);for(let i=1;i<=4;i++){const p=structuredClone(pose);p.position[0]+=i*2e-6;eq(slow.observe(p,i*100),false);}
 const translated=structuredClone(pose);translated.position[0]+=12e-6;eq(slow.observe(translated,600),true);eq(slow.ready(859),false);eq(slow.ready(860),true);
 const rotational=createViewStability();rotational.observe(pose,0);for(let i=1;i<=4;i++){const p=structuredClone(pose);p.direction[0]=i*2e-11;eq(rotational.observe(p,i*100),false);}
 const rotated=structuredClone(pose);rotated.direction[0]=12e-11;eq(rotational.observe(rotated,600),true);eq(rotational.ready(859),false);eq(rotational.ready(860),true);
 for(const change of [p=>{p.up[0]=1e-4;},p=>{p.fov+=.01;},p=>{p.aspect+=.01;},p=>{p.position[2]+=1;},p=>{p.direction[1]=.001;}]){const p=structuredClone(pose),t=createViewStability();t.observe(pose,0);change(p);eq(t.observe(p,1000),true);eq(t.ready(1259),false);eq(t.ready(1260),true);}
 const input=structuredClone(pose),immutable=createViewStability();immutable.observe(input,0);input.position[0]+=5;eq(immutable.observe(pose,300),false);eq(immutable.ready(300),true);
 for(const invalid of [null,{...pose,position:[NaN,0,0]},{...pose,direction:null},{...pose,up:[0,1,Infinity]},{...pose,fov:undefined},{...pose,aspect:0}]){const t=createViewStability();t.observe(pose,0);eq(t.observe(invalid,400),true);eq(t.ready(1000),false);eq(t.observe(pose,1100),true);eq(t.ready(1360),true);}
 const cleared=createViewStability();cleared.observe(pose,0);cleared.clear();eq(cleared.ready(1000),false);eq(cleared.status(1000).changes,0);cleared.observe(pose,2000);eq(cleared.ready(1900),false);eq(cleared.observe(pose,NaN),true);eq(cleared.ready(5000),false);
 assert.throws(()=>createViewStability({positionTolerance:-1}));checks++;
 const camera={positionWC:{x:1,y:2,z:3},directionWC:{x:0,y:0,z:-1},upWC:{x:0,y:1,z:0},frustum:{fov:1,aspectRatio:2}};
 const copied=publicViewPose(camera);eq(copied,{position:[1,2,3],direction:[0,0,-1],up:[0,1,0],fov:1,aspect:2});copied.position[0]=999;eq(camera.positionWC.x,1);eq(publicViewPose(null),null);

 // Integration regression: a real controller can settle/read with the SDK event
 // still marked moving, but meaningful motion invalidates pending reads.
 class Events{constructor(){this.events={};}addEventListener(k,f){(this.events[k]??=[]).push(f);}removeEventListener(k,f){this.events[k]=this.events[k].filter(x=>x!==f);}emit(k,e={}){for(const fn of this.events[k]||[])fn(e);}}
 class Element{constructor(){this.children=[];this.style={};this.hidden=true;this.ownerDocument={createElement:()=>new Element()};}setAttribute(){}replaceChildren(){this.children=[];}append(e){this.children.push(e);}getBoundingClientRect(){return {width:150,height:30};}}
 const target=new Events(),viewport=new Events(),tooltip=new Element();target.getBoundingClientRect=()=>({left:0,top:0,right:800,bottom:600,width:800,height:600});viewport.innerWidth=800;viewport.innerHeight=600;
 let now=0,reads=0,seq=0,current=structuredClone(pose);const timers=new Map(),stable=createViewStability();
 const hover=createHoverController({target,viewport,tooltip,canRead:()=>{if(stable.observe(current,now))hover.invalidate();return stable.ready(now);},sample:()=>{reads++;return {targets:[{text:'正しい現在の候補'}],otherCount:0};},setTimer:fn=>{const id=++seq;timers.set(id,fn);return id;},clearTimer:id=>timers.delete(id)});
 stable.observe(current,now);const pointer={clientX:20,clientY:20,pointerType:'mouse',buttons:0},fire=()=>{for(const [id,fn] of [...timers]){timers.delete(id);fn();}};
 now=300;target.emit('pointermove',pointer);for(let i=0;i<15;i++){now+=16;current.direction[0]+=2e-16;if(stable.observe(current,now))hover.invalidate();}now=580;fire();eq(reads,1);eq(tooltip.hidden,false);
 current.position[0]+=2;now=600;if(stable.observe(current,now))hover.invalidate();eq(tooltip.hidden,true);target.emit('pointermove',pointer);fire();eq(reads,1);
 now=900;target.emit('pointermove',pointer);now=1170;fire();eq(reads,2);eq(tooltip.hidden,false);
 target.emit('pointermove',pointer);current.up[0]=.1;now=1200;if(stable.observe(current,now))hover.invalidate();fire();eq(reads,2);eq(tooltip.hidden,true);hover.destroy();
 return checks;
}
