# 0.39 再現源・比較元・確認の境界

`cesium-probe/` が現在の3D生成源、`../scene3d/` が配布用生成物です。CesiumJS 1.145.0、packageManagerとlockfileを保持します。`../forecast/`、`../shared/`、`../weather/` は操作模型の編集元です。模型の人工標本を本体の気象取得・物理積分へ接続した版ではありません。

比較元はmain M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e` の `references/design_trials/photoreal_connection_038.zip` です。旧ZIPと今回のZIPを別フォルダーへ展開して比較してください。`reproduction380.md` と0.38 evidenceは当時の実績を保持する資料で、現在のsourceに対する最新検査票ではありません。

## 作業用コピーで再生成する

成果物を直接上書きしないよう、展開した `workflow-ui-039` を別の作業フォルダーへコピーします。Node >=22、package.jsonに指定したpnpmを使います。`source/cesium-probe` で次を実行します。

```powershell
pnpm install --frozen-lockfile --ignore-scripts
node test.mjs
node make-fixture.mjs
node build.mjs
```

buildは作業用コピーの `scene3d/` を生成し、build-inventory.jsonに指紋を記録します。Google通信は不要です。`BJP_CESIUM_DEPENDENCIES` は、作業環境に既にある同じ固定依存を参照する場合だけ使う補助変数です。この変数を参照するのはbuild.mjsだけで、make-fixture.mjsのbare importを解決するnode_modulesは別途必要です。環境変数だけでinstallを代用しません。通常の展開先では指定しません。node_modulesは配布ZIPへ入れません。

模型ルートをローカルHTTPで提供します。

```powershell
python -m http.server 8390 --bind 127.0.0.1
```

- `/forecast/` は候補・遅延・禁止領域・詳細・3D往復・KML保存の入口です。
- `/weather/` は人工8,768時刻の風を対象に、年間の高度構造と来向円環・保存SVGを確認する入口です。
- `/scene3d/index.html?probe=synthetic` は人工の屋根・段差・穴付き面を使う無キー試験です。
- `/review/kml-preview.html` は生成KMLを標準KmlDataSourceで読みます。外部画像・NetworkLinkは扱いません。

## 証拠の読み分け

`review/evidence/` の各票は、読んだsource・実行段階・前後の失敗と修復を分けて保持します。作業時の絶対パスを含む独立批評脚本は証拠であり、全てがそのまま任意フォルダーで動く汎用テストではありません。再実行するときはコピーでパスを合わせ、元票を上書きせず別の出力へ保存します。

主担当の実物操作はCUAによるものです。3D担当が初期に別ブラウザ方式で実施した9条件は、その方法を記した履歴としてのみ残します。現在のブラウザ検証はCUAで行い、当該脚本を再実行する手順にしません。sourceのモック検査・人工3DのGPU描画・Google写真3Dの実観察・Google EarthでのKML確認を互いの代用にしません。

全目録KMLの非表示対象はXMLで保持を確認し、初期表示は独立readerで確認します。readerには親visibilityを子へ焼き込む制約があるため、読込後に親だけをONにして全子が戻ることは確認器の保証外です。模式AGLは人工高度を地面相対と見立てたKML宣言です。楕円体背景で実地形の高度変換を受け入れません。

## 接続したまま表示を改善する

利用者が画面に入力したMap Tiles APIキーを用い、明示接続後の同じViewer/tilesetで候補・表示・詳細を比較します。キーの値、キー付き通信URL、HAR、Googleタイルを証拠へ保存しません。限定表示更新の対象と対象外は `cesium-probe/README.md` にあります。ディスクのコードを変えただけでは適用済みではなく、画面に適用された版と接続試行の範囲を記録します。

0.39の最終実観察と保存の状態はrepo S34と `review/evidence/root-design390.md` を参照します。記録されていない成功を、旧0.38の結果から補いません。
