# 0.39 再現・保存境界の最終独立批評

基準 main M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`。凍結した 0.39 runtime に対する、再現手順と記録案の有限批評である。担当 `/root/weather370`。次の四本文を全読した。

- `release/workflow-ui-039/source/reproduction390.md`
- `reviews/scene-rebuild390-final.md`
- `metadata/PREPARATION.md`
- `metadata/body-proposals390.md`

対応する package/build/fixture source、再生成の初回失敗・最終 receipt、旧 reproduction380、旧 inventory、本文で参照される現表示 source を追加で読んだ。再生成 helper、pnpm install、ブラウザー、Google は実行していない。runtime / source / metadata / repo 本文を変更していない。下記 F-W1 は主担当の明示依頼により、reviews 内の最終再生成説明だけを訂正した。

## 判定

通常の別コピーによる再現経路と、検査・人工描画・Google 実観察・保存到達の境界は、本文から追跡できる。旧版の証拠を現在の受入へ繰り上げたり、未作成 PR を観測済みとしたりする記述は見つからなかった。

一つの誤った保護保証 F-W1 を修正した。小さい文言提案 F-W2 / F-W3 は主担当へ連絡した。Google 未接続・最終用途受入未完・UI 保存到達未確認は残件として維持する。この票は全体の用途受入や Git 保存完了を意味しない。

## F-W1 / P2：一回用 helper の証拠保護を過大に記述していた

scene-rebuild390-final.md の初読時の末段は、二つの helper が「元証拠を上書きしないガード」を持つとしていた。しかし `finalize-scene-source390.mjs` は既存 workRoot の検出を try 内で throw し、catch で失敗を記録した後、無条件に `writeFile(receiptPath, ...)` を実行する。再実行すると再生成自体を止めても、完成済み `scene-rebuild390-final.json` を失敗 receipt で上書きし得る。`resume-scene-rebuild390.mjs` の前提検査は try 外にあり、この問題と区別する。

実際に再実行して証拠を壊す検査は行っていない。制御フローの読取で特定し、主担当が採用した。主担当の指示で MD 末段を「再実行禁止」「既存 workRoot 拒否は receipt の保護ではない」「今回実績の履歴資料で通常再現対象外」「別コピーの reproduction390.md を使う」へ訂正した。helper 本体と成功 receipt は保持した。

修正後 MD SHA-256 は `e0c09dcc1f6d9fa04c4a8bd1025fec332a79b4d17bf7c39c99ca2ed611801003`。この訂正は誤った保証の除去として受入可。歴史 source を現行の汎用再実行手順へ作り替えない判断は妥当である。

## F-W2 / P3：補助環境変数の範囲を限定すると再現が迷いにくい

通常手順は pnpm install → test → make-fixture → build で、packageManager と Cesium の固定値、作業先からの生成相対パスは整合している。一方 BJP_CESIUM_DEPENDENCIES を参照するのは build.mjs であり、make-fixture.mjs は `import ... from 'cesium'` という通常の bare import を行う。環境変数だけではそのモジュール解決を置換しない。今回の独立作業コピーでは別途 node_modules junction を置いたことが receipt と説明に記録されている。

現手順は install を省略するよう明示しておらず、通常経路の破綻とは判定しない。ただし補助変数の段落に「build 用の探索先であり、test/fixture の node_modules 解決を代替しない」と一文添えると、既存依存を流用する読者の誤解を防げる。新規環境での pnpm install は今回の独立再生成の実施範囲ではない。

## F-W3 / P3：点の説明は入口で修正した表現へ揃える

body-proposals の「黄い飛翔時点と着地は記号でも区別する」は、既に入口で修正した「黄色の塗りと暗い縁」の説明へ揃えるとよい。凍結 source では飛行中も着地も L.circleMarker である。異なる形を実装済みと再び読ませない。KML の 50 太 / 90 中 / 95 細の説明は現 export390 の幅配列と一致しており、この点を誤りとはしない。

## 独立に裏付けを照合した範囲

- 最終 receipt は test / fixture / build の終了 0 と、再生成の byte 一致を分けている。初回は exitCode=null / EPERM の子プロセス起動失敗で、初回検査を成功件数に含めていない。初回 JSON とログが別名で保持されていることを読んだ。
- source inventory の 50 登録ファイルと runtime inventory の 411 登録ファイルを、現ファイルの SHA-256 に独立照合し、登録内の差は 0。最終再生成の 412 実体は inventory 自身を含む数として説明され、411 と矛盾しない。この批評で別コピーから再生成を再実行したわけではない。
- 現 source-inventory SHA `16154bc58c52fe2a34b6b97898ec92987ed8e7b7787eb24896e2a069682784f8`、runtime build-inventory SHA `7aa4bd35e0dca1eb3391524d276fa8853005ebad7fbab015d141e54f1b85f244` は報告値と一致した。
- source 内の旧0.38 evidence は baseline-model の対応ファイルと比較して変更なし。旧 inventory の保管コピーも元 byte と一致。reproduction380.md の差は冒頭へ追加した歴史資料の案内のみで、元本文は維持されている。ここから旧7ZIPすべての最終パッケージ保持まで検証済みとは拡張しない。
- metadata は 107→108、新1資産/1scope、旧45論証保持という準備案を示す。旧0.36/0.37を現在の統合状態へ遡及分類せず、0.38の観測済み Git 遷移と新0.39の pending を分けている。実読前の印更新・未知PR番号の仮置きを避ける手順も明確。
- body-proposals の source 反例32件は担当の最新 checks.json の32件と一致した。自担当の21件、sceneの167件、rootの実UI観察と一括の検査数へ合算していない。

## 保存と観察の境界

KML は source で生成・構造検査し、別 reader で図形を確認した証拠がある。しかし実UIの保存操作は、生成とブラウザーへの保存要求までで Downloads の実ファイル到達は未確認。候補JSONも同じ未確認である。application/octet-stream の試行も到達を確認できず、標準KML MIMEへ戻したため、MIME変更を解決と記録しない本文案は妥当。

一方、年間SVGは実ファイル・ハッシュ・単独表示まで主担当記録がある。この二つを同じ「保存成功」へまとめない方針を支持する。Google 写真3Dは主担当が利用者入力を待つ段階で、旧0.38実接続を新0.39へ転用しない。source/人工3Dの受入により接続確認や課金実績を補わない。

主担当の最新実績が加わるなら、その観測時点から記録を追加する。現在の未確認という経過を無かったことにする書換えは不要。最終 ZIP・管理印・PR 実績はそれぞれの完了後に本文へ戻す。

## 全読時指紋と残る範囲

| 本文 | SHA-256 |
|---|---|
| source/reproduction390.md | `8baedf85d7907a9de02bdf3fe0597ae867c707f07423d58f58c938d09bb22187` |
| metadata/PREPARATION.md | `ec243a69f19734d56fd67ac9fe235d40cd52cc9684c0e36ef617ae8ba357cc55` |
| metadata/body-proposals390.md | `7fc0eb4489f5e8365dd889f1fdf57c33d989543663a545bce0d6e95e962d40f3` |

scene-rebuild MD は F-W1 の訂正後指紋を上に記した。metadata helper の全実行分岐、最終 ZIP の展開再現、新規依存取得、実ブラウザーの保存完了、Google/Google Earth の適合、repo全依存 scope の今回実読、Git 保存はこの票の受入範囲外。
