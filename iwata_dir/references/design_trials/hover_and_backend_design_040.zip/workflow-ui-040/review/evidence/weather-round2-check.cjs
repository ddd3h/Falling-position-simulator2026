// No browser, network, DOM library or provider calls. Execute fixed helper and
// actual annual/export functions with explicit DOM-shaped values.
const fs=require('fs'),vm=require('vm'),crypto=require('crypto'),path=require('path');
const top='C:/Users/genia/AppData/Local/Temp/balloon-design-390';
const root=top+'/release/workflow-ui-039/weather',base=top+'/baseline-model/workflow-ui-038/weather';
const checks=[];const check=(name,pass,detail)=>checks.push({name,pass:!!pass,...(detail===undefined?{}:{detail})});
function fixture(dir){const ctx=vm.createContext({window:{}});vm.runInContext(fs.readFileSync(dir+'/fixture.js','utf8'),ctx);return ctx.window.WindFixture;}
const F=fixture(root),B=fixture(base),D=require(root+'/direction-key.js');
const uv=(d,s=10)=>[-s*Math.sin(d*Math.PI/180),-s*Math.cos(d*Math.PI/180)];
const observations=Object.fromEntries([
 ['north',[[0,-10],[0,-10]]],['wrap',[uv(359),uv(1)]],['west',[[20,0],[20,0]]],
 ['calm',[[0,0],[0,0]]],['cancellation',[[20,0],[-20,0]]],['weak',[[.01,0],[.01,0]]],['empty',[]]
].map(([key,x])=>[key,F.summary(x)]));
check('Real north remains numeric zero',observations.north.dir===0);
check('359/1 mean is north',Math.abs(observations.wrap.dir)<1e-9);
check('Positive u is FROM west',observations.west.dir===270);
check('All calm direction and constancy undefined',observations.calm.dir===null&&observations.calm.R===null);
check('Opposing strong wind differs from calm',observations.cancellation.dir===null&&observations.cancellation.R===0&&observations.cancellation.s===20);
check('No new calm speed threshold',observations.weak.dir===270&&observations.weak.R===1);
check('Empty input remains no summary',observations.empty===null);
const roundtrip=JSON.parse(JSON.stringify(observations));
check('JSON preserves null versus north zero',roundtrip.calm.dir===null&&roundtrip.cancellation.dir===null&&roundtrip.north.dir===0);
check('Undefined labels contain no numeric direction',!/[0-9]+(?:\.[0-9]+)?°/.test(D.appearance(observations.calm).label)&&!/[0-9]+(?:\.[0-9]+)?°/.test(D.appearance(observations.cancellation).label));
check('Calm, cancellation, empty labels distinguish reasons',new Set(['calm','cancellation','empty'].map(k=>D.appearance(observations[k]).label)).size===3);
check('Periodic hue is equal at 0 and 360',D.color(0)===D.color(360));
check('Nonzero low R retains direction with caveat',D.appearance({dir:270,R:.1,s:20}).kind==='low'&&D.appearance({dir:270,R:.1,s:20}).label.includes('代表性が弱い'));
function rawDigest(f){const h=crypto.createHash('sha256');for(const r of f.records){h.update(JSON.stringify([r.id,r.year,r.month,r.day,r.bin,r.quarter,r.hour,r.validUTC]));h.update(Buffer.from(r.uv.buffer));}return h.digest('hex');}
const raw={before:rawDigest(B),after:rawDigest(F),count:F.records.length};
check('Every raw u/v and dated membership byte unchanged',raw.before===raw.after,raw);
check('Calendar definition unchanged',JSON.stringify(B.calendarDefinition)===JSON.stringify(F.calendarDefinition));
const app=fs.readFileSync(root+'/app.js','utf8'),oldApp=fs.readFileSync(base+'/app.js','utf8');
for(const name of ['roseCounts','rose','monthly','spatial']){const prefix=' function '+name+'(';check(name+' implementation unchanged',app.split('\n').find(l=>l.startsWith(prefix))===oldApp.split('\n').find(l=>l.startsWith(prefix)));}
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let host={innerHTML:''},mode='real',grain='quarter';const byGrain={quarter:Array.from({length:48},(_,i)=>F.records.filter(r=>r.quarter===i)),half:Array.from({length:24},(_,i)=>F.records.filter(r=>r.bin===i))};
const fieldCases=[observations.north,observations.calm,observations.cancellation,observations.weak,null,{...observations.west,R:.1}];
const ctx=vm.createContext({F,D,esc,console,state:{annualGrain:grain,view:'annual',from:2020,to:2025,hours:[3,9,15,21]},cache:{selected:F.records},metadata:()=>({version:'0.39',directionDefinition:D.definition}),rowsFor:(g,i)=>byGrain[g][i],periodName:(g,i)=>String(i),periodDescription:()=>'',statsFor:(g,i)=>mode==='counterexamples'?Array.from({length:16},(_,l)=>fieldCases[(i+l)%fieldCases.length]):stats[g][i],$:selector=>selector==='#annual-plots'?host:{textContent:'年間の高度構造'}});
vm.runInContext(app.slice(app.indexOf(' const fmt='),app.indexOf(' const classes=')),ctx);
vm.runInContext(app.slice(app.indexOf(' function bar('),app.indexOf(' function levelLabels(')),ctx);
vm.runInContext(app.slice(app.indexOf(' const altitudeEdges='),app.indexOf(' const selectedYears=')),ctx);
vm.runInContext(app.slice(app.indexOf(' function groupStats('),app.indexOf(' function rebuild(')),ctx);
const stats={quarter:byGrain.quarter.map(x=>ctx.groupStats(x)),half:byGrain.half.map(x=>ctx.groupStats(x))};
vm.runInContext(app.slice(app.indexOf(' function annual(){'),app.indexOf(' const world=')),ctx);
vm.runInContext(app.slice(app.indexOf(' function exportSVG('),app.indexOf(' async function exportStandalone(')),ctx);
const parse=()=>[...host.innerHTML.matchAll(/<svg\b([^>]*)>([\s\S]*?)<\/svg>/g)].map(m=>{const [x,y,width,height]=m[1].match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);return {viewBox:{baseVal:{x,y,width,height}},innerHTML:m[2],closest:()=>null,getAttribute:name=>name==='aria-label'?m[1].match(/aria-label="([^"]*)"/)[1]:null};});
host.querySelectorAll=()=>parse();
ctx.annual();let figures=parse();
check('Four annual data figures retained',figures.length===4);
check('Only direction key grows vertically',figures.map(x=>x.viewBox.baseVal.height).join(',')==='275,332,275,275');
check('Original 48 by 16 direction cells retained',(figures[1].innerHTML.match(/data-direction-state=/g)||[]).length===48*16);
check('Direction ring occurs once',figures.filter(x=>x.innerHTML.includes('data-direction-key="from-circular"')).length===1);
check('North east south west positions encoded',figures[1].innerHTML.includes('x="108" y="238"')&&figures[1].innerHTML.includes('x="149" y="280"')&&figures[1].innerHTML.includes('x="108" y="324"')&&figures[1].innerHTML.includes('x="66" y="280"'));
const saved=ctx.exportSVG('annual-plots');fs.writeFileSync(__dirname+'/weather-round2-annual.svg',saved.source);
check('Standalone SVG retains same circular key',saved.source.includes(D.legend()));
check('Export retains FROM and null definition',saved.source.includes('from-direction-key-v1')&&saved.source.includes('dir=null'));
const scales=[...saved.source.matchAll(/<g transform="translate\((\d+) ([\d.]+)\) scale\(([\d.]+)\)">/g)];
check('Every saved annual data area uses same full width scale',scales.length===4&&scales.every(x=>+x[3]===1.08),scales.map(x=>({y:+x[2],scale:+x[3]})));
check('Taller direction figure does not collide with next figure',+scales[2][2]>=+scales[1][2]+332*1.08+20);
ctx.state.annualGrain='half';ctx.annual();check('24 by 16 switch retained',(parse()[1].innerHTML.match(/data-direction-state=/g)||[]).length===24*16);
mode='counterexamples';ctx.annual();figures=parse();const forced=ctx.exportSVG('annual-plots');fs.writeFileSync(__dirname+'/weather-round2-counterexamples.svg',forced.source);
check('Undefined annual cells have explicit labels',figures[1].innerHTML.includes('平均来向なし（全標本が無風）')&&figures[1].innerHTML.includes('平均来向なし（平均ベクトルが0）'));
check('Counterexample SVG preserves real north zero',figures[1].innerHTML.includes('0.0°（来向）'));
check('No NaN/null degree rendered',!/(NaN|null|undefined)°/.test(forced.source));
const out={basis:'M380 19bf0cc5cd32509a44ca8e246f4294ab0972d61e',scope:'No Browser/Google/network. Fixed source functions under explicit DOM-shaped harness; real pixels, CSS layout, download and print remain unverified.',observations,checks,pass:checks.every(x=>x.pass),sourceHashes:Object.fromEntries(['app.js','fixture.js','direction-key.js','index.html'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(root+'/'+p)).digest('hex')]))};
fs.writeFileSync(__dirname+'/weather-round2-check.json',JSON.stringify(out,null,2));console.log(JSON.stringify({pass:out.pass,conditions:checks.length,failed:checks.filter(x=>!x.pass),raw}));if(!out.pass)process.exitCode=1;
