"""Finite own-visibility/catalog inspection of the second actual UI KML download."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
from datetime import datetime, timezone
import json
import xml.etree.ElementTree as ET

source = Path('C:/Users/genia/Downloads/balloon-analysis-039 (1).kml')
dest = Path('C:/Users/genia/AppData/Local/Temp/balloon-design-390/reviews/download390-evidence')
output = dest / 'balloon-analysis-039-expanded.kml'
receipt = dest / 'physical-download390-expanded.json'
if receipt.exists():
    raise RuntimeError('Do not overwrite existing receipt')
data = source.read_bytes()
if output.exists() and output.read_bytes() != data:
    raise RuntimeError('Existing evidence differs')
if not output.exists():
    output.write_bytes(data)

ns = {'k': 'http://www.opengis.net/kml/2.2'}
tree = ET.fromstring(data)
local = lambda e: e.tag.rsplit('}', 1)[-1]
text = lambda e, key, default='': e.findtext('k:' + key, default=default, namespaces=ns)
ext = lambda e: {v.get('name'): text(v, 'value') for v in e.findall('k:ExtendedData/k:Data', ns)}
folders = []
placemarks = []
def walk(node, path=(), effective=True):
    name = text(node, 'name')
    own = text(node, 'visibility', 'default1')
    visible = own != '0'
    if local(node) == 'Folder':
        path = (*path, name)
        folders.append({'path': list(path), 'own_visibility': own, 'effective_visibility': effective and visible, 'extended_data': ext(node), 'direct_placemarks': len(node.findall('k:Placemark', ns)), 'child_folders': len(node.findall('k:Folder', ns))})
    if local(node) == 'Placemark':
        placemarks.append({'name': name, 'folder_path': list(path), 'own_visibility': own, 'effective_visibility': effective and visible, 'extended_data': ext(node), 'style': text(node, 'styleUrl'), 'geometry': dict(Counter(local(e) for e in node.iter() if local(e) in ['Point', 'LineString', 'Polygon', 'LinearRing']))})
    for child in node:
        if local(child) in ['Document', 'Folder', 'Placemark']:
            walk(child, path, effective and visible)
walk(tree)

coords = [[float(v) for v in token.split(',')] for e in tree.findall('.//k:coordinates', ns) for token in (e.text or '').split()]
rings = [[tuple(float(v) for v in token.split(',')) for token in text(e, 'coordinates').split()] for e in tree.findall('.//k:LinearRing', ns)]
result = {'at_utc': datetime.now(timezone.utc).isoformat(), 'observation': 'root reports actual new forecast tab10 UI added two artificial region files, +30/+60 children, hid parent A while showing children and B, then saved all four candidates and regions', 'source': str(source), 'copy': str(output), 'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'copy_identical': data == output.read_bytes(), 'xml_parse': True, 'counts': dict(sorted(Counter(local(e) for e in tree.iter()).items())), 'folders': folders, 'placemarks': placemarks, 'coordinate_tuples': len(coords), 'numeric_lon_lat_range_valid': all(len(c) in (2, 3) and -180 <= c[0] <= 180 and -90 <= c[1] <= 90 for c in coords), 'linear_ring_count': len(rings), 'all_rings_explicitly_closed': all(len(r) >= 4 and r[0] == r[-1] for r in rings), 'limits': ['Own/effective visibility is computed from raw XML; it is not inferred from Cesium entity.show.', 'Physical original remains unchanged. Root observes UI and separate reader.', 'Not Google Earth rendering or scientific acceptance.']}
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key not in ['placemarks']}, ensure_ascii=False, indent=2))
