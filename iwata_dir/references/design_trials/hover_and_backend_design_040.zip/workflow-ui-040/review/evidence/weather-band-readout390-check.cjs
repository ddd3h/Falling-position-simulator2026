// Independent counterexamples: source functions only, no browser/API/network.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const base=path.resolve(__dirname,'../release/workflow-ui-039/source/cesium-probe/src'),out=path.join(__dirname,'weather-band-readout390-evidence');fs.mkdirSync(out,{recursive:true});
const source=fs.readFileSync(path.join(base,'band-readout.js'),'utf8'),main=fs.readFileSync(path.join(base,'main.js'),'utf8');
const context={console};vm.createContext(context);vm.runInContext(source.replaceAll('export ',''),context);
const read=(p,x,o)=>context.readBand(p,x,o);
const ring=r=>[[141-r,43-r],[141+r,43-r],[141+r,43+r],[141-r,43+r],[141-r,43-r]];
const band=(level,lower,r,inner)=>({type:'Feature',properties:{kind:'contour-band',candidateId:'A',resultId:'rA',level,lowerLevel:lower},geometry:{type:'Polygon',coordinates:[ring(r),...(inner?[ring(inner).reverse()]:[])]}});
const payload={snapshotId:'displayed-A',context:{kind:'overview'},candidates:[{candidateId:'A',resultId:'rA',label:'A',focused:true,visible:true,available:true}],geojson:{type:'FeatureCollection',features:[band(.5,0,.01),band(.9,.5,.02,.01),band(.95,.9,.03,.02),{type:'Feature',properties:{kind:'region',levelName:'topmost-zone'},geometry:{type:'Polygon',coordinates:[ring(.1)]}}]}};
const checks=[];function check(test,label){assert.ok(test,label);checks.push(label);}
check(read(payload,[141,43]).level===.5,'center belongs to inner band even with topmost forbidden region');
check(read(payload,[141.015,43]).level===.9,'outside 50 hole and inside 90 belongs to 50-90 band');
check(read(payload,[141.025,43]).level===.95,'outside 90 hole belongs to 90-95 band');
check(JSON.stringify(read(payload,[141.01,43]).levels)==='[0.5]','shared 50 boundary reported once rather than two bands');
check(JSON.stringify(read(payload,[141.02,43]).levels)==='[0.9]','shared 90 boundary reported once');
const no50=structuredClone(payload);no50.geojson.features=no50.geojson.features.filter(f=>f.properties.level!==.5);
check(read(no50,[141,43]).kind==='not-displayed','hole remains excluded when 50 is hidden');
check(read(no50,[141.01,43]).kind==='boundary','hidden 50 outer line remains geometric boundary of 90 band hole');
check(read(payload,[141.04,43]).kind==='outside95','95 outside only if an actual outer 95 ring exists');
const no95=structuredClone(payload);no95.geojson.features=no95.geojson.features.filter(f=>f.properties.level!==.95);check(read(no95,[141.04,43]).kind==='not-displayed','missing 95 never invents outside95 conclusion');
check(read(payload,null).kind==='unavailable','unknown surface position never becomes outside95');
check(read(payload,[141,43],{bandsVisible:false}).text.includes('面の表示はOFF'),'local fill-off remains explicit while reading the same contour subdivision');

const elements={};const el=id=>elements[id]??={textContent:'',checked:true};let pickCalls=0,heightCalls=0,exclusions=[];let picked={longitude:141.015,latitude:43},height=100;
context.elements=elements;context.$=el;context.diag={};context.payload=payload;context.renderedPayload=payload;context.tileset={};context.presentationError=null;context.readoutMarker={id:'old-mark'};context.overlayStore={pickExclusions:[{id:'current-analysis'},{id:'previous-analysis'}]};
context.C={Cartesian2:function(x,y){Object.assign(this,{x,y});},Cartographic:{fromCartesian:x=>x},Cartesian3:{fromRadians:(lon,lat,h)=>({lon,lat,h})},Math:{toDegrees:x=>x},Color:{WHITE:'white',BLACK:'black'},HeightReference:{CLAMP_TO_3D_TILE:'mesh'}};
context.viewer={scene:{canvas:{getBoundingClientRect:()=>({left:10,top:20})},pickPositionSupported:true,sampleHeightSupported:true,pickPosition(){pickCalls++;return picked;},sampleHeight(p,excluded){heightCalls++;exclusions=excluded.map(x=>x.id);return height;},requestRender(){}},entities:{remove(){},add:o=>o}};
vm.runInContext(main.slice(main.indexOf('function clearReadout('),main.indexOf('const clicks=createClickTracker()')),context);
context.inspectSurface({clientX:30,clientY:50});check(context.diag.surfaceReadout.level===.9,'actual inspectSurface uses rendered A bands');check(exclusions.includes('current-analysis')&&exclusions.includes('previous-analysis')&&exclusions.includes('old-mark'),'height query excludes current and old overlays plus previous inspection mark');
height=undefined;context.inspectSurface({clientX:30,clientY:50});check(context.diag.surfaceReadout===null&&el('bandReadout').textContent.includes('帯の外とは判定しません'),'failed mesh height clears prior result instead of outside answer');height=100;
context.payload={...payload,snapshotId:'received-B',candidates:[{...payload.candidates[0],candidateId:'B'}]};context.presentationError='rollback';context.inspectSurface({clientX:30,clientY:50});check(context.diag.surfaceReadout.candidateId==='A'&&context.diag.surfaceReadout.renderedSnapshotId==='displayed-A'&&context.diag.surfaceReadout.acceptedSnapshotId==='received-B'&&el('bandReadout').textContent.startsWith('旧表示の読取り'),'rollback reads old visible candidate A with explicit prefix while B is accepted');
context.presentationError=null;const before=pickCalls;context.inspectSurface({clientX:30,clientY:50});check(pickCalls===before&&el('bandReadout').textContent.includes('更新中'),'new payload preparation blocks surface query against stale view');
context.payload=payload;context.renderedPayload={...payload,context:{kind:'detail'}};context.inspectSurface({clientX:30,clientY:50});check(pickCalls===before&&el('bandReadout').textContent.includes('詳細'),'detail refuses whole-population band lookup before any surface query');

const event=(extra={})=>({button:0,pointerId:1,clientX:10,clientY:10,ctrlKey:false,shiftKey:false,altKey:false,metaKey:false,...extra});
const clicks=context.createClickTracker();clicks.start(event(),0);clicks.move(event({clientX:25}));check(!clicks.end(event(),100),'drag returning to initial point is not a click');
clicks.start(event({button:2}),0);check(!clicks.end(event({button:2}),100),'right-drag channel is not a lookup');
clicks.start(event(),0);const changedModifier=clicks.end(event({ctrlKey:true}),100);
const report={checks,passed:checks.length,scope:'pure source functions + synthetic Cartesian/scene mock, no Cesium depth or browser acceptance',finding:{modifierPressedAfterDown:{observedLookup:changedModifier,expectedLookup:false}},calls:{pickCalls,heightCalls},sha256:{band:crypto.createHash('sha256').update(source).digest('hex'),main:crypto.createHash('sha256').update(main).digest('hex')}};
fs.writeFileSync(path.join(out,'checks-before.json'),JSON.stringify(report,null,2));fs.writeFileSync(path.join(out,'band-readout-before.js.txt'),source);console.log(JSON.stringify(report,null,2));
