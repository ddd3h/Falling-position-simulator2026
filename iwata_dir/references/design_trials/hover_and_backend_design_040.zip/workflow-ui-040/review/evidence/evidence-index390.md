# 0.39 証拠の入口と保存目録

基準は PR26 統合済み main M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`。この目録は未統合候補に証拠を収録した時点のもので、Git保存・main統合を証明しません。コピー時には試験・Google通信・ブラウザー操作を行っていません。

## 最初に読むもの

- [保存経路の調査](weather-download-path390.md)：旧タブ未到達を残し、新タブの実UI→物理ファイル→XML構造→独立reader表示までの有限確認を読む。
- [独立の対象/表示反例](weather-cross-components390.md)と[帯クリック反例](weather-band-readout390.md)：同じ対象を表示・説明・保存へ渡せるかを、失敗から修復まで追う。
- [KML readerの限界](weather-kml-review.md)：raw XMLのown visibility、SDKの焼込み、人工楕円体、Google Earth未確認を区別する。
- [r8詳細カード](scene-implementation390-r8.md)：概要の表示操作を詳細へ誤持込みした問題と、主担当の同一接続観察の帰属を読む。
- 最終の主担当実観察は root が別途収録する `root-design390.md` とrepo S34へ戻る。未コピー時は、この目録から受入済みと補わない。

## 何を区別して読むか

| 証拠 | 確認した範囲 | ここからは言えないこと |
|---|---|---|
| source/assert/mock | 指定入力と該当版の変換、境界、rollback、表示状態 | 写真の読みやすさ、depth位置精度、科学的正しさ |
| 人工3D・独立reader | 指定場面のWebGL表示と操作を主担当が観察 | Google Earth・実地形高度・あらゆるLOD/端末 |
| 実Google観察 | 主担当が同じ接続上で操作した有限場面 | 請求回数、屋根/樹冠の一般的精度、科学的干渉 |
| 実DownloadsのJSON/KML | 実UIから到達した実ファイルと複製・構造 | 旧失敗タブの復旧、全ブラウザ保存保証 |
| 再生成receipt | 固定依存から別作業コピーを生成して指紋一致 | 新規依存取得・配布全環境・物理モデル採用 |

`forecast-source390/` のKMLは人工生成fixtureで、`download390-evidence/` は実UI保存ファイルです。混同しません。初回167条件の `scene-rebuild390-final.*` と、後続r8の179条件 `scene-rebuild390-r8.*` を同じ時点にしません。r2 failureは半透明color期待値の誤り、初回EPERMは起動失敗であり、両方とも別の失敗として保持します。

## 再現の入口と実行禁止の履歴

通常の再現は [source/reproduction390.md](../../source/reproduction390.md) を読み、別のコピーで行ってください。証拠の試験スクリプトは作業時の絶対パスや前後のsourceに依存し、そのまま任意フォルダーで動く汎用テストではありません。

**`finalize-scene-source390.mjs`、`resume-scene-rebuild390.mjs`、`scene-r8-finalize.mjs` は一回限りの保存実績を監査する資料で、通常再現対象ではなく再実行禁止です。** とくに最初のhelperは既存workRootを拒否してもcatchでreceiptを上書きし得ます。今回これらを実行していません。失敗・成功票を上書きしてはいけません。[経緯](scene-rebuild390-final.md)と[独立指摘](weather-final-provenance390.md)を参照してください。

## 原要求と画像

[提供PDF原本](../inputs/feedback_v_0_38_0.pdf)、[抽出本文](../inputs/feedback_v_0_38_0.txt)、[1頁](../inputs/pages/page-1.png)・[2頁](../inputs/pages/page-2.png)・[3頁](../inputs/pages/page-3.png)・[4頁](../inputs/pages/page-4.png)を保存しました。抽出textだけでは図と注記の位置関係を代替できないため、4頁画像も保持します。資料内の文は現在の操作許可として扱いません。

新収録画像は人工3D2枚と原風資料の3頁抜粋、および提供PDFの4頁です。Google画面・Googleタイル・HAR・node_modules・鍵は収録対象にしていません。テキストの鍵形状パターン検査は漏えいの一般保証ではありません。

## ファイル目録

以下は今回コピーしたファイルです。原本からバイト変更せず、全SHA-256は [evidence-files390.json](evidence-files390.json) に保存しています。短縮指紋は識別用です。ローカル作業receiptは `P390/metadata/evidence-stage390.json`。旧0.38資料と既存の実UI SVG前後2点は今回のコピーとは別に、末尾の保持一覧へ分けます。
### 要求と問いの再構成（9ファイル）

初巡の独立解釈、原風資料の読取、採否前の反例を保持。 **限界：** この設計レビューは実装・科学採用の完了を示さない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [design-round1-forecast.md](design-round1-forecast.md) | 23175 | `16a571b672f4` |
| [design-round1-scene-evidence.json](design-round1-scene-evidence.json) | 4701 | `d284d3fe26b8` |
| [design-round1-scene.md](design-round1-scene.md) | 26020 | `35d0f4926d2b` |
| [design-round1-weather.md](design-round1-weather.md) | 16213 | `b567cd94ba5f` |
| [weather-evidence/meaning-counterexamples390.cjs](weather-evidence/meaning-counterexamples390.cjs) | 2250 | `cd289c984d8f` |
| [weather-evidence/meaning-counterexamples390.json](weather-evidence/meaning-counterexamples390.json) | 3023 | `acfb5a646c61` |
| [weather-evidence/wind-page-12.png](weather-evidence/wind-page-12.png) | 246494 | `bf7aa1f75593` |
| [weather-evidence/wind-page-35.png](weather-evidence/wind-page-35.png) | 106385 | `0c6a905d7d46` |
| [weather-evidence/wind-page-37.png](weather-evidence/wind-page-37.png) | 141663 | `727a9b5a4462` |

### 2D・KMLの実装と人工出力（18ファイル）

全目録と可視性、色・帯・相別経路、32条件のsource検査と人工KMLの比較。 **限界：** ここにある生成fixtureを、UIの物理ダウンロードやGoogle Earth表示の証拠にしない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [curtain-material390-hashes.json](curtain-material390-hashes.json) | 1292 | `98048f669f8e` |
| [curtain-material390.md](curtain-material390.md) | 3874 | `8da4f5634276` |
| [design-round2-forecast.md](design-round2-forecast.md) | 3603 | `60db7e8b6579` |
| [forecast-implementation390-round1.md](forecast-implementation390-round1.md) | 12599 | `e6f80d17d596` |
| [forecast-source-check390.cjs](forecast-source-check390.cjs) | 10571 | `89fb6075d3a7` |
| [forecast-source390/checks.json](forecast-source390/checks.json) | 1940 | `2fb3b217f5e6` |
| [forecast-source390/curtain-alpha-14-comparison.kml](forecast-source390/curtain-alpha-14-comparison.kml) | 272860 | `1824417657cd` |
| [forecast-source390/curtain-alpha-22-comparison.kml](forecast-source390/curtain-alpha-22-comparison.kml) | 272860 | `a835610b8133` |
| [forecast-source390/overview-default4-two-sets.kml](forecast-source390/overview-default4-two-sets.kml) | 381076 | `c05c1c9e74e5` |
| [forecast-source390/overview-inventory-final.json](forecast-source390/overview-inventory-final.json) | 417996 | `c22046a1778a` |
| [forecast-source390/overview-inventory.json](forecast-source390/overview-inventory.json) | 416988 | `22e33fade256` |
| [forecast-source390/overview-parent-hidden-final.kml](forecast-source390/overview-parent-hidden-final.kml) | 276560 | `6c7faa5f482f` |
| [forecast-source390/overview-parent-hidden.kml](forecast-source390/overview-parent-hidden.kml) | 273621 | `2400cde2b509` |
| [forecast-source390/regions.kml](forecast-source390/regions.kml) | 2818 | `ecab80ef8bf3` |
| [forecast-source390/scene-snapshot-final.json](forecast-source390/scene-snapshot-final.json) | 143279 | `77be6cf9b6d7` |
| [forecast-source390/scene-snapshot.json](forecast-source390/scene-snapshot.json) | 143050 | `a6b67da6c910` |
| [forecast-stage390-download-final.json](forecast-stage390-download-final.json) | 1423 | `818c9d8d0b70` |
| [forecast-stage390-manifest.json](forecast-stage390-manifest.json) | 1174 | `97ce524c116d` |

### 来向円環・無風・保存SVG（9ファイル）

向き未定義の反例、31条件から33条件への追加確認、人工SVGと自然寸法修復。 **限界：** 実気象・科学的な風向推定の検証ではない。実UI保存SVGは既存2ファイルを別途保持。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [weather-round2-annual.svg](weather-round2-annual.svg) | 1175423 | `2fbc5a4b35a5` |
| [weather-round2-check.cjs](weather-round2-check.cjs) | 8213 | `e6a54ba3f6bf` |
| [weather-round2-check.json](weather-round2-check.json) | 4917 | `6a5381a875b6` |
| [weather-round2-counterexamples.svg](weather-round2-counterexamples.svg) | 625302 | `dd1105175975` |
| [weather-round2.md](weather-round2.md) | 4941 | `9e4dbe4b0d5c` |
| [weather-svg-intrinsic-annual.svg](weather-svg-intrinsic-annual.svg) | 1175453 | `b72bec491c6a` |
| [weather-svg-intrinsic-check.cjs](weather-svg-intrinsic-check.cjs) | 813 | `e83eb63c6838` |
| [weather-svg-intrinsic-check.json](weather-svg-intrinsic-check.json) | 5120 | `897a0a18dd61` |
| [weather-svg-intrinsic-counterexamples.svg](weather-svg-intrinsic-counterexamples.svg) | 625332 | `d4edee98e30b` |

### 3Dの状態・表示・詳細カード（25ファイル）

各版のsource検査とr8詳細カードの前後、人工runtime観察を保持。 **限界：** 167条件と179条件は別時点。キーなしsource成功だけで実Googleの用途受入としない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [detail-catalog-critic390.md](detail-catalog-critic390.md) | 6421 | `0a2b82c025bb` |
| [detail-catalog390-r8-after.json](detail-catalog390-r8-after.json) | 1570 | `a8fe63bf9224` |
| [detail-catalog390-r8-before.json](detail-catalog390-r8-before.json) | 1577 | `591e86ec366e` |
| [detail-catalog390-r8-counterexample.mjs](detail-catalog390-r8-counterexample.mjs) | 4310 | `3eead3f607a2` |
| [scene-implementation390-r8.md](scene-implementation390-r8.md) | 4424 | `45791f79585b` |
| [scene-implementation390-round1.md](scene-implementation390-round1.md) | 12302 | `58a8a28dcbcb` |
| [scene-r8-before/README.md](scene-r8-before/README.md) | 8711 | `cf4ba0012753` |
| [scene-r8-before/source-inventory.json](scene-r8-before/source-inventory.json) | 8171 | `16154bc58c52` |
| [scene-r8-before/src/catalog.js](scene-r8-before/src/catalog.js) | 3810 | `7fba481dbd02` |
| [scene-r8-before/test.mjs](scene-r8-before/test.mjs) | 16079 | `f2374b658485` |
| [scene-runtime390-r1/observed.json](scene-runtime390-r1/observed.json) | 2122 | `448fcc9e75e0` |
| [scene-runtime390-r2/01-synthetic.png](scene-runtime390-r2/01-synthetic.png) | 99565 | `67c3135cffa1` |
| [scene-runtime390-r2/02-failed-update-kept.png](scene-runtime390-r2/02-failed-update-kept.png) | 129701 | `b0f6a085bef0` |
| [scene-runtime390-r2/observed.json](scene-runtime390-r2/observed.json) | 626 | `968a88052474` |
| [scene-stage390-r6.json](scene-stage390-r6.json) | 3099 | `509458544964` |
| [scene-stage390-r7.json](scene-stage390-r7.json) | 3224 | `7e9ec9b85fda` |
| [scene-stage390-r8-before.json](scene-stage390-r8-before.json) | 80941 | `bd682c82962a` |
| [scene-unit390-r1.json](scene-unit390-r1.json) | 342 | `fa0eba82bf64` |
| [scene-unit390-r2-failure.json](scene-unit390-r2-failure.json) | 290 | `c91fc26ad36f` |
| [scene-unit390-r3.json](scene-unit390-r3.json) | 342 | `29de1164d225` |
| [scene-unit390-r4.json](scene-unit390-r4.json) | 342 | `cdde6fe2a4d2` |
| [scene-unit390-r5.json](scene-unit390-r5.json) | 342 | `b644892a7fa5` |
| [scene-unit390-r6.json](scene-unit390-r6.json) | 416 | `176fa09dc39f` |
| [scene-unit390-r7.json](scene-unit390-r7.json) | 416 | `5b2f4c0bf64a` |
| [scene-unit390-r8.json](scene-unit390-r8.json) | 556 | `7dbb32c02fdb` |

### 別場面からの独立反証（14ファイル）

rollback旧図形/新説明の混在、帯とクリックの反例、修復前後の21条件を追える。 **限界：** source/mock反例は実mesh depth・斜視の位置取得精度を保証しない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [weather-band-readout390-check.cjs](weather-band-readout390-check.cjs) | 6824 | `0a927e1ee4a9` |
| [weather-band-readout390-evidence/band-readout-after.js.txt](weather-band-readout390-evidence/band-readout-after.js.txt) | 4259 | `1d110c67ffd9` |
| [weather-band-readout390-evidence/band-readout-before.js.txt](weather-band-readout390-evidence/band-readout-before.js.txt) | 4191 | `d6d434216827` |
| [weather-band-readout390-evidence/checks-after.json](weather-band-readout390-evidence/checks-after.json) | 1813 | `a04de3cdd7ee` |
| [weather-band-readout390-evidence/checks-before.json](weather-band-readout390-evidence/checks-before.json) | 1681 | `880c7d3482b8` |
| [weather-band-readout390-recheck.cjs](weather-band-readout390-recheck.cjs) | 7061 | `d1033f37e3a8` |
| [weather-band-readout390.md](weather-band-readout390.md) | 5656 | `3309190781f6` |
| [weather-cross-components390.md](weather-cross-components390.md) | 11777 | `21c6531035e0` |
| [weather-cross390-counterexamples.cjs](weather-cross390-counterexamples.cjs) | 5446 | `039748001eed` |
| [weather-cross390-evidence/counterexamples-after.json](weather-cross390-evidence/counterexamples-after.json) | 5068 | `a05a4018c34a` |
| [weather-cross390-evidence/counterexamples-before.json](weather-cross390-evidence/counterexamples-before.json) | 4819 | `37c28866064c` |
| [weather-cross390-evidence/main-after-read.js.txt](weather-cross390-evidence/main-after-read.js.txt) | 22677 | `29444c439501` |
| [weather-cross390-evidence/main-before-read.js.txt](weather-cross390-evidence/main-before-read.js.txt) | 21168 | `ca80287b9a80` |
| [weather-cross390-recheck.cjs](weather-cross390-recheck.cjs) | 5830 | `b1be5f928633` |

### 再生成・指紋・実行失敗（16ファイル）

初回EPERMと後続再生成、r8の別作業コピー、source/runtime指紋を保持。 **限界：** 固定依存からの再生成であり、新規環境の依存取得や全端末動作の検証ではない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [finalize-scene-source390.mjs](finalize-scene-source390.mjs) | 9124 | `e06f215aa1ab` |
| [resume-scene-rebuild390.mjs](resume-scene-rebuild390.mjs) | 5185 | `d454c66af97b` |
| [scene-r8-finalize.mjs](scene-r8-finalize.mjs) | 8162 | `77d730834db1` |
| [scene-rebuild390-build.log](scene-rebuild390-build.log) | 140 | `441ab3d35a12` |
| [scene-rebuild390-final.json](scene-rebuild390-final.json) | 90601 | `31e04a3c2805` |
| [scene-rebuild390-final.md](scene-rebuild390-final.md) | 2992 | `e0c09dcc1f6d` |
| [scene-rebuild390-initial-launch-failure.json](scene-rebuild390-initial-launch-failure.json) | 88001 | `19b535a5a0d8` |
| [scene-rebuild390-make-fixture.log](scene-rebuild390-make-fixture.log) | 91 | `e0f86ada9417` |
| [scene-rebuild390-r8-build.log](scene-rebuild390-r8-build.log) | 143 | `a84d83108382` |
| [scene-rebuild390-r8-make-fixture.log](scene-rebuild390-r8-make-fixture.log) | 91 | `e0f86ada9417` |
| [scene-rebuild390-r8-test.log](scene-rebuild390-r8-test.log) | 551 | `4589c90c6c8f` |
| [scene-rebuild390-r8.json](scene-rebuild390-r8.json) | 5855 | `87786461816f` |
| [scene-rebuild390-test-initial-launch-failure.log](scene-rebuild390-test-initial-launch-failure.log) | 125 | `d6aaa0ffa431` |
| [scene-rebuild390-test.json](scene-rebuild390-test.json) | 416 | `5b2f4c0bf64a` |
| [scene-rebuild390-test.log](scene-rebuild390-test.log) | 411 | `72ac6a72703a` |
| [source-inventory390-from038.json](source-inventory390-from038.json) | 7560 | `c01c4bcd5104` |

### 実UI保存とファイル到達（9ファイル）

新IABタブのJSON/KML実ファイル、原本との一致、XML目録/初期可視性を保存。 **限界：** 旧タブ未到達の内部原因は未特定。表示成功の帰属はroot、XML構造確認はweather担当。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [download390-evidence/balloon-A-r1.json](download390-evidence/balloon-A-r1.json) | 747 | `14e081006d08` |
| [download390-evidence/balloon-analysis-039-expanded.kml](download390-evidence/balloon-analysis-039-expanded.kml) | 381012 | `6d985ec16038` |
| [download390-evidence/balloon-analysis-039.kml](download390-evidence/balloon-analysis-039.kml) | 133470 | `3bf09c180180` |
| [download390-evidence/physical-download390-expanded.json](download390-evidence/physical-download390-expanded.json) | 144295 | `60e591e6eb66` |
| [download390-evidence/physical-download390-first.json](download390-evidence/physical-download390-first.json) | 3888 | `fe43dc6da444` |
| [inspect-download390-expanded.py](inspect-download390-expanded.py) | 3631 | `575f9841baa9` |
| [inspect-download390.py](inspect-download390.py) | 3823 | `e9ef080a7a3a` |
| [weather-download-path390.md](weather-download-path390.md) | 10276 | `32bd3a8caf68` |
| [weather-download-probe390-syntax.js](weather-download-probe390-syntax.js) | 2694 | `0cc19624a65b` |

### 入口・読込器・記録の批評（4ファイル）

文書の時制・確認範囲、Cesium KML readerの限界を独立に点検した記録。 **限界：** 後続本文や全依存の読了を、この限定票から推定しない。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [weather-body-critique390-limited.md](weather-body-critique390-limited.md) | 2855 | `e605709e0d70` |
| [weather-entry-critique390.md](weather-entry-critique390.md) | 6783 | `06b04a2566c5` |
| [weather-final-provenance390.md](weather-final-provenance390.md) | 7928 | `802c48891602` |
| [weather-kml-review.md](weather-kml-review.md) | 10541 | `4760ab5f5ea7` |

### 後続hover案・未実装（1ファイル）

名称識別とクリック帯区分を分ける目的、責務、反例候補を保持。 **限界：** 今回の実装・実観察の結果ではない。次host更新時の採用候補。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [hover-label-design390.md](hover-label-design390.md) | 9109 | `bea7155cea8a` |

### 提供入力（6ファイル）

原PDF/text/4頁画像は同じバイトで保存。科学的真値や操作命令として受入した意味ではありません。

| ファイル | bytes | SHA-256先頭12桁 |
|---|---:|---|
| [../inputs/feedback_v_0_38_0.pdf](../inputs/feedback_v_0_38_0.pdf) | 870248 | `af8228f0ce1f` |
| [../inputs/feedback_v_0_38_0.txt](../inputs/feedback_v_0_38_0.txt) | 4292 | `736a01f12295` |
| [../inputs/pages/page-1.png](../inputs/pages/page-1.png) | 290915 | `8141f7bcd91b` |
| [../inputs/pages/page-2.png](../inputs/pages/page-2.png) | 634129 | `cd8281952bd6` |
| [../inputs/pages/page-3.png](../inputs/pages/page-3.png) | 579150 | `0ca5249c0f72` |
| [../inputs/pages/page-4.png](../inputs/pages/page-4.png) | 36217 | `ccf8b61602a2` |

### 既存保持（34ファイル、全バイト不変）

0.38当時の記録を今回の検証へ読み替えません。`weather-annual-039-ui-save.svg` と `-fixed.svg` は既に主担当が保存した0.39実UI SVGの修復前後で、今回も保持しています。

- [cesium-implementation380.md](cesium-implementation380.md) — `62830ef1c8e2`
- [cesium-rebuild380-before-displayrefine.json](cesium-rebuild380-before-displayrefine.json) — `9b8dea8fe79b`
- [cesium-rebuild380-before-fixturefix.json](cesium-rebuild380-before-fixturefix.json) — `d9912344134f`
- [cesium-rebuild380.json](cesium-rebuild380.json) — `fe648ffc064c`
- [cesium-source-final380.json](cesium-source-final380.json) — `1026f3ea3b0d`
- [cesium-unit380-displayrefine.json](cesium-unit380-displayrefine.json) — `2923589b7c1c`
- [cesium-unit380-final.json](cesium-unit380-final.json) — `f5a1c1637034`
- [cesium-unit380-fixturefix.json](cesium-unit380-fixturefix.json) — `1b3fbeeef65f`
- [cesium-unit380.json](cesium-unit380.json) — `f5a1c1637034`
- [connection-critic380.md](connection-critic380.md) — `5ebbb82dcc46`
- [dependency-review380-forecast.md](dependency-review380-forecast.md) — `76ecbea0c76c`
- [document-critique380-weather.md](document-critique380-weather.md) — `5924cfb6e419`
- [document-review380.md](document-review380.md) — `d1fb29b07666`
- [google3d-connection-review380.md](google3d-connection-review380.md) — `4222514221d4`
- [halo-view-critic380.md](halo-view-critic380.md) — `c1367c7ff46f`
- [inspect380-line-ending-anomaly.json](inspect380-line-ending-anomaly.json) — `23e125affe74`
- [inspection-ui-review380.md](inspection-ui-review380.md) — `4542a005d728`
- [layout-state-critic380-google-mock.json](layout-state-critic380-google-mock.json) — `fd3580ee525c`
- [layout-state-critic380-run.mjs](layout-state-critic380-run.mjs) — `f579e29e681e`
- [layout-state-critic380-synthetic.json](layout-state-critic380-synthetic.json) — `411492ef0985`
- [layout-state-critic380.md](layout-state-critic380.md) — `cdf2d42d5d39`
- [new-inputs380.md](new-inputs380.md) — `acc7b58111b4`
- [prepare-layout-state-critic380.mjs](prepare-layout-state-critic380.mjs) — `9daed3f0787e`
- [purpose-critic380-round2.md](purpose-critic380-round2.md) — `5aace5ee1d97`
- [request-budget-critic380.md](request-budget-critic380.md) — `1866813abd54`
- [request-budget-mock380-before-gate.json](request-budget-mock380-before-gate.json) — `77228cf9f0f1`
- [request-budget-mock380.json](request-budget-mock380.json) — `65e542080529`
- [request-budget-mock380.mjs](request-budget-mock380.mjs) — `327373dfe8f0`
- [root-live-observation380.md](root-live-observation380.md) — `8b52a179d57e`
- [view-memory-critic380-initial.json](view-memory-critic380-initial.json) — `4e5a848f07a0`
- [view-memory-critic380-recheck.json](view-memory-critic380-recheck.json) — `f630e62ac5dc`
- [view-memory-critic380.mjs](view-memory-critic380.mjs) — `115974a6899b`
- [weather-annual-039-ui-save-fixed.svg](weather-annual-039-ui-save-fixed.svg) — `f58929520f33`
- [weather-annual-039-ui-save.svg](weather-annual-039-ui-save.svg) — `2f82fd4667ce`

## この収録作業の境界

root-design390.md、入口index/README、repo本文、ZIP、Gitは本担当の変更対象外です。これらは主担当が別途確定します。この目録とコピーは証拠の保存作業であり、掲載された全試験を再実行・再受入したという意味ではありません。

## 最終続報の追加（1ファイル）

[weather-final-body390.md](weather-final-body390.md) は、現repo VISION workflow390/D178/CTX§1・67と配布README/review入口の続報だけを再読した限定票です。形の誤記と旧保存未到達の固定は修正済みで、hover未実装・有限観察・旧失敗保持の区別に残る阻害事項は見つかりませんでした。全旧本文、全リンク、実Google再操作、ZIP/Gitの受入ではありません。

追加ファイル 3872 bytes、SHA-256 `19eca70abe18b3b36eefab09ca5dcbca7fc25dbd85d4875fe291a2d845db6199`。上のカテゴリ表と111件の初回収録はその時点の目録として維持し、この1件を加えたコピー総数は112件です。主担当のroot-design390.mdは引き続き別担当の収録対象です。
