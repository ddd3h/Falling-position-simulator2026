import {cp,mkdir,readFile,writeFile,readdir,copyFile,symlink,lstat} from 'node:fs/promises';
import {constants} from 'node:fs';
import {join,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const P='C:/Users/genia/AppData/Local/Temp/balloon-design-390',S=join(P,'release/workflow-ui-039/source/cesium-probe'),R=join(P,'release/workflow-ui-039/scene3d'),E=join(P,'reviews'),BEFORE=join(E,'scene-r8-before');
const W=join(P,'rebuild390-r8'),WS=join(W,'source/cesium-probe'),WR=join(W,'scene3d'),DEPS='C:/Users/genia/AppData/Local/Temp/balloon-design-380/cesium-probe/node_modules';
const hash=b=>createHash('sha256').update(b).digest('hex');
async function inventory(root,exclude=[]){const files=[];async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name),path=relative(root,p).replaceAll('\\','/');if(exclude.includes(path))continue;if(e.isDirectory())await walk(p);else if(e.isFile()){const b=await readFile(p);files.push({path,bytes:b.length,sha256:hash(b)});}else throw new Error(`Unexpected non-file: ${path}`);}}await walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));return files;}
function diff(a,b){const am=new Map(a.map(f=>[f.path,f])),bm=new Map(b.map(f=>[f.path,f]));return [...new Set([...am.keys(),...bm.keys()])].sort().flatMap(path=>{const before=am.get(path),after=bm.get(path);return before?.bytes===after?.bytes&&before?.sha256===after?.sha256?[]:[{path,before:before??null,after:after??null}];});}
async function fresh(path){try{await lstat(path);throw new Error(`Path already exists: ${path}`);}catch(e){if(e.code!=='ENOENT')throw e;}}
if(process.argv[2]==='prepare'){
 await fresh(BEFORE);await mkdir(BEFORE,{recursive:true});
 for(const file of ['source-inventory.json','README.md','src/catalog.js','test.mjs']){await mkdir(join(BEFORE,file,'..'),{recursive:true});await copyFile(join(S,file),join(BEFORE,file),constants.COPYFILE_EXCL);}
 const before={at:new Date().toISOString(),source:await inventory(S),runtime:await inventory(R)};
 await writeFile(join(E,'scene-stage390-r8-before.json'),JSON.stringify(before,null,2)+'\n');
 console.log(JSON.stringify({prepared:true,sourceFiles:before.source.length,runtimeFiles:before.runtime.length,preserved:BEFORE}));
}else if(process.argv[2]==='rebuild'){
 const out=join(E,'scene-rebuild390-r8.json');await fresh(out);await fresh(W);
 const before=JSON.parse(await readFile(join(E,'scene-stage390-r8-before.json'),'utf8'));
 const receipt={stage:'0.39 r8 detail static card',startedAt:new Date().toISOString(),source:S,runtime:R,workSource:WS,workRuntime:WR,node:process.version,dependencies:DEPS,googleNetwork:false,browser:false,commands:[],pass:false};
 async function run(file,args=[]){const r=spawnSync(process.execPath,[file,...args],{cwd:WS,env:{...process.env,BJP_CESIUM_DEPENDENCIES:DEPS},encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024});const log=join(E,`scene-rebuild390-r8-${file.replace(/\.mjs$/,'')}.log`);await writeFile(log,`exit=${r.status}\nsignal=${r.signal??''}\n${r.stdout??''}\n${r.stderr??''}${r.error?`\n${r.error.message}`:''}`);receipt.commands.push({file,args,exitCode:r.status,log});if(r.status!==0)throw new Error(`${file} failed; see ${log}`);}
 try{
  if(JSON.parse(await readFile(join(DEPS,'cesium/package.json'),'utf8')).version!=='1.145.0')throw new Error('Dependency version differs');
  await mkdir(join(W,'source'),{recursive:true});await cp(S,WS,{recursive:true,errorOnExist:true,force:false});await symlink(DEPS,join(WS,'node_modules'),'junction');
  await run('test.mjs',[join(E,'scene-unit390-r8.json')]);
  receipt.tests=JSON.parse(await readFile(join(E,'scene-unit390-r8.json'),'utf8'));
  const readme=await readFile(join(S,'README.md'),'utf8'),marker='## 詳細カードの修復（r8）';if(readme.includes(marker))throw new Error('README r8 note already exists');
  await writeFile(join(S,'README.md'),readme.trimEnd()+`\n\n${marker}\n\n主担当の同一Google接続での批評を受け、詳細欄を操作のない対象カードへ変更した。概要用の可視チェックとdisabled候補ボタンを外し、候補色・full label・選択 n/N 着地点を示す。選択0を保持し、pendingは前回結果であることを伝える。概要の可視操作、注目、bandLegend、geometry、main/provider/HTML/CSSは変更していない。\n\n第8票 scene-unit390-r8.json は${receipt.tests.checks}条件成功。概要の可視状態に左右されない詳細表現、0/少数選択、遅延子の名前、pending、操作callbackなし、受領payload不変を追加確認した。これはキーなしsource検査であり、修復後のGoogle実画面は主担当の後続観察へ帰属する。catalog.jsは「表示だけ更新」の対象で、既存host/providerの再読込を必要としない。\n\nr8変更前のsource/runtime指紋と旧inventoryは reviews/scene-stage390-r8-before.json と reviews/scene-r8-before/ に保持。新しい独立作業コピー rebuild390-r8/ の再生成・byte照合は reviews/scene-rebuild390-r8.json へ記録し、前回scene-rebuild390-final.jsonを上書きしない。\n`);
  const sourceFiles=await inventory(S,['source-inventory.json']);const inv=JSON.stringify({engine:'cesium@1.145.0',files:sourceFiles},null,2)+'\n';await writeFile(join(S,'source-inventory.json'),inv);
  for(const file of ['README.md','source-inventory.json'])await copyFile(join(S,file),join(WS,file));
  await run('make-fixture.mjs');await run('build.mjs');
  const generated=await inventory(WR),current=await inventory(R);receipt.generatedRuntimeChanges=diff(current,generated);
  if(receipt.generatedRuntimeChanges.some(f=>!['src/catalog.js','build-inventory.json'].includes(f.path)))throw new Error('Generated runtime changed beyond catalog and inventory');
  if(diff(before.runtime,current).length)throw new Error('Current runtime changed concurrently');
  // Only the generated catalog and its inventory are deployed; host/provider remain byte-untouched.
  for(const file of ['src/catalog.js','build-inventory.json'])await copyFile(join(WR,file),join(R,file));
  const sourceAfter=await inventory(S),runtimeAfter=await inventory(R);
  receipt.sourceChanges=diff(before.source,sourceAfter);receipt.runtimeChanges=diff(before.runtime,runtimeAfter);
  if(receipt.sourceChanges.some(f=>!['src/catalog.js','test.mjs','README.md','source-inventory.json'].includes(f.path)))throw new Error('Original source changed beyond allowed paths');
  receipt.rebuiltSourceDifferences=diff(sourceAfter,await inventory(WS,['node_modules']));receipt.runtimeDifferences=diff(runtimeAfter,generated);
  const ri=JSON.parse(await readFile(join(R,'build-inventory.json'),'utf8'));
  receipt.sourceInventoryDifferences=diff(sourceFiles,sourceAfter.filter(f=>f.path!=='source-inventory.json'));receipt.runtimeInventoryDifferences=diff(ri.files,runtimeAfter.filter(f=>f.path!=='build-inventory.json'));
  receipt.sourceInventory={files:sourceFiles.length,bytes:sourceFiles.reduce((n,f)=>n+f.bytes,0),sha256:hash(inv),selfExcluded:true};
  receipt.runtimeInventory={files:ri.files.length,physicalFiles:runtimeAfter.length,bytes:ri.files.reduce((n,f)=>n+f.bytes,0),sha256:hash(await readFile(join(R,'build-inventory.json')))};
  receipt.catalog={sha256:hash(await readFile(join(S,'src/catalog.js'))),revision:'0.39.0-r8-detail-card'};
  receipt.pass=['rebuiltSourceDifferences','runtimeDifferences','sourceInventoryDifferences','runtimeInventoryDifferences'].every(k=>receipt[k].length===0);
  if(!receipt.pass)throw new Error('Byte comparison differs');
 }catch(e){receipt.error=e.message;process.exitCode=1;}
 receipt.finishedAt=new Date().toISOString();await writeFile(out,JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({pass:receipt.pass,error:receipt.error??null,receipt:out,tests:receipt.tests,sourceInventory:receipt.sourceInventory,runtimeInventory:receipt.runtimeInventory,catalog:receipt.catalog,sourceChanges:receipt.sourceChanges?.map(f=>f.path),runtimeChanges:receipt.runtimeChanges?.map(f=>f.path)},null,2));
}else throw new Error('Use prepare or rebuild');
