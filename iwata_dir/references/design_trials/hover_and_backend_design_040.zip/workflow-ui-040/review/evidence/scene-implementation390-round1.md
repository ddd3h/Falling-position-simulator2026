# 0.39 3D担当・第一実装と有限な検査

2026-09-26 / needs360_metadata。第一巡批評は `design-round1-scene.md`、主担当採否後の境界はその第9節。変更先は `release/workflow-ui-039/source/cesium-probe/` と、そこから生成した `scene3d/` に限定した。forecast/shared/weather/repo管理本文/.gitは編集していない。

## 実装した意味

- schema v2。全candidate catalogと現在geometryを分け、available/visible/focused/parentId/delayMinutesを受信する。親子行、独立した注目ボタンと表示checkbox、非表示/未計算の表示を追加した。
- 概要のvisible/available制限と、詳細のactive/available/選択ID制限を分けた。概要非表示の候補でも、その詳細は選択群を表示できる。詳細の候補編集は不可。選択0へ点/経路や全体輪郭を補わない。
- 絶対値のfocus/visibility intentにbaseSnapshotIdとrequestIdを付け、親のsnapshot/ackで確定する。応答待ちの一覧操作は止めるがカメラ/出口は止めない。拒否・7秒応答未確認時に自動再送しない。
- 親が用意する `contour-band` の外周と穴をそのまま描く。band自身の境界線を作らず、OFFの輪郭を穴の境界として復活させない。分位面と禁止領域面のtoggleは独立。禁止level色をpayloadから引き継ぐ。詳細の干渉点は候補色の中身/干渉level色の外縁を使う。
- 新snapshotによる自動fitを止め、初回接続と明示「受け取った地域へ」だけでfitする。保存視点は親のcollectionKeyで管理し、注目/可視/色/分位表示の変化では保持、本質的な結果/領域/選択変化では無効化する。
- 埋込みの出口は親の一つを使い、子の重複backを隠した。iframe内部のEscは親のcloseへ送る。戻ると接続解除を結び付けない。

## 接続を保つ表示改修の範囲

provider/Viewer/tilesetの寿命をmain hostに残し、overlayを専用CustomDataSourceで管理する。新しい定義・一覧DOMを準備してから差し替える。前のDataSourceを一つ保持し、描画エラー時は旧layerへ復帰できる。新module取得・準備失敗で旧表示を先に消さない。

footer「この表示の意味と接続状態」内の「表示改修の確認 → 表示だけ更新」は、同じローカルの `overlays.js`、`catalog.js`、`style.css` を限定して更新する。Google helperやページ/iframe再読込を呼ばない。更新回数・適用したmodule版を診断へ記録する。更新失敗をprovider失敗と読み替えない。

これは任意のmain/protocol/provider、HTML入口、依存module、親forecastコードを安全にhot reloadする機構ではない。対応しない修復は別の無キー資料で確認し、そのためにliveを安易に終了しない。接続前にこの境界を整える目的の実装であり、あらゆる改修を一接続へ収めた証明ではない。

## 実行した検査と失敗の保持

1. `scene-unit390-r1.json`：固定Cesium 1.145.0で125条件成功。新v2の候補/詳細/hidden、帯の穴、50OFF時の90穴、material、保存視点、overlay準備・commit・rollback、認証値の非保存/エラー限定など。Google通信なし。
2. 純粋検査追加時、半透明ColorのHEX期待値がalphaを省いたため失敗した。実値 `#f28c282e` のalphaは既定.18を保持していた。色と透明度を別検査へ修正し、原失敗を `scene-unit390-r2-failure.json` に残した。
3. `scene-unit390-r3.json`：138条件成功。catalogの親子、短い遅延表示、hidden focus説明、絶対visibility intent、応答待ち/詳細/独立fixture時の編集抑止、禁止level色と詳細点の候補色/干渉外縁を追加した。ブラウザー描画の合格票ではない。
4. forecast担当の `forecast-source390/scene-snapshot.json` を本担当のv2 validatorへ渡し受理。hidden親A・可視B・注目の子C3、50OFFの90/95帯2面という実際の送信資料が契約に一致した。独立の統合UI操作完了とはしていない。

### 取得済みブラウザー証拠の方法と限界

この担当は当初、独立Node Playwright＋headless Edge＋一時ローカルHTTPによる無キー試験を実行した。全非ローカルHTTPを遮断し、既存タブ/既存profileを使っていない。通常権限はspawn EPERMで起動せず、同じ試験を権限再試行して起動した。この方法は後から主担当が指示した「ブラウザー操作はCUAのみ」に合わないため、その指示受領後は中止した。以後の実物検査は主担当CUAへ引き継ぎ、本担当はNodeの純粋source検査/buildだけを継続した。

- `scene-runtime390-r1/observed.json`：Edge起動EPERM。実画面成功0。
- `scene-runtime390-r2/observed.json`：人工mesh/帯、表示module＋CSS更新、意図的module取得失敗について9条件成功、Google要求0、root helper0、pageerror0。同viewer、カメラ/記憶保持、失敗時に適用済み表示を保持した。親iframeを取得する待ち条件が早過ぎたため脚本の `assert.ok(frame)` で終了し、全体passはfalse。親往復を成功扱いにしていない。
- 同r2の `01-synthetic.png` と `02-failed-update-kept.png` を本担当がview_imageで視認。初回は人工meshと点が先に現れ、線/面はまだ準備中。後者は屋根/段差・輪郭・3帯・禁止面の穴・5点が見え、取得失敗後も旧表示が残る。写真meshでの可読性の保証ではない。

この観察を受け、`DataSourceDisplay.ready` の変化を診断 `overlayReady` と「線と面を準備しています／準備できました」へ反映する修復を適用した。最新buildへ含まれるが、この修復後の実画面は本担当未確認であり、主担当CUAの確認待ちである。元の9条件の版へ修復後の成功を遡って帰属させない。

独立ブラウザーと一時HTTPは脚本finallyで終了済み。既存Googleタブの終了・reload・キー読取・追加接続はしていない。`runtime-check.cjs` は取得済み証拠の説明用として保持する。現在の作業でこのブラウザー操作経路を再実行しない。

## 主担当へ渡す確認点

`/scene3d/index.html?probe=synthetic` はGoogle0の人工形状。readyの機械的な目安はschema v2、initialized、overlayReady、tiles.visibleThisFrameだが、それだけを受入とせず画像を見る。親iframeではhidden focus→表示、親子一覧、2D帰還、詳細3/N・0/N、stale拒否を確認する。実写真上の分位区間識別、候補同色での識別、近接時の地物可読性はCUAの有限批評を待つ。常設insetや地点クリック読取りは、この帯実物の不足を確認してから採否する。

現在のsource-inventoryは0.38比較元の票が残っており、0.39の最終票ではない。主担当の修復批評が閉じ、sourceが凍結した後に新しいsource/runtime指紋を確定する。

## 独立批評後の修復（接続前）

主担当CUAは分位面OFFで禁止面が残ること、hidden親から子C3への注目/非表示が2Dへ継続すること、hidden子の詳細60/60が輪郭なしで受理されることを観察した。本担当の観察へ付け替えない。指摘された詳細候補名は、階層のない単独行ではfull labelを使うよう修復し、純粋票r4は139条件成功。

weather担当の独立反例は、旧geometryへrollbackした際に新snapshotの選択数/説明が残ることを示した。詳細2→0の受領失敗で旧2点に選択0と書かれる問題であり、単なる診断票の誤記ではない。旧mainと失敗票は `weather-cross390-evidence/` に保持された。

修復では、最新受領payloadと確定renderedPayloadを分離した。`diag.receivedSnapshot` / `acceptedSnapshotId` は新受領、`diag.snapshot` / receipt / summary / definition / renderedEntities / kinds / geometrySha256は表示版に合わせる。rollbackは旧payloadと表示診断を一括復元し、未反映であることを表示する。新受領と旧表示が違う間はcatalogを操作不可とし、handlerでも拒否する。別collectionの旧地物に対して新しい集合の視点を記憶しない。weatherは同じ反例を再実行し、旧2点・2/60・旧receiptへ戻ることと、新受領selected-zeroが別に残ることを確認した（`counterexamples-after.json`）。

入力変更が既存結果へ反映されていない候補は `pending && available` に応じて「入力未反映（表示は前回結果）」を出す。計算結果がない候補へ「前回結果」と書かない。詳細のdefinitionは経験楕円の一般説明ではなく、選択群とその平均経路・地表参照線の意味へ限定した。r5は141条件成功。

## 近接地点の輪郭区分読取り

写真背景の差によってopacityだけでは帯を読み切れないという主担当の再批評を受け、通常の短い左clickで、地図外の一行と小印へ注目候補の経験輪郭区分を返す案が採用された。新モードや常設の大パネルは追加していない。

- 地理包含は確定renderedPayloadの `contour-band` 外周/穴だけで行う。shared境界は二つの帯へ重複分類せず「50%境界上」等を返す。95%外は95外周が確定している場合だけ。非表示帯の穴に入る位置を95%外と誤認しない。重複形状は曖昧として止める。
- 深度の地表位置を公開 `Scene.pickPosition` から取り、公開 `Scene.sampleHeight` で既存overlay/小印を除いた現在描画中meshの高さを確認する。地表が取れない場合は取得不能であり帯外ではない。もっとも高詳細なtileを新たに取得する経路は使わない。固定SDK同梱sourceの `Scene.js` と `Picking.js` を実読し、`pickFromRay` はprivateのため採用しなかった。
- 短いprimary pointer操作だけを読む。途中で5 CSS pxを超えて戻ったドラッグ、右操作、修飾キー、長押し、wheel中断、別pointerはクリックとしない。移動/回転/zoomの既存割当を奪わない。
- 詳細、hidden focus、未計算、focusなしはそれぞれ説明し、全体帯を復活させない。ローカルの面OFFで輪郭区分を読む場合はOFFと併記する。禁止領域の上でもtopmost Entityの属性を帯区分へ流用しない。
- 新受領、表示commit、rollbackで古い読取りと印を消す。描画準備中は待ち案内、失敗後に旧表示を読む場合は旧表示と明記し、renderedSnapshotId/candidateId/resultIdを診断へ結ぶ。点の位置と読取りの対象を分離して残さない。

`band-readout.js` の区分/穴/境界/表示OFF/欠損地表とクリック・ドラッグ反例を追加したr6は165条件成功、Google通信なし。最新buildは411 files。実クリックの地物対応、表示面積、通常操作との衝突は主担当CUAによる確認待ちであり、純粋検査を実物の用途受入へ拡張していない。

weatherの独立読取りでは、押下後にCtrlを追加する短い操作をまだclickとして受理する反例が出た。moveで修飾が現れた時点で中断し、upでも無修飾を要求するよう修復。原失敗票を残し、担当純粋票r7は167条件、独立再批評は21条件成功となった（`weather-band-readout390-evidence/checks-after.json`）。読取り文の「クリック地点」は、カメラを動かした後も画面中央の値だと誤認しないために付けた。

`scene-stage390-r7.json` で14個の入口/CSS/srcについて生成runtimeとのbyte一致を確認し、411ファイルのbuild-inventory指紋を記録した。main SHA256は `6d4eefa9fe25f63bc542c3fc7f19f3615107cc713a4dfeb944d610dd364cff95`。これは接続前のsource段階票であり、実meshの拾い方やクリックの用途受入を意味しない。以後の実物結果は主担当記録へ帰属させる。
