# hover名称識別の独立案（コード前）

2026-09-26。対象sourceはr8、catalog SHA256 `d092946cddc278d6b558878fa948d79748615a08c1cf8ddc543da837fab1851b`、main SHA256 `6d4eefa9fe25f63bc542c3fc7f19f3615107cc713a4dfeb944d610dd364cff95`。main/overlays/overlay-store/band-readout/catalog、親のregion/candidate payloadを実読した。実Googleタブ・キー・通信へ触れていない。本文は採否案で、実装・実meshのhover受入ではない。

## 推奨する最小の用途

止めたカーソルの下にある「現在表示中の面」の設定名を、短い一時ラベルで読む。クリックの「ここは経験輪郭50–90%間か」という地点区分と役割を分ける。hoverで分位区分や新しい統計を増やさず、クリックの小印・確定readoutも書き換えない。

初期対象は `contour-band` の塗りと `region` の塗りの2種類に絞る。

- 分位の面：候補catalogのfull label。表示例「落下分散：A 標準案 ＋0.5時間」。50/90/95ごとに同じ名前を繰り返さない。
- 領域の面：領域設定名 `label` と設定済み `levelName`。表示例「領域：学校周辺 · 注意」。色だけではレベルを読み分けにくいため、短いlevel名は有用。priority値を「レベル番号」や危険度へ読み替えない。名前が未設定なら明確なIDを使い、地物から名称を推測しない。
- 落下点・平均着地・放球点・停止点・経路・支持境界は対象外。Googleの建物名・道路名を問い合わせる機能にも広げない。

線だけの候補に名称が出ない境界を明示する。面をOFFにした場合、面内部をhoverしても名称を出さない。輪郭線は初期対象から外すのが最小だが、比較中の非注目候補は線しかないため識別できないという反例は残る。実物でその反例が支配的なら、後続で `kind:contour` だけを表示線の数pixel以内に限定して候補名へ結び付ける。経路や全点へ一括拡張しない。線の近傍判定を面の地理内包判定で代用しない。

## 重複と邪魔にならない出し方

最多2対象名と「他n件」に絞る。帯はcandidateId/resultIdで、領域はregionIdで重複を除く。50/90/95の境界やMultiPolygonの複数partから同じ対象を何回も数えない。同名の異なる領域は名前だけで統合しない。

面が重なる場合は、落下分散名があれば1枠を確保し、もう1枠に領域を置く。複数領域は親から渡されたpriority順、同順位は安定ID順とする。「他n件」のnは、現在表示している面の同定済み対象数から算出する。APIのpick件数上限で打ち切った値を完全な重複数として使わない。穴の中はその面の対象に含めず、候補の非表示・ローカルの面OFFも反映する。

候補はカーソルから少し離れた小さな一時tooltip。表示は最大2名＋件数程度、`pointer-events:none`、画面端で反転/内側へ収め、対象の真上を覆わない。長い名称は読める折返しを許しつつ幅を制限する。常設パネルや上部の追加行を増やさず、既存クリックreadoutは維持する。固定隅の欄は地物を覆わない利点があるが、名称と指した場所の対応が弱くなるため代案にとどめる。

約250msの短い静止を初期案とする（適正値は人工画面で調整）。pointerdown・buttons押下・drag・wheel・pinch・カメラ移動・pointerleave・window blur・pause中は直ちに消す。操作入力を止めたりcaptureしたりせず、移動後に改めて静止したときだけ読む。境界を横切る間に大量の説明が点滅する状態を避ける。touchへ長押し等を勝手に割り当てない。

## 表示対象の決め方と地物pick

推奨は、hostが現在の写真meshの画面位置を取得し、確定 `renderedPayload` の表示中ポリゴン（穴あり）へ照合する方法。既存クリックのpublic depth/mesh確認を共通化し、region/bandの表示状態をフィルターにする。Google tileの名称metadataは読まない。生のpick結果に未知のEntity/primitiveが来たからといって名前を表示しない。

これにより、点やクリック小印が上にある場合に「その点のID」へ識別が乗っ取られるのを避け、屋根・地面の位置と描画対象の面を結び付ける。深度/mesh位置が取れない空や取得待ちでは名称なしとし、適当な楕円体座標へ外挿しない。裏側の地物や見えていない領域を、画面座標の下にあるというだけで列挙しない。境界のpixelと地理内包の差、屋根/壁の近接は人工形状で実物確認が必要。

Cesium `drillPick` は重なったprimitiveを前から順に取得できるが、primitive数と意味上の対象数は一致せず、指定limitは収集を打ち切る。画面上で実際に拾える面を照合する補助候補にはなるものの、初版からこれだけで「他n件」を確定しない。固定SDK 1.145.0のScene実装と公式APIで公開境界を確認した。private `pickFromRay` や `*MostDetailed` をhoverのために採用しない。現在描画の深度と、overlay/markerを除く公開sampleHeightを使う範囲にとどめる。[Scene API](https://cesium.com/learn/cesiumjs/ref-doc/Scene.html#drillPick)（2026-09-26確認）。

受領中・表示更新中・rollback直後はtooltipを消す。名称解決は描画済みsnapshotと現在のlocal visibilityに束縛し、acceptedだけ先に変わった新候補名を旧面へ付けない。少なくとも未反映の不一致が解消するまではhoverを抑制する。成功後は新表示から読み直す。設定名のHTML解釈はせずtextContentで描画する。

## 接続寿命と責務

現在の限定表示更新は `overlays.js` のEntity定義、`catalog.js` の一覧DOM/帯説明、style.cssだけを差し替える。Viewer、canvas入力、pointer tracker、renderedPayload、pauseとprovider寿命はmain hostが所有し、外へ公開していない。したがって、**現在のr8 liveへcatalogだけで正しいmesh hoverを追加する経路はない**。

catalogのDOM生成へglobal pointer listenerを隠して登録する、Cesiumのprototypeを差し替える、DOMから内部Viewerを探索する、公開globalにViewer/keyを追加する、といった接続維持のための迂回は採らない。catalogの再生成やrollbackでlistenerが重複・残留し、確定表示との整合を失う。

最小の正しい追加は、host所有のhover controllerを1個作り、入力/静止タイマー/表示消去/現在surface取得を担当させること。別の純粋resolverはsnapshot＋point＋可視状態から名称とIDだけを返す。UIのtooltipはDOM所有を明示し、destroy/pause/update時に消す。providerの生成・再接続・鍵取得をhoverへ渡さない。この構成なら機能実行でroot helperを呼ぶ理由はないが、カメラ操作に伴う通常tile読込までゼロと主張しない。

初回導入にはmain側の明示的なhook追加が必要で、現在の読み込み済みhostへは再読込なしで反映できない。今の接続を勝手に終了せず、この接続で必要な批評を済ませた後、主担当が次のhost起動時点を判断する。将来の名称文言/対象の選定ロジックは、限定更新の明示的なinterfaceへresolverを加えれば同一接続内で試せる。ただし初回から汎用のプラグイン基盤や任意module実行口へ広げない。

## 採用後に必要な有限反例

コード前の採否を得た後、少なくとも次を確認する。まだ実行していない。

1. 候補面＋領域面＋複数の重複領域、同名別ID、MultiPolygon、穴、50/90共有境界で重複数と名前が正しい。
2. 非表示・面OFF・詳細の輪郭なし・0選択で存在しない面名が出ない。線だけ表示は初版対象外と一致する。
3. 点/クリック小印の重なり、屋根/壁/地面、空、低解像/取得待ちで、前景のmesh位置から離れた名前が出ない。
4. hover後のdrag/wheel・視点記憶復帰・2D往復・snapshot切替・描画失敗で古いtooltipを残さず、クリックreadoutとカメラ操作を妨げない。
5. 名称の長さ・2対象＋他n・画面端・狭いviewportで邪魔にならず、更新/破棄を繰り返してlistener/root helperが増えない。

根拠は現sourceの責務分離、固定Cesium 1.145.0（engine26.3.0）の `Scene.js`、公式 [Scene API](https://cesium.com/learn/cesiumjs/ref-doc/Scene.html#pickPosition) と [ScreenSpaceEventHandler API](https://cesium.com/learn/cesiumjs/ref-doc/ScreenSpaceEventHandler.html)（2026-09-26確認）。公式公開APIの存在と本模型でのhover適合は分けている。
