# 0.39 単クリック帯読取の独立反例

基準 M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`、未統合候補 workflow-ui-039。`band-readout.js`、main の `inspectSurface` / 受領・commit・rollback、overlay-store の pickExclusions を読んだ。source と独立モックのみで、ブラウザー・実 Google・Cesium の実深度バッファは操作していない。

## 目的への適合

濃淡を写真に勝つほど強くする代わりに、注目候補の局所を一つの短文で読む構成は、近接して建物・林縁と落下域の位置関係を確かめる目的に合う。帯の値を新しい確率推定とせず、現在描画している固定 polygon の区分を返す点を維持する。別画面や専用の選択モードを追加していない点も適切。

## 独立に確認した場面

脚本 `weather-band-readout390-check.cjs` は担当の fixture に依存せず、141°E / 43°N 付近に矩形の三帯と大きい禁止領域を置いた。`readBand` と main の `inspectSurface` を実 source から評価し、後者の scene / Cartesian 部分のみ小さくモックした。結果 `weather-band-readout390-evidence/checks-before.json` には 19 条件の有限成功と、下記一反例を分けて保存した。

- 禁止領域が重なっていても、topmost feature の種類を答えにせず注目 A の地理的な帯を読む。
- 50% / 90% の共有境界は一つの境界として返り、二つの帯へ同時所属しない。
- 50% を非表示にしても 90% 帯の穴は埋まらず、中央を 50–90% と読まない。95% の外周が送られていないときは、さらに外側でも「95% 外」と推測しない。
- 面全体 OFF は区分の意味を変えず「面の表示は OFF」と示す。
- sampleHeight へ現・旧分析 Entity と前の読取印を除外対象として渡す。mesh 高さが得られない場合は前の読取を消し、95% 外とはしない。
- 新受領 B の更新に失敗して旧 A が見える場面では、A の geometry と resultId から判定し、「旧表示の読取り」と出す。診断は受領 B と描画 A を別に保持する。
- 更新準備中、詳細群では地表 query を実行せず、全体帯の読み取りへ進まない。
- 大きく drag して開始位置へ戻る操作と右ボタンは click としない。

新受領・表示commit・rollback時に古い印と文言を消すことは source の呼出し箇所を読んだ確認である。今回のモックで全 lifecycle を改めて実行したという意味ではない。上の禁止面の成功も、scene の地表位置が与えられた場合の地理判定と除外引数についての確認で、実写真上の pickPosition が禁止面を越えて同じ背景位置を得る証明ではない。

## B-W1 / P3：押下後に修飾キーを加えると通常クリックに含まれる

初版 `createClickTracker.start` は修飾キーを拒否するが、move / end では確認しない。無修飾 pointerdown の後、Ctrl=true の短い pointerup を与えると true を返した。Ctrl+左ドラッグが視点の回転に使われるため、開始後に Ctrl を加えた小さい操作の終端が読取りになる余地がある。

最小修正は end でも無修飾を要求し、move で修飾キーが現れた場合は当該 click 候補を解除すること。普通の微小ぶれを全部禁止する必要はない。これは source 関数で再現した反例であり、root の実ブラウザーで誤動作を観測したものではない。scene 担当へ連絡済み。

## 次の実物確認へ残すこと

API の適合は source だけで受け入れない。root が通常 click / drag の区別、背景の実位置、禁止面や印の重なり、読取文と印の対応を実視認する必要がある。pickPosition で復元した longitude / latitude と、その位置で overlay を除外して sampleHeight した結果を使う方式であり、画面の同一 ray 上の地物へ正しく戻るか、斜視・建物縁・樹冠で自然に見えるかは特に実物の問いである。

灰色や穴の判定成功を写真背景の精度、禁止領域の法的意味、校正された落下確率、課金回数の確認に拡張しない。新しい操作の負担も、読取の短文が地図を遮らないか、印を探す余計な視線移動を生まないかという実物評価へ残す。

## 読取時指紋

- band-readout.js: `d6d4342168271330f46d088af5c001140875512c56c10ea44b4c2e2b2ee2031b`
- main.js: `2aeab5ec79532b6f7da51fcf18b40a751cdf20b38ef1a9e043fc48943939dbcc`

19 条件は件数による全面受入を意味しない。B-W1 は別枠で残し、修復後は初回 JSON と source 控えを保持した別出力で再確認する。

## B-W1 修復後の独立再確認

担当修復後、`weather-band-readout390-recheck.cjs` で前の 19 条件に二つの反例を加えて再評価した。無修飾 down→Ctrl 付き up、および途中で Shift を押して離してから up の双方が false となった。21 条件の結果を `weather-band-readout390-evidence/checks-after.json`、修復 source を `band-readout-after.js.txt` へ保存し、初回の失敗証拠は残した。

修復後の band SHA-256 は `1d110c67ffd90dacbe73d58f3d6f767f55621e1ec5211e631baaecd79b5800fe`、main は `6d4eefa9fe25f63bc542c3fc7f19f3615107cc713a4dfeb944d610dd364cff95`。B-W1 の source 上の修復は受入可。上記の実深度・斜視・地物上のクリックに関する未確認範囲は変わらない。
