"""Read only the two root-confirmed UI downloads, preserve copies and finite parse evidence."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
from datetime import datetime, timezone
import json
import xml.etree.ElementTree as ET

dest = Path('C:/Users/genia/AppData/Local/Temp/balloon-design-390/reviews/download390-evidence')
source_dir = Path('C:/Users/genia/Downloads')
dest.mkdir(exist_ok=True)
names = ['balloon-A-r1.json', 'balloon-analysis-039.kml']
result = {'at_utc': datetime.now(timezone.utc).isoformat(), 'basis': 'main M380 19bf0cc5cd32509a44ca8e246f4294ab0972d61e', 'observation': 'root reports actual no-Google forecast tab10 UI save, after old tab7 requests did not reach Downloads', 'files': []}
for name in names:
    source = source_dir / name
    data = source.read_bytes()
    output = dest / name
    if output.exists() and output.read_bytes() != data:
        raise RuntimeError('Existing evidence differs: ' + name)
    if not output.exists():
        output.write_bytes(data)
    result['files'].append({'source': str(source), 'copy': str(output), 'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'copy_identical': output.read_bytes() == data})

j = json.loads((dest / names[0]).read_text(encoding='utf-8-sig'))
result['candidate_json'] = {'valid_json': True, 'format': j.get('format'), 'name': j.get('name'), 'result_id': j.get('result', {}).get('id'), 'top_level_keys': list(j), 'result_keys': list(j.get('result', {})), 'note': j.get('note')}

ns = {'k': 'http://www.opengis.net/kml/2.2'}
tree = ET.fromstring((dest / names[1]).read_bytes())
tag = lambda e: e.tag.rsplit('}', 1)[-1]
counts = Counter(tag(e) for e in tree.iter())
folders = []
for folder in tree.findall('.//k:Folder', ns):
    folders.append({'name': folder.findtext('k:name', default='', namespaces=ns), 'own_visibility': folder.findtext('k:visibility', default='default1', namespaces=ns), 'direct_placemarks': len(folder.findall('k:Placemark', ns)), 'child_folders': len(folder.findall('k:Folder', ns))})
coordinate_tuples = 0
numeric_valid = True
ring_closed = []
for e in tree.findall('.//k:coordinates', ns):
    coords = [[float(v) for v in token.split(',')] for token in (e.text or '').split()]
    coordinate_tuples += len(coords)
    numeric_valid = numeric_valid and all(len(v) in (2, 3) and -180 <= v[0] <= 180 and -90 <= v[1] <= 90 for v in coords)
for ring in tree.findall('.//k:LinearRing', ns):
    coords = [[float(v) for v in token.split(',')] for token in ring.findtext('k:coordinates', default='', namespaces=ns).split()]
    ring_closed.append(len(coords) >= 4 and coords[0] == coords[-1])
result['kml'] = {'xml_parse': True, 'root_tag': tree.tag, 'document_name': tree.findtext('k:Document/k:name', default='', namespaces=ns), 'counts': dict(sorted(counts.items())), 'folders': folders, 'coordinate_tuples': coordinate_tuples, 'numeric_lon_lat_range_valid': numeric_valid, 'linear_rings': len(ring_closed), 'all_linear_rings_explicitly_closed': all(ring_closed), 'altitude_modes': dict(Counter((e.text or '') for e in tree.findall('.//k:altitudeMode', ns)))}
result['limits'] = ['Root owns and observed UI actions; this script verifies only physical files and copies.', 'Not a reproduction of the failed old tab, no claim that it is repaired.', 'JSON parse and KML XML/coordinate structure do not prove statistical/scientific validity or Google Earth rendering.', 'This initial fresh-tab sample does not cover four candidates/two region sets/hidden parent, which root plans separately.']
receipt = dest / 'physical-download390-first.json'
if receipt.exists():
    raise RuntimeError('Do not overwrite existing receipt')
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
