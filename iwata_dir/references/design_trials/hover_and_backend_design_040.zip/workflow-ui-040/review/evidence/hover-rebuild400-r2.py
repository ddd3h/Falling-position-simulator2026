from pathlib import Path
import hashlib,json,subprocess,os,shutil,datetime

p=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-design-400')
source=p/'release/workflow-ui-040/source/cesium-probe'
report=p/'reviews/hover-rebuild400-r2.json'
rebuild=p/'reviews/hover-rebuild400-r2'
if rebuild.exists() or report.exists(): raise SystemExit('Refusing to overwrite an existing rebuild observation')
def digest(f):
    data=f.read_bytes()
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
old=source/'source-inventory.json'
shutil.copyfile(old,p/'reviews/hover-source-inventory400-before-r2.json')
files=[{'path':f.relative_to(source).as_posix(),**digest(f)} for f in sorted(source.rglob('*')) if f.is_file() and f.name!='source-inventory.json']
old.write_text(json.dumps({'engine':'cesium@1.145.0','files':files},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
copy=rebuild/'source/cesium-probe'
shutil.copytree(source,copy)
node=r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
env=os.environ.copy();env['BJP_CESIUM_DEPENDENCIES']=r'C:/Users/genia/AppData/Local/Temp/balloon-design-380/cesium-probe/node_modules'
commands=[['test.mjs',str(p/'reviews/hover-unit400-rebuild-r2.json')],['make-fixture.mjs'],['build.mjs']]
out=[]
for i,cmd in enumerate(commands,1):
    run=subprocess.run([node,*cmd],cwd=copy,env=env,text=True,capture_output=True)
    (p/f'reviews/hover-rebuild400-r2-{i}.log').write_text(run.stdout+run.stderr,encoding='utf8')
    out.append({'command':cmd,'exit_code':run.returncode})
    if run.returncode: raise SystemExit(f'command {i} failed')
comparisons=[]
for sub in ['scene3d','shared']:
    a=p/'release/workflow-ui-040'/sub;b=rebuild/sub
    paths=[f.relative_to(b) for f in b.rglob('*') if f.is_file()]
    if sub=='scene3d':
        if set(paths)!=set(f.relative_to(a) for f in a.rglob('*') if f.is_file()): raise SystemExit('Runtime path set mismatch')
    for rel in sorted(paths):
        expected=digest(a/rel);actual=digest(b/rel)
        comparisons.append({'path':(Path(sub)/rel).as_posix(),'equal':expected==actual,**actual})
if not all(c['equal'] for c in comparisons): raise SystemExit('Runtime bytes mismatch')
evidence={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis_commit':'7622593e0d4dacb101f9ed86990f2832845494ed','engine':'cesium@1.145.0','commands':out,'runtime_files_compared':len(comparisons),'all_equal':True,'google_network':False,'browser_observation':False,'source_files':len(files),'comparisons':comparisons}
report.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in evidence.items() if k!='comparisons'},ensure_ascii=False))
