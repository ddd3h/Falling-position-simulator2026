# 0.39 独立批評：表示と意味が別々に戻らないか

基準 main M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`。候補は `release/workflow-ui-039`、未統合。批評者 `/root/weather370`。この票は source と生成 KML の有限読取であり、ブラウザー、GPU、Google、Google Earth は操作していない。模型本体は編集していない。

## 問いと方法

新しい機能が動くかだけでなく、「前の計算を見ているのに新しい入力で計算したと思う」「選択を空にしたはずなのに旧群の点を選択 0 の説明で読む」という場面を置いた。読み取った範囲は forecast の appearance390 / export390 / scene-document / app の受渡しと分類、shared/scene-style、および Cesium source の main / catalog / overlays / overlay-store / protocol / view-memory / receipt-status。`reviews/forecast-source390/overview-inventory.json` と `overview-parent-hidden.kml` の保存内容も参照した。初巡のチェック件数を今回の証明へ移してはいない。

実関数の独立反例は `weather-cross390-counterexamples.cjs`。結果は `weather-cross390-evidence/counterexamples-before.json`、読取時点の main は `main-before-read.js.txt` として保持した。main SHA-256 は `ca80287b9a801dfcb0e9b01dde6e1cfce0116bd8e7160803d7f2bc58e00b380f`。DOM と overlay store の最小モックで関数の状態遷移を検査したもので、GPU エラーを実ブラウザーで起こした証拠ではない。

## 修復を推奨する点

### W-C1 / P1：旧図形へ戻ったのに新しい選択数・説明が残る

`source/cesium-probe/src/main.js` の `installPresentation` は図形の commit 後に `updateSummary(next)` を行う。`restorePreviousPresentation` は旧図形・候補 DOM・CSS・renderedSnapshotId を戻すが、contextSummary / definition / notes / receipt / renderedEntities / overlayKinds を戻さない。受領時点の `payload` と `diag.snapshot` も新しい版になる。

独立反例では、詳細で選択 2/60 の結果 A を表示し、選択 0/60 の結果 B へ更新してから rollback を呼んだ。旧 A の 2 点と renderedSnapshotId=A に戻る一方、見出しは「選択 0/60」、受領票は B、renderedEntities は 0 のままだった。警告は出るが、どの群を見ているのかが複数の表示で食い違う。これは単なる診断欄の不一致ではなく、施設と比較している群の読み違いを生む。

最小修復は、受領済み状態と実際に描画した状態を分け、旧図形と一緒に旧 summary / definition / receipt / 描画診断を戻すこと。新要求 B を消す必要はなく、「B は受領済み、現在の図は A」と区別する。旧図形に対して新 B の ID で候補操作を送らないよう、描画版と受領版が違う間は候補操作を無効にする。接続や provider を再作成する必要はない。root と scene 担当へ連絡済み、修復採用の返答あり。修復後の受入は本票後半へ別記する。

### W-C2 / P2：入力未反映の結果が 3D で普通の現在結果に見える

forecast の `analysisDocument` は catalog に `pending:dirty(t)` を送っている。KML の候補説明は「入力未反映・変更前の結果」を含む。一方 `catalog.js` の行は pending を使わず、main の summary も使わない。独立モックで pending=false / true の候補 A が、ともに「A / 注目・表示」という同一の文言になることを確認した。

具体的には親の打上げ条件を変更して再計算せず、旧結果を持つ遅延子を 3D で見る場面。2D にあった未反映の注意が消え、屋根や禁止域との関係を新条件の結果だと思う余地がある。座標や resultId 自体は旧結果を正しく維持しているので、再計算を強制する修正は不要。候補行に短く「入力未反映・変更前」を出し、詳細でも同じ注意を保つのが最小修復。全条件を常時再掲して情報量を増やす必要はない。

### W-C3 / P2：帯の `count` が帯内部の件数に読める

`shared/scene-style.js` の bands は上側輪郭の count を引き継ぎ、scene-document の contour-band はそのまま `count` として保存する。現在の生成物では 50–90% の帯が count=54 / denominator=60、90–95% の帯が count=57 / 60 になっている。これはそれぞれ上側輪郭の累積被覆数であり、穴を除いた帯内部の数ではない。KML ExtendedData で帯を調べる次の利用者にとって `count` の対象が不明確である。

「区間の確率値ではない」という説明と、排他的な幾何学帯の作り方は適切。ただしそれだけでは count の意味を説明していない。最小修復は帯から count を省くか、`upperContourCount` 等へ明示的に改名し、必要なら lowerContourCount を添えること。輪郭側の被覆数は保持する。帯内部の実点包含を新しく計算する機能はこの修復に不要である。forecast 担当へ報告済み。

## 情報負担を軽くする改善

### W-C4 / P3：詳細で表示していない楕円を説明している

詳細は「選択 3/60 着地・輪郭なし」と正しく示す一方、candidate.probabilityDefinition を無条件に表示するため「経験楕円。安全域・校正された予報確率ではない」が隣に残る。注意そのものが誤りではないが、今見ている 3 点を説明せず、表示のない対象に読者の注意を割く。詳細時の definition は「選択した着地 ID とその群の平均形状」に寄せ、概要の楕円説明は概要へ限定する方が用途に合う。

大きな新しい説明パネルは不要である。候補行の短い状態、現在の群を示す既存見出し、凡例という既存の関係を正確にする方が効果が高い。

## 現設計で維持すべき点と反対案

- **全候補非表示**でも catalog を送るため、3D から表示を戻せる。図形がないことを「候補がない」と扱わないのは有用。禁止領域・支持境界が残ることも、候補とは別の参照情報として合理的である。入口を閉じて回復操作を失わせる反対案は採らない。
- **非表示の親と表示中の遅延子**を KML で同じ系列の兄弟 folder に置く設計は、親の checkbox が子の表示まで消す誤りを防ぐ。`localVisible` と候補 folder の visible を分けることにも意味がある。ただし Cesium KML reader の親 visibility 焼込みの限界は別票 `weather-kml-review.md` の通りで、XML の設計が正しいことから任意 reader の操作復元まで受け入れない。
- **詳細の少数・0 選択**では選択 ID のみを送り、空集合を全標本へ戻す fallback を設けていない。3D の詳細で別候補の切替を止めることで、選択群の文脈を守っている。全体輪郭を「便利だから」と追加すると全母集団と選択群が混ざるため、現行の省略を保つべきである。
- **禁止面と帯の重なり**は、2D では禁止領域専用 pane を上に置き、禁止領域の分類を独立して維持する。複数候補を同時に塗らず注目だけを塗る案は、色の加算を標本密度と誤認する負担を減らす。3D の写真上で細線・穴・禁止面が読めるかは実視認が必要で、この source 読取だけで受け入れない。
- **レベル色と候補色**は同じ palette から選べるが、同じ色の禁止面と帯が重なる場面は操作模型の視認課題として残る。ユーザーが選べる色を禁じるより、形・線・濃淡と短い凡例で役割が追えるかを root の実物評価で見るべきである。見ていない段階で色衝突を実不具合と断定しない。

## 未確認と範囲

ブラウザーの実描画、写真地物上の重なり、Google Earth の KML 対応、SDK での更新失敗時の実 GPU 挙動は未確認。純粋な状態遷移反例を接続回数・課金・統計精度の検証へ拡張しない。KML の経路カーテンの透明度は root / forecast 担当の比較観察対象であり、この票では濃度を決定していない。

## 修復後の独立再確認

scene 担当が W-C1 / W-C2 / W-C4 を修復した後、同じ反例の期待を変えた別脚本 `weather-cross390-recheck.cjs` で再確認した。main SHA-256 `29444c439501117bf91f27efa3d9937c762313019f068671e0fe31fe03dcac87`、元 source は `weather-cross390-evidence/main-after-read.js.txt`、結果は `counterexamples-after.json`。初回失敗の source / JSON / script は上書きしていない。

- rollback 後は旧 2 点、選択 2/60 の見出し、旧受領票、renderedEntities=2 が一致する。新受領 selected-zero は acceptedSnapshotId に別に保持される。
- pending=true の候補行には「入力未反映（表示は前回結果）」が現れ、false と区別できる。
- 詳細の definition は選択数と選択群の平均経路へ変わり、経験楕円を説明しなくなった。

以上三件は source 関数の状態・文言について有限受入可。GPU rollback の実視認は未確認。帯の W-C3 はこの再確認に含めない（JSON の bandProperties は初回生成 inventory を参照したもの）。後続修復・KML 再生成の帰属を混ぜない。

防御上の小さな改善余地として、sendIntent 自体は描画版≠受領版の条件を直接検査せず、catalog の disabled と presentationError に依存する。非同期 prepare が長くなった場合の旧 DOM からの送信を関数の入口でも拒否すると一貫する。現状の実ブラウザーで発生を観測したものではなく、追加の P1 として扱わない。

## 局所の帯区分を読む案への追加批評

root から「写真の林と畑の明暗差が .18/.10/.05 の濃度差より強く、輪郭から離れた近接画面では帯の区分を色だけで断言しにくい」という観察を受けた。これは root の実視認であり、私の独立画像観察ではない。

帯を写真に勝つほど濃く塗ると、確認対象の地物を隠す。濃淡には概観を担わせ、局所は短い文字で確かめる方針は目的に合う。ただし中央視線の常時計算・常設十字印は、読みたい場所がパンで自動的に替わること、見たい地物と中心が常に同じとは限らないことに注意が要る。

試すなら通常の単クリックで一点に小印を置き、既存の地図外帯に「注目 A・経験輪郭 50–90% 間」と短く示す一案を推す。新画面・専用モード・再集計・確率値の推定は不要。クリックとドラッグを分け、topmost に禁止面があるため帯判定が消えること、地形位置を取得できない場合に「95% 外」と表示すること、旧描画に新受領候補の区分を答えることを反例として扱う。高密度な複数値パネルへ拡大しない。

今回必須かは「輪郭の外へ拡大した局所でも、人が帯区分を確認する」場面を受入に含めるかによる。単なる装飾改善として必須にはしないが、地物との位置関係を近接して読む今回の目的には直接つながる。まず一つの小さい読取案を比較する価値がある。標準操作で輪郭をすぐ参照できる場面では現行表示だけで十分な可能性も残す。
