from pathlib import Path
import hashlib,json,difflib,sys
from PIL import Image,ImageOps,ImageDraw
from pypdf import PdfReader

stage=Path('C:/Users/genia/AppData/Local/Temp/balloon-design-400')
repo=Path('C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
build=stage/'plan-build'
suffix=sys.argv[1] if len(sys.argv)>1 else ''
pdf=build/'docs/PROJECT_PLAN.pdf'
reader=PdfReader(pdf)
texts=[p.extract_text() or '' for p in reader.pages]
(build/f'pdf-text{suffix}.txt').write_text('\n'.join(f'\n--- PAGE {i+1} ---\n{t}' for i,t in enumerate(texts)),encoding='utf-8')
rendered=sorted((build/f'rendered{suffix}').glob('page-*.png'))
assert len(rendered)==len(texts),(len(rendered),len(texts))
contact=build/f'contact{suffix}';contact.mkdir(exist_ok=True)
for start in range(0,len(rendered),4):
    chunk=rendered[start:start+4]
    canvas=Image.new('RGB',(1850,2660),'#cccccc')
    for j,path in enumerate(chunk):
        img=Image.open(path).convert('RGB')
        x=(j%2)*925;y=(j//2)*1330
        canvas.paste(img,(x,y+28))
        ImageDraw.Draw(canvas).text((x+10,y+6),f'Page {start+j+1}',fill='black')
    canvas.save(contact/f'pages-{start+1:02d}-{start+len(chunk):02d}.png')
paths=['docs/PROJECT_PLAN.md','docs/ENVIRONMENT_CONTRACT.md','docs/WEATHER_DATA_GUIDE.md']
observed={}
for name in paths:
    before=(stage/'base-0.39.0'/name).read_bytes();after=(repo/name).read_bytes()
    observed[name]={'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'before_lines':len(before.splitlines()),'after_lines':len(after.splitlines())}
    (stage/'reviews'/f'{Path(name).stem}-400.diff').write_text(''.join(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),after.decode('utf-8').splitlines(keepends=True),fromfile='M390/'+name,tofile='candidate/'+name)),encoding='utf-8')
info={'pages':len(texts),'page_text_lengths':[len(t) for t in texts],'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'tex_crlf_count':(build/'docs/PROJECT_PLAN.tex').read_bytes().count(b'\r\n'),'source_copy_equals_repo':(build/'docs/PROJECT_PLAN.md').read_bytes()==(repo/'docs/PROJECT_PLAN.md').read_bytes(),'changed_md':observed,'scope':'Rendering and text metadata are not visual approval; pages require independent visual inspection.'}
(stage/'reviews'/f'plan-build400-evidence{suffix}.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(info,ensure_ascii=False,indent=2))
