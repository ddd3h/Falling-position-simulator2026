# 0.39 source最終指紋と独立再生成

実施日時と全ファイル照合は `scene-rebuild390-final.json`。元sourceへの変更は `README.md` と `source-inventory.json` の2ファイルだけで、main・renderer等の実装と現行scene3d runtimeは不変。

旧0.38由来のsource inventoryを `source-inventory390-from038.json` へ元byteのまま保持し、現sourceの全50ファイル（529,130 bytes、inventory自己のみ除外）から同形式で再生成した。新inventory SHA256は `16154bc58c52fe2a34b6b97898ec92987ed8e7b7787eb24896e2a069682784f8`。README末尾では実装側167条件、独立担当21条件、主担当CUAの人工3D有限観察を分け、読み込み済みhostに未適用の変更を観察済みとしない。

別作業コピー `rebuild390/source/cesium-probe/` を新規作成し、既存P380の固定Cesium 1.145.0依存を参照して `test.mjs` → `make-fixture.mjs` → `build.mjs` を実行した。再取得・Google接続・ブラウザー操作は行っていない。bare importを解決するnode_modules junctionはこの独立作業コピーだけにあり、release/sourceや配布物へ含めない。

- test: 167条件成功、GoogleNetwork=false。WebGL/Google meshの追加観察ではない。
- fixture: GLBとtileset JSONを再生成し、元sourceとbyte一致。
- build: 現runtimeの411ファイル（22,809,659 bytes）とbuild-inventory.jsonを含む計412実体を、パス・サイズ・SHA256で全比較して一致。欠落・追加・byte差なし。
- source再生成後の比較も全一致（独立作業用junctionのみ除外）。元sourceの許可外変更なし、元runtime変更なし。
- build-inventory SHA256: `7aa4bd35e0dca1eb3391524d276fa8853005ebad7fbab015d141e54f1b85f244`。
- lockとCesium license/ThirdPartyは元byteを保持し、source inventoryとruntime inventoryへ記録。

初回はNode子プロセス起動がEPERMで停止し、test本文を実行できなかった。`scene-rebuild390-initial-launch-failure.json` と `scene-rebuild390-test-initial-launch-failure.log` に保持。同一処理を承認された実行環境で再試行し、3コマンドとも終了0で完了した。初回を検査成功として数えていない。

実行用記録は `finalize-scene-source390.mjs` と `resume-scene-rebuild390.mjs`。これらは今回の実績を保存する履歴資料であり、再実行しません。特に前者は既存workRootを拒否してもcatch後にreceiptを書き込むため、完成済みのreceiptを上書きし得ます。既存作業先を拒否するガードは出力receiptを保護するものではありません。通常の再現対象から外し、`source/reproduction390.md` の別コピーでの手順を使用します。再試行時に古い作業コピーを削除する設計ではありません。独立批評でこの限界を確認し、helper本体を履歴から書き換えずに本段落を訂正しました。
