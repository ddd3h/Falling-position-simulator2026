# 0.39 別KML readerの証拠境界と保存SVGの初期表示

担当 weather370 / 基準 main M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`。対象は候補 `review/kml-preview.html/.js`。読取批評のみでreaderやKML exporterは変更していない。後続の明示依頼により、weather/app.js の保存SVG最外要素への寸法付与だけを追加修復した。Browser/Googleキー操作はしていない。

## 1. 判定：有用な別読取経路だが、互換性の証明にはしない

このpreviewは模型のGeoJSON→Cesium変換関数を使わず、出力KMLを標準 `KmlDataSource` で読む。そのため、styleUrl参照、KML色/透過、座標、穴、Folderの保存、extrudeを実際の別パーサへ渡せる点は有用である。入力XMLを見栄えの良い独自Entityへ作り直す検証より、出力形式の誤りを見つけやすい。

一方、元模型と同じCesium描画系を使うため、描画エンジン/ドライバの独立性までは持たない。Google Earthでの初期表示、既定アイコン、地形・高度・描画順が同じであるという受入にはできない。Cesium自身もKML対応を完全とはしていない。[Cesium KmlDataSource公式文書](https://cesium.com/learn/cesiumjs/ref-doc/KmlDataSource.html)

SDKの実体は `source/cesium-probe/package.json` の **Cesium 1.145.0**。確認した非minify sourceは `P380/cesium-probe/node_modules/.pnpm/@cesium+engine@26.3.0/node_modules/@cesium/engine/Source/DataSources/KmlDataSource.js`。当初こちらが別版1.132と思い込んで実装担当へ問い合わせたが、packageと実装担当の回答で訂正した。以下は固定1.145.0のsource読解であり、任意バージョンの一般則に拡張しない。

## 2. 具体的な見落としと帰属

| 観点 | sourceから確かめたこと | 出力の判定へ使う境界 |
|---|---|---|
| 親Folderと子のvisibility | SDK 2253–2265行の `ancestryIsVisible` と `entity.show=ancestryIsVisible(parent)&&(visibility??true)` は、読込時に親の非表示を子自身のshowへ反映する。previewはcheckboxからe.showを変更するだけ。 | 原XMLで親0・子1でも、ロード後の子showはfalse。親をONにするだけでは子は戻らない。これは読取側の変換制約であり、exporterが子visibilityを誤保存した証拠にはならない。原XMLのown visibilityと、読込直後のeffective visibilityと、操作後のSDK状態を分ける。 |
| ツリーと要素数 | SDK 2314–2325行ではDocumentは子ノード処理へ進み、FolderはEntityになる。MultiGeometryは別Entityへ展開されうる。previewのcountsは全Entity（非描画コンテナーも含む）とisShowingを数える。 | 「要素数がKML Placemark数と同じ」や「可視数＝地図上の点数」とはできない。ツリーはこのSDKの階層であり、原XMLのDocument/Folder/Placemark構造は別の構造検査が正本。 |
| default icon / 点の色 | SDK 1470–1512行ではPointのbillboardに画像が無いと黄色のpinを生成する。IconStyle処理ではbillboard.colorを設定する（961行）。明示画像、色掛け、scale、空Iconによる抑制は別の情報。 | このreaderで目立つ既定pinが出ても、exporterが形を指定した証拠ではない。青緑/紫等のIconStyle色がそのまま平面の色として再現されるとも限らない。原XMLのIconStyle/画像指定、readerのbillboard、実画面を分ける。点を独自の丸へ補正して綺麗に見せる検証にはしない。 |
| relative高度とextrude | 1407付近と1437付近はrelativeToGround/absolute等を楕円体参照の位置のまま返し、MSL未対応のコメントがある。1605–1626行ではextrude LineStringをWallGraphicsへ変換し、polygon styleの面とline styleのoutlineを使う。1723–1726行ではextrudable polygonにperPositionHeight/extrudedHeight0を設定。 | 楕円体だけのpreviewではrelativeToGroundとabsoluteの地形上の差を検証できない。カーテンが立つ・同じxyへ降りる・色が分かれることは有限に見られるが、実際の地表高度・実飛行の高さ基準・Google Earthでの地形追従は未確認。KML宣言自体の意味は公式仕様と照合する。[Google KML Reference](https://developers.google.com/kml/documentation/kmlreference#linestring) |
| 穴 | SDK 1732–1754行はinnerBoundaryIsをPolygonHierarchy.holesへ移す。previewのreceiptはpolygonの有無と色だけで、穴数/座標を収録していない。 | 原XMLに内環があるだけでなく、他の重なりを消した単独領域で穴から背景グリッドが見えるかを視認する。穴の上に別候補帯や別領域が重なると、穴が潰れたように見えることがある。原XML・読込hierarchy・画面を別々に照合する。 |
| 線の順序と透過 | previewはKmlDataSource.loadへclampToGroundを指定せず、既定false。SDK 1643–1647行ではこのときLineStringのgx:drawOrder非対応を警告する。標準KML読込の一部機能は警告の後も成功しうる。 | 複数半透明面・輪郭・投影線の上下関係を、XML順がそのまま描画順になるとして判定しない。色/alpha/outlineを保存していることと、特定readerの合成像は別。警告が1回だけ出る実装もあるので、再読込で警告なし＝対応済みとはしない。 |

とくに最初のvisibility問題は実害がある。非表示親候補の子孫を含めてKMLへ保存する要件を確かめるとき、初期状態で見えないことは確認できるが、親だけONにして子が出ないことをexportの失敗と判定してはいけない。主担当へこの反例を伝え、previewを補正して「正しく見せる」ことはせず、確認範囲に制約を明記し、raw XMLの検査へ帰属する方針が採られた。

## 3. receiptと視認の使い分け

現在の `KML_PREVIEW_RECEIPT` はid/name/parent/show/isShowing、polygon/polyline/wallの有無、polygonの色を返す。この範囲なら独立証拠として使えるが、**線・点・カーテンの色、線幅、icon、穴、位置/高さ、高度解釈まで検証した票ではない**。必要な観察場面だけ、raw XMLのstyle/visibility/座標を照合し、readerの対応propertyを取得する。すべてのKML機能を扱う大型検査器へ拡張する必要はない。

最小の実視認は次の三場面で足りる。

1. 親A可視/子A+遅延非表示、親B非表示/子B+遅延own可視を含むファイルを**ロード直後に記録**。後からcheckboxを触った結果を初期状態の証拠へ混ぜない。親/子のraw visibilityは別に読む。
2. 同じ禁止領域の外環＋穴と重なる別領域を、単独/重複の両方で読む。色/alpha・境界を比較し、穴越しの人工グリッドを確認する。白塗りが残るならreaderの正常な既定値で問題を隠さない。
3. 上昇/下降の地上線・立体線・カーテンを斜視と真上で比較。色の役割、面の抜け、点アイコンを読む。グリッド楕円体で読めたという有限範囲で記録し、実地形上の高度基準やGoogle Earth互換へ拡張しない。

`NetworkLink`/外部画像を対象外とする入口は本模型の自己出力を読む用途に合う。ただし、これは任意KMLの全対応・完全な外部参照拒否を検証したものではない。KML exporterは本批評時点で別担当の実装中であり、その最終出力への実視認受入はまだしていない。

## 4. 保存SVG：内部倍率の成功だけでは配布物の読取を受入できない

主担当は保存した4図のSVGをstandalone browserで開き、全体が高さ約712pxへ収まって小さくなることを観察した。これは31条件で確認した「内部の全4図が同じ倍率1.08」という事実とは矛盾しない。内部図は同倍率でも、最外SVGの固有寸法が無ければ文書全体がviewerの枠へ適合されうる。

現生成物はviewBoxのみでwidth/heightを持たなかった。SVG2では未指定幅/高さはautoであり、auto/百分率は固有幅/高さの決定には使わない。一方viewBoxは比率を与える。[SVG2 Intrinsic sizing](https://www.w3.org/TR/SVG2/coords.html#IntrinsicSizing)

この用途は保存した図を他の人が開いて読めることなので、「ズームすれば読めるから成功」とはしない。最小修復は**保存物の最外SVGだけ**に自然な幅/高さを付け、viewBoxと内部座標は保持することである。画面内のすべてのSVGへ固定幅を付けると既存responsive配置を壊すため採らない。新しい専用viewerやズームUIも不要。

主担当の追加許可を受け、`weather/app.js` の `exportSVG` が返す最外要素だけを `width="1130" height="1504.56" viewBox="0 0 1130 1504.56"`（現在の年間4図の場合）とするよう修復した。他の保存図も計算済みのW/heightを使い、内容/統計は変えない。固定値1130等を全図へ直書きしたわけではない。

旧 `weather-round2-annual.svg` / `weather-round2-counterexamples.svg` と31条件票は保持した。修復後は `weather-svg-intrinsic-check.cjs/json`、`weather-svg-intrinsic-annual.svg` / `weather-svg-intrinsic-counterexamples.svg` に分けた。既存31条件に最外寸法/画面内responsive維持の2条件を加え、33条件成功。原8,768時刻のu/v・暦所属digestも一致する。source側の確認であり、修復後を主担当が再保存しstandalone表示して読めるまで、browser受入とはしない。

## 5. 指紋と未確認

- 読取時preview JS SHA-256: `cab9d479cb759bdd7ae1b2c662daae2bbd369e29034ea0e9b8796cf342fddc2d`
- 同HTML: `6a55401ccb342fe86289eb0cc6c65d43909e3ff8783c959e3b3d782f902827ee`
- 保存最外寸法修復後 weather/app.js: `0b21dfdc79fb56872dcd5a04e64fb15a5b88faddd8c40476756d24a98a32de41`

本稿のKML判断はsourceの独立批評であり、この担当によるKML実描画やGoogle Earth試験ではない。previewへ注記を追加した後の文面、最終exportの具体的ファイル、Browserにおける修復後SVGは別の確認として追記する必要がある。sourceから確認できない箇所を画面成功として補っていない。
