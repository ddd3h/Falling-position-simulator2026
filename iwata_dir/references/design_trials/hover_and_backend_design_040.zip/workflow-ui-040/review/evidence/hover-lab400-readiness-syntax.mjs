
import {createHoverController} from '../scene3d/src/hover-controller.js';
import {resolveHover} from '../scene3d/src/hover-labels.js';
import {pickSurface,pickedNameBoundaryIndices} from '../scene3d/src/surface-pick.js';
import {createOverlayStore} from '../scene3d/src/overlay-store.js';
import {overlayEntities} from '../scene3d/src/overlays.js';
import {fixture,FIXTURE_CENTER} from '../scene3d/src/fixture.js';
import {validatePayload} from '../scene3d/src/protocol.js';
import {fitBoundsDistance} from '../scene3d/src/camera-fit.js';
const C=window.Cesium,$=id=>document.getElementById(id),map=$('map'),tooltip=$('surfaceHover');
let viewer,store,rendered,busy=true,moving=false,lastPose='',serial=0,updateRevision=0,sampleCount=0,connected=false,gateChecks=0,postRenders=0,moveStarts=0,moveEnds=0;
function readiness(reason='観測'){
 const values={connected,busy,moving,paused:$('paused').checked,rendered:!!rendered,dataSourceReady:viewer?.dataSourceDisplay.ready??null,pickPositionSupported:viewer?.scene.pickPositionSupported??null,sampleHeightSupported:viewer?.scene.sampleHeightSupported??null,entities:store?.items.length??0,gateChecks,postRenders,moveStarts,moveEnds};
 values.canRead=connected&&!busy&&!moving&&!values.paused&&values.rendered&&values.dataSourceReady;
 $('readiness').textContent=reason+' · '+Object.entries(values).map(([key,value])=>`${key}=${value}`).join(' / ');
 return values.canRead;
}
const at=(east,north)=>[FIXTURE_CENTER[0]+east/(111320*Math.cos(FIXTURE_CENTER[1]*Math.PI/180)),FIXTURE_CENTER[1]+north/111320];
function snapshot(){
 const data=fixture(),base=data.candidates[0],eastShift=at(30,0)[0]-FIXTURE_CENTER[0];
 data.snapshotId=`hover-lab-${++serial}`;data.collectionKey='hover-lab400-artificial'+($('longNames').checked?'-overlap':'');data.context.activeCandidateId=$('focus').value;base.focused=$('focus').value===base.candidateId;
 base.label=$('longNames').checked?'同じ接頭辞をもつ比較候補・'.repeat(18)+'A 終端':'人工候補 A';
 const other={...base,candidateId:'fixture-B',resultId:'hover-lab-B',focused:!base.focused,label:$('longNames').checked?'同じ接頭辞をもつ比較候補・'.repeat(18)+'B 終端':'人工候補 B'};data.candidates.push(other);
 const shapes=data.geojson.features.filter(f=>['contour','contour-band'].includes(f.properties.kind));
 for(const original of shapes){const f=structuredClone(original);f.properties.candidateId=other.candidateId;f.properties.resultId=other.resultId;f.properties.color='#ff9d60';for(const ring of f.geometry.coordinates)for(const c of ring)c[0]+=eastShift;data.geojson.features.push(f);}
 data.geojson.features=data.geojson.features.filter(f=>f.properties.kind!=='contour-band'||f.properties.candidateId===$('focus').value);
 const region=data.geojson.features.find(f=>f.properties.kind==='region');region.properties.regionId='lab-region';region.properties.levelName='優先レベル';region.properties.priority=3;
 if($('longNames').checked){region.properties.label='同名領域';for(const [id,priority] of [['second',2],['third',1]]){const copy=structuredClone(region);copy.properties.regionId=id;copy.properties.priority=priority;data.geojson.features.push(copy);}}
 return validatePayload(data);
}
function visible(item){const p=item.properties,kind=p?.kind?.getValue?.()??p?.kind;return kind==='contour-band'?$('showBands').checked:kind==='region'&&item.polygon?$('showRegions').checked:item.polyline?$('showLines').checked:true;}
const hover=createHoverController({target:map,viewport:window,tooltip,canRead:()=>{gateChecks++;return readiness('controller gate');},sample:point=>{
 sampleCount++;const surface=pickSurface(C,viewer.scene,point,store.pickExclusions);
 if(!surface){$('result').textContent=`読取り ${sampleCount}：現在の mesh 位置を取得できません。名称なし。`;return null;}
 const hits=$('showLines').checked?pickedNameBoundaryIndices(viewer.scene,surface.screen,store.items):[];
 const result=resolveHover(rendered,surface.point,{bandsVisible:$('showBands').checked,regionsVisible:$('showRegions').checked,linesVisible:$('showLines').checked,lineFeatureIndices:hits});
 $('result').textContent=`読取り ${sampleCount}：mesh 確認済み／表示対象 ${result.total} 件／境界 feature ${hits.length} 件。${result.targets.map(t=>t.text).join(' / ')}${result.otherCount?' / 他 '+result.otherCount+' 件':''}`;
 return result;
}});
async function update(){hover.invalidate();if(!viewer)return;const own=++updateRevision;busy=true;$('state').textContent='人工の表示を準備しています。';try{const next=snapshot(),prepared=await store.prepare(overlayEntities(C,next));if(own!==updateRevision){store.discard(prepared);return;}for(const item of prepared.items)item.show=visible(item);store.commit(prepared);rendered=next;viewer.scene.requestRender();}finally{if(own===updateRevision)busy=false;}}
function reset(){hover.invalidate();if(!viewer||!rendered)return;const distance=fitBoundsDistance(rendered.camera.bounds,rendered.camera.center,{width:map.clientWidth,height:map.clientHeight,fov:C.Math.toDegrees(viewer.camera.frustum.fovy),pitch:-48});viewer.camera.lookAt(C.Cartesian3.fromDegrees(...rendered.camera.center),new C.HeadingPitchRange(0,C.Math.toRadians(-48),distance));viewer.camera.lookAtTransform(C.Matrix4.IDENTITY);viewer.scene.requestRender();}
function xy(){const x=Number($('x').value),y=Number($('y').value);if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||y<0||x>map.clientWidth||y>map.clientHeight){$('result').textContent='XY は地図の範囲内へ指定してください。';return null;}const rect=map.getBoundingClientRect();$('cross').style.left=`${x}px`;$('cross').style.top=`${y}px`;$('cross').hidden=false;return {clientX:rect.left+x,clientY:rect.top+y,pointerId:400,pointerType:'mouse',isPrimary:true,bubbles:true};}
function stateLater(){setTimeout(()=>{$('state').textContent=`人工背景のみ／Google 0／snapshot ${rendered?.snapshotId}／tooltip ${tooltip.hidden?'非表示':'表示'}／mesh 読取り ${sampleCount} 回`;readiness('入力後 420 ms');},420);}
$('still').onclick=()=>{const event=xy();if(!event)return;map.dispatchEvent(new PointerEvent('pointermove',{...event,buttons:0}));stateLater();};
$('drag').onclick=()=>{const event=xy();if(!event)return;map.dispatchEvent(new PointerEvent('pointerdown',{...event,button:0,buttons:1}));map.dispatchEvent(new PointerEvent('pointermove',{...event,clientX:event.clientX+20,buttons:1}));map.dispatchEvent(new PointerEvent('pointermove',{...event,buttons:1}));map.dispatchEvent(new PointerEvent('pointerup',{...event,button:0,buttons:0}));stateLater();};
$('cancel').onclick=()=>{map.dispatchEvent(new PointerEvent('pointercancel',{pointerId:400,pointerType:'mouse',bubbles:true}));stateLater();};
$('wheel').onclick=()=>{const event=xy();if(event)map.dispatchEvent(new WheelEvent('wheel',{...event,deltaY:0}));stateLater();};
$('position').onclick=()=>{if(!viewer)return;let screen;if($('preset').value==='sky')screen={x:map.clientWidth/2,y:8};else{const presets={roof:[20,0,65],ground:[-50,-30,0],hole:[0,0,65],contour:[105,-60,0],region:[110,0,25]},[east,north,height]=presets[$('preset').value];screen=C.SceneTransforms.worldToWindowCoordinates(viewer.scene,C.Cartesian3.fromDegrees(...at(east,north),height));}if(!screen){$('result').textContent='現在のカメラでは試験地点を投影できません。地域へ戻して試してください。';return;}$('x').value=screen.x.toFixed(1);$('y').value=screen.y.toFixed(1);xy();$('result').textContent='十字の XY を設定しました。静止入力を押すと current mesh を読みます。';};
for(const id of ['showBands','showRegions','showLines'])$(id).onchange=()=>{hover.invalidate();for(const item of store?.items||[])item.show=visible(item);viewer?.scene.requestRender();stateLater();};
for(const id of ['focus','longNames'])$(id).onchange=update;
$('paused').onchange=()=>{hover.invalidate();viewer.useDefaultRenderLoop=!$('paused').checked;if(!$('paused').checked)viewer.scene.requestRender();stateLater();};$('reset').onclick=reset;
try{
 C.Ion.defaultAccessToken='';viewer=new C.Viewer(map,{baseLayer:false,baseLayerPicker:false,geocoder:false,globe:false,animation:false,timeline:false,homeButton:false,sceneModePicker:false,navigationHelpButton:false,fullscreenButton:false,vrButton:false,infoBox:false,selectionIndicator:false,scene3DOnly:true,requestRenderMode:true,maximumRenderTimeChange:Infinity,skyBox:false,skyAtmosphere:false});
 store=createOverlayStore(C,viewer);viewer.screenSpaceEventHandler.removeInputAction(C.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
 viewer.camera.moveStart.addEventListener(()=>{moveStarts++;moving=true;hover.invalidate();readiness('camera moveStart');});viewer.camera.moveEnd.addEventListener(()=>{moveEnds++;moving=false;hover.invalidate();readiness('camera moveEnd');});
 viewer.scene.postRender.addEventListener(()=>{postRenders++;const pose=JSON.stringify([viewer.camera.positionWC.x,viewer.camera.positionWC.y,viewer.camera.positionWC.z,viewer.camera.heading,viewer.camera.pitch]);if(pose!==lastPose){lastPose=pose;hover.invalidate();}if(connected&&!busy&&viewer.dataSourceDisplay.ready&&!moving){$('state').textContent=`人工背景のみ／Google 0／${map.clientWidth}×${map.clientHeight} px／表示準備完了`;}readiness('postRender');});
 const tile=await C.Cesium3DTileset.fromUrl('../scene3d/fixtures/tileset.json',{maximumScreenSpaceError:4,enableCollision:true});viewer.scene.primitives.add(tile);connected=true;await update();reset();for(const id of ['position','still','drag','cancel','wheel','reset'])$(id).disabled=false;
}catch(error){$('state').textContent='人工診断の準備に失敗しました。';$('result').textContent=String(error?.message||error);}
window.addEventListener('pagehide',()=>{hover.destroy();store?.destroy();if(viewer&&!viewer.isDestroyed())viewer.destroy();});
