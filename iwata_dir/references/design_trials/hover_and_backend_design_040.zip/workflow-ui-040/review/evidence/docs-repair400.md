# 0.40 文書責務の限定修復・生成記録

担当 document_audit400。基準 main M390 `7622593e0d4dacb101f9ed86990f2832845494ed`。比較実体 `P400/base-0.39.0` の3MDと、編集前のrepo3MDのSHA256一致を確認して着手した。元local.gitのHEADを基準にしていない。

## 修復理由と範囲

詳細な判定は `doc-audit400.md`。本体が変わらないPROGRAM/THEORY/COMMANDS/INDEXをUI改版ごとに生成し直す必要はない。一方、PLANは完成像を用意する段階から人工操作模型を実計算へつなぐ段階へ進める必要があり、ENV/WGにはS32後のmember取得を現在の次作業として固定したままの案内が残っていた。

主担当から許可された本文編集は次の3MDだけ。健康票・構造登録・指示書・判断台帳・Git操作は主担当の責務として触れていない。

| パス | 変更箇所と意味 | 保持したこと |
|---|---|---|
| `docs/PROJECT_PLAN.md` | metadataと位置づけ、第10.4先頭の現在判断、第10.6、第12章。A入力閉包→B保存GFS一飛行/非同期実行と既存表示→C少数MC/延期→D過去/長期/取得拡張を受入条件で結ぶ | 既存科学出典、0.13〜0.25の取得/試作/16飛行案の履歴、三用途、追加実験を要求しない方針。全モデルをAで作る工程にしない |
| `docs/ENVIRONMENT_CONTRACT.md` | 現validatorが必要とする具体値/単位と径破裂の組合せ制約、recordsの不等間隔/同UTC別相と表示adapterの境界。旧次案内を当時の段取にし現PLAN/接続設計へ結ぶ | 科学式、取得近似、後半の試作契約、外部観測日。一飛行契約へjob基盤の未実装APIを混ぜない |
| `docs/WEATHER_DATA_GUIDE.md` | 近い成果の次案内だけを修復。GEFS調査を撤回せず、完成像から選ぶ現在の一体成果へ接続 | 全API/配布の調査内容と取得観測の確認日。今回の保存GFS接続方針を外部仕様の再認定としない |

ENV/WGのmetadataは編集版として0.40へ更新、先頭の0.24確認印は保持し、今回の限定節に0.40更新/確認印を追加。PLANは変更した4範囲にのみ0.40印を置いた。全資料の科学的全面再確認とは表示していない。

現 `flight/config.py` を全文実読し、表の必須量・単位・径破裂×等温のみの制約・降下密度モデル・既定量を対応させた。未来の入力支援・分布・実行状態は、主担当が作る `docs/INTEGRATION_DESIGN.html` の編集責務へ返した。新資料リンクは主担当の追加と対で最終確認する必要がある。

## 検査と生成

固定基準との差分は `PROJECT_PLAN-400.diff`, `ENVIRONMENT_CONTRACT-400.diff`, `WEATHER_DATA_GUIDE-400.diff`。編集後MDはそれぞれ629/708/487行。各before/after SHA256は `plan-build400-evidence.json`。現作業前に取得した固定ベースとの比較であり、元local.gitの古いHEADとの差分ではない。

PDF skillを適用し、authoring開始markerを edit / count 1 / pdf で一回成功させた。独立copy `P400/plan-build` へMD、既存 `tools/build_docs.py` と `tools/template.tex` を複写して生成。本体3MD以外の生成元コードは変更していない。

専用環境をBUILDと照合：Python3.12.12（Miniforge既存）、Pandoc3.11、XeTeX0.999998/TeX Live2026、Noto Sans CJK JP RegularとNoto Sans Mono CJK JP Regular。専用rootの実行ファイルとフォントが選ばれたことを確認。process内PATH/FONTCONFIG/locale設定のみで、導入・永続PATH・ACLは変更していない。

最初のsandbox内生成は、Pythonが作ったtempdirへXeLaTeXが `PROJECT_PLAN.log` を書けず0頁で停止し、cleanupもWinError5となった。`plan-build/build.stdout`, `build.stderr` に失敗を保存。元repoのTeX/PDFは保った。同じ独立copy・同じ生成器を通常権限で再試行し成功した。`build-retry.stdout`, `build-retry.stderr` に終了証拠を保存。自動承認レビュー拒否が起きたという証拠はなく、最初の失敗はOSの一時領域アクセス拒否である。

成功生成は28物理頁、TeX CRLF0、Overfull/Missing characterのREVIEW行0。Pandocの既存 `--no-highlight` 非推奨警告を1件保持。PDFメタデータとページ本文量、元MDと生成用MDの一致は `plan-build400-evidence.json`、再読補助は `plan-qa400.py`。

Popplerで全28頁を1300px高のPNGへ描画し、4頁ずつの原寸contact画像7枚を全て視認した。表紙0.40/日付、本文と柱、ページ番号、表の反復見出し、数式、コマンド折返し、日本語、改訂した第10.4表と第10.6のA〜D表、第12章を確認。文字欠け・黒塗り・重なり・内容の横はみ出しは見えない。

ただし既存templateの一般的な節移行の問題が露出した：物理p5末尾の太字「過去の窓口調査」がp6の表と分かれ、p10末尾の第7章見出しの本文はp11へ、p14末尾の10.2見出しの表はp15へ移る。意味改訂の担当範囲外であるtemplateの調整要否を主担当へ返した。生成器成功だけで、この節移行が改善済みとはしない。現時点ではrepoのTeX/PDFへ受け入れていない。

## 未確認と次担当

- 主担当：新INTEGRATION_DESIGNとのリンク/論旨整合、変更理由と部分範囲の登録、健康票、指示書実績、固定比較検査、保存/PR。
- 生成担当：主担当の節移行判断後、必要なら独立copyで再生成・全頁再点検し、同じMDからのTeX/PDFを一組として受け入れる。
- 今回は全科学式・全取得仕様・全コマンドの再検証を行っていない。現本体APIやデータの挙動も変更していないため、全物理回帰を追加実施していない。独立監査のAPI索引署名1試験と20module hash一致は別reportの有限な証拠として扱う。

## 見出し孤立の一般修正候補（主担当の追加依頼）

主担当から、独立 plan-build 内だけで template の孤立見出しを改善し、影響を視認して候補を返す指示を受けた。repo の template と TeX/PDF はまだ変更していない。変更前の template・生成 MD/TeX/PDF は `plan-build/baseline` に保持した。

既存導入済みの `titlesec` 本体を読み、`nobottomtitles*` と `bottomtitlespace` の機能を確認した。追加パッケージを使わず、見出しと後続内容に必要な本文行高に比例する余白を確保する。ページ番号を指定する改頁や、特定見出しの名前に依存する処理を入れない。差分は `template-plan400.diff`。

最初の候補 r2 は6行を確保し、全29頁を視認した。元の3箇所は解消したが、後半の「同じ『散らばり』でも、何を比べたかを分ける」見出しだけが表から分離する新たな箇所を発見した。この候補を採用せず、`candidate-r2` と `rendered-r2` / `contact-r2` に残した。

r3 は8本文行を確保する候補とした。同じ専用環境で再生成成功し、29物理頁。Poppler の全29頁を画像化し、contact-r3 の8画像（1〜29頁）を全て視認した。既出の孤立見出しが解消し、章/小節の本文への接続、反復表見出し、数式、コマンド、出典と日本語を確認。文字欠け、黒塗り、本文の重なり、横はみ出し、空白ページは見えない。長表が複数頁に分かれる箇所は保持されるが、表見出しは反復される。変更前28頁から29頁へ増えることと、節間で早めの改頁による余白が増えることは、今回の孤立防止との交換条件である。

本文変更はなく、生成TeXの begin{document} 以降が初回28頁版と完全一致することを追加検査した。主文書にハードコードされた改頁を加えた結果ではない。新しい依存・生成器変更はない。今後どんな長表でも自動的に孤立を完全防止する証明ではないため、文書改訂時の全頁視認は引き続き必要。

採用候補は `plan-build/tools/template.tex` と、同じ生成元による `plan-build/docs/PROJECT_PLAN.tex` / `PROJECT_PLAN.pdf`。PDF SHA256 は `b9406115053c30767cb3b35c6ecf0cd400b1aaeb88fc914eb2311f81e86c6d13`。生成・hash根拠は `plan-build400-evidence-r3.json` と `plan-template400-final.json`。repo への受け入れは主担当の採用判断後に行う。

## 採用と、元量の用語統一

主担当がr3を採用し、repo tools/template.tex と PLAN TeX/PDF を確認済み候補から複写、全byte/SHA256一致を確認した。続く独立設計批評の採否に合わせ、ENV 96の「独立量を標本化」を「元量を結合規則に従って標本化」、PLAN10.6表Cの「一つの独立量」を「一つの元量」へ限定修正した。元となる量が統計的に独立であると誤解されることを避けるためで、科学式・分布の採用変更ではない。

PLANは同じ独立環境でr4を再生成成功。29頁を全てレンダリングし、全頁の画素比較で、物理p27の表C本文の矩形(340,244)〜(576,306)以外はr3と完全一致。p27を単頁画像で再視認し、表Cの用語と折返し・他行との境界が良好なことを確認した。r4の全29頁を再度目視したとはしない。r3の全頁視認＋残り28頁の画素一致＋変化p27の再視認で受け入れた。証拠はplan-r4-pixel-diff.jsonとplan-build400-evidence-r4.json。

r4 PLAN TeX/PDF をrepoへ複写し、独立生成物とSHA256一致を確認。現PDFは `9aad42a246d7c09637e4243d06142b671a28f39040a986dd0b85da3bf793140d`。r3を最終PDFとする以前の記述は、その時点の採用記録として保持する。
