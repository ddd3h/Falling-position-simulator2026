import {cp,mkdir,readFile,writeFile,readdir,copyFile,symlink,lstat,realpath} from 'node:fs/promises';
import {constants} from 'node:fs';
import {join,relative,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';

const taskRoot='C:/Users/genia/AppData/Local/Temp/balloon-design-390';
const source=join(taskRoot,'release/workflow-ui-039/source/cesium-probe');
const runtime=join(taskRoot,'release/workflow-ui-039/scene3d');
const workRoot=join(taskRoot,'rebuild390');
const workSource=join(workRoot,'source/cesium-probe');
const workRuntime=join(workRoot,'scene3d');
const reviews=join(taskRoot,'reviews');
const deps='C:/Users/genia/AppData/Local/Temp/balloon-design-380/cesium-probe/node_modules';
const receiptPath=join(reviews,'scene-rebuild390-final.json');
const hash=b=>createHash('sha256').update(b).digest('hex');
const receipt={startedAt:new Date().toISOString(),source,runtime,workSource,workRuntime,dependencies:deps,node:process.version,googleNetwork:false,browser:false,commands:[],pass:false};

async function inventory(root,exclude=[]){
  const files=[];
  async function walk(dir){
    for(const e of await readdir(dir,{withFileTypes:true})){
      const path=join(dir,e.name), name=relative(root,path).replaceAll('\\','/');
      if(exclude.includes(name))continue;
      if(e.isDirectory())await walk(path);
      else if(e.isFile()){const bytes=await readFile(path);files.push({path:name,bytes:bytes.length,sha256:hash(bytes)});}
      else throw new Error(`Unexpected non-file inventory entry: ${name}`);
    }
  }
  await walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));return files;
}
function differences(a,b){
  const am=new Map(a.map(f=>[f.path,f])),bm=new Map(b.map(f=>[f.path,f]));
  return [...new Set([...am.keys(),...bm.keys()])].sort().flatMap(path=>{
    const before=am.get(path),after=bm.get(path);
    return before?.bytes===after?.bytes&&before?.sha256===after?.sha256?[]:[{path,before:before??null,after:after??null}];
  });
}
async function run(file,args=[]){
  const r=spawnSync(process.execPath,[file,...args],{cwd:workSource,env:{...process.env,BJP_CESIUM_DEPENDENCIES:deps},encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024});
  const stem=file.replace(/\.mjs$/,'');
  const log=join(reviews,`scene-rebuild390-${stem}.log`);
  await writeFile(log,`exit=${r.status}\nsignal=${r.signal??''}\n${r.stdout??''}\n${r.stderr??''}${r.error?`\n${r.error.message}`:''}`);
  receipt.commands.push({file,args,exitCode:r.status,signal:r.signal,log});
  if(r.status!==0)throw new Error(`${file} failed; see ${log}`);
}

try{
  try{await lstat(workRoot);throw new Error('Independent rebuild path already exists; choose a fresh path, never delete it.');}catch(e){if(e.code!=='ENOENT')throw e;}
  if(!resolve(workRoot).startsWith(resolve(taskRoot)+'/')&&!resolve(workRoot).startsWith(resolve(taskRoot)+'\\'))throw new Error('Work path is outside task root');
  const packageData=JSON.parse(await readFile(join(deps,'cesium/package.json'),'utf8'));
  if(packageData.version!=='1.145.0')throw new Error('Fixed dependency version differs');
  receipt.dependencyVersion=packageData.version;
  receipt.sourceBefore=await inventory(source);
  receipt.runtimeBefore=await inventory(runtime);
  const previous=await readFile(join(source,'source-inventory.json'));
  const previousCopy=join(reviews,'source-inventory390-from038.json');
  await copyFile(join(source,'source-inventory.json'),previousCopy,constants.COPYFILE_EXCL);
  receipt.previousInventory={path:previousCopy,bytes:previous.length,sha256:hash(previous)};
  const oldInventory=JSON.parse(previous);
  receipt.previousInventoryDifferences=differences(oldInventory.files,receipt.sourceBefore.filter(f=>f.path!=='source-inventory.json'));

  const readmePath=join(source,'README.md');
  const readme=await readFile(readmePath,'utf8');
  const marker='## 保存前の検査票と観察段階（0.39）';
  if(readme.includes(marker))throw new Error('Final README stage note already exists');
  await writeFile(readmePath,readme.trimEnd()+`\n\n${marker}\n\n最終sourceの純粋検査は scene-unit390-r7.json の167条件成功。独立担当のクリック読取り反例は weather-band-readout390-evidence/checks-after.json の21条件成功で、修復前の票も保持する。前者は実装側の条件検査、後者は独立したsource反例の再検査であり、いずれもGoogle接続や実meshの視認を含まない。\n\n主担当のCUAでは、読み込み済みの人工3D hostで屋根上の50%内、地面の50–90%間・90–95%間・95%外、空の取得不能を別々に確認し、小印と読取位置の一致を観察した。表示module更新後の人工背景・配置・保存視点ボタンの保持と読取りリセット、pan dragで読取りが勝手に変わらないことも主担当の有限観察である。当時のhostには最新の「クリック地点」接頭辞が未適用だったため、最新hostの全変更をこの観察で検証済みとは扱わない。最後の修飾キー反例の修復は上記167/21条件へ帰属する。Google写真mesh上の適合・実接続数・後続受入は主担当の別記録へ戻す。\n\n保存前の独立再生成は、元のsource/runtimeを置換せず、別作業コピーで固定依存を用いて test → make-fixture → build と全runtimeのbyte照合を行う。結果は reviews/scene-rebuild390-final.json、各コマンドlog、scene-rebuild390-test.json に分離する。この再生成はGoogle無し・ブラウザー無しであり、実表示の追加証拠ではない。source-inventory.jsonは本READMEを含むsourceの全ファイルを記録し、自己だけを除外する。旧0.38由来のinventoryは reviews/source-inventory390-from038.json に元byteのまま保持する。\n`);
  const currentSourceFiles=await inventory(source,['source-inventory.json']);
  const nextInventory=JSON.stringify({engine:'cesium@1.145.0',files:currentSourceFiles},null,2)+'\n';
  await writeFile(join(source,'source-inventory.json'),nextInventory);
  receipt.sourceInventory={files:currentSourceFiles.length,bytes:currentSourceFiles.reduce((s,f)=>s+f.bytes,0),sha256:hash(nextInventory),selfExcluded:true};
  await mkdir(join(workRoot,'source'),{recursive:true});
  await cp(source,workSource,{recursive:true,errorOnExist:true,force:false});
  receipt.copiedSourceDifferences=differences(await inventory(source),await inventory(workSource));
  if(receipt.copiedSourceDifferences.length)throw new Error('Initial source copy differs');
  // Only the independent work copy receives this read-only dependency reference.
  await symlink(deps,join(workSource,'node_modules'),'junction');
  receipt.dependencyJunction={path:join(workSource,'node_modules'),resolved:await realpath(join(workSource,'node_modules')),packaged:false};
  await run('test.mjs',[join(reviews,'scene-rebuild390-test.json')]);
  await run('make-fixture.mjs');
  await run('build.mjs');

  const originalAfter=await inventory(source), rebuiltSource=await inventory(workSource,['node_modules']);
  const runtimeAfter=await inventory(runtime),rebuiltRuntime=await inventory(workRuntime);
  receipt.originalSourceChanges=differences(receipt.sourceBefore,originalAfter);
  if(receipt.originalSourceChanges.some(f=>!['README.md','source-inventory.json'].includes(f.path)))throw new Error('Frozen original source changed');
  receipt.originalRuntimeChanges=differences(receipt.runtimeBefore,runtimeAfter);
  receipt.rebuiltSourceDifferences=differences(originalAfter,rebuiltSource);
  receipt.runtimeDifferences=differences(runtimeAfter,rebuiltRuntime);
  const runtimeInventory=JSON.parse(await readFile(join(runtime,'build-inventory.json'),'utf8'));
  receipt.runtimeInventoryDifferences=differences(runtimeInventory.files,runtimeAfter.filter(f=>f.path!=='build-inventory.json'));
  receipt.sourceInventoryDifferences=differences(currentSourceFiles,originalAfter.filter(f=>f.path!=='source-inventory.json'));
  receipt.runtimeComparison={payloadFiles:runtimeInventory.files.length,physicalFiles:runtimeAfter.length,bytesExcludingInventory:runtimeInventory.files.reduce((s,f)=>s+f.bytes,0),allPhysicalFilesCompared:true,buildInventoryIncluded:true};
  receipt.fixtures=rebuiltSource.filter(f=>f.path.startsWith('fixtures/'));
  receipt.pass=['originalRuntimeChanges','rebuiltSourceDifferences','runtimeDifferences','runtimeInventoryDifferences','sourceInventoryDifferences'].every(k=>receipt[k].length===0);
  if(!receipt.pass)throw new Error('Rebuild comparison differs; inspect receipt differences');
}catch(e){receipt.error=e.message;process.exitCode=1;}
receipt.finishedAt=new Date().toISOString();
await writeFile(receiptPath,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({pass:receipt.pass,error:receipt.error??null,receipt:receiptPath,sourceInventory:receipt.sourceInventory,runtimeComparison:receipt.runtimeComparison,commands:receipt.commands.map(c=>({file:c.file,exitCode:c.exitCode})),runtimeDifferences:receipt.runtimeDifferences?.map(f=>f.path)},null,2));
