# 0.40 パッケージ・検査helperの静的監査

2026-09-27、hover400。root依頼で3本の全文を読んだ。helperの実行・import・修正は行っていない。基準M390 `7622593e0d4dacb101f9ed86990f2832845494ed`。監査時の実在位置とSHA256は次の通り。

| P400下の対象 | SHA256 |
|---|---|
| `metadata/package400.py` | `b045418dde8bc04e360215af3ab61bd59494ac2d05acc0c6b42e97f55b0b780e` |
| `metadata/run_checks400.py` | `e406c4fb2cbda87f523135f2cd178abacbae6b81f0a14b645a626d07d99f5add` |
| `metadata/regression400/run_regression400.py` | `99db13e3f309ca998c0a382d793037dbf540cd994d0153bb50d506f347845361` |

**必要修復は回帰helperの成功条件1件。** 末尾はunittestの終了0だけを条件にし、検出した `tested_code_unchanged=false` やGit HEAD変化を失敗終了へ結びつけていない。並行する文書更新は別に記録して許容しつつ、試験code不変・前後Git読取成功・HEAD同一を成功条件へ追加することをrootへ提案した。初回の対象codeのM390との差異はreceiptに記録するが、それだけで科学採用や現実行との同等性を証明しない。

他の重点項目は静的読取上整合した。

- **Pと基準。** package/checksは `metadata/` 所在の `parents[1]`、regressionは実際には `metadata/regression400/` 所在の `parents[2]` なので、いずれもP400になる。baseは0.39、旧108/候補113、M390/treeを用いる。旧0.38基準への変換漏れは対象3本には見当たらない。
- **収録。** sourceは `release/workflow-ui-040` のみ。指定reviewsの `.md/.json/.diff/.mjs/.py/.log` とinputsの `.pdf/.txt/.png` をstageへコピーする。`.py/.log` 追加後を再読した。リンク不成立の `review/integration-design400.html` は明示除外、`.git/node_modules/__pycache__` またはfile symlinkを見つけたら停止する。P400全体やbrowsercache/provider取得物を収録するコードではない。
- **全member。** stageの各fileをsize/SHA256で目録化し、ZIP書込直前に同じbyteを再照合。固定prefix/日時で新規ZIPを作り、既存ZIPを上書きしない。完成ZIPのCRC・member集合・全memberのsize/SHA256を再読照合する。旧8ZIPも固定manifest SHAと照合する。receiptはGit helperが要求する単一object `path/bytes/sha256/members/files/all_member_bytes_verified` と一致する形である。
- **秘密scan。** stageのraw bytesをGoogle APIキー・GitHub token・秘密鍵headerの限定patternで検査し、失敗時に出すのは相対pathだけで一致値は出さない。これは全秘密の検出保証や圧縮PDF内部の全面検査ではない。Google/browserキーを採取する操作は存在しない。rootからのGoogle通信log・browserkey採取無しという運用報告は、pattern scanの結果と区別する。
- **四検査。** state、health＋base、現contract＋transition/base、固定旧contract＋transition/baseの4本を実行する構成で、guardを改変・省略しない。候補113fileを実行前後hashで凍結し、全4結果ok/終了0と凍結成立を終了0の条件にする。receipt/tested-hashes形式は既読Git helperと整合する。`observed_main` は固定定数の記録で、remoteの現在値を取得した証拠ではない。保存直前の別観測が必要。
- **回帰。** 標準 `unittest discover -s tests -v` をそのまま呼ぶ。code pathを宣言集合＋実Pythonファイルから集め、既存M390と前後差を記録する。新規attempt外部directoryへstdout/stderr/receiptを残し、`-B` と環境変数でpycache生成を抑える。試験対象/期待値を書き換えたりskipを追加するコードはない。

この読取は実package完成、scan無一致、四検査成功、回帰成功を意味しない。最終byteに対してrootが実行して得る結果を別に記録する。package後にstage/reviewsへ追記すればZIP内には反映されないため、配布物の収録時点と後続の実績を区別する。

追記：root修復後のregression L59–71を読戻した。SHA256 `d527158e5d3581b8e71e97e85c327c4646af0a841caa5b7f770a0b6e4b8798a6`。今回の実行では文書も凍結する判断により、終了0はunittest終了0/error無しに加え `all_hashed_files_unchanged` と、前後Git読取成功・両HEADが元local固定 `ad3494d700068d873a22ed2fbbf6f0a760a41735` に一致することを要求する。報告対象のhash済み集合の変化を成功終了へ結びつけない欠陥は、この限定読取で解消を確認した。一般的な並行文書更新の説明は残っているが、今回の成功条件はそれも許容しない。この追記でもhelperは未実行。
