
'use strict';
const $=id=>document.getElementById(id),records=[];
const samples={
 json:{type:'application/json',extension:'json',source:'{"fixture":"download-path-probe390","artificial":true,"value":39}\n'},
 kml:{type:'application/vnd.google-earth.kml+xml',extension:'kml',source:'<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>download-path-probe390 artificial</name><Placemark><name>fixture point</name><Point><coordinates>141,43,0</coordinates></Point></Placemark></Document></kml>\n'},
 svg:{type:'image/svg+xml;charset=utf-8',extension:'svg',source:'<svg xmlns="http://www.w3.org/2000/svg" width="640" height="160" viewBox="0 0 640 160"><rect width="640" height="160" fill="#eef4f5"/><text x="24" y="85" font-family="sans-serif" font-size="26">download-path-probe390 artificial</text></svg>\n'}
};
// Core operations mirror the two current helpers. The input generation is held equal.
function forecastPath(data,name,type,record){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.hidden=true;document.body.append(a);record.anchorConnected=a.isConnected;try{a.click();return{bytes:blob.size,name};}finally{a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}}
function weatherPath(data,name,type,record){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;record.anchorConnected=a.isConnected;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);return{bytes:blob.size,name};}
async function run(route,event){const kind=$('kind').value,timing=$('timing').value,sample=samples[kind],number=records.length+1,record={number,route,kind,timing,eventTrusted:event.isTrusted,activationAtClick:navigator.userActivation?.isActive??null,phase:'preparing'};records.push(record);try{if(timing==='microtask')await Promise.resolve();record.activationAtRequest=navigator.userActivation?.isActive??null;const name=`download-probe390-${number}-${route}.${sample.extension}`,result=(route==='forecast'?forecastPath:weatherPath)(sample.source,name,sample.type,record);Object.assign(record,result,{phase:'requested'});$('status').textContent=`${name}（${result.bytes} bytes）をブラウザーへ要求しました。実ファイル到達はこのページでは判定できません。`;}catch(error){record.phase='request-error';record.errorName=error?.name||'Error';$('status').textContent='保存要求処理が失敗しました。';}finally{$('log').textContent=JSON.stringify(records,null,2);}}
$('forecast').onclick=e=>run('forecast',e);$('weather').onclick=e=>run('weather',e);
