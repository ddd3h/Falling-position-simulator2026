# KML投影面の材質を追った記録

2026-09-26。rootの独立読込で「立体線は見えるが投影面の色を判別しづらい」と報告されたため、透明度を変更する前に原XMLとreaderを照合した。GUIの判読評価はroot担当であり、ここはsourceの確認。

`forecast-source390/overview-parent-hidden.kml` のC3上昇/下降はvisibility=1、LineStringはextrude=1、tessellate=0、altitudeMode=relativeToGround。上昇のPolyStyle色は `0eb97214`、下降は `0e1559c3`、いずれもfill=1。KMLのaa値0eは14/255≒0.0549で、面色は正しく青/橙に指定されている。LineStyleはalpha0、width0。独立した立体線を別Placemarkに出すため、投影面の縁は二重に出さない設定である。

KML標準のLineString extrusionでは線にLineStyle、地面への面にPolyStyleを使用できる。今回の高度モードもextrudeに許される形式で、XMLの指定だけから「面色を指定していない」とは判断できない。[Google KML Reference — LineString](https://developers.google.com/kml/documentation/kmlreference#linestring)

固定SDK実sourceは `balloon-design-380/cesium-probe/node_modules/.pnpm/@cesium+engine@26.3.0/node_modules/@cesium/engine/Source/DataSources/KmlDataSource.js`。1070–1081行でPolyStyleのcolor/fillをpolygonへ読み、1605–1626行でextrudeのLineStringからWallGraphicsを生成、polygon.material/fillをwallへ渡し、line側はoutlineColor/widthへ用いている。現0.39配布vendor/Cesium.jsの対応するminified関数 `jLe` にも同じ分岐と代入があることを読んだ。公式1.145タグのsourceにも同じ処理がある（行番号は配布packageと異なる）。[Cesium 1.145 KmlDataSource source](https://github.com/CesiumGS/cesium/blob/1.145/packages/engine/Source/DataSources/KmlDataSource.js)

したがって、読込後のwall.materialもXMLの薄い青/橙を受け取る設計である。GPUで実際に画素へ出たことの証明ではないが、第一仮説は「面を生成しない/色を取り違えた」より、5.5%の薄さと見る角度である。真上からの視点では垂直面が細くなるので、斜め視点でも比較する必要がある。

比較用だけに `curtain-alpha-14-comparison.kml` と `curtain-alpha-22-comparison.kml` を作った。全対象、visibility、高度、線、帯は同じで、curtain用2StyleのPolyStyle alphaだけを14%/22%へ変えている。どちらもruntime既定へ採用したとは記録しない。主担当が地物を隠さずに面の役割を読めるかを比較する。

別の限界として、同じ固定readerの1427–1443行は線のrelativeToGround/absolute座標を楕円体参照のまま返す。wallも読んだ座標をpositionsへ渡す。ローカル確認は人工楕円体背景なので、KML標準が意味する実地形からの高さを検証できない。保存形式の模式AGL指定、readerの描画近似、本体の高さ基準は分けて残す。

## 同じreader/視点での比較後の採否

rootがCUAで5.5%・14%・22%を同じ独立readerと視点で比較した。5.5%はほぼ見えず、14%も薄い一方、22%では上昇青/下降橙の地面までの面を識別でき、人工グリッドと背後の点も透けたとの実物報告を受領した。この可読性判断により、rootの依頼でruntimeのcurtain既定を22%へ変更した。実地形/全背景で最適な値の科学的採用ではない。

元5.5%の `overview-parent-hidden.kml` と14/22%比較ファイルは変更せず保持する。新既定のsourceから再生成する出力は `overview-parent-hidden-final.kml` と別名にし、原比較の証拠を上書きしない。これはKML出力側の変更で、接続済みの3D背景やsceneの表示層を変更しない。
