import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='C:/Users/genia/AppData/Local/Temp/balloon-design-400/release/workflow-ui-040/';
const files=['forecast/hover400.mjs','forecast/hover-geometry400.mjs','shared/hover-labels.mjs'];
const hashes=Object.fromEntries(files.map(f=>[f,createHash('sha256').update(fs.readFileSync(root+f)).digest('hex')]));
class Node{
 constructor(){this.listeners=new Map();this.children=[];this.style={};this.hidden=true;this.attributes={};}
 addEventListener(e,f){this.listeners.set(e,[...(this.listeners.get(e)||[]),f]);}
 removeEventListener(){}
 emit(e,args={}){for(const fn of this.listeners.get(e)||[])fn(args);}
 append(x){this.children.push(x);}
 replaceChildren(){this.children=[];}
 setAttribute(k,v){this.attributes[k]=v;}
 getBoundingClientRect(){return this.id==='mapNameHover'?{left:0,top:0,right:180,bottom:50,width:180,height:50}:{left:0,top:0,right:500,bottom:300,width:500,height:300};}
 closest(){return null;}
 querySelector(selector){return selector==='.leaflet-tooltip'&&this.nativeTooltip?this.nativeTooltip:null;}
}
const container=new Node(),win=new Node(),doc=new Node(),body=new Node(),timers=new Map();let next=0;
doc.hidden=false;doc.body=body;doc.createElement=()=>new Node();doc.querySelector=()=>null;
globalThis.document=doc;globalThis.window=win;globalThis.innerWidth=500;globalThis.innerHeight=300;
globalThis.setTimeout=(fn)=>{const id=++next;timers.set(id,fn);return id;};globalThis.clearTimeout=id=>timers.delete(id);
const events=new Map(),map={getContainer:()=>container,on(names,fn){for(const name of names.split(' '))events.set(name,[...(events.get(name)||[]),fn]);},containerPointToLatLng:()=>({lng:0,lat:0}),latLngToContainerPoint:([lat,lon])=>({x:250+lon*100,y:150+lat*100})};
const feature={type:'Feature',properties:{kind:'region',regionId:'r1',visible:true,label:'test region',fillOpacity:.2},geometry:{type:'Polygon',coordinates:[[[-1,-1],[1,-1],[1,1],[-1,1],[-1,-1]]]}};
let documentReads=0,currentFeature=feature;
win.BJP_HOVER_HOST={map,canRead:()=>true,document:()=>{documentReads++;return {context:{kind:'overview'},candidates:[],features:[currentFeature]};}};
await import(new URL('file:///'+root+'forecast/hover400.mjs').href+'?audit='+Date.now());
const tip=body.children[0],pointer={clientX:250,clientY:150,pointerType:'mouse',buttons:0,target:new Node()},flush=()=>{for(const [id,fn]of[...timers]){timers.delete(id);fn();}},emitMap=name=>{for(const fn of events.get(name)||[])fn();};
container.emit('pointermove',pointer);flush();const idleLabelVisible=!tip.hidden;
win.BJP_MAP_HOVER.invalidate();emitMap('movestart');container.emit('pointermove',pointer);flush();const labelDuringMove=!tip.hidden;
emitMap('moveend');win.BJP_MAP_HOVER.invalidate();emitMap('zoomstart');container.emit('pointermove',pointer);flush();const labelDuringZoom=!tip.hidden;
emitMap('zoomend');emitMap('movestart');emitMap('zoomstart');emitMap('moveend');container.emit('pointermove',pointer);flush();const labelAfterOneOfTwoMotionsEnds=!tip.hidden;
emitMap('zoomend');container.emit('pointermove',pointer);flush();const labelAfterBothMotionsEnd=!tip.hidden;
container.nativeTooltip=new Node();container.emit('pointermove',pointer);flush();const labelOverNativeTooltip=!tip.hidden;
container.nativeTooltip=null;container.emit('pointermove',pointer);container.nativeTooltip=new Node();flush();const labelIfNativeTooltipOpensDuringDelay=!tip.hidden;container.nativeTooltip=null;
currentFeature={...feature,properties:{...feature.properties,label:'new region'}};
container.emit('pointermove',pointer);flush();const oldInventoryUntilCommit=tip.children[0]?.textContent==='領域：test region',hoverDocumentReads=documentReads;
win.BJP_MAP_HOVER.commit(win.BJP_HOVER_HOST.document());const commitClearedLabel=tip.hidden;
container.emit('pointermove',pointer);flush();const labelAfterCommit=tip.children[0]?.textContent;
doc.hidden=true;doc.emit('visibilitychange');container.emit('pointermove',pointer);flush();const labelWhileHidden=!tip.hidden;doc.hidden=false;
const {contourIndices}=await import(new URL('file:///'+root+'forecast/hover-geometry400.mjs').href);
const closeToRegionBoundary=contourIndices([feature],{x:148,y:150},([lon,lat])=>({x:250+lon*100,y:150+lat*100}));
const checks={idleLabelVisible,labelDuringMove,labelDuringZoom,labelAfterOneOfTwoMotionsEnds,labelAfterBothMotionsEnd,labelOverNativeTooltip,labelIfNativeTooltipOpensDuringDelay,oldInventoryUntilCommit,hoverDocumentReads,commitClearedLabel,labelAfterCommit,labelWhileHidden,closeToRegionBoundary};
assert.equal(idleLabelVisible,true);assert.equal(labelDuringMove,false);assert.equal(labelDuringZoom,false);assert.equal(labelAfterOneOfTwoMotionsEnds,false);assert.equal(labelAfterBothMotionsEnd,true);
assert.equal(labelOverNativeTooltip,false);assert.equal(labelIfNativeTooltipOpensDuringDelay,false);assert.equal(oldInventoryUntilCommit,true);assert.equal(hoverDocumentReads,1);assert.equal(commitClearedLabel,true);assert.equal(labelAfterCommit,'領域：new region');assert.equal(labelWhileHidden,false);assert.deepEqual(closeToRegionBoundary,[0]);
console.log(JSON.stringify({observedAt:new Date().toISOString(),hashes,checks,assertions:13,scope:'Fake DOM and timers exercise the unmodified production module; no browser, Google connection, or live physical pointer observation.'},null,2));
