# 0.40 名称 hover 独立批評

担当：document_audit400。2026-09-27。repo 本体は編集せず、P400 配下の候補を読取・診断した。根本ニーズは「いま指している落下分散／指定領域を少数の名前で識別し、地物との関係を読める」ことであり、tooltip の存在自体を受入にしない。

## 判定

3D の責務分離は意図に合う。名称識別を Google の地物メタデータや新しい provider 接続へ結び付けず、実表示中の分析対象へ限定し、表示世代・カメラ移動・エラー・一時停止で無効化している。候補 ID／結果 ID と領域 ID で重複を除き、落下分散と領域を一つずつ優先して最大二件にする設計は、名前を知るという狭い目的に対して妥当である。

一方、2D の最初の実装には 3D と同じ認識規則が最後まで接続されていなかった。移動中抑止・既存点 tooltip との競合・領域輪郭・長い名前が対象である。共通 resolver を import することだけでは、操作中の対象が一致する保証にならない。

以下の行番号は最初の独立読取時点の候補。変更後は下の再点検欄を優先する。

## 具体的指摘と方向

### H1 — 地図の慣性移動／ズーム中に名称が再出現する（要修正）

`forecast/hover400.mjs:9,35` は `movestart zoomstart` で一度消すが、動作中の状態を `canRead` に持たない。その後にボタンを離した pointermove が入り、260 ms より長く移動が続くと、名称を表示できる。表示後の move も無効化対象でないので、背景と対象の移動に tooltip が取り残される。

これは単にタイマーの検査項目がない問題ではない。人間がカメラを操作している間は、座標が変わる対象へ名前を固定しないという操作上の一貫性が必要である。3D の `cameraMoving` と同じ考え方を 2D へ適用し、move／zoom の開始から完了まで抑止する。開始・終了の重なりを一つの bool で早期解除しないよう、独立状態を持つとよい。

独立診断 `hover-2d-independent400.mjs` は本番 2D module を偽 DOM／偽 timer へ import して実行。通常静止時の表示が true である対照のもと、`movestart → pointermove → timer` と `zoomstart → pointermove → timer` はどちらも表示 true になった。結果と読取 SHA256 は `hover-2d-independent400-before.json`。これは実ブラウザの慣性を見たという証拠ではなく、制御経路が動作中を許す直接的な反例である。

### H2 — SVG 点の旧 tooltip と面の新 tooltip が競合する（要修正）

`forecast/app.js:37,39,43` では着地点・平均点・干渉点の `L.circleMarker(...).bindTooltip(...)` が残る。`hover400.mjs:12` は `.leaflet-marker-icon` と control を除くため、SVG circleMarker は除かれず、点の tooltip と、その背後の面／輪郭の名称が同時に出得る。名前を絞る意図に反し、どちらの説明を読めばよいかが曖昧になる。

点の既存説明に優先を与えて新 hover を抑止するなど、どちらかを選ぶ。点の tooltip 自体をこの作業の都合で削除する必要はない。輪郭も `.leaflet-interactive` になるので、その class を一律除外すると今回の目的が失われる。点だけを識別する class または layer 種別で区別するべきである。

この指摘はソースからのイベント競合推論であり、同時表示の実画面観察は未実施。修正の受入は点の直上とすぐ外で優先が切り替わること。

### H3 — 領域の輪郭名がホスト間で異なる（要修正）

最初の 3D は fill OFF にして輪郭だけ残した指定領域を識別できなかった。写真を読みたい利用で fill を消すのは自然なので、名称も失うべきではない。この指摘を受け 3D `pickedNameBoundaryIndices` と共通 resolver は region 境界へ対応済み。

ただし独立読取時の `forecast/hover-geometry400.mjs:9` は kind=contour のみを受け、region の画面上の近傍を除外した。2D では通常 fill があるため内部は出るが、領域境界の外側や穴側からの近傍では 3D と違う。独立診断は region 境界の外 2 px で indices=[] を確認した。輪郭を名前対象とする方針に合わせて region も含め、穴の内部そのものは対象外のままにする。

### H4 — 長い領域名の末尾欠落（要修正、通常名の可読性も確認）

2D `hover400.mjs:27` は高さを `maxHeight` で制限し、`style.css` 最後の `.map-name-hover` は `overflow:hidden`。ファイル名／施設名が長いと、区別に必要な末尾だけが消え、単なる別名として誤読され得る。候補名は入力上限があるが、import した領域名には同じ上限がない。

3D は先頭と末尾を残す明示的な中間省略に修正され、aria-label へ全名を保持する。2D でも同じ説明原則を用いる。通常長の名称は全文表示を優先し、短縮を常用して名称確認の目的を損なわない。aria-label のみを「人間が読めた」証拠にはしない。

## 採用に適する既存の判断

- `resolveHover` は Google feature 名を取り込まず、現在 payload のみを見る。分散の 50/90/95 複数線や band を同じ候補としてまとめる。
- Polygon の hole 内部を除外し、MultiPolygon を和集合として扱う。重なる領域は同一 regionId で重複計上せず、異なる名前は別対象として数える。
- 一覧を増やし続けず最大二件＋他件数。優先候補と高優先領域を一緒に読める。残数は要素数でなく対象の数。
- 3D は実表示 payload と受領 payload の一致、dataSourceDisplay.ready、停止・エラー・更新・カメラ動作を `canRead` にまとめた。差替えと rollback、表示切替、disconnect、pagehide も無効化する。
- `pickSurface` は public な current mesh API に限定し、未読込・unsupported は名前を推測しない。既存 tile 接続・renderer を利用し、hover のための新しい Google session や most-detailed fetch を追加していない。
- `textContent` と DOM 要素を使い、領域名を HTML として解釈しない。controller は host lifetime、resolver は純粋関数であり、表示 refresh のたびに listener を重ねない。

## 実装を広げる前に持つ問い

`analysisDocument()` を 2D hover のたびに作るため、全候補の classify・ellipse・mean route を再構成する。現人工模型の規模で直ちに失敗と判定しないが、将来の大規模結果では「表示中の対象 inventory」を描画時に固定し、hover はその索引だけを問い合わせる方が適する。サンプルの再計算と表示の名前読取を結び付けないという境界を backend 接続設計でも守る。

識別を絞るために除外したもの（支持境界、軌道、飛翔中点など）は、その名称が不要という永久決定ではない。今回の中心ニーズから意図的に外した範囲として記録し、利用上の問いが生じてから足す。

## 再点検

初回独立点検時の 3D 既存 `runHoverTests()` は **82 確認成功**。これは renderer を起動しない単体確認であり、Google 写真上で全対象を正しく pick できたという証拠ではない。

2026-09-27 09:54 UTC の 2D 反例は上記 JSON に保持。実装担当の修正後、同じ反例をもう一度当て、結果をここへ追記する。

### 修正後の独立再点検（2026-09-27 09:58 UTC）

`hover-2d-independent400-after.json` に SHA256 付きで保存。偽 DOM へ実 API 相当の `container.querySelector('.leaflet-tooltip')` を追加し、修正前からの静止・move・zoom・領域境界の反例に加え、開始の重なりと非同期競合を確認した。期待値を実装出力に合わせて緩めてはいない。

**13 確認成功**：静止時は名前を表示、移動中／ズーム中は非表示、move と zoom の一方だけ終了しても非表示、両方終了後に再び表示。既存点 tooltip が pointermove 時点である場合と、待機中に開いた場合の両方で新 tooltip は非表示。commit 前は旧表示 inventory を読み、commit で既存名を消し、次の hover で新名を読む。hover を繰り返しても `host.document()` は初期一回のみ。document.hidden では表示しない。領域境界の外 2 px は index 0 を得る。

H1／H2／H3 はこれらの制御経路と該当実装読戻しにより解消と判定。H4 は 2D も shared `shortenHoverText` で先頭・末尾を保持する明示省略に揃い、aria-label の全名と `overflow:hidden` 撤去を確認したため、静的な欠落原因は解消。長い実名の画面上の読みやすさは root の UI 点検へ残し、この偽 DOM の固定高さを描画品質の証拠とはしない。

`app.js:44` の描画末尾 `commit(analysisDocument())` と module 初期 snapshot を読戻した。将来への提案であった「hover で全分析を再構成しない」も今回の実装へ取り込まれた。描画と名前 inventory の所有が同じ更新点になったことは、計算量削減以上に、名前が何の表示に属するかを明確にする改善である。

## 読取境界と留保

実読：3D `hover-labels.js`, `hover-controller.js`, `surface-pick.js`, `overlays.js`, `overlay-store.js`, `protocol.js`, `hover-test.mjs` 全文。`main.js` の hover 生成、可視性、表示 commit／rollback／refresh、accept、camera／rendererror／pagehide、`style.css` と index の対象位置。2D `hover400.mjs`, `hover-geometry400.mjs`, `scene-document.js` 全文、`app.js` の drawMap・bindTooltip・各 mode・snapshot／analysisDocument・host 公開、対象 CSS と script 読込順。

独立実行：上記 82 単体確認と偽 DOM の 2D 制御反例。repo 編集・Google 接続・実ブラウザでの新規 pointer／hover 操作・課金 request は行っていない。root の UI 診断や他担当の build 再現検査を、自分の実施として数えない。

途中の疑いとして挙げた 3D tooltip の border-box 不足は、`style.css:1` の全体 `*{box-sizing:border-box}` を確認して撤回した。renderError 時の居残りも、`restorePreviousPresentation()` が失敗早期 return 前に invalidate することを確認し、指摘にしない。
