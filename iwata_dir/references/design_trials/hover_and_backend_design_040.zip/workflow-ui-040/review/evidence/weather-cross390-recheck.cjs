// Independent source-only counterexamples. No browser, provider, network or key.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const base=path.resolve(__dirname,'../release/workflow-ui-039'),out=path.join(__dirname,'weather-cross390-evidence');fs.mkdirSync(out,{recursive:true});
const mainFile=path.join(base,'source/cesium-probe/src/main.js'),main=fs.readFileSync(mainFile,'utf8');
fs.writeFileSync(path.join(out,'main-after-read.js.txt'),main);
function node(tag='div'){return {tag,textContent:'',childNodes:[],dataset:{},style:{setProperty(){}},setAttribute(k,v){this[k]=v;},append(...a){this.childNodes.push(...a);},replaceChildren(...a){this.childNodes=a;},querySelectorAll(){return this.childNodes.flatMap(x=>[x,...x.querySelectorAll()]).filter(x=>['button','input'].includes(x.tag));},remove(){this.removed=true;}};}
const elements={},el=id=>elements[id]??=node();el('presentationStyle').id='presentationStyle';
const document={getElementById:el,createElement:node},store={current:null,previous:null,async prepare(definitions){return {items:definitions};},commit(layer){this.previous=this.current;this.current=layer;},rollback(){if(!this.previous)return false;this.current=this.previous;this.previous=null;return true;},discard(){},get items(){return this.current?.items||[];}};
const renderer={PRESENTATION_REVISION:'source-counterexample',overlayEntities:(_,p)=>p.geojson.features.map(f=>({id:f.id,properties:f.properties}))};
const catalog={PRESENTATION_REVISION:'source-counterexample',catalogView:(_,p)=>{const n=node();n.textContent=p.snapshotId;return n;},bandLegend:p=>p.context.kind};
const ctx={document,console,crypto:{},TextEncoder,structuredClone,normalizeSceneColor:c=>c,parent:{},window:{},C:{},renderer,catalog,store};vm.createContext(ctx);
vm.runInContext(`const $=id=>document.getElementById(id);let viewer={scene:{requestRender(){}}},payload,renderedPayload,overlayStore=store,overlayModule=renderer,catalogModule=catalog,renderRevision=0,presentationError=null,previousPresentation=null,intentPending=null,receiveError=null,entityItems=[];const diag={};const viewMemory={updateCollection(){return false;},has(){return false;}};function updateConnectButton(){}function updateViewMemoryUI(){}function updateCatalog(){if(renderedPayload)$("candidates").replaceChildren(catalogModule.catalogView(document,renderedPayload,sendIntent,{busy:!!presentationError||renderedPayload!==payload}));}function sendIntent(){}function visibilityFor(){return true;}function resetCamera(){}function status(t){$('status').textContent=receiveError||presentationError||t;}function receipt(p){return {snapshotId:p.snapshotId,selection:p.context.selection.count,featureCounts:{landing:p.geojson.features.length}};}function validatePayload(p){return p;}`,ctx);
const section=(a,b)=>main.slice(main.indexOf(a),main.indexOf(b,main.indexOf(a)+a.length));
vm.runInContext(section('function updateSummary(next)','function loadPresentationCss('),ctx);
function snapshot(id,count){return {snapshotId:id,title:id,context:{kind:'detail',selection:{count,denominator:60}},candidates:[{candidateId:'A',label:'A',focused:true,available:true,visible:true,color:'#08788b',probabilityDefinition:'definition '+id}],notes:[id],geojson:{features:Array.from({length:count},(_,i)=>({id:id+'-'+i,properties:{kind:'landing'}}))}};}
const flatten=n=>[n.textContent,...n.childNodes.map(flatten)].join('|');
(async()=>{
ctx.first=snapshot('selected-two',2);ctx.second=snapshot('selected-zero',0);
await vm.runInContext('accept(first)',ctx);await vm.runInContext('accept(second)',ctx);
const before=vm.runInContext('({summary:$("contextSummary").textContent,receipt:$("receipt").textContent,renderedId:diag.renderedSnapshotId,renderedEntities:diag.renderedEntities})',ctx);
vm.runInContext('restorePreviousPresentation()',ctx);
const after=vm.runInContext('({summary:$("contextSummary").textContent,definition:$("definition").textContent,receipt:$("receipt").textContent,renderedId:diag.renderedSnapshotId,renderedEntities:diag.renderedEntities,shownIds:overlayStore.items.map(x=>x.id),status:$("status").textContent})',ctx);
assert.equal(after.renderedId,'selected-two');assert.equal(after.shownIds.length,2);assert.match(after.summary,/選択 2\/60/);assert.match(after.receipt,/selected-two/);assert.equal(after.renderedEntities,2);assert.equal(vm.runInContext('diag.acceptedSnapshotId',ctx),'selected-zero');
const catalogSource=fs.readFileSync(path.join(base,'source/cesium-probe/src/catalog.js'),'utf8');
vm.runInContext(catalogSource.replace(/^import[^\n]+\n/,'').replaceAll('export ',''),ctx);
ctx.clean={context:{kind:'overview'},candidates:[{candidateId:'A',parentId:null,label:'A',focused:true,available:true,visible:true,color:'#08788b',resultId:'old-result',pending:false}],geojson:{features:[]}};
ctx.dirty=structuredClone(ctx.clean);ctx.dirty.candidates[0].pending=true;
const clean=flatten(vm.runInContext('catalogView(document,clean,()=>{})',ctx)),dirty=flatten(vm.runInContext('catalogView(document,dirty,()=>{})',ctx));assert.notEqual(clean,dirty);assert.match(dirty,/入力未反映/);
const inv=JSON.parse(fs.readFileSync(path.join(__dirname,'forecast-source390/overview-inventory.json'),'utf8'));
const bands=inv.features.filter(f=>f.properties.kind==='contour-band').map(f=>f.properties);
const report={sourceSha256:crypto.createHash('sha256').update(main).digest('hex'),scope:'actual source functions with minimal DOM/store mock; no browser/GPU/Google',rollback:{before,after},pending:{clean,dirty,identical:false},bandProperties:bands};
fs.writeFileSync(path.join(out,'counterexamples-after.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});

