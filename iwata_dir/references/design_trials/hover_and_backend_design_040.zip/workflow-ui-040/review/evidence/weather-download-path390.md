# 保存要求と実ファイル到達を分けた調査 — 0.39

基準 main M380 `19bf0cc5cd32509a44ca8e246f4294ab0972d61e`。対象は未統合候補 `release/workflow-ui-039`。担当 weather370 はソース読取、キー不要 fixture の作成、指定済み Downloads 2ファイルの複製・構造確認のみ実施した。CUA と実保存操作は root が担当した。現在の Google 接続中の親タブには触れていない。

## 結論

同じ現行 helper を使う新しい予報タブでは、実際の模型 UI から候補 JSON と分析地図 KML が Downloads に到達した。旧タブでの未到達は保持する。**新タブで保存できたことは確認できたが、旧タブが保存できなかった内部原因や旧タブの復旧は確認していない。** helper の DOM 寿命差を修正して直った結果ではなく、ソース不変での対照観察である。

「KML を生成」「ブラウザへ保存要求」「物理ファイル到達」「外部 reader で表示」は別段階である。今回最後まで確認したのは下記2ファイルの物理到達・複製一致・構造解析まで。Google Earth の表示や科学的意味の受入ではない。

## ソースとイベント経路

| 対象 | 実読箇所 | 内容と意味 |
|---|---|---|
| forecast helper | `forecast/app.js:168` | Blob URL、body に追加した hidden anchor、同期 click、直後 anchor 除去、60秒後 URL 破棄。 |
| 候補 JSON | 同176 | ボタンから直接同期呼出し。モーダルは使わない。 |
| 分析地図 KML | 同225–226 | モーダル確認後、同期生成から helper へ。phase は generate/download-request/requested であり、requested は実保存の受領票ではない。 |
| モーダル適用 | 同74–75 | dialog を閉じてから保存処理を呼ぶ。modal 外要素の inert が、JSON と KML 両方の失敗原因である説明は支持されない。 |
| weather SVG | `weather/app.js:95,112` | exportStandalone を await した後、DOM へ追加しない anchor を click、1.5秒後 URL 破棄。 |

forecast の document click handler はメニューを閉じるだけで、export click に対する preventDefault はない。地図・contextmenu 用の preventDefault と区別した。forecast HTML に CSP/sandbox 指定は見当たらず、weather は self/GSI を限定する CSP を持つ。ライブ旧タブが保持する JS のバイト同一性は本担当では取得していない。

実読時 forecast app SHA-256: `fc2d68231004e275d0f8943ec032f00df778858fd2f18c11d18f6d59ba3187e2`。weather app: `0b21dfdc79fb56872dcd5a04e64fb15a5b88faddd8c40476756d24a98a32de41`。

HTML 標準の click は合成イベントの発火であり、保存完了の返答ではない。download の保存処理は UA 側で行われる。この区別は current receipt の requested という表現に合うが、特定 IAB の失敗原因を標準だけから断定はできない。[HTML Standard: activation](https://html.spec.whatwg.org/multipage/interaction.html#dom-click)、[downloading resources](https://html.spec.whatwg.org/multipage/links.html#downloading-resources)

## 原因仮説を絞った経過

| 仮説 | 反証・残る範囲 |
|---|---|
| KML 生成で例外 | 旧タブで requested と約373 KB が得られており弱い。新タブでは実 KML を XML 解析できた。 |
| KML MIME の拒否 | 先行 octet-stream 比較でも未到達、JSON も未到達だった。新タブは標準 KML MIME で成功。一般的な MIME 拒否は支持されない。 |
| Blob URL を早く破棄 | forecast 現行60秒でも旧タブで未到達。weather は1.5秒で物理保存された。主因とする根拠はない。 |
| 大きすぎるファイル | weather SVG 約1.69 MB は到達し、旧 KML 約373 KB は未到達。単純な共通サイズ上限は弱い。 |
| DOM 追加・即除去の違い | 専用 fixture で両方式が同じ66 bytesのJSONを保存できた。差自体を失敗原因とする証拠なし。 |
| 特定タブの保存状態／IAB ホスト処理 | 現行実模型を新タブで保存すると成功。旧タブとの差として残る。ただし多数保存の制限など具体的なホスト内機構は未確認であり断定しない。 |

## 専用 fixture（実模型の代用品ではない）

`review/download-path-probe390.html` は同じ小さいデータを2つの helper の anchor 操作へ渡す。JSON/KML/SVG と同期/Promise 後を選べるが、自動保存や連続再試行はない。模型の state、キー、外部通信には触れない。

fixture SHA-256 `797d19cb92ac38d69f9e85004a095515130b9434587a3e113916f5308391fe89`。抽出 JS の `node --check` が成功。root の CUA 観察では新タブ9、JSON/同期で各ボタンを1回実行し、`download-probe390-1-forecast.json` と `download-probe390-2-weather.json` が各66 bytesで物理到達した。本担当はその2ファイルを複製・解析していない。これは helper 単体比較の root 観察であり、実模型保存成功へ置き換えない。

## 実模型 UI の物理保存確認

root は Google に接続しない新規 forecast タブ10を開き、通常の「この候補を保存」と「分析地図KML」→モーダル「保存」を実行した。旧 Google 親タブ7は維持している。

| 原 Downloads ファイル | bytes | SHA-256 |
|---|---:|---|
| `balloon-A-r1.json` | 747 | `14e081006d08f1bb5404360455b725dd9c079a856f4561a625eaab1bcfd2dbe5` |
| `balloon-analysis-039.kml` | 133470 | `3bf09c18018051c2345743e5b792e2f75741e5274fbbbf5d7609c37ac904fd97` |

本担当は指定2ファイルだけを `reviews/download390-evidence/` へ複製し、原本とのバイト一致を確認した。原本は変更していない。JSON は valid、候補「標準案」、result r1、人工模型の注記あり。KML は標準 namespace の XML として読み取れ、37 Placemark、5 Folder、17 LinearRing は全て明示閉環、2333座標の lon/lat は数値範囲内。候補 A/B は各18 Placemark、指定領域 Folder は空である。この初回ファイルに4候補・2領域・非表示親の確認を含めない。

実行スクリプト `reviews/inspect-download390.py`、受領票 `reviews/download390-evidence/physical-download390-first.json`。受領票を上書きせず、追加事例は別ファイルへ記録する。

## 残る確認

- root が初回実 KML を独立 reader へ渡して視認する。XML parse は表示受入にしない。
- root が新タブで4候補・2領域・非表示親を構成して保存する場合は、別受領票へ記録し、旧タブ未到達や今回初回成功を消さない。
- 旧タブの原因追跡は未解決。Google 接続を維持する必要がある間は全体再読込を行わない。新タブ成功だけを根拠に、旧タブ内部のダウンロード状態を回復したと記録しない。
- weather の成功メッセージはコード上は保存要求後に「保存しました」と表示する。今回の weather 実ファイル成功とは別に、一般に物理完了を検出する API は用いていない。修正するなら source 凍結を解除する判断が必要で、本担当は変更していない。

## 追加の実保存と全目録・可視性（初回とは別の標本）

root は同じ新規予報タブ10で「二つの人工領域を追加」、+30/+60分の遅延子を作成、親Aを非表示、遅延子2候補とBを表示してから、全4候補と全領域のKMLをUIで保存した。Downloads `balloon-analysis-039 (1).kml` は381012 bytes。別名 `download390-evidence/balloon-analysis-039-expanded.kml` へ複製し原本と一致、SHA-256 `6d985ec16038981506e6dc2db9721040e427306f2e78b39982cba1e3fbce9c7b`。初回2候補の実ファイルと受領票は保持した。

`inspect-download390-expanded.py` と受領票 `download390-evidence/physical-download390-expanded.json` は、raw XMLの親子構造から own visibility と実効可視性を別に記録する。Cesium reader が子へ焼き込んだ entity.show を根拠にしない。

| XML中の候補/容器 | own visibility | 内容 |
|---|---:|---|
| A系列容器 | 1 | 3候補は同じ階層の子Folder |
| A 標準案 / r1 | 0 | 46 Placemarkを保持、実効非表示 |
| A ＋0.5時間 / r3（C3） | 1 | 51 Placemarkを保持 |
| A ＋1時間 / r4（C4） | 1 | 53 Placemarkを保持 |
| B系列容器 / Bモデル比較r2 | 1 / 1 | 21 Placemarkを保持 |
| 指定領域 | 1 | L1-Z1（穴あり1polygon）とL2-Z1（重複領域2polygon）を別の2 Placemarkで保持 |

全体174 Placemark、7 Folder、4780座標、37 LinearRingは明示閉環。数値lon/lat範囲は妥当。raw XMLでの実効可視101/非表示73であり、SDKのentity数とは同じ概念ではない。Aの輪郭はlocalVisible=trueを保持しつつ候補可視=falseで抑制され、親を隠したために子2候補が隠れる構造にはなっていない。Aの各帯にはupper/lowerの累積被覆数と、帯内人数ではないという定義が残る。

root 続報では、初回133470 bytesの実UI保存KMLを独立 reader へ渡し、55 entity/可視43、相別22%カーテンと線・輪郭を視認した。本担当による画面確認ではない。

続いて root は追加4候補の実保存KMLを同じ標準 reader で読み、209 entity/可視120、A親unchecked、+30/+60checked、B表示、指定領域の色・透過・干渉点を視認した。個別 object の初期非表示に従って経路等が隠れることも確認した。raw XMLの全目録保持は本担当、独立 reader の描画は root に帰属する。

この2事例については、**実模型UI→Downloads実ファイル→バイト一致保管→XML構造→独立reader表示**の経路が成立したとして限定受入できる。旧タブの未到達と内部原因未特定は残る。Google Earth、実地形のrelative高さ、全ブラウザ・全端末の保存品質はこの確認へ加えない。上述「残る確認」の初回/追加 reader 予定はこの続報で完了し、過去の予定文を履歴として保持する。
