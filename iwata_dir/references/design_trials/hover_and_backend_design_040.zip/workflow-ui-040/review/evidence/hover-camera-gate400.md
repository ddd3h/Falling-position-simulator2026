# 実物診断で見つかった静止判定の停止

主担当からの CUA 観察（人工 lab）：実際の canvas に形状と線はあるが、静止入力後も mesh 読取り 0、tooltip 非表示。可視 readiness は `dataSourceReady=true`、`moving=true`、`moveStarts=1`、`moveEnds=0`、`canRead=false`。`postRenders=2480` に増えても止まらなかった。その後追加した public camera delta は up.x / up.y の差が約 `-2.220e-16`、right.z が `-3.123e-16` という微小値だった。これは root が実画面から報告した観察であり、本担当がブラウザーを操作したものではない。

固定 Cesium 1.145.0 / engine 26.3.0 のローカル一次 source を確認：`Scene/View.js` の cameraEqual は位置を最大成分で正規化し、direction / up / right / transform / frustum とともに EPSILON15 で比較する。最後の変更から cameraEventWaitTime を超えると moveEnd を出す。`DataSourceDisplay.ready` は初回全 Entity の準備を待つ sticky な値で、今回の UI は true であった。ready 由来の停止という当初の仮説は、この観察で除外した。

r2 host は SDK の moveStart boolean を moveEnd まで保持し、postRender の exact JSON の差でも毎回 hover を取り消す。微小な姿勢数値差が続くと、視認上の静止にかかわらず永続的に停止する。SDK 自体の欠陥や唯一の誤差生成源まで断定しない。**host が視認上の静止をイベント終端と完全数値一致に依存させた設計を修正すべき**という判断である。

試験案を lab のみへ実装：world position / direction / up / fov / aspect の累積有意差を観測し、最後の有意差から 260 ms を読むまでの静止条件とした。位置は 1e-5 m、向き・画角は 1e-10 の微小許容。基準を毎 frame 更新しないため、遅い実移動も累積して判定する。SDK の moving は診断値として表示し、readiness の sole gate には使わない。exact JSON の取消も lab から撤去。

これは lab の修復案であり、まだ本担当は修復後の actual pick を視認していない。production main.js / scene3d runtime / 接続中の Google host は変更していない。source テスト 261 条件や前回 417 ファイル同一は、この実物の停止を検出していなかった。これらを hover の実物完成の根拠にはしない。主担当の修復後観察を待ち、適切なら純粋な安定判定 module と有限反例へ落としてから production へ反映する。
