# 0.39 予報側の第一実装と修復の根拠

2026-09-26 / forecast370。基準はM380固定模型。第一巡・第二巡批評の後、rootの限定依頼に従い `release/workflow-ui-039/forecast/` と `shared/scene-style.js` だけを変更した。repo本文、source基準、scene/weather、キー・Google接続は変更していない。

実装の単位は次のとおり。

- `shared/scene-style.js`：離散パレット、レベルの色解決、全hit IDsを保持する最高レベルの選択、排他帯のPolygon/穴、色の形式変換。面の確率区間を50/40/5%の確率と呼ばない。
- `forecast/scene-document.js`：候補/結果/領域から対象一覧を作る。通常3Dは可視geometry、KMLは全geometryを生成する。同じ意味を二つの描画ライブラリから逆取得しない。
- `forecast/export390.js`：名前/Style/visibility/ExtendedData/地表線/模式AGL線/投影面をKMLへ変換。点アイコンはdata URIで自己完結し、既定の黄色pinへの依存を避ける。
- `forecast/appearance390.js`：系列色の離散選択と、レベル名・順位・色の低頻度編集。通常地図を大きな設定表で占有しない。
- `forecast/app.js`、HTML/CSS：既存操作へ接続。2Dの排他帯と小凡例、飛翔中の黄中心/暗縁点、領域のファイル単位/必要時の領域別割当、v2親正本の操作、保存入口を扱う。

v2は全candidate catalogと可視geometryを分ける。hiddenへのfocusで自動showしない。detailは概要hiddenでも既存の注目1候補の選択群を表示し、概要の可視編集を拒否する。0選択は0のまま。intentは絶対値、古いsnapshotIdは拒否して現在snapshotとACKを返す。collectionKeyは全候補の結果ID、zoneVersion、詳細のactive/result/selectedIDsから作り、focus/visibility/色/帯を含めない。cameraやMCをintentで再計算しない。

KMLでは候補Folderのvisibilityと、各オブジェクト自身のlocalVisibleを分けた。非表示親の図形すべてへeffective falseを二重保存すると、親を戻しても図形が消えたままになるためである。系列Folderは関係の容器、親候補と遅延子はその中の別Folderとして表現する。固定Cesium KmlDataSourceの祖先visibility焼込みは、元XMLのown visibilityとは別のreader制約としてroot/weatherが評価中。

rootの初回実物批評を受け、KMLボタンを50/90/95操作の間から地図操作末尾へ移し、単体保存を「この候補を保存」とした。未設定の領域に関する常設のレベル色説明は省略した。詳細の飛行中statusには黄中心/暗縁の小点見本を添え、上位領域色が黄色系でも「何の点か」を色だけに依存させない。概要で非表示の候補をdetailへ開いたとき、mapContextまで「非表示」と誤表示しないようにした。

## 有限の検査

`forecast-source-check390.cjs` は実sourceの純粋部分をVMで動かし、人工fixtureから文書を生成する。27項目成功。hidden親/visible子、全catalogとgeometryの区別、90%を隠しても95帯の内側穴を残す、全hit IDs・最高level、hidden領域を判定へ残す、表示変更でcollection同一、全候補hidden、detail hidden/3選択/0選択、m変換と模式AGL、KML色順序、self-contained icon、leafのlocalVisible、stale/focus/visibility/detail拒否とMC不変を確認した。DOM操作・描画の受入ではない。最初のharnessは補助関数conditionNumberの取込不足で停止し、その取込だけ補い再実行した。実装の不具合と検査器の不足を混同しない。

KML XMLはPython標準XML parserでも読取り、全styleUrl参照が解決しNetworkLinkがないことを確認した。overviewは121 Placemark/28 Style、領域は2/2。fixtureは `forecast-source390/overview-parent-hidden.kml`、`regions.kml`。inventoryとv2 snapshotのJSON、検査項目一覧も同所に保存した。第一実装5JSの構文検査は成功した。

実描画はroot所有のキー不要ローカルCesium KmlDataSource入口で別途評価する。楕円体背景では実地形との差やGoogle Earth本体の動作は保証できない。KMLの線種/縁取り/背景は元画面と完全なピクセル一致にはならない。今回の人工AGLは新しい出力用表示仮定であり、fixtureの科学的高さ基準を採用した意味ではない。

この時点で完成/受入は宣言しない。root/scene側とのv2往復、実際の近接図・複数候補・KML再表示、面の重なりと視認性に対する独立批評を受けて修復を続ける。

## 統合判断を読み直して追加した、資料へ残す境界

`root-design390.md` 第1–5節を読み、同じ対象のまま読む/比較する/持ち出すという目的、詳細にvisible条件を誤適用しない訂正、補助輪郭の保持、背景と表示の寿命を分ける判断が、上記実装に対応することを照合した。rootのCUA実観察と当担当のsource検査は独立した証拠として扱う。

人工hの表示仮定を伝える場所は、(1)「分析地図KML」の保存確認文、(2)KML Documentのdescription、(3)各立体線/投影面のdescriptionおよびExtendedData.definitionである。一般の2D分析画面には長い常設注意を加えない。変換は相別進行率を揃えた同じ標本のh平均[km]→mであり、KMLのrelativeToGroundへ渡す。この出力用の見立てを、元データのAGL定義が検証できた事実や、本体でAGLを採用する決定へ移さない。本体の高さ基準、海面/楕円体等の変換、実地形との接触は未受入である。

全目録とは現在の固定結果に対応する概要対象の集合である。可視geometryだけの3D snapshotとは別に、同じ結果から全対象を生成する。非表示の候補・非表示の割合帯・干渉点表示OFF時の干渉対象もKML内へ残し、初期表示を記録する。未計算候補は名前の容器と未計算説明を持つが図形を捏造しない。入力未反映なら旧結果を保存する。全MC時系列や、計算途中の状態、完全な編集再開セッションは保存していない。分析KMLは点/線/立体形状を含むので、従来の「禁止領域を追加」というPolygon専用読込へ戻すためのファイルではない。禁止領域セット保存は別の入口として残す。

KMLの読込結果はreaderごとに評価する。今回の独立経路は固定Cesium KmlDataSourceで、Google Earth実機ではない。祖先visibilityを子のshowへ焼き込む読込、線種や縁取りの扱い、地形の解像度、半透明面の重なり等は原XMLが同じでも差が出る。XMLに全対象とown visibilityが存在すること、readerへ入った後に対象を再表示できること、最初の見た目が読めることを別々に記録する。地面へのextrusionの存在を、楕円体の人工背景だけで実地形に沿う面の受入へ広げない。

## 接続を増やさず再現する入口

1. 展開した `release/workflow-ui-039` で `python -m http.server 8390 --bind 127.0.0.1` を起動し、`http://127.0.0.1:8390/forecast/` を開く。HTTPはローカル。2D地理院背景は外部タイル取得を伴うが、Googleへの接続操作は不要。
2. 共通の準備で二つの人工領域を追加する。「レベルと色」で上位レベルを追加し、重複領域へ割り当てる。その領域を非表示にしても干渉数が変わらず、テーマ色と最高レベル色が対応することを調べる。段階の上下交換も同じ着地点で比べる。
3. Aに遅延子を作り、親Aを非表示、子だけ表示、Bを非注目表示にする。90%の表示を切り、95帯の内側を塗りつぶさないことを確認する。「分析地図KML」で保存し、保存確認とdescriptionの人工高さ仮定を読む。
4. 模型を再計算しない独立反例は `node reviews/forecast-source-check390.cjs` で生成する（本作業配置ではreviewsとreleaseはP390直下）。fixtureと検査のJSONは `reviews/forecast-source390/`。このharnessはDOMを代用しているので、UIの使いやすさや実描画を受け入れる検査ではない。
5. root所有の `http://127.0.0.1:8390/review/kml-preview.html` へfixture KMLを読み、穴・帯・透過・親子の初期表示・立体線/投影面を確認する。これはキー不要の別reader検査。接続済みGoogle画面をこの確認のために再読込・切断しない。

実際にGoogle背景で批評する段階は主担当が管理する。表示色・帯・注目の変更が新しいMC結果や背景接続を必要としない設計と、実際に新規リクエストが発生したかの観測は区別して残す。

追記：rootの同一KML reader/視点での5.5/14/22%比較を受け、curtainは22%を今回の既定にした。詳細は `curtain-material390.md`。原5.5%と比較2ファイルを保持し、現在sourceの生成先を `overview-parent-hidden-final.kml` へ分離した。現在のharnessはこのfinal版を生成する。title/topbarの現行模型表記も0.39へ修復した。ディスクの変更を既に開いているページへ適用済みとは主張しない。

独立weather批評を受けた語義修復：contour-bandの `count` は実装上、上側輪郭の累積被覆数だった。帯内部の人数と誤読し得るため `upperContourCount` / `lowerContourCount` に分け、帯から曖昧なcountを除いた。輪郭自体のcountは維持する。帯のdefinitionにも累積被覆であることを記す。新しい帯内点判定や科学的確率計算を足す変更ではない。scene担当がそのまま受信可能と確認し、source反例検査もこの語義を追加した。

KMLの線表現を再批評し、標準LineStyleで破線をそのまま移せないことを、単なる互換性の注意だけで済ませないよう修復した。帯がない非注目候補でも各輪郭を識別する必要があるため、root採用により50%太/90%中/95%細の3段階の幅へ代替した。注目は3.2/2.4/1.6 px、非注目は2/1.5/1 px。名称とDocument descriptionにも対応を残す。元画面の破線とピクセル単位に同じという主張はしない。
# 実UIの保存未着を受けた切り分け（追加）

主担当のCUA操作では、人工2領域とAの+30/+60分を作成してKML保存を押しても、ダイアログが閉じる一方Downloadsへ現れず、downloadイベントも待ち時間切れになった。これはpure-source検査では検出できなかった実導線の未了であり、原因を生成失敗と断定しない。

実stateと同形の4候補・既定1レベル・人工2セットで `exportOverviewKML()` を実行し、`forecast-source390/overview-default4-two-sets.kml` の生成は成功。handlerへ生成/保存要求の段階を分けたtry/catchを入れ、`KML_EXPORT_LAST`へphase・候補/領域セット数・bytes・error名のみ残す。UIは「生成し、ブラウザへ保存を要求した」と表示し、OSへの保存完了とは言わない。失敗時は生成前か生成後かを短く示す。

共通downloadのanchorをDOMへ一時追加してclickし、Blob URLの保持を1秒から60秒へ延ばした。ブラウザの非同期取得を支える修復だが、これが原不具合の原因であるという証拠はまだない。DOMダブルで生成/要求の成功と両段階の失敗を分離できることを確認し、source反例検査は32件成功。実ブラウザの保存到達・再読込は主担当の再評価待ちである。無キー、既存Google接続には触れていない。

## 保存MIME比較の非採用

主担当が同じIABでapplication/octet-streamへの変更を比較したが、373 KB生成と保存要求の通知のみでDownloads未到達だった。候補JSONも未到達であり、KML MIMEだけが原因という仮説は支持されなかった。KMLの2経路は標準application/vnd.google-earth.kml+xmlへ復帰した。DOMへのanchor追加・60秒URL保持・生成/保存要求のエラー区別は保持。実ファイル到達は未受入として専用ブラウザでの検証課題へ残し、生成fixtureと独立reader描画の成功とは区別する。
