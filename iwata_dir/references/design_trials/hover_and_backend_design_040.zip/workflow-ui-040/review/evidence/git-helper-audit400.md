# 0.40 外部Git helperの実行前読取監査

2026-09-27、hover400。対象は `P400/git_helpers/` の `common400.py`（155行）、`save_git.py`（96行）、`readback_plan.py`（14行）、`verify_readback.py`（37行）、`manifest.py`（20行）、`prepare_pr.py`（21行）。全行を読み、既存の固定観測JSONの関連key/値と照合した。helperのimport・実行・保存操作・Git通信は行っていない。この報告はrootの実行releaseではない。

基準M390 `7622593e0d4dacb101f9ed86990f2832845494ed`、tree `090a1620d46bb05e4fffdb933d6d64cd93ff8186`、予定branch `codex/ui400-hover-backend-design`。

## 修正提案

**保存後照合のPR簡略形式を、今回使う観測形式へ限定することを推奨する。** `verify_readback.py` L4–10では、公式のnested `head`/`base` 形式なら両repoのprivateを要求するが、平坦な形式へのfallbackではprivateを調べず、base repoを観測値ではなく `REPOSITORY` 定数で補っている。そのため同じ成功記録が示す「両repoを観測して同一private repoと確認した」という根拠が形式によって異なる。修正案は今回の公式nested形式のみを受け、head/base両方のdict、repo ID/private/full_nameとPR番号を照合すること。平坦形式を残す場合は相当する実観測項目を必須にし、存在しないbase情報を定数で補完しない。rootへ報告済み。監査担当は修正していない。

`common400.py` L95–97のPLAN stamp-only例外は、L18でPLANがALLOWEDに入ったため現状到達しない。今回PLAN本文の案内修復を許容したこととは整合するので保存阻害の欠陥ではないが、将来読者がstamp-only制限が働くと誤解しないよう、不要分岐の整理または意図の注記が望ましい。

## 読取で確認したゲート

| 論点 | 確認根拠と限定結論 |
|---|---|
| 基準/数量 | common L8–17、61–79がM390と108旧path＋明示5新path＝113を要求する。現存 `main-observed` / `tree-observed` / `recovery400` / `base-manifest` は対応keyを持ち、main/tree、blob108、manifest108、matched108が宣言と一致 |
| private/対象repo | 固定 `repo-observed` のID 1373721672、full_name、private=true、default_branch=mainを読取確認。common L141–155はroot releaseと15分以内の別観測を要求し、再度同一ID/private/mainを検査する。ただし今回の観測は保存直前の鮮度証明ではない |
| 新5asset | `hover_and_backend_design_040.zip`、`INTEGRATION_DESIGN.html`、Excelレビュー/manifest/原ZIPをNEWで列挙。旧108のpath set保持と合わせて照合する。ALLOWEDにPLAN md/tex/pdf、ENV/WG、SOURCES、template.texが含まれ、今回の予定編集を表現している |
| 元local .git | common L50–60が元HEAD `ad3494d...` と実.git pathを読み、全fileのsize/hash fingerprintを作る。save/manifest/planは前後を比較し、元repoではrev-parse/git var等の読取のみ。checkout/reset/add/update-ref等の変更操作はない |
| 外部bare | save L21–31がP400直下・元repo外・非symlink・所有receipt・remote一致・alternates無しを要求する。init/fetch/hash-object/mktree/commit-treeはここへ限定される |
| main非書込 | push先は固定作業branchのみ。mainはfetch/ls-remote/readback比較の対象で、mainへpushやmergeする命令はない。競合する他者のmain更新自体を防ぐものではなく、前後照合で停止/報告する設計 |
| C1 | common expected_parent=M390。save L52はbranch未存在、commit-tree親=M390。L77–78は空のexpected-old付きleaseで既存branch置換を拒否する |
| C2 | expected_parentは保存済C1＋113file固定読戻し＋実PR番号を必須にする。C2 pathset不変で変更を6記録fileへ限定。commit-treeの唯一の親はC1、leaseは同じC1なので許される更新はその直系FFだけ |
| 再試行 | pendingがあると同一版・basis・manifest・親・tree・検査証拠を要求し、remoteが期待headまたは同じcommitの場合だけ再開する。相違時に新commitを作って押し直す経路ではない |
| byte固定 | current_manifestが113対象のsize/git blob SHA1/SHA256/modeを作り、metadata manifestとの全一致、4検査receipt＋tested hashesとの全一致、書込直前再照合を要求する |
| 113file読戻し | verify L15–25がtree非truncated・blob113・重複無し・pathset・mode/size/blob SHA・commit親/tree/main・PR head/base/draft/open/unmergedを照合する。全blobの再download/SHA256ではなくGit object identityによる全path一致という検証方法 |
| 認証値 | remoteは資格情報を含まない固定https URL。Git既存認証を用い、interactive promptを止め、stderrは選別した固定語以外を隠す。認証値を引数・receiptへ保存する処理はない。git identityはcommit生成用環境変数へ渡し、診断receiptには出さない。commit自身にGit著者情報が必要なのは通常の保存動作 |
| PR作成の役割 | prepare_prはC1固定tree/全pathを照合し、base=main/head=固定branch/draft=trueの具体JSONを外部へ書くだけ。API呼出しやmergeを行わない。既存PRの直前lookup・実作成・attachはrootの既存connector手順 |

## 機械変換とJSON schemaの確認範囲

6ファイル内を旧0.39/0.38、旧branch、旧main SHA、旧countで検索した。残る108・base-0.39.0・M390・PR27は今回の基準/過去PRとして整合する。新PRは27より大きい実観測番号を要求し、仮番号を作らない。LOCAL_HEADは元local.gitを変えないための別IDでありM390へ置き換えるべき値ではない。

既存JSONの形は、main=`commit.sha` / `commit.commit.tree.sha`、tree=`sha,tree,truncated`、recovery=`main,tree,matched`、base manifest=`path,mode,bytes,git_blob,sha256`で、helperの読取形と一致する。

監査時点で下記はまだ存在せず、実物schemaとの最終照合はできていない。存在しなければhelperは保存前に失敗するため、未確認を埋めて実行可能と扱わない。

| root作成予定の入力 | helperが要求する形 |
|---|---|
| `metadata/package400.json` | 単一object、絶対 `path` が新模型ZIPと一致、`bytes/sha256/all_member_bytes_verified=true/members/files`。members＝files件数＝unique member path数 |
| `metadata/git-manifest400.json` | `path,bytes,mode,git_blob,sha256` の配列。113対象を現在manifestと順序込み全一致 |
| `metadata/git-preparation400.json` | `base_commit/base_tree/branch_proposed/expected_registered_paths` がM390/tree/branch/113 |
| `validation-{C1,C2}-final/receipt.json` | basis/tree/main、113/108、検査中不変、resultsは正確にstate/health/contract-new/contract-oldの4つ、各ok=true/exit_code=0 |
| `tested-hashes.json` | 全113path→SHA256 object、現在manifestと全一致 |
| `git-release400.json` | root release、版/対象root/basis/main/branch/tag/実PRまたはnull、鮮度観測へのP400内path |

`readback_plan` はPR有無で計画ファイル名を分けるが、raw remote-commit/tree/mainの出力先は共通である。実connectorで二度読み直す際は、既存原観測を無言で上書きせず、同一固定証拠を再使用するか別名で残すというroot側運用が必要である。

## 監査の限界

対象helperは一度も実行していないため、Python構文/実環境Git動作/認証/実remote状態/pack転送成功は未確認。今回ファイル内に資格情報を見出すための無差別secret探索は行っておらず、資格情報を扱う呼出し/出力経路を読んだ。上の修正提案と実物schema照合をrootが処理し、完成済成果・検査・直前remote確認の後にのみreleaseする。

## rootによるPR形式修復の読戻し

同日、rootが修復した `verify_readback.py` 全37行を再読した。SHA256は `09667c28e72bcd55f22b1c522a041e34dcf20131e851206e7ccc3645cd14143a`。L5でhead/base双方のnested dictを必須にし、L6–8で双方のrepo ID/private/full_nameを観測値から照合する。旧平坦形式とbase repo定数補完は除かれた。PR番号は呼出し側L22で実観測と照合する。初回のprivate形式差の指摘はこの読取範囲で解消した。その他の未生成metadata、実行・remote鮮度の未確認は継続する。この再確認でもhelperの実行は行っていない。
