const fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const root='C:/Users/genia/AppData/Local/Temp/balloon-design-390/baseline-model/workflow-ui-038';
const context=vm.createContext({window:{}});
const fixture=fs.readFileSync(root+'/weather/fixture.js','utf8');
vm.runInContext(fixture+'\nglobalThis.F=window.WindFixture;',context);
const F=context.F,FM=require(root+'/forecast/math.js');
const uv=(from,speed)=>[-speed*Math.sin(from*Math.PI/180),-speed*Math.cos(from*Math.PI/180)];
const cases=[
 ['north-wrap',[uv(359,10),uv(1,10)]],
 ['west-wind',[[20,0],[20,0]]],
 ['opposed-strong',[[20,0],[-20,0]]],
 ['all-calm',[[0,0],[0,0]]],
 ['weak-but-constant',[[.01,0],[.01,0]]],
 ['empty',[]]
].map(([name,vs])=>({name,summary:F.summary(vs)}));
const circle=Array.from({length:20},(_,i)=>({id:'circle-'+i,lon:Math.cos(i*Math.PI/10)*.1,lat:Math.sin(i*Math.PI/10)*.1}));
const clusters=Array.from({length:20},(_,i)=>({id:'cluster-'+i,lon:(i<10?-.15:.15)+.006*Math.cos(i*Math.PI/5),lat:.006*Math.sin(i*Math.PI/5)}));
const contain=(samples)=>[.5,.9,.95].map(p=>{const e=FM.ellipse(samples,p);return {p,rank:e.rank,actualCount:e.count,threshold:e.threshold};});
const blend=(fg,bg,a)=>fg.map((x,i)=>Math.round(x*a+bg[i]*(1-a)));
const a=[0,150,190],b=[150,75,200],photo=[80,100,75],alpha=.18;
const result={basis:'M380 19bf0cc5cd32509a44ca8e246f4294ab0972d61e',scope:'Read-only execution of fixed artificial helpers. Synthetic counterexamples, not real weather or flight validation.',wind:cases,ellipse:{tiedCircle:contain(circle),bimodal:contain(clusters),bimodalNearestSampleToMeanDegrees:Math.min(...clusters.map(x=>Math.hypot(x.lon,x.lat)))},compositing:{alpha,aOverB:blend(a,blend(b,photo,alpha),alpha),bOverA:blend(b,blend(a,photo,alpha),alpha),sameAlphaNested3:1-(1-alpha)**3,note:'Illustrates order dependence and accumulated opacity; not screenshot/perceptual acceptance.'},sourceHashes:Object.fromEntries(['weather/fixture.js','weather/app.js','forecast/math.js','source/cesium-probe/src/overlays.js'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(root+'/'+p)).digest('hex')]))};
fs.writeFileSync(__dirname+'/meaning-counterexamples390.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
