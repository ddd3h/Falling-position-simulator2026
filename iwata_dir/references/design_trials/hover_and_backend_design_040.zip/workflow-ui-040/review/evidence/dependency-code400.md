# 0.40 文書依存変更に対する既存コードの限定読取

記録日：2026-09-27。担当：hover400（root から独立して読取）。基準：main M390 `7622593e0d4dacb101f9ed86990f2832845494ed`、比較用固定展開 `P400/base-0.39.0`。P400 は `C:/Users/genia/AppData/Local/Temp/balloon-design-400`。

結論：下記5ファイルは固定M390とbyte一致し、全文を読んだ範囲では、今回の ENV-CONTRACT の案内修復・入力境界追記、および新資料の管理登録に伴うコード変更は不要である。実行時に読む入力と、文書管理上の依存を区別できる。新しい接続設計やExcel参考ZIPの登録だけで、将来機能・科学仮定・入力変換が既存実行へ入る経路はない。check_contract は登録資料を管理用の本文・構造・byteとして読むことがあるが、その内容をPythonとして実行したり飛行設定へ変換したりしない。

これは既存コード全体の科学監査でも、試験の再実行結果でもない。今回の読取時点では CONTINUITY/CONTENT_HEALTH の最終0.40登録が未反映であり、最終登録への検査合格を述べていない。root が登録・構造移行記録を完成させ、固定M390に対する通常の検査で別途確定する。

## 読取方法と固定範囲

現在の対象5ファイルと固定展開の SHA256 を照合後、全行を読んだ。ENVIRONMENT_CONTRACT は固定M390との全差分と、その差分を含む周辺を読んだ。CONTINUITY/CONTENT_HEALTH は対象scope・assetと現在版情報を読み、checkerの全実装から追加登録の判定経路を確認した。レビュー中に対象コードのimport・実行・テスト・外部通信は行っていない。編集はこの報告のみ。

| scope ID | 対象 / 全読範囲 | SHA256（現在＝M390） |
|---|---|---|
| ENV-NORMALIZER | `tools/normalize_gfs_fixture.py` L1–300 | `2f041a6145bf5ec1be4dfb8bd58837c179e30b59bbcee21fbf8648617c2c2ff0` |
| ENV-TEST | `tests/test_environment.py` L1–329 | `9f238e22e05982254b64b51dcb493b490e7c81cc478a01d584f28cc8e58a4e5a` |
| MODEL-COMPOSER | `tools/compose_model.py` L1–351 | `288015dcfe5fd163e4122aa2d960cf65d8854d8e004d43c450ee16b18289270c` |
| FORECAST-PLANNER | `tools/plan_gfs_forecast.py` L1–292 | `ad74113c5b58becb1ebc1df355a90eb26ef8f070fddd702e59f804715d738e28` |
| VERIFY-CONTRACT | `tools/check_contract.py` L1–468 | `43718e6e0b009b291220c13eb551c7e8831b9358ef44eae3d4500a455a6fe668` |

今回読んだ ENV 差分は、版・日付、限定確認の説明、L80–100の「操作模型から一標本の実入力へ進む境界」、L134–142の「一体成果の成立条件」の案内修復、および末尾空行である。gpm専用試作契約、静的構成器、GFS時刻計画器の既存本文・数値規則を今回書き換える差分はない。入力境界表の `flight/config.py` との全面照合は別担当の成果であり、この5scopeレビューで代用しない。

## ENV-NORMALIZER

**実装根拠。** L37–88はUTC・有限値・支持区間・配列の入口、L90–154は明示された軸/場の整合と地下/欠測mask、L156–203は各列のgpm補間から水平・UTC補間へ進む照会である。正の重みを持つ全cellを要求し、外挿・欠測橋渡し・重みの再正規化・経度wrapを行わない。L205–218は幾何高度変換・地表空隙補完・着地・全飛行・予報精度・一般adapterを未受入と明示する。

**実入力。** L221–267の `load_fixture(root)` は兄弟の `inspect_gfs_fixture.py` を固定パスで読み、明示された `root/references/gfs_p1_fixture/manifest.json` とそこに記録されたローカルGRIBを処理する。gh/t/u/vと地表量、hPa→Pa、初期UTC＋leadという処理も不変。L249/257は原GRIB/manifestの読取中変化を拒否する。L269–300の証拠書出し/CLIは別の新規出力先に限定される。

**今回の依存影響・変更不要理由。** ENV-CONTRACT の `source_paths`/`depends_on` 登録は仕様・再確認の関係である。このモジュールはMarkdown/CONTINUITY/新HTML/参考ZIPを読み込まず、references全体の自動探索も行わない。ENVが将来の入力解決と現行一飛行を分けたことは、gpm限定試作を新runtimeと混同しない既存境界に沿う。案内修復に合わせて実行規則を変える必要はない。

**未確認。** ecCodes/NumPyの現在環境、実GRIB再デコード、問い合わせ結果の再実行、一般GFS・全飛行・高さ変換・実大気精度は今回未確認。読んだ兄弟inspectorの呼出し境界を超えて、その全実装を再監査したわけではない。

## ENV-TEST

**実装根拠。** L15–19は対象normalizerを固定パスでimportする。L22–56で人工場/照会を構成し、L59–254は既知のaffine場・一定風・端点・範囲外・UTC・非有限値・地下・欠測・支持重み・配列変更・外部出力制限等を調べる。L257–325は既存ecCodes/NumPyが無いとskipし、固定manifestをnormalizer経由で読み、原GRIBの直接デコード値・3時刻・gpm・地下mask等を別に照合する。ゼロ風の200秒確認は規定した照会予定であり、飛行モデルの実装ではない。

**今回の依存影響・変更不要理由。** テストの入力は人工配列または固定GRIBであり、新HTML/ExcelZIPやCONTINUITYを読んで期待値へ使う経路はない。ENV-CONTRACT の今回差分は既存の数値受入条件を変えておらず、試験条件を書き換える根拠にならない。元の「軌道solver/実大気を受け入れない」というL1–5の限界も保持される。

**未確認。** 今回はテストを実行していない。成功数、skip数、現在環境での全回帰成功をこの報告から推定しない。`test_flight_weather`/`test_trajectory` 等の新runtime側検査も本scope外。

## MODEL-COMPOSER

**実装根拠。** L27–91は固定のschema/単位/構成要素/イベントの候補辞書。L136–168は速度状態の明示導入・引継ぎ・破棄を扱い、L171–284は段階のfamily、鉛直風の二重加算、重複provider、閉包不足・循環・未使用要素/parameter、イベント・地形要求を検査する。L287–334の `compose_model(spec, capabilities)` は渡された宣言だけをdetachedなplanへ合成する。capability照合はfield名/単位に限られ、座標・時刻支持、欠測、高さ、力・速度評価、イベントと数値積分等を `unresolved_contracts` に残す。L337–351の簡易profileは数値的なTawhiri再現ではない。

**今回の依存影響・変更不要理由。** ファイルI/O・ネットワーク・文書解釈・ZIP読込み・登録によるplugin探索はない。新接続設計の入力recipeや製品値からの導出は、この静的候補辞書へ自動追加されない。ENV L84–100が現 `flight/config.py` と将来の入力解決を分け、構成宣言の受理を飛行可能と扱わない方針は、composerの既存の責務と整合する。構成器の科学式・係数を今回追加/変更する理由はない。

**未確認。** 全候補の物理的採用、force evaluatorとの全面互換、実行可能モデルの網羅性や精度は未評価。`composition_valid` が実行/科学受入を表すと解釈しない。

## FORECAST-PLANNER

**実装根拠。** L40–50の内部依存はcomposerの `FIELD_UNITS` のみ。L63–162で明示JSON/UTC、正の飛行秒数、提供inventoryのproduct/run/lead/valid/availabilityを検査する。L165–199は単一runの予定時刻で窓の両端と内部を覆い、欠落をunknownとして扱う。L202–253は通常は提供一覧の最新runのみ、明示時のみ旧runへfallbackし、混合しない。時間支持の結果は `temporal_plan_ready` であり、実データ取得・field支持・補間・飛行を受け入れない。L269–288のCLIは利用者が明示したrequest/inventory/optional required-fields JSONを読みstdoutへ返す。

**今回の依存影響・変更不要理由。** ENVの次作業の順序を変えても、GFS配布を取得する機能や資料を読む機能は増えない。HTML/Markdown/ExcelZIPを解釈する入口、references自動走査、CONTINUITY連動の実行config注入はない。要求fieldは明示引数でのみ渡される。既存時間規則・fallback・不支持理由は不変のため、案内修復に伴うコード変更は不要。

**未確認。** 現時点のprovider実配布時刻、予報の鮮度・全run網羅、実ダウンロード、指定した高度/変数の支持、過去場・長期統計・飛行結果は未確認。384hの規則はこのコードの宣言として読んだだけで、今回の外部仕様再検証ではない。

## VERIFY-CONTRACT

**実入力と読取境界。** L25–60はCONTINUITYの読取、repo内に閉じるpath、文書boundary間の本文/指紋を扱う。L91–118のsnapshot/local digest、L168–240の共通入口照合は管理資料とbyteを読む。ZIPを登録した場合、snapshotでbyteをhashするが、展開・解析コード実行・物理値採用はしない。HTMLも `HTMLParser` またはtextとして読み、script実行はしない。

**新asset/node/scopeの既存経路。**

| 判定経路 | 今回の追加登録への意味 |
|---|---|
| `structural_projection` L243–273 | `asset:<path>`、`node:<id>`、`design:<path>`、`scope:<id>`を構造identityとして抽出する。scopeはpath/parent/depends_on/selector等を対象とし、確認stampだけの変更と区別する |
| `compare_structure` L276–327 | 固定baseの全宣言path/byteのsnapshotを候補へ結合。追加/変更identityに現在版・basis・base snapshotが一致する唯一の移行記録を要求し、before/after hashとreason/preserved/impact/recoveryを照合する |
| 同 L310–314 | guard変更は明示guard記録、identity追加/削除はmigrationまたはguardかつreplacement/dispositionが必要。新資料だから黙って例外扱いする経路はない |
| `inspect` L339–358 | CURRENT_PATHSとassetsの完全一致、存在、目的/現役割/退役条件/出所、lifecycle、consumer、source_paths、生成元循環を確認する |
| 同 L359–391 | healthのfile coverage、scope目的、narrative ID/親/本文境界/説明/feeds、派生asset view、document designを確認する |
| 同 L398–437 | base比較を指定した場合、構造遷移に加えて新nodeをbefore=`new`として変更理由とafter digestを要求する。変更assetの理由、削除node/assetの行先も確認する。base無しの現状態検査をtransitionと称せない |
| 同 L438–451 | 祖先への影響確認を本文自身の変更と分離する。構造整合は意味・真実・承認・科学採用の証明ではないと返す |

**今回の依存影響・変更不要理由。** 接続設計/参考ZIPの追加は現schemaのasset/node/scope/必要ならdocument_designの登録と移行記録で表現でき、checkerのschemaや許可ガードを変える要求ではない。`GUARD_PATHS` L121–126はchecker自身に固定されており、候補の登録操作で既存guard監視を外す設計ではない。未知の文書を実行入力へ昇格する仕組みもない。従って、この追加のために検査器を弱めたり特例を追加したりする変更は不要。

**未確認・完了条件。** 読取時点のCONTINUITYはversion 0.39.0 / basis M380で、INTEGRATION/Excel新登録はまだ見当たらなかった。この報告は「最終0.40構造移行が成功した」証拠ではない。rootが0.40の全asset/node/scope/移行記録/派生目録/healthを同期した後、固定M390に対する `--base` + `--transition` を含む所定検査で確定する。ENTRYの外部UI一致、GitHub保存、資料の読者価値、自然言語の妥当性はchecker合格でも別に評価する。

## 次担当への限定結論

この5scopeは「文書依存変更を理由に本文コードを変える必要なし、該当依存境界は読取確認済み」と扱える。更新版の確認根拠へ使う場合は、今回の限定読取と他の実行検査を別々の証拠にする。`updated_in`を今回版へ上げるコード変更は発生していない。

接続実装が始まった時点では、文書に予定した入力解決・分布・ID・実行ジョブ等をどの明示APIから渡すかが新しい検証対象になる。今回「参照資料を保存した」ことを、その新入力の受入済み根拠に使わない。
