# 人工 WebGL 診断 host

対象 `release/workflow-ui-040/review/hover-lab400.html`。親から追加許可されたこの単独 HTML だけを追加。source/main.js と実 Google 接続中の loaded r2 host を変更していない。

目的は CUA の現 API から任意の pointer hover 入力を出す手段がない状況で、**明示的な診断 UI の合成入力**と実 WebGL pick / tooltip を結び付けること。閲覧制限や操作権限を迂回する手段ではない。実マウス・実タッチ・Google mesh・親との受渡し全体の確認を代用しない。

診断は配布 `scene3d/src/hover-controller.js`、`hover-labels.js`、`surface-pick.js`、`overlay-store.js`、`overlays.js` を直接 import する。独自の常設 tooltip や手描きの結果を診断成功に使わない。固定の Cesium runtime と人工 fixture だけを読み、Google provider は import せず、API キー入力を設けない。

操作は試験地点 → XY 設定 → 静止入力。XY は canvas の CSS pixel。世界座標 preset を現在 camera の public worldToWindowCoordinates で画面へ変換し、十字位置と pointer event の client 座標を一致させる。カーソル座標は地表との交差が保証されるものではなく、実際に pick した current mesh の結果欄が根拠になる。上端 preset を「必ず空」と決めつけない。

UI からは静止、同じ地点へ戻る drag、cancel、delta 0 の wheel、面/境界可視、候補の注目 A/B、長名と同名別 ID の領域重複、一時停止を扱える。drag / wheel の合成入力は controller の取消を確認する用途に限定し、カメラの操作品質には一般化しない。カメラは通常の地図操作と地域ボタンを別に使用する。

HTML の module 構文検査は成功。実 WebGL 表示・tooltip の視認は root の CUA 観察へ帰属させる。この診断 host の独自処理が正常であっても production main.js の受入完了とはしない。
