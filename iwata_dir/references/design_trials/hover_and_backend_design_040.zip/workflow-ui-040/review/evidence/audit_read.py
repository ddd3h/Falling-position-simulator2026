from pathlib import Path
import re,html,json,sys,hashlib,subprocess,datetime

base=Path('C:/Users/genia/AppData/Local/Temp/balloon-design-400/base-0.39.0')
if sys.argv[1]=='html':
    p=base/sys.argv[2]
    t=p.read_text(encoding='utf-8')
    ident=sys.argv[3]
    m=re.search(r'<(?P<tag>[a-z0-9]+)\b[^>]*\bid="'+re.escape(ident)+r'"[^>]*>',t)
    if not m: raise ValueError(ident)
    end=t.find('</'+m['tag']+'>',m.end())+len(m['tag'])+3
    seg=t[m.start():end]
    print(f'{p.relative_to(base)} lines {t[:m.start()].count(chr(10))+1}-{t[:end].count(chr(10))+1}')
    seg=re.sub(r'<(?:script|style)\b.*?</(?:script|style)>','',seg,flags=re.S)
    seg=re.sub(r'</(?:p|tr|li|h[1-6]|div|section)>','\n',seg)
    print(html.unescape(re.sub('<[^>]+>',' ',seg)))
elif sys.argv[1]=='lines':
    p=base/sys.argv[2]
    a=p.read_text(encoding='utf-8').splitlines()
    lo=int(sys.argv[3]);hi=int(sys.argv[4])
    print(p.relative_to(base))
    for n in range(lo, min(hi,len(a))+1): print(f'{n}: {a[n-1]}')
elif sys.argv[1]=='health':
    j=json.loads((base/'docs/CONTENT_HEALTH.json').read_text(encoding='utf-8'))
    print('keys',list(j))
    for u in j['units']:
        if any(s in str(u.get('id','')) for s in sys.argv[2:]): print(json.dumps(u,ensure_ascii=False,indent=2))
elif sys.argv[1]=='inventory':
    j=json.loads((base/'docs/IMPLEMENTATION_INDEX.json').read_text(encoding='utf-8'))
    declared=j['structure']['physical_modules']
    actual=sorted(p.relative_to(base).as_posix() for p in (base/'balloon_sim').rglob('*.py'))
    rows=[{'path':m['path'],'expected':m['source_sha256'],'actual':hashlib.sha256((base/m['path']).read_bytes()).hexdigest()} for m in declared]
    health=json.loads((base/'docs/CONTENT_HEALTH.json').read_text(encoding='utf-8'))
    ids={'PLAN','PLAN-POSITION','PLAN-ROADMAP','PLAN-RESUME','ENV-CONTRACT','PROGRAM-CORE','THEORY-CORE','COMMANDS-CORE','IMPLEMENTATION-INDEX','IMPLEMENTATION-NOTES','WORK-ORDER','WEATHER-GUIDE','CONTROL'}
    selected=[{'id':u['id'],'path':u['path'],'updated_in':u.get('updated_in'),'reviewed_in':u.get('reviewed_in'),'review':u.get('review')} for u in health['units'] if u['id'] in ids]
    cmd=[sys.executable,'-B','-X','utf8','-m','unittest','tests.test_flight_cli.FlightCliTests.test_published_api_index_resolves_actual_signatures_and_tests','-v']
    r=subprocess.run(cmd,cwd=base,capture_output=True,text=True,encoding='utf-8')
    report={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':'7622593e0d4dacb101f9ed86990f2832845494ed','actual_modules':len(actual),'declared_modules':len(declared),'missing_in_index':sorted(set(actual)-{m['path'] for m in declared}),'extra_in_index':sorted({m['path'] for m in declared}-set(actual)),'module_hashes':rows,'hash_mismatch':[r['path'] for r in rows if r['expected']!=r['actual']],'api_entries':len(j['entries']),'test':{'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr},'health_unchanged_observation':selected}
    out=Path(__file__).with_name('doc-audit400-evidence.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'module_hashes','health_unchanged_observation'}},ensure_ascii=False,indent=2))
