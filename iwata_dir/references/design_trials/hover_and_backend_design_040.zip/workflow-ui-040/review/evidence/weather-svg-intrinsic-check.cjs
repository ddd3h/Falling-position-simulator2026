// Reuse the independent source harness; keep its pre-fix SVG/receipt unchanged.
const fs=require('fs'),Module=require('module'),path=require('path');
const testpath=path.join(__dirname,'weather-round2-check.cjs');
let source=fs.readFileSync(testpath,'utf8').replaceAll('weather-round2-','weather-svg-intrinsic-');
source=source.replace("const out={basis:","check('Saved outer SVG has explicit intrinsic dimensions',saved.source.startsWith('<svg width=\"1130\" height=\"1504.56\" ')&&saved.source.includes('viewBox=\"0 0 1130 1504.56\"'));check('Live annual SVG remains responsive without fixed width',!/^<svg[^>]*\\swidth=/.test(host.innerHTML.match(/<svg[^>]*>/)[0]));const out={basis:");
const child=new Module(testpath,module);child.filename=testpath;child.paths=module.paths;child._compile(source,testpath);
