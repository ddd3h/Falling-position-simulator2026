import {readFile,writeFile,readdir,copyFile} from 'node:fs/promises';
import {constants} from 'node:fs';
import {join,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const reviews='C:/Users/genia/AppData/Local/Temp/balloon-design-390/reviews';
const receiptPath=join(reviews,'scene-rebuild390-final.json');
const receipt=JSON.parse(await readFile(receiptPath,'utf8'));
if(receipt.commands.length!==1||receipt.commands[0].exitCode!==null||receipt.pass)throw new Error('This retry only resumes the recorded pre-test launch failure');
await copyFile(receiptPath,join(reviews,'scene-rebuild390-initial-launch-failure.json'),constants.COPYFILE_EXCL);
await copyFile(join(reviews,'scene-rebuild390-test.log'),join(reviews,'scene-rebuild390-test-initial-launch-failure.log'),constants.COPYFILE_EXCL);
receipt.initialFailure={receipt:'scene-rebuild390-initial-launch-failure.json',log:'scene-rebuild390-test-initial-launch-failure.log',reason:'spawnSync node.exe EPERM before test code started'};
receipt.commands=[];delete receipt.error;receipt.resumedAt=new Date().toISOString();
const hash=b=>createHash('sha256').update(b).digest('hex');
async function inventory(root,exclude=[]){const files=[];async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name),path=relative(root,p).replaceAll('\\','/');if(exclude.includes(path))continue;if(e.isDirectory())await walk(p);else if(e.isFile()){const b=await readFile(p);files.push({path,bytes:b.length,sha256:hash(b)});}else throw new Error(`Unexpected non-file: ${path}`);}}await walk(root);files.sort((a,b)=>a.path.localeCompare(b.path));return files;}
function diff(a,b){const am=new Map(a.map(f=>[f.path,f])),bm=new Map(b.map(f=>[f.path,f]));return [...new Set([...am.keys(),...bm.keys()])].sort().flatMap(path=>{const before=am.get(path),after=bm.get(path);return before?.bytes===after?.bytes&&before?.sha256===after?.sha256?[]:[{path,before:before??null,after:after??null}];});}
async function run(file,args=[]){const r=spawnSync(process.execPath,[file,...args],{cwd:receipt.workSource,env:{...process.env,BJP_CESIUM_DEPENDENCIES:receipt.dependencies},encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024});const log=join(reviews,`scene-rebuild390-${file.replace(/\.mjs$/,'')}.log`);await writeFile(log,`exit=${r.status}\nsignal=${r.signal??''}\n${r.stdout??''}\n${r.stderr??''}${r.error?`\n${r.error.message}`:''}`);receipt.commands.push({file,args,exitCode:r.status,signal:r.signal,log});if(r.status!==0)throw new Error(`${file} failed`);}
try{
  await run('test.mjs',[join(reviews,'scene-rebuild390-test.json')]);
  await run('make-fixture.mjs');
  await run('build.mjs');
  const sourceAfter=await inventory(receipt.source),runtimeAfter=await inventory(receipt.runtime);
  const rebuiltSource=await inventory(receipt.workSource,['node_modules']),rebuiltRuntime=await inventory(receipt.workRuntime);
  const sourceInventory=JSON.parse(await readFile(join(receipt.source,'source-inventory.json'),'utf8'));
  const runtimeInventory=JSON.parse(await readFile(join(receipt.runtime,'build-inventory.json'),'utf8'));
  receipt.originalSourceChanges=diff(receipt.sourceBefore,sourceAfter);
  if(receipt.originalSourceChanges.some(f=>!['README.md','source-inventory.json'].includes(f.path)))throw new Error('Frozen original source changed');
  receipt.originalRuntimeChanges=diff(receipt.runtimeBefore,runtimeAfter);
  receipt.rebuiltSourceDifferences=diff(sourceAfter,rebuiltSource);
  receipt.runtimeDifferences=diff(runtimeAfter,rebuiltRuntime);
  receipt.runtimeInventoryDifferences=diff(runtimeInventory.files,runtimeAfter.filter(f=>f.path!=='build-inventory.json'));
  receipt.sourceInventoryDifferences=diff(sourceInventory.files,sourceAfter.filter(f=>f.path!=='source-inventory.json'));
  receipt.runtimeComparison={payloadFiles:runtimeInventory.files.length,physicalFiles:runtimeAfter.length,bytesExcludingInventory:runtimeInventory.files.reduce((s,f)=>s+f.bytes,0),allPhysicalFilesCompared:true,buildInventoryIncluded:true,buildInventorySha256:hash(await readFile(join(receipt.runtime,'build-inventory.json')))};
  receipt.fixtures=rebuiltSource.filter(f=>f.path.startsWith('fixtures/'));
  receipt.testReport=JSON.parse(await readFile(join(reviews,'scene-rebuild390-test.json'),'utf8'));
  receipt.pass=['originalRuntimeChanges','rebuiltSourceDifferences','runtimeDifferences','runtimeInventoryDifferences','sourceInventoryDifferences'].every(k=>receipt[k].length===0);
  if(!receipt.pass)throw new Error('Byte comparison differs');
}catch(e){receipt.error=e.message;process.exitCode=1;}
receipt.finishedAt=new Date().toISOString();await writeFile(receiptPath,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({pass:receipt.pass,error:receipt.error??null,receipt:receiptPath,sourceInventory:receipt.sourceInventory,runtimeComparison:receipt.runtimeComparison,testReport:receipt.testReport,commands:receipt.commands.map(c=>({file:c.file,exitCode:c.exitCode})),runtimeDifferences:receipt.runtimeDifferences?.map(f=>f.path),rebuiltSourceDifferences:receipt.rebuiltSourceDifferences?.map(f=>f.path)},null,2));
