import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const P='C:/Users/genia/AppData/Local/Temp/balloon-design-390',S=P+'/release/workflow-ui-039/source/cesium-probe',E=P+'/reviews';
const {fixture}=await import(pathToFileURL(S+'/src/fixture.js'));
const oldPath=E+'/scene-r8-before/src/catalog.js',newPath=S+'/src/catalog.js';
async function load(path){const raw=await readFile(path,'utf8'),module=await import('data:text/javascript;base64,'+Buffer.from(raw.replace("'./colors.js'",JSON.stringify(pathToFileURL(S+'/src/colors.js').href))).toString('base64'));return{module,sha256:createHash('sha256').update(raw).digest('hex')};}
class Element{constructor(tag){this.tagName=tag;this.children=[];this.dataset={};this.attrs={};this.style={setProperty:(k,v)=>{this.attrs[k]=v;}};}append(...nodes){this.children.push(...nodes);}setAttribute(k,v){this.attrs[k]=v;}}
const doc={createElement:tag=>new Element(tag)},flat=n=>[n,...n.children.flatMap(flat)];
const render=(module,p)=>flat(module.catalogView(doc,p,()=>{}));
const projection=nodes=>nodes.map(n=>({tag:n.tagName,text:n.textContent??null,className:n.className??null,dataset:n.dataset,attrs:n.attrs,checked:n.checked??null,disabled:n.disabled??null,click:typeof n.onclick==='function',change:typeof n.onchange==='function'}));
const detail=fixture();detail.context={kind:'detail',selection:{count:28,denominator:60,sampleIds:[]},contours:'none'};detail.candidates[0].visible=false;detail.candidates[0].label='A 標準案 ＋0.5時間';detail.candidates[0].parentId='parent';detail.candidates[0].delayMinutes=30;
const old=await load(oldPath),current=await load(newPath),overview=fixture();
for(const [stage,loaded] of [['before',old],['after',current]]){
 const {module}=loaded,nodes=render(module,detail),checks=[],check=(name,pass)=>checks.push({name,pass});
 check('Detail has no checkbox/button with overview visibility',nodes.every(n=>!['input','button'].includes(n.tagName)));
 check('Full delayed child label is retained',nodes.some(n=>n.textContent==='A 標準案 ＋0.5時間'));
 check('Current selected count is local to the identity card',nodes.some(n=>n.textContent==='選択 28/60 着地点'));
 check('No overview non-display explanation is required',nodes.every(n=>!n.textContent?.includes('概要では非表示')));
 check('Overview hidden state does not dim the detail subject',nodes.every(n=>!n.className?.includes('not-visible')));
 check('Detail has no intent-producing handlers',nodes.every(n=>typeof n.onclick!=='function'&&typeof n.onchange!=='function'));
 const shown=structuredClone(detail);shown.candidates[0].visible=true;
 check('Same selection gives same card regardless of overview visibility',JSON.stringify(projection(nodes))===JSON.stringify(projection(render(module,shown))));
 const zero=structuredClone(detail);zero.context.selection.count=0;
 check('Zero selection is explicitly zero',render(module,zero).some(n=>n.textContent==='選択 0/60 着地点'));
 const pending=structuredClone(zero);pending.candidates[0].pending=true;
 check('Pending previous-result annotation is retained',render(module,pending).some(n=>n.textContent?.includes('入力未反映（表示は前回結果）')));
 const inputBefore=JSON.stringify(detail);render(module,detail);
 check('Input payload is not mutated',JSON.stringify(detail)===inputBefore);
 check('Detail bandLegend remains unchanged',module.bandLegend(detail)===old.module.bandLegend(detail));
 check('Overview DOM and operation affordances remain unchanged',JSON.stringify(projection(render(module,overview)))===JSON.stringify(projection(render(old.module,overview))));
 check('Candidate color is retained',nodes.some(n=>n.attrs['--c']==='#1ae0ff'));
 const report={stage,catalogSha256:loaded.sha256,checks,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length,googleNetwork:false,browser:false,scope:'Source-derived plain DOM counterexamples. Detail selection count fixture tests presentation only; no result sampling or mesh claim.'};
 await writeFile(E+`/detail-catalog390-r8-${stage}.json`,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({stage,passed:report.passed,failed:report.failed}));
 if(stage==='after'&&report.failed)process.exitCode=1;
}
