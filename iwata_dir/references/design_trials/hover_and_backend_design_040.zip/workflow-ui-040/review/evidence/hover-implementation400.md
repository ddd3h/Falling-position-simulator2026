# 名称 hover の設計・実装・第 2 巡修復

基準 main M390 `7622593e0d4dacb101f9ed86990f2832845494ed`。担当 `/root/hover400`。旧 0.39 原資料を読み、0.40 展開候補の 3D source/runtime と shared の純粋解決 module だけを変更した。root repo、forecast の入力処理、weather、旧 0.39 は編集していない。Google/CUA は操作していない。

## 問いと採否

名称を知るために対象をクリックして画面を変えるのは余計な操作になる。目的は「既に見ているものがどの候補・領域か」を短時間で確かめること。面だけに限定すると線しかない非注目候補の比較が成立しないため、当初案を拡張し候補の contour の近傍も対象とした。独立批評から、同じ理由で領域面 OFF の境界線も対象とした。点・経路・Google 地物名へは広げない。

主担当が実施前計画を S34 に記録済み。今回の実装は主担当が確認する模型への提案であり、source 試験だけで実物受入を閉じない。

## 責務と状態

- `main.js` が一個の `hover-controller.js` を所有。静止 260 ms、pointer/button/wheel/修飾/leave/blur/scroll、カメラ移動、pause、受領/表示更新/rollback、接続解除で隠す。ポインターを capture せず camera の既存操作を止めない。
- `hover-labels.js` が描画済み payload + surface 座標 + visibility + known line feature indices から名前を解決。帯ごとの同名重複を candidate/result ID で除く。領域は region ID、同名別 ID は別対象。候補 1 枠と優先領域 1 枠、最大 2 名＋他 n。穴の内部・完全透明・非表示・詳細の全体分布は除外。
- `surface-pick.js` はクリックと hover に共通の public depth / sampleHeight。現在の mesh に取れた位置だけを扱い、overlay とクリック小印を高さの取得から除く。地表位置なしを帯外や楕円体へ代用しない。line は public drillPick 9×9 px、件数上限なし、現在の known Entity の contour / region polyline のみ。
- accepted と rendered の不一致、準備中、表示エラー時は hover を停止。旧表示に新名を付けない。クリックの marker / 読取欄とは独立。provider/root helper/key を controller/resolver へ渡さない。
- build は `shared/hover-labels.mjs` と `shared/band-readout.mjs` を同じ source から生成。2D 側の import が source/ に依存しないようにした。shared への生成は root の追加許可を受けた 2 ファイルに限定。

## 第 2 巡批評からの修復

1. 領域面 OFF・境界線 ON の識別欠落を修復。内部を面扱いに戻すのではなく、表示線の近傍だけを対象にした。
2. max-height と overflow:hidden の無言切断を撤去。通常名は全文折返し。地図高に収まらない極端な名称だけ先頭＋末尾を明示的な中間省略で保つ。全文を aria-label に保持。無制限の長名を全て同時に視認できるとは主張しない。
3. 再生成初回で make-fixture が外部依存指定に未対応と分かったため、test と同じ固定依存解決へ揃えた。形状の式・値・生成結果は変更していない。

## 実行した証拠

- `hover-unit400-initial.json`: 253 条件成功（旧 179 + 新 74）。この初票の scope 文字列は旧テストのままのため、最新の範囲記述は次票を参照。
- `hover-unit400-r2.json` と `hover-unit400-rebuild-r2.json`: 261 条件成功（旧 179 + 新 82）。穴/MultiPolygon、同名別 ID、ID 重複、候補＋領域枠、線のみ、面 OFF・詳細 0 群、透明、未知 pick 除外、textContent、timer 取消/破棄、viewport 配置、長名先頭/末尾、public mesh 取得不能を確認。
- `hover-rebuild400-2.log`: 初回別コピーでの Cesium import 失敗を保持。試験の合格と再生成失敗を分離。
- `hover-rebuild400-r2.json`: 別コピーで test → make-fixture → build 成功。scene3d 415 ファイル（inventory 含む）と shared 2 ファイル、計 417 ファイルの全 byte/hash が元候補と一致。Google 0、ブラウザー未使用。

## 残る実物の判断

斜め視点・壁/屋根の遮蔽と line 近傍、線の重なり、取得待ち、通常カメラ操作後の取消、画面端・長名・狭い viewport、クリックとの独立、2D 往復の同一接続を root の実物確認へ渡す。synthetic の成功から Google 実写真の視認品質を一般化しない。名称の分布が大きく重なる場合の最大 2 名＋他 n の使いやすさも実際の比較で批評する。根拠となる科学的分布や禁止領域の判定方法そのものは変更していない。

## 第 3 巡：実物の停止から host の静止判断を修復

主担当の lab 観察で、SDK moving=true / moveStarts=1 / moveEnds=0 のまま、mesh 読取り 0 と分かった。dataSourceReady=true なので当初の準備状態仮説は除外した。公開 camera には 10^-16 程度の変化が観察された。詳細は hover-camera-gate400.md。旧 261 条件と 417 byte 照合ではこの欠陥を検出できなかった。

lab 先行修復後、root は gate canRead=true / stableMs=759 / 読取り1 / 表示対象2 を観測し、「落下分散：人工候補 A」「領域：人工の穴つき領域 · 優先レベル」を実 DOM で確認した。これは人工 WebGL と合成入力による限定観察であり、Googleや物理マウス操作の成功ではない。

許可を受けて production に同じ考え方を実装。view-stability.js は公開 world position / direction / up / fov / aspect の累積有意差を保持する。SDKイベント終端と raw JSON 同値に依存せず、最後の有意差から260msで静止とする。main は描画frameと読取り直前に同じ純粋trackerを観測する。labも同じmoduleをimportする。destroyでclear、pauseや受領/表示不一致等の他のgateは保持した。

最新票 hover-unit400-rebuild-r3.json は 340 条件成功。初票 hover-unit400-r3.json も340成功だが scope 文に静止判定の追記前のため、範囲の正本は再生成票と source README。新規79条件は浮動小数jitter、SDK moveEnd不在、累積slow translation/rotation、roll/zoom/aspect、invalid/clear/再静止、controller結合の反例を確認する。hover-rebuild400-r3.json は別コピーで test → make-fixture → build が成功し、scene3d 416（inventory込）+ shared 2 の418ファイルが全byte一致した。

最終source main SHA256 `bc63c7bf05799e13b4dfff4c5f352f89a7352c0902205300b9d7f8997cb5d054`、tracker `a8dd03a7b0ecf2f7afc5718df56cc90845de0dc1e0f82967d5d041b47ab12658`。hostRevision は `0.40.0-r3-view-stability`。r2からのsource差分は main / tracker / tracker test / test.mjs / README / inventory の6パスのみ。provider、protocol、geometry、click reader、SDKは不変。接続済み Google loaded r2 は維持し、ディスクr3を適用済みとは言わない。新しいproduction hostの実物確認はrootへ渡す。