# r8 詳細catalogの対象カード

編集前判断は `detail-catalog-critic390.md`。主担当は実Google接続を保持したまま、概要で非表示にした候補の詳細選択群を読むとき、disabled/unchecked checkboxから現在の表示対象を誤認しやすいと批評した。概要の可視状態を詳細の表示状態に読み替えず、詳細欄を操作のない対象カードへ分けた。

`catalog.js` のdetail分岐だけで候補色・full label・選択 n/N 着地点を示し、概要用チェックとdisabledボタン、注目/表示の状態語、概要非表示の弁明を除いた。pendingは「入力未反映（表示は前回結果）」として残し、「選択群の変更は分析画面で行います」と案内する。選択0をそのまま示す。概要のcatalog処理、bandLegend、geometry、main/provider/protocol/HTML/CSSは不変。revisionは `0.39.0-r8-detail-card`。

無キーの汎用source検査は179条件成功（従来167に詳細カードの反例12条件追加）。そのほか保存した旧catalogと新catalogへ同じ13条件を当てた対比では、旧版は7条件に不適合、新版は13条件すべて通過した。概要可視状態によらない詳細表現、0/少数選択、full label、色、pending、intent handlerの不在、入力payloadの不変、概要のDOM/操作部品とbandLegendの不変を確認。これらは実装担当によるsource検査であり、独立担当の21条件や主担当の実Google視認とは別票である。画面上での読みやすさは主担当の同一接続上の後続観察へ残す。

`rebuild390-r8/source/cesium-probe/` を新規作成し、固定Cesium 1.145.0依存からtest→make-fixture→buildをすべて終了0で実行した。配備は生成された `src/catalog.js` と `build-inventory.json` だけ。元main/provider/HTML等を再保存・再読込しない。runtime411件＋inventory自身の412実体すべてが独立再生成とbyte一致し、fixture再生成後のsourceも一致。Google通信・ブラウザー操作はない。

- sourceの変更: catalog.js、test.mjs、README.md、source-inventory.jsonのみ。
- catalog SHA256: `d092946cddc278d6b558878fa948d79748615a08c1cf8ddc543da837fab1851b`。
- source inventory: 自己除外50 files / 532,525 bytes、SHA256 `a65ca7a9df749bdc49dba1a510a4557a2e14be4859a0bf1b934ea0c2ea82e6a1`。
- runtime inventory: 411 files / 22,810,157 bytes、SHA256 `0c322da381f6b18134ffcf83b176eb7cc2ea7958fd7c38c634ff807d796826b4`。
- 変更前は `scene-stage390-r8-before.json` と `scene-r8-before/` に保持。前回 `scene-rebuild390-final.json` などは上書きしていない。
- 新票は `scene-unit390-r8.json`、`scene-rebuild390-r8.json`、`detail-catalog390-r8-before.json` / `-after.json`。実行用脚本と3コマンドlogもreviewsへ保持。

主担当の実接続を用いた後続観察は、同じiframeの「表示だけ更新」でこのcatalog revisionを適用して行う。source修復/配備をもってliveへ自動反映したとは扱わない。更新後は元視点、接続試行数、選択geometryを保ったまま、カードが自然に読めることを確認する。観察結果は主担当記録へ戻す。

作業中の追加ユーザー意見「クリックせず、対象を絞ったhoverで落下分散や領域の設定名称を読みたい」は後続検討として保持した。名称識別とクリック地点の輪郭区分は別の必要であり、相互の代用としない。r8にはhover実装を混ぜていない。対象の絞込み、重複対象、線と面、mesh/overlayのpick、表示場所、同一接続内更新の境界を改めて検討する。

## 主担当によるr8の実画面受入

主担当から、同じGoogle接続で「表示だけ更新」に成功し、「A 標準案 / 選択28/60着地点 / 選択群の変更は分析画面」の静的カードと点群を視認したとの報告を受領した。画面内接続試行1を保持し、輪郭なし38表示要素。2Dへ戻って概要へ再入場すると、A注目・非表示、子2表示/B表示の操作目録へ戻ることを主担当が実観測し、今回の修復を受入とした。この段落は主担当CUAの有限観察であり、実装担当がliveタブへ接続した結果ではない。hoverは未実装のまま別設計へ進む。
