const fs = require('node:fs');
const path = require('node:path');
const ts = require(path.join(process.cwd(), 'frontend/node_modules/typescript/lib/typescript.js'));
const out = path.join(__dirname, 'fe-state-review450');
fs.mkdirSync(out, {recursive: true});
for (const name of ['domain', 'workspaceState']) {
  const source = fs.readFileSync(path.join(process.cwd(), 'frontend/src', name + '.ts'), 'utf8');
  const compiled = ts.transpileModule(source, {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022}}).outputText;
  fs.writeFileSync(path.join(out, name + '.js'), compiled);
}
const {initialState, workspaceReducer: reduce} = require(path.join(out, 'workspaceState.js'));
const candidate = id => ({id, label: id, revision: 1, weather_source_id:'fixture', config:{}});
const run = (id, candidateId, state='completed') => ({run_id:id,candidate_id:candidateId,state,result_available:state==='completed'});
const project = {schema:'balloon.project/1',title:'review',candidates:[candidate('A'),candidate('B')],compare_run_ids:['a0','b0']};
const restore = () => reduce(initialState(), {type:'restore',project:structuredClone(project),revision:1,runs:[run('a0','A'),run('b0','B'),run('a1','A','running')]});
const result = (id, epoch, intent) => ({type:'result',run:run(id,'A'),candidateId:'A',epoch,intent,result:{run_id:id}});
let first = restore();
first = reduce(first,{type:'accepted',candidateId:'A',run:run('a1','A','running')});
first = reduce(first,{type:'selection_requested',candidateId:'A',epoch:1});
first = reduce(first,result('a0',1,'select'));
const withoutReload = reduce(first,result('a1',0,'complete')).project.compare_run_ids;
let reopened = reduce(initialState(),{type:'restore',project:first.project,revision:2,runs:Object.values(first.runs)});
reopened = reduce(reopened,{type:'accepted',candidateId:'A',run:run('a1','A','running')});
const withReload = reduce(reopened,result('a1',0,'complete')).project.compare_run_ids;
let epochCollision = restore();
epochCollision = reduce(epochCollision,{type:'selection_requested',candidateId:'A',epoch:1});
epochCollision = reduce(epochCollision,result('a2',1,'select')); // new generation's explicit selection
const beforeLate = epochCollision.project.compare_run_ids;
epochCollision = reduce(epochCollision,result('a1',1,'select')); // previous generation's delayed selection
const report = {scope:'Actual reducer replay only; not a browser/hook timing test',savedOldSelection:{withoutReload,withReload},crossReloadEpochCollision:{beforeLate,afterLate:epochCollision.project.compare_run_ids}};
fs.writeFileSync(path.join(__dirname,'fe-state-review450.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
