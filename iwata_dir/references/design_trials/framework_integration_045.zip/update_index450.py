from pathlib import Path
import ast,hashlib,json,re
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp');P=Path(__file__).resolve().parent
j=json.loads((P/'basis-C2/docs/IMPLEMENTATION_INDEX.json').read_text(encoding='utf-8'))
j['version']='0.45.0';j['role']='Python公開API署名、実ファイル階層と依存、HTTP/TypeScriptの明示的な手動読解の索引。構造本文はPROGRAM、仕様はIMPLEMENTATION_NOTES、進捗はS35。'
new=[('APP-create_app','backend/app.py','create_app','FastAPI経路とserviceの生存期間を構成し、計算の意味をservice/核へ委譲する'),('SERVICE-submit','backend/application.py','ApplicationService.submit','元入力と解決値・場・コードを固定し、一飛行を有限queueへ受理する'),('SERVICE-get_result','backend/application.py','ApplicationService.get_result','完了印と内容の指紋を照合して固定結果を読む'),('SERVICE-save_project','backend/application.py','ApplicationService.save_project','草案revisionと固定結果の比較参照を保存し、競合を拒否する'),('WORKER-execute_run','backend/worker.py','execute_run','固定した入力を前後照合し既存核を一度実行して新規stagingへ出力する'),('STORAGE-publish_result','backend/storage.py','publish_result','核の成果物を照合してCOMMITTEDとrun仕様を加え、結果directoryへ公開する'),('STORAGE-read_result','backend/storage.py','read_result','DBが参照する固定結果の完了印と内容指紋を照合し読込む')]
for ident,path,symbol,purpose in new:
 scope=ast.parse((R/path).read_text(encoding='utf-8'))
 for part in symbol.split('.'):scope=next(n for n in scope.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==part)
 j['entries'].append(dict(id='API-'+ident,path=path,symbol=symbol,signature=ast.unparse(scope.args),purpose=purpose,theory_or_structure_anchor='WEB-SERVICE',test_path='backend/tests/test_application.py',introduced_in='0.45.0',changed_in='0.45.0',reviewed_in='0.45.0',lifecycle='active',next_review='入力/HTTP/仕事/保存の意味変更時に草案と固定結果の分離、停止、再開を同じ変更で点検',structure_symbol_id=path.removesuffix('.py').replace('/','.')+'.'+symbol,structure_anchor='WEB-SERVICE'))
def tree(node,parent):
 name=getattr(node,'name',parent);identity=(parent+'.'+name) if hasattr(node,'name') else parent
 row={'id':identity,'name':name,'kind':'class' if isinstance(node,ast.ClassDef) else 'async_function' if isinstance(node,ast.AsyncFunctionDef) else 'function' if isinstance(node,ast.FunctionDef) else 'module','line':getattr(node,'lineno',1),'end_line':getattr(node,'end_lineno',None)}
 if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):row['signature']=ast.unparse(node.args)
 children=[tree(n,identity) for n in getattr(node,'body',[]) if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))]
 if children:row['children']=children
 return row
for path in sorted((R/'backend').glob('*.py')):
 text=path.read_text(encoding='utf-8');node=ast.parse(text);module=path.relative_to(R).as_posix().removesuffix('.py').replace('/','.');top=tree(node,module);top['end_line']=len(text.splitlines());imports=[]
 for n in ast.walk(node):
  if isinstance(n,(ast.Import,ast.ImportFrom)):imports.append({'scope':module,'line':n.lineno,'statement':ast.unparse(n),'relative':bool(getattr(n,'level',0))})
 assignments=[]
 for n in node.body:
  if isinstance(n,ast.Assign):assignments.extend({'target':ast.unparse(t),'line':n.lineno,'value_expression':ast.unparse(n.value)} for t in n.targets)
 j['structure']['physical_modules'].append({'path':path.relative_to(R).as_posix(),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'tree':top,'imports':imports,'module_assignments':assignments,'extraction_note':'Python ASTの構文位置/import文。関数内importを含み、runtime束縛の自動解決はしない。'})
modules=[('src/main.tsx','React rootへAppとCSSを接続'),('src/App.tsx','二候補の草案・結果・比較操作を配置'),('src/ConfigEditor.tsx','現在核の直接入力と候補版を編集'),('src/useWorkspace.ts','取得/送信/poll/保存/再開、通信の生存期間を管理'),('src/workspaceState.ts','草案・run・結果参照・選択epochを純粋状態更新へ集約'),('src/api.ts','相対/api/v1のJSON通信とエラーを集約'),('src/domain.ts','型・JST/UTC・入力差・相分割・表示内挿'),('src/MapPanel.tsx','軌道/イベント/停止点/時刻位置と任意背景を表示'),('src/HistoryPanel.tsx','高度履歴と共通時刻、イベントとmetadata付きSVG保存')]
j['structure']['manual_interpretation']['typescript_modules']=[{'path':'frontend/'+path,'purpose':purpose,'source_sha256':hashlib.sha256((R/'frontend'/path).read_bytes()).hexdigest(),'imports':[m.group(1) for m in re.finditer(r"from\s+['\"]([^'\"]+)['\"]",(R/'frontend'/path).read_text(encoding='utf-8'))],'method':'実本文の手動読解とimport文字列の補助抽出。TypeScript AST/API署名をPython検査へ偽装しない。'} for path,purpose in modules]
j['structure']['manual_interpretation']['data_flows'].extend([
 {'from':'candidate draft / compare selections','through':['frontend/src/useWorkspace.ts','frontend/src/api.ts','backend.app.create_app','backend.application.ApplicationService'],'to':'fixed run IDs / versioned project','boundary':'草案と固定結果を分離。HTTP経路は手動照合。後着完了で明示選択を上書きしない。'},
 {'from':'fixed run specification / saved GFS','through':['backend.worker.execute_run','balloon_sim.flight.trajectory.simulate','balloon_sim.results.export.export_result','backend.storage.publish_result'],'to':'COMMITTED result directory and DB reference','boundary':'一worker、有限queue、入力前後照合。job completedに物理stoppedを含む。'},
 {'from':'committed result reference','through':['backend.storage.read_result','backend.application.ApplicationService.get_result','frontend/src/api.ts','frontend/src/useWorkspace.ts'],'to':'AppからMapPanel / HistoryPanelへ同じ固定結果と経過時間を渡す','boundary':'両パネルがdomainをimportする。元場を再loadせず指紋を照合。表示内挿は科学的再積分ではない。再読した仕事は観察だけで保存比較を替えない。'}])
j['structure']['manual_interpretation']['http_routes']=[{'method':method,'path':'/api/v1'+path,'service':service} for method,path,service in [('GET','/health','serviceの現在設定'),('GET','/weather-sources','weather_sources'),('POST','/runs','submit'),('GET','/runs','list_runs'),('GET','/runs/{run_id}','get_run'),('GET','/runs/{run_id}/result','get_result'),('POST','/runs/{run_id}/cancel','cancel'),('GET','/project','get_project'),('PUT','/project','save_project')]]
j['structure']['extraction_limits'].append('0.45のbackendは定義木/import文まで。既存lexical_call_edgesは核の0.24抽出を保持し、新しいHTTP/process/TypeScriptの接続はmanual_interpretationへ明記。完全な呼出網や全OS挙動を自動証明しない。')
j['test_contract']='tests/test_flight_cli.pyが24主要Python APIの実定義AST署名・旧公開import署名・試験所在を照合する。backendの仕事/保存はbackend/tests、TypeScriptの表示/状態はfrontend/srcの試験と実UIで別確認。型と所在の一致は科学的正しさを認定しない。'
j['extraction']['application_addition']={'basis_commit':'346e9484d3fc3444fd7a12c9e85710e479685666','source':'0.45 backend/frontend working files','method':'backend Python AST definitions/import statements and separately labeled frontend/HTTP/process manual review','generated_by':'P450/update_index450.py; external finite evidence','self_hash_excluded':True}
(R/'docs/IMPLEMENTATION_INDEX.json').write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'entries':len(j['entries']),'physical_modules':len(j['structure']['physical_modules']),'typescript_modules':len(modules)},ensure_ascii=False))
