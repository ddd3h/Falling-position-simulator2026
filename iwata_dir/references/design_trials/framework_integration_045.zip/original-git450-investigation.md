# 元.gitの追加objectに関する読取調査

結論：旧0.44観測後に33ファイルが追加されているが、旧905ファイルの内容変更・削除は0。32件は既知の0.44 C2の完全なblob、1件は既知の大きいZIPの先頭と一致する未完の一時objectだった。現在は938ファイル。元.gitの全体が0.44以後不変だったとは言えない。一方、HEAD/ref/index/config/reflog等の既存byteは旧票と一致し、外側bareへ固定sourceを保存する内容上の障害は見つからなかった。

今回の操作は通常ファイルの読取、SHA計算、zlibのメモリ内復号とP450への報告保存のみ。Gitコマンド、元.git/作業source/保存helperへの書込、削除、rebaselineを行っていない。object本文・ZIP内容は出力せず、型・size・時刻とpath/hashの対応だけを記録した。

## 数・時刻・内容の確認

- 親から渡された `original-git450-difference.json` は33行で、すべてbefore=null。現在再読でも同じ33追加。旧905行の変更0・削除0で、調査中2回の全体走査ではpath/size/SHAに変化なし。差分票以後の新規追加もない。
- 追加33件のWindows作成時刻はUTC `2026-09-29 05:04:47.445782`〜`05:04:48.234639`、JST14:04:47〜14:04:48に集中する。これはファイルシステムが返す時刻で、作成者の識別ではない。元の0.44 snapshotはUTC04:21:11.775507。
- 32個はcanonicalな `objects/xx/<38桁hex>`。zlibが正常終端し、`blob <size>`、payload size、全object SHA1とファイル名が一致した。全32個のpayload size/SHA256/Git blobはP450/basis-C2の登録ファイルと一致する。うち10個は現在の作業sourceとも一致し、残22個はその後に編集された資料のC2版である。新0.45 frontend/backend実装のblobではない。
- 33件目 `objects/c6/tmp_obj_kKSWOQ` は未完zlib。headerのblob sizeは87,767,595 bytes、実際に復号できたpayloadは56,022,270 bytes。これは固定C2と現在の `references/design_trials/interaction_and_burst.zip` の先頭56,022,270 bytesと完全一致した。全ZIPの期待blobは `c63b04ac8e72ba9e1765d42fa020dfb9842f2094`。一時ファイル自体を完成済objectとして数えていない。
- HEAD/ORIG_HEAD/FETCH_HEAD、index、config、packed-refs、refs以下、logs以下など、非object制御ファイルはすべて旧byteと一致した。HEADの解決値M101は親の差分票の確認であり、この担当はGit rev-parseを再実行していない。

根拠は `original-git450-object-review.json`（33件すべての形態、時刻、path/hash照合、2回走査）と `original-git450-partial-review.json`（一時objectのZIP先頭照合、外側bareの分離）にある。元票はP440 `original-git440.json` を変更せず参照した。

## 原因について言える範囲

32個がすべて同じC2版で、作成が約0.8秒に集中し、大きい既存ZIPで未完の一時objectが残る形は、C2作業内容を一括してGit object化する処理がそのZIP付近で中断したことと整合する。参照・通常indexを進めた証拠はなく、追加commit/treeも見つからない。

しかしファイルの内容指紋と時刻だけでは、実行したプロセス、呼出元、コマンド、停止理由を特定できない。アプリの差分/復旧用snapshot等は候補にすぎず、Codex、GitKraken、OneDriveその他を原因として断定しない。現在のsource blobであることを「今回の保存helperが書いた」という証拠にもしない。今回のsave450 snapshotはその約1時間後に差を検出して停止し、freeze/publish以前だった。

## 外側保存との関係

`P430/git-save430` は元.gitと異なる通常ディレクトリで、親・bare・objectsのlink/junction/reparseはなし。configはbare=trueで固定originに一致する。objects/info/alternates、http-alternatesも存在しない。これはファイル読取の確認で、remote接続やpushの成功検証ではない。

保存helperは固定M420/C2を外側bareへ取得し、166実体をsourceから独立にhash-objectし、唯一の親・全tree/blob・branch leaseを照合する。元.gitの新33ファイルを保存の入力集合へ採用する設計ではない。既存identity読取のconfigも変わっていない。このため今回の停止は外側保存先の破損ではなく、0.45候補に加えた「過去snapshot全体との完全一致」条件が、既に発生していた追加を検出したものと評価する。

## 正当な検査境界の提案

旧票を残したまま、主担当がこの33件を有限に受理することは可能と考える。0.44 helperは当該保存開始時からの不変を守り、0.45候補はそれに過去snapshotとの同一条件を追加した。この強化条件を変更するなら、その理由と観測差を明示し、元.gitが過去から完全不変だったという主張はしない。

最小案は、主担当がS35と外側の小さい受理票へ、旧snapshot hash・差分票/今回2証拠のhash・許容する33件のpath/SHA・既存変更削除0・書込主体未特定を記録することである。snapshot許可は「旧905＋この33の正確な集合」に限り、現在938全体を今回保存期間の観測として固定する。その後の変更/削除/追加は従来どおり停止させる。releaseも旧票と受理票、新観測をhashで結ぶ。こうすれば過去の差を隠したrebaselineや一般的な.git例外規範を作らず、保存操作中の保護を維持できる。

HEAD/ref/index/configだけに検査を縮め、objects全体を無条件で無視する緩和は不要。一時objectを削除して旧集合に見せること、git gc/prune等の修復、旧snapshotの書換えも不要である。ここでは提案までで、save450.pyは候補hash `6b36918cc4a70364415c3af88a1d5652074c5835db87268e0590d247faa46340` のまま変更していない。主担当の明示した受理とhelper再レビューより先に保存を進めることは提案しない。
