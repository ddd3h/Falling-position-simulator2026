# 0.45管理・生成経路の有限依存レビュー

2026-09-29、frontend430。repo本文・metadataを編集せず、管理検査の実行を待ったまま閉じる。対応JSONに各対象の現在ファイルSHA256、C2比較、own/dependency digest、読取範囲と生成一致を記録した。比較元は0.44記録C2 `346e9484d3fc3444fd7a12c9e85710e479685666`、採用mainはM420 `4e3e4db0d047af9479bcd68bfc2553eeb71efcc9`。

## 読んだ範囲と方式

- P450/metadata450.pyとapprove_metadata450.pyの全文。prepare/requirements/finalizeの分離、根拠mapping、事前指紋、固定C2/137と29追加、更新/確認、原本/PLAN/guard集合の保持を読んだ。本担当はhelperを実行していない。
- CHECK-RUNNERのtools/run_checks.py全文。VERIFY-CONTRACTのtools/check_contract.py全文を分割読取し、とくに190–324行のentry/structural_projection/compare_structureを再読。check_healthはSpans/Contents/normalize/digest（1–121行）を読んだ。check_stateのsource_files（1–78行）、test_state新反例（95–173行）、3試験のcopytree除外変更を今回の依存として読む。test_state/test_health/test_contract、runner、checkerのinspect/mainは実行していない。
- CONTINUITYは固定C2との変更top-levelと追加29assetのpath/purpose/lifecycle及びhelperによる生成内容を対象とした。変更のない過去narrative全体を全文再読した意味ではない。
- RESEARCH-SOURCESのpacket_sources.json全文、RESEARCH-BUILDのbuild_research_packet.py全文。全指定範囲をbuild関数でメモリ内抽出し、6MDについてC2→現在入力の全固有差分を読む。共通差分の重複は同一性でまとめ、本文全科学範囲の再審査とはしない。rootが作ったpacket450-02の7diffも読み、現在repoの6MD+manifestが今回のメモリ内生成とbyte一致することを確認した。生成物を本担当が置換したわけではない。

## 指摘と修復後の判断

1. **抽出源への依存欠落を5edge補完（採用・反映確認）**。RESEARCH-SOURCESが実抽出するVISION、WEATHER-GUIDE、IMPLEMENTATION-NOTES、FLIGHT-CONFIGを宣言していなかった。またRESEARCH-BUILDのHTML抽出はcheck_health.Spansへ依存する。rootがmetadata450.prepareへ前4件とRESEARCH-BUILD→VERIFY-HEALTHを追加し再prepareした。更新後311unitの依存グラフにmissing/cycleなし。全抽出元pathがRESEARCH-SOURCESの宣言pathに含まれる。関連設計への追加依存DECISIONSは抽出源でないが、誤った原本混入ではない。

2. **runnerの射程（説明を修復）**。既存run_checksは専用conda Python3.12/64bitとpre/state/health/unittest/postの入口で、backend pytestやfrontend Vitestを呼ばない。runtime3rootの導入に対してsource列挙/fixtureコピーが有限に対応することと、追加アプリ試験の包含は別である。rootがBUILD19行へC09のnpm test/専用Python pytestを別実行すると明記したのを読戻した。runnerを今回の全製品検査入口へ改造する必要はない。

3. **0.45生成物と返却原本（整合）**。6MD全てに「今回の0.45生成束は未発行候補」と採用main M420/候補抜粋の区別が入り、0.43未移行や0.42 FastAPI未採用は当時の状態へ限定される。Q410-05は現在のReact/FastAPI/1worker/n=1保存再閲覧と、未完の一般分散/複数端末/持出しを分ける。UI_WALKTHROUGHが0.40.1人工模型を扱うという先頭の対象表示も保持し、新画面の全仕様と見せない。原研究2MD/ZIPは抽出sourceに含まれず、固定C2と3原本の全byte一致を確認。受領済み0.42研究を0.45へ改訂・再発行したという主張はない。

4. **approve/helperの確認範囲（条件付き適合）**。approveはunit→evidenceを明示し、必要scope不足と現在指紋を確認する。原研究2MD/ZIPをmappingへ入れず、全歴史/科学を再確認したという一括文言を避けている。ただし指紋取得は読取行為やZIP作成を証明しない。RESEARCHの再生成一致とEVIDENCEのZIP全member/hash/CRCは、記述した実績を終えてからapproveする必要がある。rootは未実行で、今回報告を収録・ZIP更新/CRC後に進むと確認した。finalize前の読み直し指紋、guard4集合、PLAN3 byte保持の事前検査はこの順序と適合する。

## 生成・指紋の適用時点

本票の生成一致はrootのpacket450-02適用後、最終stamp前の現在ソースに限る。6MDとmanifestの7実体が現在入力の生成と一致した。stampで出典全体のraw hashや抜粋内印が変わるため、rootがfinalize後に再生成し、派生物の指紋と生成一致を取り直す必要がある。現在票のprojectionや旧raw hashを新byteへそのまま貼らない。

CONTINUITYは構造比較元C2、HEALTH/研究configの採用mainはM420と役割を分けている。schema/policyはC2と等しく、固定登録137+29=166の追加を有限に扱う。guard変更や新依存は意味を説明する変更記録が必要で、検査件数だけで受け入れるものではない。

## 限界と引渡し

管理5検査、unit tests、Git固定保存/読戻し、最終ZIP収録の実績は本票から発生しない。対象checkerの今回変更依存への適合を読んだもので、全履歴・全科学・全OS・全悪意入力を再監査したとはしない。Python標準ライブラリのread-only digest/JSON比較と、読取済みgeneratorのメモリ内buildのみ実行し、出力は本MD/JSONだけ。追加の重要な所見はなく、明示mapping/finalizeと後続検査へ引き渡せる。
