# Backend担当によるFE保存・後着の独立批評

2026-09-29。useWorkspace.ts / workspaceState.ts / api.ts / domain.ts / App.tsx /
workspaceState.test.tsを全文読取。repo編集なし。backendの契約は読み取った現実装
（同request ID/同内容は旧run、compare_run_idsはcompletedのみ、草案CAS）に限定。
最初の2点はrootとFE担当へ先行連絡した。修正前スナップショットに対する所見であり、
この後のFE修正を未確認のまま合格へしない。
読取時 SHA256: useWorkspace.ts `d88fc58978142b6d15b97cbcc7ac0083ee438d185e8169fbdf5783a843d3dce6`、
workspaceState.ts `b749f2b921e9ce62a654b0002722eedc3a81ee8a40a2ef584a909cd6abc866ed`。

## 1. 終端後の明示再試行が新しい試行にならない

useWorkspace.ts:33-34、207-219。requestIdsはcandidate内容をキーにして保持され、
211の`??=`により同内容は同IDを再利用する。watchの終端/失敗処理84-94にも、
新しい明示操作へIDを割り当て直す処理がない。backend/application.py:167-171は
このIDの旧runを返す契約なので、これはサーバの正常な重複受付防止と組み合わさって
再試行を阻む。

具体例: Aが一時的な保存失敗でfailedになった後、原因解消後に同条件の
「この条件で計算」を押す。再度旧failedのrun IDが返り、実計算は発生しない。
interrupted後も同じ。completed後の明示計算も旧結果を再表示する。
入力を無意味に編集するかページを読み直さないと新しい試行にならない。

採否案: request IDは「一回の送信意図」を識別する。POST応答不明/通信再送は
同IDを維持し、runの終端が確認できた後の新しい明示クリックは新IDにする。
通信例外すべてで無条件にIDを捨てるのも二重受付を生むので避ける。
backendのidempotency契約は変える必要がない。

## 2. 保存した旧結果の明示固定が再読込で失われる

useWorkspace.ts:108（epoch初期化）、153-162（activeをacceptedへ入れepoch0のwatch）、
workspaceState.ts:60-68（restoreがselectionEpoch/latestRunを初期化）、86-94と110-116。
同画面ではepochが後着完了から手動選択を守るが、その意図は保存されない。
再接続したwatchもintent='complete'なので、active runの完了時に比較へ自動選択される。

具体例: a1を計算中に「完了後もこの結果を表示する」でa0を固定し、比較を保存。
ブラウザを再読込すると保存比較[a0,b0]は最初に戻るが、a1完了時には[b0,a1]へ
切り替わる。古い結果ファイルは破壊されないものの、「明示して保存した選択を維持」
という利用者の意図と一致しない。新しい比較を保存しない限りサーバ上の比較は旧版。

`fe-state-review450.cjs`は現実のdomain/workspaceStateを一時CommonJSへ変換して
reducerを再生した（FEソース編集なし）。`fe-state-review450.json`の結果:
再読込なし[b0,a0]、保存比較をrestore→active accepted→完了なら[b0,a1]。
これはreducerの実行確認で、実ブラウザのhook timing試験とは区別する。

採否案: 再読込で見つけたactive runは状態・結果の取得を再開するが、既存の保存比較を
暗黙に置換しないobserve intentとする等。新しい明示startだけが自動選択を予約する。
初回に保存結果がない時の扱いはUIで明示すればよく、永続イベント方式の一般化は不要。

## 3. 同一hook内の再読込についての限定した注意

useWorkspace.ts:46-47のwatchingはrun IDだけで、load generationを含まない。
旧watchがfetch/sleep中に同hookのloadを呼ぶと、新loadの同run watchはalready watching
でreturnし、その後旧watchがgeneration不一致で終わると監視がなくなる可能性がある。
またselectResult:188-204はgeneration検査なしで、epochをloadが0へ戻した後、
旧request epoch1と新選択epoch1が衝突すると旧応答が新選択へ勝つ。
後者のreducer再生は[b0,a2]の選択が旧epoch1の後着で[b0,a1]へ戻ることを確認した。

ただし現App.tsxでloadが明示ボタンから呼ばれるのは「source一覧なしのエラー再接続」
だけ。通常のブラウザ全再読込は新hookとなり、古いJS応答は残らない。この項目を
通常の全再読込で必ず発生する不具合とは主張しない。loadを共通の再読込操作として
保証するなら、watch所有をgeneration込みにし、select/save後着にもgenerationを
検査するという小さな境界補強で足りる。今回の受入を大きな状態機械へ拡張しない。

## 適合している点と検査の限界

現reducerは同generationの手動選択後に来る旧epoch完了を表示選択へ反映しない。
同A/Bの完了順が逆でも別candidateの比較を消さず、結果辞書に旧結果を残す。
saveはcaptured projectのsignatureだけを保存済みにするため、保存中の編集が
誤って保存済みになることを防ぐ。restoreの結果読込はallSettledで、片方の破損が
他方と草案を消さない。stoppedのresult_availableはbackend契約どおり完成結果として
選択でき、landing:nullを着地へ変換しない。上記1/2も科学出力自体を変更する問題では
なく、明示操作/保存比較/新試行の意味の問題である。

ブラウザ操作、hookの通信遅延注入、サーバ再起動はroot担当の独立検証に委ねた。
このレビューはFE全仕様・全アクセシビリティ・描画・科学モデルの再監査ではない。

## 最終再批評の追記 — freeze08で有限close

主担当の最終依頼により、修正済み17 sourceとbuildを再読した。読取開始時は
build07 `index-D2iVSvFo.js`、途中で主担当によるHistoryPanelのSVG軸ラベル修正が入り、
指定をfreeze08 `index-B4Uq6UDf.js`へ更新した。最初の独立harnessは9境界を通った後に
build名の不一致で停止し、無言で旧build合格とはしなかった。主担当から差分の範囲を
確認後、現build08を固定して再実行し9/9が通った。

`frontend-evidence450.json`の現在のactive_sources 17件と実file hashは全一致。
最終独立証拠は `fe-final-review450.cjs` と `fe-final-review450.json`。
実コードのexported API/helper/reducerとConfigEditorのイベントhandlerを一時copyで
実行し、6対象sourceはharness実行前後でhashが等しいことを確認した。
repo編集はしていない。build/全sourceの最終固定保存自体は主担当の責務である。

1. **再送と新試行の分離は解消。** workspaceState.tsのSubmissionIntentsは
   受理確認でintentを解放し、422等4xxは確定拒否として解放、500/502等は保持する。
   useWorkspace.startはapi.startの受理応答後にacknowledgeし、ApiErrorのstatusを
   rejectへ渡す。実api.tsへfetch stubで502を返した場合と、202のJSONが読めない場合は
   同じIDを維持した。受理後の明示試行は新IDとなり、前IDの遅いacknowledgeは新IDを
   消さないことを実行確認した。これはプロキシの実障害を注入したE2Eではない。

2. **保存比較の再読込反例は解消。** loadから再接続するwatchはintent='restore'を
   渡す。reducerはresult辞書とrun一覧を増やすが、restoreを選択更新に使わない。
   前回の同じa0/b0保存→active a1→後着結果を現在の呼出intentで再生すると、
   比較は[a0,b0]のまま、a1は結果一覧へ追加された。前回harnessが用いた'complete'は
   当時のhook呼出の再現であり、最終版の再接続はそのactionを送らない。

3. **監視所有と後着の世代境界は補強済み。** RunWatchOwnersはrun IDとgenerationを
   管理し、新世代の同run取得を許す一方、旧finallyでは新所有を解除しない。
   acquire1→acquire2→release1→acquire2拒否→release2→acquire2成功を確認した。
   watchのpoll/result、load、selectResult、startの後着更新、save成功/失敗/finallyは
   loadGenerationとaliveを照合する。前回のepoch衝突例は、旧generationのactionが
   reducerへ届く前に止まる。hook全体をReact環境の遅延通信で再演したものではなく、
   ownerの実行と呼出位置のコード読取による有限な確認である。

4. **直接入力の意味は保持。** 実api.startで送ったconfig JSONはcaptured候補と同一。
   元候補も不変。ConfigEditorを実行して、保存場選択はsource IDだけを変えること、
   経度一項目の変更は他の入力へ伝わらないことを確認した。径7.3m破裂を設定した
   等温浮力から定速へ変更しても径条件は保持され、draftIssueが未対応として止める。
   定速へ替えた際に高度破裂へ無言変換しない。方式そのものの変更はその方式の
   入力を初期値へ置換するが、画面下の注意に明示され、他sectionを変えない。
   初期A/Bは保存場から作る5/6m/sの比較presetであり、元isothermal例の完全再現とは
   表示・説明していない。数値積分設定は保持され、表示カーソルはconfigを更新しない。

5. **build08の指定修正は表示範囲。** HistoryPanel.tsxを全文読取し、bottom=65と
   独立した中央の「経過時間 [分]」行を確認した。軌道入力は元recordsをphasesで
   表示する経路で、API・model・solverへの書込はない。旧build07のHistoryPanel本文の
   byte差分まではこの担当の手元に保持していないため、変更がこの二箇所だけという
   操作実績は主担当の記録へ戻す。現HistoryPanelとbuild08参照の整合は確認した。

この焦点範囲で新たな重大な具体反例は見つからず、前回指摘をcloseする。一般的な
全React interleaving、実proxy障害、ブラウザ表示、科学精度、長期運用、可搬保存の
合格には広げない。ブラウザ表示とサーバ再起動の実操作は主担当の別証拠で扱う。
