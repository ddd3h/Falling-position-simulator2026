"""Fixed 0.45 save helper. Import is inert; only /root runs CLI/publish.

Run from the source workspace: snapshot -> freeze -> root release JSON -> publish.
Optional record-freeze -> root record release -> record-publish changes <=6 paths.
All Git writes are confined to the existing P430/git-save430 bare directory.
The fixed existing branch must start at 0.44 C2; main is verified separately and never changed.
The exact 137 prior + 29 new paths are fixed. This helper is not a metadata/test checker.
Only /root may execute after reviewing this candidate; publish also requires a stage release.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess

P = Path(__file__).resolve().parent
OLD = P.parent / 'balloon-framework-430'
PREVIOUS = P.parent / 'balloon-research-440'
G = OLD / 'git-save430'
BASIS_DIR = P / 'basis-C2'
BASE = '346e9484d3fc3444fd7a12c9e85710e479685666'
BASE_TREE = '7e090262c5da55a089b9f4a9292f06fa14a53c96'
BASE_FREEZE_HASH = 'fe8e750aafe6909899ddfb7b1bab70dc680a3182f99546a81f5a86a737dc62ab'
BASE_RECEIPT_HASH = '58b6db927d8ad8c5a71aa73a9e2d378f609e4144cc92be5445588d771401a897'
BASIS_MANIFEST_HASH = 'd9c0c2793fafaa82092957cb1515e780cc2bbb6bab41d0a15afd9032bf64a584'
NEW_ASSETS_HASH = '72b9bc725609af2c6f5c97d099d79deb7481f3cc137118ee6884e8030f35eec0'
PREVIOUS_ORIGINAL_HASH = 'dbe054bb1103df45b22d74ddd39f385369362275ad1567bb4a35794a06eaba90'
MAIN_BASIS_HASH = '2c55303bc568295f3faea29e75efe8f77779c1fb77d5ad31a75e3335c9e07b52'
MAIN = '4e3e4db0d047af9479bcd68bfc2553eeb71efcc9'
MAIN_TREE = '61f6853081aea968222f341e2b62dbada642dabc'
ORIGINAL_HEAD = 'ad3494d700068d873a22ed2fbbf6f0a760a41735'
BRANCH = 'codex/framework430-assessment'
REF = 'refs/heads/' + BRANCH
REMOTE = 'https://github.com/GENIANY/space-balloon-simulator-jp.git'
NEW = {
    '.gitignore',
    'backend/README.md',
    'backend/__init__.py',
    'backend/app.py',
    'backend/application.py',
    'backend/contracts.py',
    'backend/pyproject.toml',
    'backend/requirements.lock',
    'backend/storage.py',
    'backend/tests/test_application.py',
    'backend/worker.py',
    'frontend/index.html',
    'frontend/package-lock.json',
    'frontend/package.json',
    'frontend/src/App.tsx',
    'frontend/src/ConfigEditor.tsx',
    'frontend/src/HistoryPanel.tsx',
    'frontend/src/MapPanel.tsx',
    'frontend/src/api.ts',
    'frontend/src/domain.test.ts',
    'frontend/src/domain.ts',
    'frontend/src/main.tsx',
    'frontend/src/style.css',
    'frontend/src/useWorkspace.ts',
    'frontend/src/workspaceState.test.ts',
    'frontend/src/workspaceState.ts',
    'frontend/tsconfig.json',
    'frontend/vite.config.ts',
    'references/design_trials/framework_integration_045.zip',
}
RECORD_ALLOWED = {'BOOTSTRAP_RUNBOOK.html', 'REFERENCE_LOG.md', 'CONTENT_MAP.md',
                  'docs/VERSION_HISTORY.json', 'docs/CONTENT_HEALTH.json',
                  'docs/CONTINUITY_CONTRACT.json'}
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never', GIT_OPTIONAL_LOCKS='0')


class Refused(RuntimeError):
    pass


def need(ok, why):
    if not ok:
        raise Refused(why)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write_new(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def path_name(name):
    need(isinstance(name, str) and bool(name), 'empty/nontext path')
    need(not any(c in name for c in '\\\t\r\n\0:'), 'nonportable path')
    p = PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix() == name and '..' not in p.parts,
         'noncanonical or escaping path')
    return p


def safe_file(base, name):
    relative = path_name(name)
    path = base
    for part in relative.parts:
        path = path / part
        need(not path.is_symlink() and not path.is_junction(), 'linked path: ' + name)
    need(path.is_file() and path.resolve().is_relative_to(base.resolve()),
         'missing or escaping file: ' + name)
    return path


def git(args, where=G, data=None, env=None):
    try:
        r = subprocess.run(['git', '-C', str(where), *args], input=data,
                           capture_output=True, env=env or ENV, timeout=180)
    except subprocess.TimeoutExpired:
        raise Refused('git ' + args[0] + ' timed out; inspect receipts/refs, do not blindly retry')
    # Never print git diagnostics: they may contain authentication material.
    need(r.returncode == 0, 'git ' + args[0] + ' failed (exit ' + str(r.returncode)
         + '); inspect receipts/refs before recovery')
    return r.stdout


def gt(args, where=G, data=None, env=None):
    return git(args, where, data, env).decode('utf-8').strip()


def original_state(root):
    gd = root / '.git'
    need(gd.is_dir() and not gd.is_symlink() and not gd.is_junction(),
         'original .git must be a regular directory')
    head = gt(['rev-parse', 'HEAD'], root)
    need(head == ORIGINAL_HEAD, 'original checkout HEAD is not the explicitly required M101')
    rows = []
    for p in sorted(gd.rglob('*')):
        need(not p.is_symlink() and not p.is_junction(), 'linked path inside original .git')
        if p.is_file():
            rows.append({'path': p.relative_to(gd).as_posix(), 'sha256': digest(p)})
    return {'head': head, 'files': rows, 'fingerprint': sha(
        json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}


def previous_original(root):
    # Prior evidence is retained. Only a root-approved exact addition inventory
    # may explain the already observed difference; later differences still fail.
    path = safe_file(PREVIOUS, 'original-git440.json')
    need(digest(path) == PREVIOUS_ORIGINAL_HASH, 'previous original snapshot changed')
    saved = read(path)
    need(saved.get('schema') == 'save440-original/1' and saved.get('root') == str(root)
         and saved.get('state', {}).get('head') == ORIGINAL_HEAD,
         'previous snapshot belongs to another workspace/schema/head')
    approval_path = safe_file(P, 'original-git450-additions-approval.json')
    approval = read(approval_path)
    need(approval.get('schema') == 'save450-original-additions-approval/1'
         and approval.get('approved') is True and approval.get('reviewed_by') == '/root',
         'explicit root approval of the 33 original-object additions is required')
    need(approval.get('root') == str(root)
         and approval.get('helper_sha256') == digest(Path(__file__))
         and approval.get('prior_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH,
         'original-additions approval names another root/helper/prior snapshot')
    difference_path = safe_file(P, 'original-git450-difference.json')
    difference_hash = '6974eada550cc4defed17c255f15556ac3f1de4e1a41b897d99ae0f2ad0d46b3'
    need(digest(difference_path) == difference_hash
         and approval.get('difference_sha256') == difference_hash,
         'original-object difference evidence changed')
    expected_evidence = {'original-git450-object-review.json': 'c92cdb54af5ab203e4cb48404d29eca2166887ca731a03d1ff2c26ac78548708', 'original-git450-partial-review.json': 'c7574906acbad49e8d8204e69d8f03f0b2ee4eaf5fe43ffb8de29138fe02c071', 'original-git450-investigation.md': 'f7e0c79021818b902fe315d6ada29994a05812764a34bbdc69481da39796a0e2'}
    need(approval.get('evidence') == expected_evidence,
         'original-additions approval names different investigation evidence')
    for name, expected in expected_evidence.items():
        need(digest(safe_file(P, name)) == expected, 'original-object investigation changed: ' + name)
    difference = read(difference_path)
    need(difference.get('prior_head') == ORIGINAL_HEAD and difference.get('now_head') == ORIGINAL_HEAD,
         'original HEAD differs in the reviewed difference')
    old_rows = saved['state']['files']
    old_paths = {r['path'] for r in old_rows}
    delta = difference['diff']
    need(len(old_rows) == len(old_paths) == 905 and len(delta) == 33
         and all(r.get('before') is None and r['path'] not in old_paths
                 and isinstance(r.get('after'), str) and re.fullmatch('[0-9a-f]{64}', r['after'])
                 for r in delta), 'approved inventory is not 905 unchanged plus 33 additions')
    additions = sorted([{'path': r['path'], 'sha256': r['after']} for r in delta], key=lambda r: r['path'])
    need(approval.get('allowed_additions') == additions and approval.get('prior_file_count') == 905
         and approval.get('expected_file_count') == 938,
         'approved additions/count differ from the exact investigation')
    for r in additions:
        path_name(r['path'])
        need(r['path'].startswith('objects/'), 'reviewed addition is outside object storage')
    rows = sorted(old_rows + additions, key=lambda r: root / '.git' / r['path'])
    need(len({r['path'].casefold() for r in rows}) == 938, 'original inventory path collision')
    state = {'head': ORIGINAL_HEAD, 'files': rows, 'fingerprint': sha(
        json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}
    need(approval.get('expected_fingerprint') == state['fingerprint'],
         'approved original inventory fingerprint mismatch')
    return state


def original(root):
    saved = read(safe_file(P, 'original-git450.json'))
    need(saved.get('schema') == 'save450-original/1' and saved.get('root') == str(root)
         and saved.get('prior_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH
         and saved.get('additions_approval_sha256') == digest(safe_file(P, 'original-git450-additions-approval.json'))
         and saved.get('difference_sha256') == digest(safe_file(P, 'original-git450-difference.json')),
         'snapshot belongs to another workspace/schema/prior snapshot/addition approval')
    need(saved['state'] == previous_original(root),
         'original snapshot differs from the explicitly approved 938-file inventory')
    now = original_state(root)
    need(now == saved['state'], 'original .git changed since save450 snapshot; no automatic rebaseline')
    return now


def checked_rows(rows, count):
    need(len(rows) == count and len({r['path'].casefold() for r in rows}) == count,
         'fixed basis must contain exactly ' + str(count) + ' unique blobs')
    for r in rows:
        path_name(r['path'])
        need(r['mode'] in {'100644', '100755'} and re.fullmatch('[0-9a-f]{40}', r['blob'])
             and re.fullmatch('[0-9a-f]{64}', r['sha256'])
             and type(r['size']) is int and r['size'] >= 0, 'invalid basis row')
    return {r['path']: r for r in rows}


def main_basis():
    path = safe_file(OLD, 'fixed-bases.json')
    need(digest(path) == MAIN_BASIS_HASH, 'M420 fixed basis changed')
    b = read(path)
    need(b.get('our_main') == MAIN, 'main basis is not M420')
    return checked_rows(b['our_files'], 131)


def basis():
    manifest_path = safe_file(P, 'basis450.json')
    path = safe_file(PREVIOUS, 'record-freeze440.json')
    receipt_path = safe_file(PREVIOUS, 'record-git-receipt440.json')
    need(digest(manifest_path) == BASIS_MANIFEST_HASH
         and digest(path) == BASE_FREEZE_HASH and digest(receipt_path) == BASE_RECEIPT_HASH,
         'C2 fixed manifest/evidence changed')
    manifest, b, receipt = read(manifest_path), read(path), read(receipt_path)
    need(manifest.get('main') == MAIN and manifest.get('candidate') == BASE
         and manifest.get('tree') == BASE_TREE, 'wrong basis450 manifest')
    need(b.get('schema') == 'save440-freeze/1' and b.get('stage') == 'record'
         and b.get('main') == MAIN and b.get('main_tree') == MAIN_TREE
         and b.get('branch') == BRANCH and b.get('remote') == REMOTE
         and b.get('version') == '0.44.0', 'wrong C2 freeze')
    need(receipt.get('schema') == 'save440-receipt/1' and receipt.get('stage') == 'record'
         and receipt.get('status') == 'readback_verified' and receipt.get('commit') == BASE
         and receipt.get('tree') == BASE_TREE and receipt.get('parent') == b['parent']
         and receipt.get('main') == MAIN and receipt.get('branch') == BRANCH
         and receipt.get('files') == 137 and receipt.get('freeze_sha256') == BASE_FREEZE_HASH
         and receipt.get('original_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH
         and b.get('original_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH, 'wrong C2 receipt')
    prior = checked_rows(manifest['files'], 137)
    need(prior == checked_rows(b['files'], 137), 'basis450 and C2 freeze rows differ')
    need(BASIS_DIR.is_dir() and not BASIS_DIR.is_symlink() and not BASIS_DIR.is_junction(),
         'basis-C2 must be a regular directory')
    actual = set()
    for p in BASIS_DIR.rglob('*'):
        need(not p.is_symlink() and not p.is_junction(), 'linked path inside basis-C2')
        if p.is_file():
            actual.add(p.relative_to(BASIS_DIR).as_posix())
    need(actual == set(prior), 'basis-C2 path set differs from fixed 137 rows')
    for r in prior.values():
        data = safe_file(BASIS_DIR, r['path']).read_bytes()
        need(len(data) == r['size'] and sha(data) == r['sha256']
             and hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == r['blob'],
             'basis-C2 file differs from fixed row: ' + r['path'])
    return prior


def new_assets():
    path = safe_file(P, 'newassets450.json')
    need(digest(path) == NEW_ASSETS_HASH, 'new asset declaration changed')
    rows = read(path)
    need(isinstance(rows, list) and len(rows) == 29, 'new assets must contain exactly 29 rows')
    names = [r['path'] for r in rows]
    need(len({name.casefold() for name in names}) == 29 and set(names) == NEW,
         'new asset paths differ from the explicitly reviewed 29 paths')
    for name in names:
        path_name(name)
    return NEW


def rows_for(root, prior):
    health = read(safe_file(root, 'docs/CONTENT_HEALTH.json'))
    need(health['document_version'] == '0.45.0' and health['basis_commit'] == MAIN,
         'HEALTH must identify 0.45.0 based on M420')
    names = list(health['files'])
    need(len(names) == 166 and len({n.casefold() for n in names}) == 166
         and not set(prior) & new_assets() and set(names) == set(prior) | NEW,
         'must retain all 137 paths and add only the reviewed 29 implementation/evidence paths')
    rows = []
    for name in sorted(names):
        path_name(name)
        need(not any(x.casefold() in {'.git', '.agents', '.codex', '__pycache__'}
                     for x in PurePosixPath(name).parts), 'administrative path in manifest')
        data = safe_file(root, name).read_bytes()
        need(len(data) < 100 * 1024 * 1024, 'oversized file: ' + name)
        rows.append({'path': name, 'mode': prior.get(name, {}).get('mode', '100644'),
                     'size': len(data), 'sha256': sha(data),
                     'blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    return rows


def refs():
    lines = gt(['ls-remote', '--heads', REMOTE, 'refs/heads/main', REF], P).splitlines()
    pairs = [line.split() for line in lines]
    need(all(len(p) == 2 for p in pairs) and len({p[1] for p in pairs}) == len(pairs),
         'malformed remote refs')
    return {p[1]: p[0] for p in pairs}


def expect_refs(parent):
    expected = {'refs/heads/main': MAIN, REF: parent}
    need(refs() == expected, 'main changed or existing branch parent mismatch')
    return expected


def prepare_bare():
    need(OLD.is_dir() and not OLD.is_symlink() and not OLD.is_junction()
         and G.is_dir() and not G.is_symlink() and not G.is_junction()
         and G.resolve().parent == OLD.resolve(), 'existing external bare path escaped P430')
    need(gt(['rev-parse', '--is-bare-repository']) == 'true', 'not bare')
    need(gt(['remote', 'get-url', '--all', 'origin']) == REMOTE
         and gt(['remote', 'get-url', '--push', '--all', 'origin']) == REMOTE,
         'unexpected fetch/push URL')


def tree_rows(commit):
    rows = {}
    for entry in git(['ls-tree', '-r', '-z', '--full-tree', commit]).split(b'\0'):
        if entry:
            meta, name = entry.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            need(kind == 'blob', 'nonblob tree entry')
            name = name.decode('utf-8')
            path_name(name)
            need(name not in rows, 'duplicate tree entry')
            rows[name] = (mode, blob)
    return rows


def verify_tree(commit, rows):
    need(tree_rows(commit) == {r['path']: (r['mode'], r['blob']) for r in rows},
         'actual tree does not match frozen path/mode/blob set')


def verify_blobs(rows):
    for r in rows:
        data = git(['cat-file', 'blob', r['blob']])
        need(len(data) == r['size'] and sha(data) == r['sha256'], 'fixed blob content hash mismatch')


def fetch_basis(prior):
    prepare_bare()
    gt(['fetch', '--no-tags', '--depth=1', 'origin', 'refs/heads/main'])
    need(gt(['rev-parse', 'FETCH_HEAD']) == MAIN
         and gt(['rev-parse', MAIN + '^{tree}']) == MAIN_TREE, 'fetched main/tree is not M420')
    main_rows = list(main_basis().values())
    verify_tree(MAIN, main_rows)
    verify_blobs(main_rows)
    # C2 is the initial parent; main is checked separately and is never the parent.
    gt(['fetch', '--no-tags', '--depth=1', 'origin', BASE])
    need(gt(['rev-parse', 'FETCH_HEAD']) == BASE
         and gt(['rev-parse', BASE + '^{tree}']) == BASE_TREE, 'fetched basis/tree is not fixed C2')
    verify_tree(BASE, list(prior.values()))
    verify_blobs(list(prior.values()))


def stage_names(stage):
    prefix = 'record-' if stage == 'record' else ''
    return {key: P / (prefix + name + '450.json') for key, name in
            [('freeze', 'freeze'), ('release', 'release'), ('pending', 'prepush'), ('receipt', 'git-receipt')]}


def frozen(root, stage, prior):
    rows = rows_for(root, prior)
    parent, changes = BASE, []
    if stage == 'record':
        first = read(safe_file(P, 'freeze450.json'))
        receipt = read(safe_file(P, 'git-receipt450.json'))
        need(receipt.get('schema') == 'save450-receipt/1' and receipt.get('stage') == 'initial'
             and receipt.get('status') == 'readback_verified' and receipt.get('parent') == BASE
             and receipt.get('main') == MAIN and receipt.get('branch') == BRANCH
             and receipt.get('freeze_sha256') == digest(P / 'freeze450.json'),
             'record requires verified initial receipt and unchanged initial freeze')
        parent = receipt['commit']
        need(re.fullmatch('[0-9a-f]{40}', parent), 'invalid record parent')
        old = {r['path']: r for r in first['files']}
        need(set(old) == {r['path'] for r in rows}, 'record cannot add/delete paths')
        changes = [r['path'] for r in rows if r != old[r['path']]]
        need(changes and set(changes) <= RECORD_ALLOWED, 'record changes exceed six management paths')
    return {'schema': 'save450-freeze/1', 'stage': stage, 'version': '0.45.0',
            'root': str(root), 'main': MAIN, 'main_tree': MAIN_TREE, 'parent': parent,
            'branch': BRANCH, 'remote': REMOTE, 'basis_commit': BASE, 'basis_tree': BASE_TREE,
            'files': rows, 'record_increment': changes,
            'changed_from_C2': [r['path'] for r in rows if r['path'] not in prior
                                  or r['blob'] != prior[r['path']]['blob']],
            'basis_sha256': digest(P / 'basis450.json'),
            'basis_freeze_sha256': digest(PREVIOUS / 'record-freeze440.json'),
            'basis_receipt_sha256': digest(PREVIOUS / 'record-git-receipt440.json'),
            'new_assets_sha256': digest(P / 'newassets450.json'),
            'main_basis_sha256': digest(OLD / 'fixed-bases.json'),
            'original_snapshot_sha256': digest(P / 'original-git450.json'),
            'helper_sha256': digest(Path(__file__))}


def validate_release(release, frozen_data, freeze_path):
    need(release.get('schema') == 'save450-release/1' and release.get('reviewed_by') == '/root'
         and release.get('approved') is True, 'explicit root release missing')
    for key in ('stage', 'main', 'branch', 'parent', 'basis_commit', 'basis_tree',
                'helper_sha256', 'original_snapshot_sha256', 'basis_sha256',
                'basis_freeze_sha256', 'basis_receipt_sha256', 'new_assets_sha256'):
        need(release.get(key) == frozen_data[key], 'release mismatch: ' + key)
    need(release.get('freeze_sha256') == digest(freeze_path), 'release names another freeze')
    evidence = release.get('evidence')
    need(isinstance(evidence, dict) and evidence, 'fixed review evidence is required')
    for name, expected in evidence.items():
        need(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected), 'invalid evidence hash')
        need(digest(safe_file(P, name)) == expected, 'evidence changed: ' + name)


def make_tree(rows, prefix=''):
    entries = {}
    for r in rows:
        if r['path'].startswith(prefix):
            name, separator, _ = r['path'][len(prefix):].partition('/')
            entries[name] = ('040000', 'tree', None) if separator else (r['mode'], 'blob', r['blob'])
    raw = b''
    for name, (mode, kind, obj) in sorted(entries.items()):
        obj = obj or make_tree(rows, prefix + name + '/')
        raw += f'{mode} {kind} {obj}\t'.encode() + name.encode() + b'\0'
    return gt(['mktree', '-z'], data=raw)


def publish(root, stage, prior, current, paths):
    need(not paths['pending'].exists() and not paths['receipt'].exists(),
         'publish already attempted; inspect receipt and fixed remote refs, no automatic retry')
    need(read(safe_file(P, paths['freeze'].name)) == current, 'source/helper/basis differs from freeze')
    release = read(safe_file(P, paths['release'].name))
    validate_release(release, current, paths['freeze'])
    parent = current['parent']
    expect_refs(parent)
    fetch_basis(prior)
    if stage == 'record':
        gt(['fetch', '--no-tags', '--depth=1', 'origin', REF])
        need(gt(['rev-parse', 'FETCH_HEAD']) == parent, 'record branch parent moved')
        verify_tree(parent, read(P / 'freeze450.json')['files'])
        need(gt(['rev-parse', parent + '^{tree}']) == read(P / 'git-receipt450.json')['tree'],
             'record parent tree differs from initial receipt')
    for r in current['files']:
        data = safe_file(root, r['path']).read_bytes()
        need(sha(data) == r['sha256'], 'source changed during object writes')
        need(gt(['hash-object', '-w', '--stdin'], data=data) == r['blob'], 'object write mismatch')
    tree = make_tree(current['files'])
    identenv = dict(ENV)
    for kind in ('AUTHOR', 'COMMITTER'):
        ident = gt(['var', 'GIT_' + kind + '_IDENT'], root)
        match = re.fullmatch(r'(.*) <([^>]+)> (.*)', ident)
        need(match is not None, 'Git identity unavailable')
        identenv['GIT_' + kind + '_NAME'], identenv['GIT_' + kind + '_EMAIL'] = match[1], match[2]
    message = ('Connect saved-field two-run comparison with local React and FastAPI (0.45.0)' if stage == 'initial'
               else 'Record 0.45 validation and fixed branch readback')
    need(frozen(root, stage, prior) == current, 'source changed before commit')
    commit = gt(['commit-tree', tree, '-p', parent], data=(message + '\n').encode(), env=identenv)
    need(gt(['rev-list', '--parents', '-n', '1', commit]).split() == [commit, parent],
         'commit must have exactly one fixed parent')
    verify_tree(commit, current['files'])
    receipt = {'schema': 'save450-receipt/1', 'stage': stage, 'status': 'push_pending_or_uncertain',
               'main': MAIN, 'parent': parent, 'commit': commit, 'tree': tree, 'branch': BRANCH,
               'files': len(current['files']), 'freeze_sha256': digest(paths['freeze']),
               'release_sha256': digest(paths['release']), 'helper_sha256': current['helper_sha256'],
               'original_snapshot_sha256': current['original_snapshot_sha256'],
               'at_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    # Durable intent first; even interrupted/ambiguous pushes cannot auto-retry.
    write_new(paths['pending'], receipt)
    expect_refs(parent)
    need(frozen(root, stage, prior) == current and read(paths['release']) == release,
         'source or release changed immediately before push')
    validate_release(release, current, paths['freeze'])
    original(root)
    lease = parent  # Both stages update this fixed existing branch; neither creates it.
    gt(['push', '--no-follow-tags', '--recurse-submodules=no',
        '--force-with-lease=' + REF + ':' + lease, 'origin', commit + ':' + REF])
    # Verify live refs, fetched identities, complete tree, then live refs again.
    need(refs() == {'refs/heads/main': MAIN, REF: commit}, 'post-push refs mismatch')
    gt(['fetch', '--no-tags', '--depth=1', 'origin', 'refs/heads/main'])
    need(gt(['rev-parse', 'FETCH_HEAD']) == MAIN and gt(['rev-parse', MAIN + '^{tree}']) == MAIN_TREE,
         'main readback changed')
    gt(['fetch', '--no-tags', '--depth=1', 'origin', REF])
    need(gt(['rev-parse', 'FETCH_HEAD']) == commit
         and gt(['rev-parse', commit + '^{tree}']) == tree, 'branch readback mismatch')
    verify_tree(commit, current['files'])
    verify_blobs(current['files'])
    need(refs() == {'refs/heads/main': MAIN, REF: commit}, 'refs changed during readback')
    original(root)
    receipt['status'] = 'readback_verified'
    write_new(paths['receipt'], receipt)
    print(json.dumps(receipt))


def execute(root, mode):
    need(P != root and not P.is_relative_to(root) and not root.is_relative_to(P),
         'helper/evidence must be outside the workspace')
    if mode == 'snapshot':
        first = original_state(root)
        need(first == previous_original(root),
             'original .git differs from the explicitly approved 905 + 33 inventory')
        need(original_state(root) == first, 'original .git changed while snapshotting')
        path = P / 'original-git450.json'
        write_new(path, {'schema': 'save450-original/1', 'root': str(root), 'state': first,
                         'at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                         'prior_snapshot_sha256': PREVIOUS_ORIGINAL_HASH,
                         'additions_approval_sha256': digest(safe_file(P, 'original-git450-additions-approval.json')),
                         'difference_sha256': digest(safe_file(P, 'original-git450-difference.json')),
                         'scope': 'Observed start of save450: prior 905 files unchanged plus exactly 33 root-approved pre-existing object additions. All 938 fixed for this save period; writer unknown; not historical whole-.git immutability.'})
        print(json.dumps({'snapshot': path.name, 'sha256': digest(path),
                          'head': first['head'], 'files': len(first['files'])}))
        return
    original(root)
    try:
        stage = 'record' if mode.startswith('record-') else 'initial'
        paths = stage_names(stage)
        prior = basis()
        current = frozen(root, stage, prior)
        if mode in {'freeze', 'record-freeze'}:
            need(not paths['freeze'].exists(), 'freeze already exists; no automatic replacement')
            expect_refs(current['parent'])
            fetch_basis(prior)
            if stage == 'record':
                gt(['fetch', '--no-tags', '--depth=1', 'origin', REF])
                need(gt(['rev-parse', 'FETCH_HEAD']) == current['parent'], 'record parent moved')
                verify_tree(current['parent'], read(P / 'freeze450.json')['files'])
            need(frozen(root, stage, prior) == current, 'source changed while freezing')
            original(root)
            write_new(paths['freeze'], current)
            print(json.dumps({'stage': stage, 'freeze': paths['freeze'].name,
                              'sha256': digest(paths['freeze']), 'files': len(current['files']),
                              'parent': current['parent'], 'changes': current['changed_from_C2'],
                              'record_increment': current['record_increment']}))
        else:
            publish(root, stage, prior, current, paths)
    finally:
        original(root)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['snapshot', 'freeze', 'publish', 'record-freeze', 'record-publish'])
    args = parser.parse_args()
    try:
        execute(Path.cwd().resolve(), args.mode)
    except (Refused, FileExistsError, KeyError, ValueError, OSError) as error:
        raise SystemExit('REFUSED: ' + str(error))


if __name__ == '__main__':
    main()
