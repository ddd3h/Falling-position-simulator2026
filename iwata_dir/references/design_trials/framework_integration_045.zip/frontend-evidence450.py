from pathlib import Path
import hashlib, json

repo = Path(r'C:\Users\genia\OneDrive\ドキュメント\00 よく使う\n_名古屋大学\06_Chart\バルーン\Balloon_Sim\2026_Sep_\space-balloon-simulator-jp')
p450 = Path(r'C:\Users\genia\AppData\Local\Temp\balloon-implementation-450')
reference = Path(r'C:\Users\genia\AppData\Local\Temp\balloon-framework-430\template\frontend')
copy = p450 / 'frontend-reference-ci'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks = [{'path': p.relative_to(reference).as_posix(), 'sha256': sha(p), 'copy_equal': (copy / p.relative_to(reference)).is_file() and p.read_bytes() == (copy / p.relative_to(reference)).read_bytes()} for p in sorted(reference.rglob('*')) if p.is_file()]
files = []
for path in sorted((repo / 'frontend').rglob('*')):
    relative = path.relative_to(repo / 'frontend')
    if not path.is_file() or relative.parts[0] in {'node_modules', 'dist'}:
        continue
    files.append({'path': 'frontend/' + relative.as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
lock = json.loads((repo / 'frontend/package-lock.json').read_text(encoding='utf-8'))
native = []
for name, package in lock['packages'].items():
    if package.get('os') or package.get('cpu'):
        native.append({'path': name, 'version': package.get('version'), 'os': package.get('os'), 'cpu': package.get('cpu'), 'optional': package.get('optional'), 'installed': (repo / 'frontend' / name).exists()})
data = {'date': '2026-09-29', 'basis_from_parent': {'main': '4e3e4db0d047af9479bcd68bfc2553eeb71efcc9', 'candidate': '346e9484d3fc3444fd7a12c9e85710e479685666'}, 'reference_source_commit': '94887cbb97a8b8ba98d84ef7662e2df200f000d7', 'reference_checks': checks, 'reference_unchanged': all(c['copy_equal'] for c in checks), 'active_sources': files, 'active_native_optional_dependencies': native, 'old_model_zip_sha256': sha(repo / 'references/design_trials/hover_surface_pick_correction_0401.zip')}
(p450 / 'frontend-evidence450.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'reference_files': len(checks), 'reference_unchanged': data['reference_unchanged'], 'active_source_files': len(files), 'installed_native': [x for x in native if x['installed']]}, ensure_ascii=False, indent=2))
