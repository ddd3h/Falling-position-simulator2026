// Independent finite replay of frozen FE source; copies/output only under P450.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const Module = require('node:module');
const crypto = require('node:crypto');
const root = process.cwd();
const ts = require(path.join(root, 'frontend/node_modules/typescript/lib/typescript.js'));
const out = path.join(__dirname, 'fe-final-review450');
fs.mkdirSync(out, {recursive:true});
const hashes = {};
for (const name of ['domain.ts','workspaceState.ts','api.ts','ConfigEditor.tsx','useWorkspace.ts','App.tsx']) {
  const relative = 'frontend/src/'+name, source = fs.readFileSync(path.join(root,relative),'utf8');
  hashes[relative] = crypto.createHash('sha256').update(Buffer.from(source)).digest('hex');
  fs.writeFileSync(path.join(out,name.replace(/\.tsx?$/,'.js')), ts.transpileModule(source,{
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}
  }).outputText);
}
const {SubmissionIntents, RunWatchOwners, initialState, workspaceReducer:reduce} = require(path.join(out,'workspaceState.js'));
const {api,ApiError} = require(path.join(out,'api.js'));
const {draftIssue} = require(path.join(out,'domain.js'));
const editorModule = new Module(path.join(out,'ConfigEditor.js'));
editorModule.filename = path.join(out,'ConfigEditor.js');
editorModule.paths = [path.join(root,'frontend/node_modules')];
editorModule._compile(fs.readFileSync(editorModule.filename,'utf8'),editorModule.filename);
const {ConfigEditor} = editorModule.exports;
const config = JSON.parse(fs.readFileSync(path.join(root,'examples/wakayama-isothermal.json'),'utf8'));
config.burst = {mode:'diameter',diameter_m:7.3};
const a = {id:'A',label:'A',revision:3,weather_source_id:'fixture',config};
const checks = [];
async function test(name, operation) { await operation(); checks.push({name,status:'pass'}); }
const run = (id,candidateId,state='completed') => ({run_id:id,candidate_id:candidateId,state,result_available:state==='completed'});
const project = {schema:'balloon.project/1',title:'review',candidates:[a,{...a,id:'B'}],compare_run_ids:['a0','b0']};
const savedState = () => reduce(initialState(),{type:'restore',project:structuredClone(project),revision:2,runs:[run('a0','A'),run('b0','B'),run('a1','A','running')]});
function descendants(node) {
  if (Array.isArray(node)) return node.flatMap(descendants);
  if (!node || typeof node !== 'object') return [];
  return [node,...descendants(node.props?.children)];
}
function edited(handler) {
  let changed;
  const tree = ConfigEditor({candidate:a,sources:[{id:'fixture',label:'saved',default_config:config}],onChange:c=>changed=c});
  handler(descendants(tree));
  assert.ok(changed);
  return changed;
}
(async()=>{
  await test('5xx POST response retains one unknown intent',async()=>{
    let i=0; const intents=new SubmissionIntents(()=>`id-${++i}`), first=intents.forAttempt(a);
    global.fetch=async()=>({status:502,ok:false,json:async()=>({error:'upstream response lost'})});
    try {await api.start(a,first); assert.fail();} catch(e) {assert.ok(e instanceof ApiError); intents.reject(a,first,e.status);}
    assert.equal(intents.forAttempt(a),first);
  });
  await test('202 unreadable JSON keeps ID; definite 422 releases it',async()=>{
    let i=0; const intents=new SubmissionIntents(()=>`id-${++i}`), first=intents.forAttempt(a);
    global.fetch=async()=>({status:202,ok:true,json:async()=>{throw new Error('truncated');}});
    try {await api.start(a,first);assert.fail();} catch(e) {intents.reject(a,first,e.status);}
    assert.equal(intents.forAttempt(a),first);
    intents.reject(a,first,422); assert.notEqual(intents.forAttempt(a),first);
  });
  await test('acknowledged intent permits a new explicit attempt and protects it from an old acknowledgement',()=>{
    let i=0; const intents=new SubmissionIntents(()=>`id-${++i}`), first=intents.forAttempt(a);
    intents.acknowledge(a,first); const second=intents.forAttempt(a); assert.notEqual(second,first);
    intents.acknowledge(a,first); assert.equal(intents.forAttempt(a),second);
  });
  await test('reload replaces watch owner; old finally cannot release newer watch',()=>{
    const owners=new RunWatchOwners(); assert.equal(owners.acquire('a1',1),true);
    assert.equal(owners.acquire('a1',2),true); owners.release('a1',1);
    assert.equal(owners.acquire('a1',2),false); owners.release('a1',2); assert.equal(owners.acquire('a1',2),true);
  });
  await test('restored active completion keeps saved a0/b0 selection while recording a1',()=>{
    let state=savedState(); state=reduce(state,{type:'accepted',candidateId:'A',run:run('a1','A','running')});
    state=reduce(state,{type:'result',candidateId:'A',run:run('a1','A'),result:{run_id:'a1'},epoch:0,intent:'restore'});
    assert.deepEqual(state.project.compare_run_ids,['a0','b0']); assert.ok(state.results.a1);
  });
  await test('physical config JSON is forwarded unchanged and source candidate is not mutated',async()=>{
    const original=JSON.stringify(a); let sent;
    global.fetch=async(url,init)=>{sent=JSON.parse(init.body);return {ok:true,status:202,json:async()=>({run_id:'r'})};};
    await api.start(a,'once'); assert.deepEqual(sent.config,a.config);assert.equal(JSON.stringify(a),original);
  });
  await test('changing saved field ID does not rewrite launch or models',()=>{
    const changed=edited(nodes=>nodes.find(n=>n.type==='select'&&n.props.value==='fixture').props.onChange({target:{value:'other-fixture'}}));
    assert.equal(changed.weather_source_id,'other-fixture'); assert.deepEqual(changed.config,a.config);
  });
  await test('switching ascent keeps diameter and incompatible pair is visibly rejected',()=>{
    const changed=edited(nodes=>nodes.find(n=>n.type==='select'&&n.props.value==='isothermal_buoyancy').props.onChange({target:{value:'constant_speed'}}));
    assert.deepEqual(changed.config.burst,{mode:'diameter',diameter_m:7.3}); assert.match(draftIssue(changed.config),/未対応/);
    assert.deepEqual(changed.config.launch,a.config.launch); assert.deepEqual(changed.config.descent,a.config.descent);
  });
  await test('one numeric field edit does not rewrite unrelated kernel input',()=>{
    const changed=edited(nodes=>nodes.find(n=>n.type==='input'&&n.props.type==='number'&&n.props.value===a.config.launch.longitude_deg).props.onChange({target:{value:'136.24'}}));
    const expected=structuredClone(a.config); expected.launch.longitude_deg=136.24;
    assert.deepEqual(changed.config,expected);assert.equal(changed.revision,a.revision+1);
  });
  for (const [relative,hash] of Object.entries(hashes)) assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,relative))).digest('hex'),hash,'source changed during review');
  const built=fs.readFileSync(path.join(root,'frontend/dist/index.html'),'utf8');
  assert.ok(built.includes('index-B4Uq6UDf.js'));
  const report={schema:'balloon.fe-final-review/1',at_utc:new Date().toISOString(),source_hashes:hashes,build_entry:'index-B4Uq6UDf.js',checks,
    limits:['Source reading and actual exported reducers/helpers/API/editor handlers only','Not a browser React-hook timing or proxy fault-injection test','No repo edits; source input and result files unchanged']};
  fs.writeFileSync(path.join(__dirname,'fe-final-review450.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:checks.length,build:report.build_entry,checks},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
