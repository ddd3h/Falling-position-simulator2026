# 0.45 backend 最小縦断設計

実装後の確定事項は `backend-delivery450.md` と repo の backend/README.md を参照。
compare_run_ids は completed 固定結果のみへ主担当判断で限定し、pending復帰はrun一覧に分けた。
dispatcher は application.py 内に置き、jobs.py は新設していない。

基準: main M420 `4e3e4db0d047af9479bcd68bfc2553eeb71efcc9`、未統合PR30 0.44記録C2 `346e9484d3fc3444fd7a12c9e85710e479685666`。2026-09-29。D-183、INTEGRATION 5/5.1/7/7.2、ENV現API/INPUT-BRIDGE、参考評価ZIP内backend-review、現config/models/trajectory/numerics/storage/export/cliを読取。主担当のS35/D184追記後、backend/とそのtestsだけ編集許可を受領した。核は移動・複写・改変しない。

## 接続と最小責務

`FastAPI → application service → bounded job runner → balloon_sim`。HTTPなしでもserviceを呼べる。既存 `validate_config` が物理入力の権威で、PydanticはHTTP外枠を担当する。保存GFSはサーバが列挙したIDから解決し、クライアントの任意path/URLを受けない。初回は直接入力二実行n=1の比較と再起動再閲覧。MC/確率域/過去場adapter/気象取得/キー/写真3D/portable importは含めない。

`backend/app.py`（factory/router/static）、`contracts.py`（HTTP DTO）、`application.py`（submit/read/project）、`storage.py`（SQLite registryとartifact検証）、`jobs.py`（1 process worker＋有限待機）、`worker.py`（固定spec→既存核/export）、README、pyprojectと依存lock、testsを新設する。既存`balloon_sim/`はその位置のまま。repo rootから`backend.app:create_app --factory`を起動する。

SQLiteはproject草案、固定run識別、job状態の小さいregistryだけに使い、原履歴は不変ファイルに置く。完成した一般queue/DBの導入ではない。UI再描画・比較選択の保存は新しい軌道を実行しない。過去場の参照にGFS runを必須化せず、weather catalog/serviceを飛行configから独立させ、将来の風だけの分析は同じ場を直接読める。未対応製品をGFSへ置換しない。

## FEと合意したHTTP契約

- `GET /api/v1/weather-sources`: 保存ID、実bundle SHA256/bytes、run/valid・格子支持、default_config。固定の保存例であり最新予報と表示しない。
- `POST /api/v1/runs`: `{client_request_id,candidate_id,candidate_revision,label,weather_source_id,config}` →202 `{run_id,job_id,state,frozen_input_hash}`。同request ID/同内容は同run、別内容は409。新しい実行は草案を書き換えず、その時の入力を固定する。
- `GET /api/v1/runs`: 既存run一覧。`GET /runs/{run_id}`: frozen spec、job状態、result_available。
- `GET /runs/{run_id}/result`: `{run_id,trial_id,n:1,weight:1,weather_snapshot,source_snapshot,result:<balloon.flight.result/1>}`。元records/eventsを保持。UTC/elapsed seconds/lat-lon/幾何ASL/AGL/phaseの型を明示する。
- `GET /api/v1/project`: `{revision,project:{schema:'balloon.project/1',title,candidates:[{id,label,revision,weather_source_id,config}],compare_run_ids:[...]}}`。
- `PUT /api/v1/project`: `{expected_revision,project}`。CAS競合409。未完成の草案は保存できるが実行はvalidatorを通す。比較はcandidate名やlatestでなく固定run IDを指す。
- 取消は待機中のみ実行可能として返す。runningを取消要求だけでcancelledにしない。初回は再起動した旧queued/runningをinterruptedへ戻し、自動再送しない。

FastAPI BackgroundTasksを重い計算器そのものにしない。process workerは1、待機上限を明示し満杯は429。workerへWeatherField配列やDB接続を渡さず、固定specのJSONと管理pathを渡す。Windows spawnで起動し、import時にworkerを作らない。実行済Futureのcancelが即停止にならないことは[Python公式](https://docs.python.org/3.12/library/concurrent.futures.html#concurrent.futures.Future.cancel)に従う。[FastAPIの注意](https://fastapi.tiangolo.com/tutorial/background-tasks/#caveat)、[spawn](https://docs.python.org/3.12/library/multiprocessing.html#contexts-and-start-methods)も確認した。性能・Windows終了動作の受入は実行試験で別に行う。

## 固定入力・保存

`config.py:52-157`はdefault展開・detach・UTC・mode検査、`trajectory.py:247-262`はlanded/stopped・理由・events/recordsを既に返す。初期不成立も数値上の停止結果として返り得る一方、config拒否は実行前エラーにする。運用jobがcompletedでも飛行はstoppedになり得る。landing=nullへ最終点を代入しない。

runへ元直接入力と正規化config、candidate ID/revision、trial ID/weight=1、場のID/実hash/metadata、核/adapterソースhash、Python/NumPy/SciPy版、numerics設定を保存する。submission時とworker開始時の固定hashを照合し、コード/場が変わったら実行しない。数学的に同じ軌道でも入力を統合しない。

`export_result`（results/export.py:42-73）は既存7出力・来歴を活用できるが、新規dir作成後に順次書くため、dir存在だけは完成証拠でない。非公開stagingへ既存export→manifest/全ファイルhash確認→runの固定情報とcommit manifest追加→同volumeのfinal dirへ移す→DBから可視にする。途中失敗はstagingを保持しfailed、旧結果へ触らない。起動回復で未完jobを成功へ昇格させずinterrupted。確定結果は気象実体が欠けても閲覧可能にし、再計算可能性とは分ける。

## 固定場

両者ともrun `2026-09-22T18:00Z`、valid `2026-09-23T03:00–09:00Z`毎時7面、33圧力面。bundle axesを直接読取した。

| ID | lat/lon支持 | gzip bytes / SHA256 |
|---|---|---|
| wakayama-gfs-fixture | 33.5–34.75 / 135.0–136.25 | 156112 / `de3c00643092b34a50451d7263987014030b1d760c2e3da6f03a5245cf8c1739` |
| hokkaido-gfs-fixture | 42.75–44.0 / 141.25–144.25 | 296340 / `69b4b0c23919eeb2e645e6a632d05824a892e301295bec4645013e0df13545a9` |

領域矩形内なら全高度/全飛行が支持されるという保証はしない。既存examplesの同地点で一軸のみ変えてA/Bを実行し、別の有限反例で支持外停止を確認する。

## 受入

1. HTTPなしで同じservice/workerから保存GFSの一飛行を実行し、現CLI核と結果の意味が一致する。
2. 同地点A/Bの二結果を保持し、実行中/完了後の草案編集が旧入力・旧履歴を変えない。片方停止/運用失敗でも他方を保持する。
3. request重送の同一性、別内容409、有限待機、待機取消、再起動interrupted、未完成artifact不可視。
4. 再起動して比較の固定run参照・草案・完全records/eventsを再閲覧できる。元気象不在でも確定結果を読める。
5. 実workerとWindows spawnを有限に実測する。2n=1へ分散領域を付けず、科学精度/MC完成とはしない。

通常起動はhost127.0.0.1/port8451、data_dirは外部既定＋env/関数引数。build済frontend/distのみ同origin配信、未buildは明確案内、/apiをSPAへ流さない。開発Vite8450→API8451はFE担当とrootが検証。依存導入は専用環境、Miniforge baseには追加しない。
