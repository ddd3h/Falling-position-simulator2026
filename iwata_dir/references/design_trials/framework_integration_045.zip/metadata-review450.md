# 0.45 metadata helper 独立レビュー

2026-09-29。read-onlyでmetadata450.py、newassets450.json、newassets450-proposal.json、
固定basis-C2のHEALTH、現check_state/health/contractの該当境界を読んだ。
helperのprepare/inspect/finalizeは実行していない。書込はこのレビューのみ。
主担当が同時に修正中なので、以下は観測版と修正状態を分ける。

## 観測した版と実体

- helper再読版SHA256: `45f2e9283bf30b16b259c1a5c91273305c840aa30c35acb55584034b19505bd4`
- newassets450.json SHA256: `72b9bc725609af2c6f5c97d099d79deb7481f3cc137118ee6884e8030f35eec0`
- 比較元C2: `346e9484d3fc3444fd7a12c9e85710e479685666`、採用main M420は別。
- newassetsは当初28sourceに証拠ZIPを追加して29行。ID/path重複0、旧ID衝突0。
- 旧HEALTHの全依存と新29行の依存を合わせて探索し、参照不在0・循環0を確認。
- 現source_filesは165実体、基準137+新source28に完全一致、列挙error0、余剰0。
  予定ZIP `references/design_trials/framework_integration_045.zip` だけ未作成だった。
  この時点のprepareはmissing newで書込前に止まる構造で、ZIPを見落として通さない。
- PLANのmd/tex/pdfは3実体ともbasis-C2とSHA256一致。
- 元proposalは時点一覧として正しく、現版と違うhashはHistoryPanel/useWorkspace/
  workspaceState/workspaceState.testの4件。最終レビューの証拠へ置換して扱い、
  05:43:31 UTCのproposal hashを最新sourceの確認根拠へ流用しない。

## 発見と修正状態

### A. 新規depends_on脱落 — 修正確認済み

初読版はNEWをpath/id/purposeだけへ落とし、prepareでdepends_on=[]のまま登録した。
このままだと例としてBACKEND-WORKER→FLIGHT-TRAJECTORYの点検依存が消え、
requirementsは空依存を正として扱う。主担当へ早期通知した。
再読版はNEW_ROWS/NEW_BY_IDを保持し、各unitのpath一致を検査したうえで
NEW_BY_ID[uid]['depends_on']を代入する。具体的な脱落は解消。

### B. reviewの指紋束縛 — 再読版では要修正

finalize:97-101付近はapproved_by/version/basis、unit_evidenceのID集合とevidence名を
照合するが、主担当が実読した時点のown/dependency digestを比較しない。
134付近でその時の現本文をreview.content_sha256へ書く。

具体反例: rootがBACKEND-STORAGEを読んでmappingを作った後、その同IDの本文が
変更される。neededもmappingも同じIDのままなので集合検査は通り、後の未読本文へ
0.45確認印と新hashが自動発行される。evidence.method/result/limitsが非空であることは
この時間差を止めない。

最小修正はreview JSONへ承認時の正規化own/dependency digestを持たせ、finalizeの
書込前に現値と照合すること。helperが承認済み手順として生成する構造記録・派生一覧
の変化はその操作を区別して記録し、一般sourceの事後差替えを同列に許さない。
全単位に一つの包括evidenceを付けるよう要求しているわけではなく、有限の実読範囲と
その時点の本文を結びたいという指摘である。

### C. guard/PLAN/全sourceの検査順 — 要preflight

再読版はguard変更集合をcheck_stateとtest_state/test_health/test_contractの4pathに
明示限定した（120付近）。その他guardを汎用理由だけで自動記録する初読版より改善。
ただし現位置はinline stampとCONTINUITY/HEALTHのput後。PLAN byte一致も末尾139。
失敗は返すものの、拒否前に確認印やregistryの一部を変更する。

prepare/finalize冒頭でPLAN3 hash、guard許可集合と承認hash、現在source_files集合を
検査するのが小さい改善である。現helperは登録集合だけを比較し、source_filesを
呼ばない。例として未登録scratch.pyをruntime3根の外へ置いてもhelper単独では
それを検査しない。後段check_stateは拒否するので、ワークフロー全体が無検査と
いう意味ではないが、helperの成功を完全登録証明として扱えない。

後段の旧新版checkerを残し、preflightはその代替ではなく途中stamp防止に使う。
guard pathが同じでも内容が後から変わる場合はBの指紋束縛で止める必要がある。

### D. 証拠ZIPの役割 — health側修正確認、asset側は要分離

再読版は.zip unitをrole='reference'へ変更した。一方、asset生成は全新規へ
lifecycle='active'と「現役の画面・APIと既存核の接続を担当」のcurrent_roleを与える。
証拠ZIPは実行sourceではなく、実績・批評の保存物である。主担当が指定した
REF-FRAMEWORK-045の役割に合わせ、asset側もreferenceの説明へ分けるのが適切。
版を含まない安定IDの要請は新28sourceへ適用済みであり、版別証拠archiveのIDを
同じ理由で改名する提案ではない。

## 更新と確認、依存伝播の適合点

updated_inは固定C2とのown digest差でだけ上がり、reviewed_inは明示mapping内だけを
上げる。依存だけが変わった単位の更新を偽装せず、requirementsへ出す方向は適切。
own/aggregateを分け、子範囲変更だけで親本文を更新したことにしないContentsを使う。
final再指紋で増えた影響もmappingへ含めるよう求め、未読IDを自動追加しない。

一方、mappingは任意の既知IDを指定できるため、実読範囲はroot evidenceの責務である。
PLAN単位はinline_marker=falseなので、bytes不変でもregistryのreviewed_inは変更可能。
これは依存の有限再点検を記す用途として許されるが、PLAN親/全PDFの科学的再確認を
実施したことにはしない。子の依存レビューとPLAN3実体不変を別に証拠化する。

固定C2の137ファイルをbasis450.jsonのsize/SHA256と照合し、HEALTH coverageも比較する
点は妥当。固定receipt自体のGit由来の真正性はrootの先行読戻しに依存する。
helperのTREE定数はmain treeで未使用、receiptのC2 tree値は固定チェックに含まれない。
低コストの補強としてC2 tree `7e090262c5da55a089b9f4a9292f06fa14a53c96` も照合すると
基準識別が明瞭になるが、このhelperだけでGit認証を再現する必要はない。

## 判定の限界

Aは修正確認済み、guard path無制限記録も集合限定を確認した。B/C/Dは上記観測版で
未解消として主担当へ通知した。主担当がこれから作るunit_evidence内容は未受領で、
その読取範囲・単位割当・結果/限界の十分性はこの時点で承認していない。
提案graphは現在のデータで欠損/循環がなく、source列挙/PLAN不変は現在実測した。
prepare/finalize実行の成功、最終checker全通過、保存commit/Git不変の実績は未主張。

## 事前検査修復の再読（2026-09-29、追記）

対象helper SHA256は `4378afd9c8d3c684ecdc9e620d1c92450cac81b0da2bb98dc60e339a56e5fee1`。
新29行JSONは `72b9bc725609af2c6f5c97d099d79deb7481f3cc137118ee6884e8030f35eec0`。
helper全文と実source_files（tools/check_state.py:29–78）を再読した。
helper本体のprepare/finalizeは実行していない。以下は静的な閉鎖判定である。

- Bは解消。finalizeのsource stamp前に、承認JSONのreviewed_digestsを各unitの正規化ownと全depends_onのaggregateへ完全一致させる。先に読んだ同IDの本文または依存本文が差し替わる反例は、確認印を書き込む前に拒否する。evidenceの文章が真実か、主担当がその範囲を実読したかは依然として人のレビュー責務である。
- Cは解消。finalizeの書込前にPLANのmd/tex/pdfが固定C2とbyte一致、guard変更が指定4pathだけ、source列挙が登録集合と完全一致であることを検査する。source_preflightは実source_filesへcallbackを渡し、列挙errorも拒否する。prepareも生成・metadata書込前に同source列挙を検査する。prepare自体はPLANやsource stampへ書かず、PLAN/guard/content承認の最終前提はfinalizeのpreflightで閉じる。これを全操作のatomic transactionや全後段エラー時のrollback保証とは呼ばない。
- Dは解消。証拠ZIPはHEALTH role=referenceに加えCONTINUITY asset lifecycle=referenceで、現役FE/BEソースとは異なる固定検証証拠として説明される。
- 新29行のID/path重複0、旧＋現登録＋新行の依存graphの不在参照0・循環0を再計算した。PLAN3のSHA256一致も再確認した。

この修復版について、前記の具体的な未読stamp・無限定guard変更・未登録source見落とし・ZIP役割混同は閉じた。追加の重大な具体反例は検出していない。basis receiptのC2 tree literal未束縛という前記の低優先度識別補強案、実際のunit evidence/読取範囲の審査、最終checkerとGit保存は別の責務として残る。依存だけが変わった11scopeの本文適合はdependency-review450.json/mdへ分離する。
