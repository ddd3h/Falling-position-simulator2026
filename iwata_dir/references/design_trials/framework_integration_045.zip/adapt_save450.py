"""Author a candidate helper and static evidence; do not import/execute it or run Git."""
from pathlib import Path
import ast, difflib, hashlib, json

P=Path(__file__).resolve().parent
Q=P.parent/'balloon-research-440'
H=Q/'save440.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(H)=='639b4afe9f5469ff344e39114f3ce1902aaf82582603740ccb3023260abbcf25'
src=H.read_text(encoding='utf-8')
frozen=json.loads((Q/'record-freeze440.json').read_text(encoding='utf-8-sig'))
receipt=json.loads((Q/'record-git-receipt440.json').read_text(encoding='utf-8-sig'))
basis=json.loads((P/'basis450.json').read_text(encoding='utf-8-sig'))
assets=json.loads((P/'newassets450.json').read_text(encoding='utf-8-sig'))
base='346e9484d3fc3444fd7a12c9e85710e479685666'
tree='7e090262c5da55a089b9f4a9292f06fa14a53c96'
assert basis['candidate']==receipt['commit']==base
assert basis['tree']==receipt['tree']==tree
assert {r['path']:r for r in basis['files']}=={r['path']:r for r in frozen['files']}
assert len(basis['files'])==137 and len(assets)==29
assert receipt['freeze_sha256']==sha(Q/'record-freeze440.json')
assert sha(Q/'original-git440.json')==frozen['original_snapshot_sha256']==receipt['original_snapshot_sha256']
new={a['path'] for a in assets}
assert len(new)==len({x.casefold() for x in new})==29
assert not new&{r['path'] for r in basis['files']}
for row in basis['files']:
    path=P/'basis-C2'/row['path']
    data=path.read_bytes()
    assert len(data)==row['size'] and sha(path)==row['sha256']
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']

s=src.replace('save440','save450').replace('440.json','450.json').replace('0.44.0','0.45.0').replace('Fixed 0.44','Fixed 0.45').replace('Record 0.44 validation','Record 0.45 validation')
def one(before,after):
    global s
    assert s.count(before)==1, ('unexpected adaptation target',before[:80],s.count(before))
    s=s.replace(before,after,1)
one("OLD = P.parent / 'balloon-framework-430'", "OLD = P.parent / 'balloon-framework-430'\nPREVIOUS = P.parent / 'balloon-research-440'")
one("BASE = 'bea3f98a39b3827006c644743bc195804e27188b'",f"BASE = '{base}'")
one("BASE_TREE = 'af3a61131c6c7dc915ec30f8d8fd92003ac1fbd1'",f"BASE_TREE = '{tree}'")
one("BASE_FREEZE_HASH = 'bd4845b2574328e38f6f686e9d1f5225c2fedefc849c948c7381cf45f5f6b89c'",f"BASE_FREEZE_HASH = '{sha(Q/'record-freeze440.json')}'")
one("BASE_RECEIPT_HASH = 'dcc8a1380c9e83ed7a610f8a3196c36890d066b9a65698779d79af18982140c1'",f"BASE_RECEIPT_HASH = '{sha(Q/'record-git-receipt440.json')}'\nBASIS_MANIFEST_HASH = '{sha(P/'basis450.json')}'\nNEW_ASSETS_HASH = '{sha(P/'newassets450.json')}'\nPREVIOUS_ORIGINAL_HASH = '{sha(Q/'original-git440.json')}'")
start=s.index("NEW_PREFIX = ")
end=s.index('RECORD_ALLOWED = ',start)
s=s[:start]+'NEW = {\n'+''.join('    '+repr(name)+',\n' for name in sorted(new))+'}\n'+s[end:]
one('The fixed existing branch must start at C2; main is verified separately and never changed.',
    'The fixed existing branch must start at 0.44 C2; main is verified separately and never changed.\nThe exact 137 prior + 29 new paths are fixed. This helper is not a metadata/test checker.\nOnly /root may execute after reviewing this candidate; publish also requires a stage release.')

start=s.index('def original(root):')
end=s.index('\ndef checked_rows(',start)
s=s[:start]+'''def previous_original(root):
    path = safe_file(PREVIOUS, 'original-git440.json')
    need(digest(path) == PREVIOUS_ORIGINAL_HASH, 'previous original snapshot changed')
    saved = read(path)
    need(saved.get('schema') == 'save440-original/1' and saved.get('root') == str(root)
         and saved.get('state', {}).get('head') == ORIGINAL_HEAD,
         'previous snapshot belongs to another workspace/schema/head')
    return saved['state']


def original(root):
    saved = read(safe_file(P, 'original-git450.json'))
    need(saved.get('schema') == 'save450-original/1' and saved.get('root') == str(root)
         and saved.get('prior_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH,
         'snapshot belongs to another workspace/schema/prior snapshot')
    need(saved['state'] == previous_original(root),
         'original snapshot differs from fixed 0.44 snapshot; no automatic rebaseline')
    now = original_state(root)
    need(now == saved['state'], 'original .git changed since save450 snapshot; no automatic rebaseline')
    return now

''' + s[end:]

start=s.index('def basis():')
end=s.index('\ndef rows_for(',start)
s=s[:start]+'''def basis():
    manifest_path = safe_file(P, 'basis450.json')
    path = safe_file(PREVIOUS, 'record-freeze440.json')
    receipt_path = safe_file(PREVIOUS, 'record-git-receipt440.json')
    need(digest(manifest_path) == BASIS_MANIFEST_HASH
         and digest(path) == BASE_FREEZE_HASH and digest(receipt_path) == BASE_RECEIPT_HASH,
         'C2 fixed manifest/evidence changed')
    manifest, b, receipt = read(manifest_path), read(path), read(receipt_path)
    need(manifest.get('main') == MAIN and manifest.get('candidate') == BASE
         and manifest.get('tree') == BASE_TREE, 'wrong basis450 manifest')
    need(b.get('schema') == 'save440-freeze/1' and b.get('stage') == 'record'
         and b.get('main') == MAIN and b.get('main_tree') == MAIN_TREE
         and b.get('branch') == BRANCH and b.get('remote') == REMOTE
         and b.get('version') == '0.44.0', 'wrong C2 freeze')
    need(receipt.get('schema') == 'save440-receipt/1' and receipt.get('stage') == 'record'
         and receipt.get('status') == 'readback_verified' and receipt.get('commit') == BASE
         and receipt.get('tree') == BASE_TREE and receipt.get('parent') == b['parent']
         and receipt.get('main') == MAIN and receipt.get('branch') == BRANCH
         and receipt.get('files') == 137 and receipt.get('freeze_sha256') == BASE_FREEZE_HASH
         and receipt.get('original_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH
         and b.get('original_snapshot_sha256') == PREVIOUS_ORIGINAL_HASH, 'wrong C2 receipt')
    prior = checked_rows(manifest['files'], 137)
    need(prior == checked_rows(b['files'], 137), 'basis450 and C2 freeze rows differ')
    need(BASIS_DIR.is_dir() and not BASIS_DIR.is_symlink() and not BASIS_DIR.is_junction(),
         'basis-C2 must be a regular directory')
    actual = set()
    for p in BASIS_DIR.rglob('*'):
        need(not p.is_symlink() and not p.is_junction(), 'linked path inside basis-C2')
        if p.is_file():
            actual.add(p.relative_to(BASIS_DIR).as_posix())
    need(actual == set(prior), 'basis-C2 path set differs from fixed 137 rows')
    for r in prior.values():
        data = safe_file(BASIS_DIR, r['path']).read_bytes()
        need(len(data) == r['size'] and sha(data) == r['sha256']
             and hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\\0' + data).hexdigest() == r['blob'],
             'basis-C2 file differs from fixed row: ' + r['path'])
    return prior


def new_assets():
    path = safe_file(P, 'newassets450.json')
    need(digest(path) == NEW_ASSETS_HASH, 'new asset declaration changed')
    rows = read(path)
    need(isinstance(rows, list) and len(rows) == 29, 'new assets must contain exactly 29 rows')
    names = [r['path'] for r in rows]
    need(len({name.casefold() for name in names}) == 29 and set(names) == NEW,
         'new asset paths differ from the explicitly reviewed 29 paths')
    for name in names:
        path_name(name)
    return NEW

''' + s[end:]
one("len(names) == 137 and len({n.casefold() for n in names}) == 137\n         and set(names) == set(prior) | NEW, 'must retain all 132 paths and add only the five research-return files'",
    "len(names) == 166 and len({n.casefold() for n in names}) == 166\n         and not set(prior) & new_assets() and set(names) == set(prior) | NEW,\n         'must retain all 137 paths and add only the reviewed 29 implementation/evidence paths'")
one("'basis_sha256': digest(OLD / 'record-freeze430.json'),\n            'basis_receipt_sha256': digest(OLD / 'record-receipt430.json'),",
    "'basis_sha256': digest(P / 'basis450.json'),\n            'basis_freeze_sha256': digest(PREVIOUS / 'record-freeze440.json'),\n            'basis_receipt_sha256': digest(PREVIOUS / 'record-git-receipt440.json'),\n            'new_assets_sha256': digest(P / 'newassets450.json'),")
one("'helper_sha256', 'original_snapshot_sha256'):",
    "'helper_sha256', 'original_snapshot_sha256', 'basis_sha256',\n                'basis_freeze_sha256', 'basis_receipt_sha256', 'new_assets_sha256'):")
one("Receive and review Q420-00 research against simulator needs (0.45.0)",
    "Connect saved-field two-run comparison with local React and FastAPI (0.45.0)")
one("first = original_state(root)\n        need(original_state(root) == first, 'original .git changed while snapshotting')",
    "first = original_state(root)\n        need(first == previous_original(root),\n             'original .git differs from fixed 0.44 snapshot; no automatic rebaseline')\n        need(original_state(root) == first, 'original .git changed while snapshotting')")
one("'at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),\n                         'scope': 'Observed start of save450 only; no earlier historical immutability claim.'",
    "'at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),\n                         'prior_snapshot_sha256': PREVIOUS_ORIGINAL_HASH,\n                         'scope': 'Observed start of save450 and exact equality with fixed save440 snapshot; no claim before that snapshot.'")

syntax=ast.parse(s,filename='save450.py')
old_ast=ast.parse(src,filename='save440.py')
old_functions={n.name:ast.dump(n,include_attributes=False) for n in old_ast.body if isinstance(n,ast.FunctionDef)}
functions={n.name:ast.dump(n,include_attributes=False) for n in syntax.body if isinstance(n,ast.FunctionDef)}
assert set(old_functions)<=set(functions), 'a previous safeguard function disappeared'
unchanged=[name for name in old_functions if old_functions[name]==functions[name]]
changed=[name for name in old_functions if old_functions[name]!=functions[name]]
assert s.count("'snapshot', 'freeze', 'publish', 'record-freeze', 'record-publish'")==1
assert '--force-with-lease=' in s and 'verify_blobs(current[\'files\'])' in s
candidate=P/'save450.py'
candidate.write_text(s,encoding='utf-8',newline='\n')
(P/'save450.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),s.splitlines(True),fromfile='P440/save440.py',tofile='P450/save450.py')),encoding='utf-8',newline='\n')
report={'scope':'Static authoring/review only. Candidate never imported or executed; no Git command executed.','old_helper_sha256':sha(H),'candidate_helper_sha256':sha(candidate),'basis_commit':base,'basis_tree':tree,'prior_files':137,'new_files':29,'total_files':166,'fixed_evidence':{str(p):sha(p) for p in [P/'basis450.json',Q/'record-freeze440.json',Q/'record-git-receipt440.json',Q/'original-git440.json',P/'newassets450.json']},'prior_rows_equal':True,'basis_copy_all_bytes_and_git_blobs_match':True,'ast_syntax':'valid; parsed only','old_functions':list(old_functions),'unchanged_ast_functions':unchanged,'adapted_functions':changed,'added_functions':sorted(set(functions)-set(old_functions)),'metadata_tests':'not performed/replaced by this helper; require separate root release evidence','new_paths':sorted(new)}
(P/'save450-static-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:report[key] for key in ['candidate_helper_sha256','prior_files','new_files','total_files','unchanged_ast_functions','adapted_functions','added_functions']},ensure_ascii=False))
