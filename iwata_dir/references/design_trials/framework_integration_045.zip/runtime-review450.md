# runtime/source 境界の独立レビュー（0.45）

2026-09-29、continuity430。対象は tools/check_state.py、tests/test_state.py / test_health.py / test_contract.py、.gitignore の固定C2 `346e9484d3fc3444fd7a12c9e85710e479685666` からの差分。repo編集なし。新API/画面の受入や最終管理検査とは別の有限レビューである。

## 結論

最終差分は採用可能。初稿にあった2件の見逃しを独立反例で指摘し、主担当の修正後、15ケースを別fixtureと最終checkerの固定コピーで確認した。指定された `frontend/node_modules`、`frontend/dist`、`backend/.venv` のみを正本列挙から外す。一般.gitignore解釈や任意階層の同名directory除外には広がっていない。

最終checker SHA256: `94ae47ee06fe15bcd0d121fff2778a11316b72e1f95df649c7e5c0aaad6ba7ba`。他4ファイルの指紋は `runtime-review450-sources.json`。実行時固定コピーは `check_state-reviewed450.py`。これは外側レビュー用であり正式な第二checkerではない。

## 反例と修正

1. 初稿は `.pyc` suffixをdirectoryでもpruneしたため、`frontend/src/cache.pyc/hidden.ts` がactualにもerrorにも出なかった。旧rglobはこの子を列挙するため意図しない除外拡大だった。主担当がregular file判定後だけpycを除外するよう改め、直接生成する小fixture回帰を追加。最終版はhidden.tsを列挙する。
2. Python 3.12 のos.walkはDirEntry.is_dirのOSErrorをonerrorへ渡さず、nondirsへ分類する（この実行環境の C:/Miniforge3/Lib/os.py も実読）。後続lstatでdirectoryと判定されても、directories配列へなければ配下へ降りず未登録sourceを見逃した。実scandirを包みis_dirだけPermissionErrorを注入した独立反例で確認。主担当が通常directoryについてname in directoriesを要求し、分類不一致を明示拒否する回帰を追加。最終版はsource directory was not traversedとして失敗する。

反例証拠は `runtime-review450-pyc-counterexample.json` と `runtime-review450-isdir-counterexample.json`。失敗時の結果を上書きしていない。

## 最終コードの評価

- expected登録pathがruntime root自体またはその子であれば、実在しなくても拒否する。除外rootをfileで占めても拒否する。
- root/祖先のlstatをprune前に行い、symlinkとWindows reparse pointを拒否して下降を止める。通常dirの内部を除外した後は、第三者のsrcや.bin linkを監査したと主張しない。
- scandir/onerror、lstat失敗、walkのdirectory誤分類、特殊なfilesystem entryを失敗として扱う。既存archive/version directory制約と、登録集合完全一致を維持する。
- `frontend/src/new.ts`、`frontend/node_modules_extra/a.js`、`docs/node_modules/a.js` は列挙される。正本の新規未登録ファイルは検査に失敗する。
- PDF走査をsource actual集合へ揃えたことは必要な変更。runtime内のvendor PDFにTeX正本契約を誤適用しなくなる。正本にあるPDFの既存例外/署名検査は維持する。
- .gitignoreは固定3rootと従来対象のcacheだけ。checkerはその文字列を一般的な除外設定として読まない。正本や唯一の保存結果をruntime下へ置いてよい許可ではない。
- 既存三試験のcopytree変更は固定3rootをコピー対象から外し、各回帰の本体assertを変えていない。既存ignore_patternsの*.pyc directory除外は以前からあったため今回新規弱体化ではない。新反例はcopytreeを通さず作り、このテストfixtureの制約で見逃しを隠さない。

## 実行の区別

|対象|実際の結果|意味|
|---|---|---|
|固定旧check_state → clean固定137実体|exit 0、1997 checks、137 files|旧契約を元のclean sourceへ適用した基準対照。新規runtime契約の証明ではない。|
|最終新版固定コピー → 同clean137|exit 0、2153 checks、137 files|除外がないときも元の正本集合を維持する。|
|旧checker → 固定137を複写してruntime4ファイル追加|exit 1、141 files、extra4とvendor PDF契約違反|旧版が意図どおりruntimeを余剰にする対照。これを合格へ言い換えない。|
|最終新版 → 同runtime fixture|exit 0、2160 checks、137 files|exact3rootを外し、元137実体を確認。|
|同fixtureへfrontend/src/unregistered.ts追加、新版|exit 1、138 files、extra該当source|runtime除外で正本外sourceを隠さない。|
|独立小fixture 15ケース|全15期待どおり|root/登録/file/link/reparse/pyc/is_dir/lstat/scandir境界。|

最終15ケースは `runtime-review450-independent-final.json`。full fixtureは `runtime-review450-full-fixture.json`、clean旧版は `runtime-review450-clean.json`、最終cleanは `runtime-review450-new-clean-final.stdout` とsources票へ。主担当報告のWindows/elevatedでの7回帰成功とは別の実行であり、同じ回帰を本担当が再実行したとはしない。

## 限界・引渡し

リンク/reparseと読取失敗の小fixtureはmetadata/OS APIへの注入を使用し、実NTFS junctionを新規作成して試したものではない。15件は変更境界の有限反例で、第三者依存の安全性、すべてのOS/異常filesystem、同時に悪意ある改変者がいる状態へのatomicな保護、科学/画面/Git保存を証明しない。

最初のTemporaryDirectory fixtureでは作成直後の子mkdirとcleanupでWinError 5が起こり、その実行は未完了。ACLを変えず、P450内の通常directoryへ新規fixtureを作って上記を実行した。恒久的な権限変更や元失敗directoryの削除は行っていない。

今回のrepo候補全体は実装/メタが進行中なので、最終root check_state/health/contract、ガード変更の登録、固定旧contractからの遷移検査は主担当へ返す。D184/S35では3runtimeの責務と2反例の修正理由を短く記録すれば足り、全過去帳簿や一般ignore schemaの増設は不要。
