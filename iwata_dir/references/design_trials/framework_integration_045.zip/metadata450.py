"""Bounded 0.45 registration: fixed 0.44 record C2 comparison, adopted main M420.
No Git, network, deletion or schema/policy edits. Explicit source-audit guard changes require fixed old/new evidence. Prepare writes metadata
and generated index/timeline blocks only. Review writes require explicit IDs.
Adapted from the reviewed 0.43 helper; no network, Git or policy changes.
"""
from pathlib import Path
from copy import deepcopy
import argparse,datetime as dt,hashlib,html,json,re,sys
P=Path(__file__).resolve().parent; B=P/'basis-C2'
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
V='0.45.0'; MAIN='4e3e4db0d047af9479bcd68bfc2553eeb71efcc9'; TREE='61f6853081aea968222f341e2b62dbada642dabc'
META=('docs/CONTENT_HEALTH.json','docs/CONTINUITY_CONTRACT.json','docs/VERSION_HISTORY.json')
BASE='346e9484d3fc3444fd7a12c9e85710e479685666'
RETURN=''
NEW_ROWS=json.loads((P/'newassets450.json').read_text(encoding='utf-8'))
NEW=[(x['path'],x['id'],x['purpose']) for x in NEW_ROWS]
NEW_BY_ID={x['id']:x for x in NEW_ROWS}
sys.path.insert(0,str(B/'tools')); import check_contract as cc,check_health as hh
def rd(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def enc(d):return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,data):
 p=Path(p);raw=data if isinstance(data,bytes) else enc(data);p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists() or p.read_bytes()!=raw:p.write_bytes(raw)
def ck(x,s):
 if not x:raise ValueError(s)
def fixed():
 receipt=rd(P/'basis450.json');rows=receipt['files']
 ck(receipt['main']==MAIN and receipt['candidate']==BASE and len(rows)==137 and receipt['tree']=='7e090262c5da55a089b9f4a9292f06fa14a53c96','basis identity')
 for row in rows:ck(sha(B/row['path'])==row['sha256'] and (B/row['path']).stat().st_size==row['size'],'basis bytes '+row['path'])
 oh,oc,ov=[rd(B/n) for n in META]
 ck(set(oh['files'])=={r['path'] for r in rows},'basis coverage')
 return oh,oc,ov,cc.snapshot_digest(B),{'sha':BASE}
def fingerprints(root,h,overrides=None):
 obj=hh.Contents(root,h['units']);obj.cache.update(overrides or {});own={};agg={};missing=[]
 for u in h['units']:
  if not (root/u['path']).is_file():missing.append(u['id']);continue
  own[u['id']]=obj.digest(u);agg[u['id']]=obj.digest(u,False)
 return obj,own,agg,missing
def source_preflight(h):
 import importlib.util
 spec=importlib.util.spec_from_file_location('state450_active',R/'tools/check_state.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 errors=[]
 actual=m.source_files(R,set(h['files']),lambda ok,msg: errors.append(msg) if not ok else None)
 ck(not errors and set(actual)==set(h['files']),'source registry mismatch '+str(errors))

def prepare():
 oh,oc,ov,base,commit=fixed();h,c,v=[rd(R/n) for n in META]
 ck(h['document_version'] in ('0.44.0',V),'unexpected version');ck(h['policy']==oh['policy'] and c['schema_version']==oc['schema_version'],'policy/schema drift');ck(set(h['files']) in (set(oh['files']),set(oh['files'])|{RETURN+n for n,_,_ in NEW}),'unexpected registered paths')
 h.update(document_version=V,basis_commit=MAIN)
 for name,uid,purpose in NEW:
  path=RETURN+name;ck((R/path).is_file(),'missing new '+path)
  h['files'][path]=dict(document_version=V,purpose=purpose,maintained=True)
  if not any(u['id']==uid for u in h['units']):
   unit=dict(id=uid,path=path,parent=None,role='implementation',purpose=purpose,updated_in=V,reviewed_in=None,inline_marker=False,depends_on=[],initial_review_due=oh['policy']['initial_unreviewed_due'])
   if name.endswith('.zip'):unit['binary']=True
   h['units'].append(unit)
  unit=next(u for u in h['units'] if u['id']==uid);ck(unit['path']==path,'new ID/path mismatch '+uid)
  unit['depends_on']=NEW_BY_ID[uid]['depends_on']
  if name.endswith('.zip'):unit['role']='reference'
  if uid not in h['focus']:h['focus'].append(uid)
  if not any(a['path']==path for a in c['assets']):c['assets'].append(dict(path=path,purpose=purpose,current_role=purpose+'。現役の画面・APIと既存核の接続を担当し、n=1の受入を分散/科学的精度へ広げない。',needed_by=['docs/PROGRAM_GUIDE.tex','docs/COMMANDS.md','role:実装と開発環境'],lifecycle='active',retire_when='固有の原本・来歴・採否・失敗を後継へ保持し、移動理由と受入先を記録した後。無断削除しない。',origin='RPT-071/D-184。参考形式の器へ移行し、既存核へ二結果比較と保存再閲覧を接続。',source_paths=[]))
 for a in c['assets']:
  if a['path']=='references/design_trials/framework_integration_045.zip':a.update(current_role='0.45実装の有限検証・失敗と修復・独立批評・実UI観察の固定証拠。現役ソースはfrontend/backendに別置する。',needed_by=['BOOTSTRAP_RUNBOOK.html#S35','REFERENCE_LOG.md','role:0.45移行の根拠'],lifecycle='reference')
 ck(set(h['files'])==set(oh['files'])|{RETURN+n for n,_,_ in NEW} and len(h['files'])==137+len(NEW),'final registered paths')
 for uid,extra in {'PROGRAM-CORE':['FRONTEND-APP','FRONTEND-WORKSPACE','BACKEND-APP','BACKEND-SERVICE','BACKEND-WORKER','BACKEND-STORAGE'], 'IMPLEMENTATION-NOTES':['FRONTEND-WORKSPACE','BACKEND-SERVICE','BACKEND-STORAGE'], 'IMPLEMENTATION-INDEX':['FRONTEND-MAIN','BACKEND-APP','BACKEND-SERVICE','BACKEND-WORKER'], 'COMMANDS-CORE':['FRONTEND-PROJECT','FRONTEND-VITE','BACKEND-README'], 'BUILD':['FRONTEND-PROJECT','FRONTEND-DEPENDENCIES','BACKEND-PROJECT','BACKEND-DEPENDENCIES','RUNTIME-IGNORE'], 'FRONTEND-API':['BACKEND-CONTRACTS'], 'FRONTEND-DOMAIN':['FLIGHT-CONFIG','FLIGHT-TRAJECTORY'], 'RESEARCH-SOURCES':['VISION','WEATHER-GUIDE','IMPLEMENTATION-NOTES','FLIGHT-CONFIG'], 'RESEARCH-BUILD':['VERIFY-HEALTH']}.items():
  u=next(u for u in h['units'] if u['id']==uid);u['depends_on']=sorted(set(u.get('depends_on',[]))|set(extra))
 source_preflight(h)
 c.update(version=V,basis_commit=BASE,comparison_base_sha256=base,comparison_base_description='採用mainはM420。局所変更の比較元は未統合PR30/0.44記録C2 346e9484d3fc3444fd7a12c9e85710e479685666の全137固定実体。原local.git M101は保持。')
 if V not in v['version_order']:v['version_order'].append(V)
 if not any(x['version']==V for x in v['versions']):v['versions'].append(dict(version=V,kind='candidate',summary='React/TypeScript/Viteと薄いPython APIへ移行し、保存GFSの二結果比較と保存再閲覧を接続する。',base_commit=MAIN,integrated_commit=None,git_status='pending',work_branch='codex/framework430-assessment',pr=30,note='PR30/0.44記録C2へ追加する未統合候補。二つのn=1の接続と三用途の全面受入を区別。private正本と人間のmain統合/public手動反映を維持。',evidence='RPT-071/D-184/S35/ACT-450。画面/API/保存・構造ガイドの有限受入。'))
 v.update(document_version=V,candidate_version=V)
 for n in META:h['files'][n]['document_version']=V
 for n,d in zip(META,(h,c,v)):put(R/n,d)
 cfg=rd(R/'docs/research/packet_sources.json');cfg.update(version=V,basis_commit=MAIN);put(R/'docs/research/packet_sources.json',cfg)
 derive(h,c,v);print(json.dumps({'prepared':True,'files':len(h['files']),'basis':BASE}))
def derive(h,c,v):
 n='CONTENT_MAP.md';s=(R/n).read_text(encoding='utf-8')
 s,count=re.subn(r'(?<=<!-- ASSET_VIEW_BEGIN -->).*?(?=<!-- ASSET_VIEW_END -->)','\n'+cc.asset_view(c)+'\n',s,flags=re.S);ck(count==1,'asset view')
 s,count=re.subn(r'(?<=<!-- CURRENT_PATHS_BEGIN -->).*?(?=<!-- CURRENT_PATHS_END -->)','\n```text\n'+'\n'.join(sorted(h['files']))+'\n```\n',s,flags=re.S);ck(count==1,'paths view');put(R/n,s.encode('utf-8'))
 n='BOOTSTRAP_RUNBOOK.html';s=(R/n).read_text(encoding='utf-8');pat=r'<tr data-history-version="([^"]+)">.*?</tr>';found=list(re.finditer(pat,s,re.S));rows={m[1]:m[0] for m in found};ck(found and len(rows)==len(found),'timeline')
 row=next(x for x in v['versions'] if x['version']==V);rows[V]='<tr data-history-version="'+V+'"><td>'+V+'</td><td>'+html.escape(row['summary'])+'</td><td>PR30/C2へ追加する未統合候補。実装と有限受入はS35。三用途/分散/科学精度の受入は別。</td></tr>'
 s=s[:found[0].start()]+'\n'.join(rows[x] for x in v['version_order'] if x in rows)+s[found[-1].end():];put(R/n,s.encode('utf-8'))
def requirements():
 oh,oc,ov,base,commit=fixed();h,c,v=[rd(R/n) for n in META];_,own,agg,missing=fingerprints(R,h);_,prior,_,_=fingerprints(B,oh);details=[]
 for u in h['units']:
  uid=u['id']
  if uid not in own:continue
  deps=[d for d in u.get('depends_on',[]) if (u.get('review') or {}).get('dependency_sha256',{}).get(d)!=agg[d]]
  changed=own[uid]!=prior.get(uid)
  if changed or deps:details.append(dict(id=uid,path=u['path'],own_changed=changed,dependency_changes=deps,inline_marker=u.get('inline_marker',False)))
 out=dict(version=V,basis=BASE,adopted_main=MAIN,missing=missing,details=details);put(P/'metadata450-required.json',out);return out
def stamp(s,u,updated,evidence_id):
 uid=u['id'];pair=f'[更新:{updated}] [確認:{V}]'
 def pair_and_reference(m):
  return re.sub(r'(?<= / )REV-[A-Z0-9_-]+(?=\s*$)',evidence_id,re.sub(r'\[更新:[^\]]+\]\s*\[確認:[^\]]+\]',pair,m[0],count=1),count=1)
 if u['path'].endswith('.html'):
  lo,hi=hh.Spans(s).spans[u['selector']] if u.get('selector') else (0,len(s));part=s[lo:hi]
  pat=r'(<p\b(?=[^>]*\bclass="[^\"]*\brevstamp\b[^\"]*")(?=[^>]*\bdata-scope="'+re.escape(uid)+r'")[^>]*>)(.*?)(</p>)'
  def marker(m):
   val,n=re.subn(r'\[更新:[^\]]+\]\s*\[確認:[^\]]+\][^\r\n]*',pair_and_reference,m[2],count=1);ck(n==1,'marker '+uid);return m[1]+val+m[3]
  part,n=re.subn(pat,marker,part,count=1,flags=re.S);ck(n==1,'scope stamp '+uid)
  if u.get('selector'):part=re.sub(r'^(<[^>]+>)',lambda m:re.sub(r'data-updated="[^"]+"',f'data-updated="{updated}"',re.sub(r'data-reviewed="[^"]+"',f'data-reviewed="{V}"',m[0])),part,count=1)
 else:
  lo,hi=0,len(s)
  if u.get('text_range'):lo,hi=s.index(u['text_range']['start']),s.index(u['text_range']['end'])
  elif f'<!-- HEALTH-LIMITED:{uid} -->' in s:lo=s.index(f'<!-- HEALTH-LIMITED:{uid} -->')
  part,n=re.subn(r'\[更新:[^\]]+\]\s*\[確認:[^\]]+\][^\r\n]*',pair_and_reference,s[lo:hi],count=1);ck(n==1,'MD stamp '+uid)
 return s[:lo]+part+s[hi:]
def finalize(review_file='metadata450-review.json', receipt_file='metadata450-finalized.json'):
 oh,oc,ov,base,commit=fixed();h,c,v=[rd(R/n) for n in META];review=rd(P/review_file)
 ck(review['approved_by']=='root' and review['version']==V and review['basis']==BASE and review['adopted_main']==MAIN,'review identity')
 mapping=review['unit_evidence'];needed={x['id'] for x in requirements()['details']};ck(needed<=set(mapping),'unread scopes '+str(sorted(needed-set(mapping))))
 for e in review['evidence'].values():ck(all(e.get(k) for k in ('method','result','limits')),'evidence incomplete')
 # Preflight before any source stamps or metadata writes.
 for n in ('docs/PROJECT_PLAN.md','docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf'):ck(sha(R/n)==sha(B/n),'PLAN changed before finalize')
 before_guard=cc.structural_projection(B,oc);after_guard=cc.structural_projection(R,c)
 changed_guards={k for k in set(before_guard)|set(after_guard) if k.startswith('guard:') and before_guard.get(k)!=after_guard.get(k)}
 ck(changed_guards=={'guard:tools/check_state.py','guard:tests/test_state.py','guard:tests/test_health.py','guard:tests/test_contract.py'},'unreviewed guard preflight')
 source_preflight(h)
 _,pre_own,pre_agg,_=fingerprints(R,h)
 for uid in mapping:
  u=next(u for u in h['units'] if u['id']==uid);ck(review['reviewed_digests'][uid]=={'own':pre_own[uid],'dependencies':{d:pre_agg[d] for d in u.get('depends_on',[])}},'content changed after review '+uid)
 ck('ENTRY' in mapping and set(mapping)<={u['id'] for u in h['units']} and set(mapping.values())<=set(h['evidence'])|set(review['evidence']),'unresolved review identity')
 _,oldown,_,_=fingerprints(B,oh);_,own,_,_=fingerprints(R,h)
 for u in h['units']:
  uid=u['id']
  if own.get(uid)!=oldown.get(uid):u['updated_in']=V
  if uid in mapping and u.get('inline_marker'):
   ck(u['path'] not in ('docs/PROJECT_PLAN.md','docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf'),'PLAN byte change forbidden in this assessment')
   s=(R/u['path']).read_text(encoding='utf-8');changed_stamp=stamp(s,u,hh.Contents(R,h['units']).effective(u,'updated_in'),mapping[uid])
   if hh.normalize(changed_stamp)!=hh.normalize(s):
    u['updated_in']=V;changed_stamp=stamp(s,u,V,mapping[uid])
   put(R/u['path'],changed_stamp.encode('utf-8'))
 # Structural comparisons bind C2; adopted main remains M420 in health/history.
 oldnodes={x['id']:x for x in oc['narrative_units']};nodes={x['id']:x for x in c['narrative_units']}
 changed=[i for i,n in nodes.items() if i not in oldnodes or n!=oldnodes[i] or cc.local_digest(R,n,c['narrative_units'])!=cc.local_digest(B,oldnodes[i],oc['narrative_units'])]
 reason='RPT-071/D-184。現役FE/APIと既存核を接続し、草案と固定結果を分けて比較・保存・再閲覧を成立させる。runtime境界は依存導入とソース監査の両立のため、指定3ディレクトリだけを列挙前に区別する。'
 preserved='既存核の式・保存原研究/旧模型・三用途と科学未決を保持。未登録ソース/登録されたruntime source/リンク/読取失敗は引き続き拒否。指定runtime以外へ除外を広げず、private正本・人間main統合・旧Git保持を維持する。'
 oldassets={a['path']:a for a in oc['assets']};assets=[a['path'] for a in c['assets'] if a!=oldassets.get(a['path'])]
 c['changes']=[x for x in c['changes'] if x.get('version')!=V]+[dict(id='CHANGE-450-IMPLEMENTATION',version=V,units=changed+['asset:'+n for n in assets],comparison_basis=BASE,reason=reason,preserved=preserved,method='PR30/0.44記録C2固定本文との比較、実コードと用途の独立批評、API/保存/非同期/画面の有限反例、旧新版checkerのclean/runtime/未登録反例、実階層と構造ガイドを評価。',before_digests={i:cc.digest(B,oldnodes[i]) if i in oldnodes else 'new' for i in changed},after_digests={i:cc.digest(R,nodes[i]) for i in changed})]
 c['entry_contract']['review']=dict(version=V,source_sha256=c['entry_contract']['text_sha256'],dependencies={n:sha(R/n) for n in ('README.md','AGENTS.md')},evidence_id=mapping['ENTRY'])
 put(R/META[1],c);put(R/META[0],h)
 before=cc.structural_projection(B,oc);after=cc.structural_projection(R,c);keys=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
 ck(not(set(before)-set(after)), 'removed identity')
 ck({k for k in keys if k.startswith('guard:')}=={'guard:tools/check_state.py','guard:tests/test_state.py','guard:tests/test_health.py','guard:tests/test_contract.py'},'unreviewed guard set')
 c['structural_changes']=[x for x in c['structural_changes'] if x.get('version')!=V]
 for key in keys:
  row=dict(key=key,version=V,comparison_basis=BASE,base_snapshot_sha256=base,before_sha256=cc.canonical_digest(before.get(key)),after_sha256=cc.canonical_digest(after[key]),kind='guard' if key.startswith('guard:') else ('migration' if key not in before else 'compatible'),reason=reason,preserved=preserved,impact='画面とAPIの現役ソース/依存宣言/有限試験を登録し、実構造と起動操作を担当資料へ戻す。node_modules/dist/venvの指定3rootをsource監査から分けるが、任意除外パターンは採用しない。',recovery='README→CONTEXT/S35→COMMANDS/PROGRAM/IMPLEMENTATION_NOTES。採否はD-184。旧設計と核は固定C2、研究原本は受領入口から戻る。')
  if key not in before:row['replacement']='FE/API現役sourceと実行環境/有限検証を追加し、既存資産/IDを保持する。'
  c['structural_changes'].append(row)
 put(R/META[1],c)
 _,own,agg,missing=fingerprints(R,h);ck(not missing,'missing scope')
 final={u['id'] for u in h['units'] if own[u['id']]!=oldown.get(u['id']) or (u.get('review') and u['review'].get('dependency_sha256',{})!={d:agg[d] for d in u.get('depends_on',[])})}
 ck(final<=set(mapping),'new unread impact '+str(sorted(final-set(mapping))))
 h['evidence'].update(review['evidence'])
 for u in h['units']:
  uid=u['id']
  if own[uid]!=oldown.get(uid):u['updated_in']=V
  if uid in mapping:u.update(reviewed_in=V,review=dict(version=V,on=review['on'],evidence_id=mapping[uid],content_sha256=own[uid],dependency_sha256={d:agg[d] for d in u.get('depends_on',[])}))
 for n in h['files']:
  if n in META or not (B/n).is_file() or sha(R/n)!=sha(B/n):h['files'][n]['document_version']=V
 h['scan_index']=hh.scan_index(h);put(R/META[0],h)
 ck(h['policy']==oh['policy'],'policy drift')
 for n in ('docs/PROJECT_PLAN.md','docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf'):ck(sha(R/n)==sha(B/n),'PLAN changed')
 put(P/receipt_file,dict(version=V,basis=BASE,adopted_main=MAIN,review_sha256=sha(P/review_file),reviewed=sorted(mapping),own_changed=sorted(i for i in own if own[i]!=oldown.get(i)),structural_changes=keys,narrative_changes=changed,limits='No test/Git/save success is implied. Source stamps can require packet regeneration and a later receipt refresh.'))
 print(json.dumps({'finalized':True,'reviewed':len(mapping),'own_changed':len([i for i in own if own[i]!=oldown.get(i)]),'structure':len(keys)}))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=('prepare','inspect','finalize'));args=a.parse_args()
 if args.action=='prepare':prepare()
 elif args.action=='inspect':print(json.dumps(requirements(),ensure_ascii=False,indent=2))
 else:finalize()
