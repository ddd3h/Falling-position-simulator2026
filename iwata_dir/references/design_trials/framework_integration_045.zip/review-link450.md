# 0.45確認欄の根拠リンク修復・再評価

2026-09-29 / frontend430。対象helperのraw SHA256は `e370b71d66aca422c272562582ddde97b9c9199a9dfdb877ba88d671a58b45d6`。metadata-review450.mdの旧指紋は変更していない。先行所見はnewreview-link450.md、純文字列再生の結果はreview-link450-dryrun.json。

**修正を今回の有限範囲で受け入れる。** stamp93–109行は、最初の確認印行にある明示suffix ` / REV-...` かつ行末だけを置換し、underscoreも完全IDに含める。ASTからck/stampだけを取り出したメモリ内再生で、現9対象（ENTRY/CTX/REFS/AGENT-ENTRY/研究入口・課題・BRIEF・UI・REVIEW042）の各1行が期待mapping IDへ変わる。repoへの適用、finalize、回帰suiteは行っていない。

先行反例も再生した。同じ行に「過去の根拠REV」を説明するだけの行は、その歴史IDを保持する。現在IDの後に歴史説明が続く曖昧な行でも、いずれのIDも勝手に変えない。翌行の歴史IDは保持する。REV-440-OLD_NOTEは末尾を残さず完全に新IDへ置換される。曖昧な行では現在IDが旧版のままになるため、将来その形式を採用したら個別に明示処理する必要があるが、現9行には該当しない。

finalize125–134行の更新印同期は、MDのREV-ID変更をnormalize後も残る本文変更としてupdated_inへ反映し、HTMLの確認段落だけの変更は本文変更にしない。既存の更新/確認規範と一致する。fixtureやcheckerを弱める修正ではなく、ENTRYのregistry IDと実際の確認欄を揃えて既存反例を有効にする修正である。

finalize110–111/166行のreview_file、receipt_file引数も読んだ。読む承認票とreceiptに記す承認票hashが同じ引数へ揃い、別名の後段票を作れる。承認票自体はこの関数が書かない。defaultは旧名なので、初回release後の呼出側は必ずrecord-metadata450-*等の別名を渡す必要があり、自動的な上書き防止機能とは主張しない。既存のroot承認・事前指紋・PLAN/guard集合の確認を外す変更はない。

更新後の本文/根拠IDをreview指紋と研究生成物へ反映してから、待機中の次の検査へ進める。今回の文字列再生は回帰suite成功やGit保存の証拠ではない。追加の重要な所見はない。
