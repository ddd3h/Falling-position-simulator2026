# Backend implementation delivery 0.45

2026-09-29. Parent authorized backend-only changes after S35/D184. Basis is PR30
0.44 C2 `346e9484d3fc3444fd7a12c9e85710e479685666`; main M420 remains a separate
adopted basis. This worker performed no Git operations, weather acquisition or
changes to `balloon_sim`. Source edits: the ten files under `backend/` listed and
hashed in `backend-evidence450.json`.

## Delivered connection

`backend.app.create_app(data_dir=None)` is the FastAPI factory. Its routes wrap
`ApplicationService` synchronously, and the service runs `execute_run` in one
spawn process. The dispatcher is in application.py rather than a separate jobs.py;
there is no extra general job framework. Four queued runs maximum, one running.
SQLite is a registry; fixed specs and committed result artifacts remain separate.
The code calls existing validate_config / load_weather / simulate / export_result.

Source snapshot records adapter and kernel file hashes plus Python, NumPy and
SciPy versions. Configuration is stored both as original submitted JSON and the
kernel's default-expanded input. Field bytes, metadata and source identity are
frozen. Hash checks before and after calculation reject changed inputs.

The kernel's seven output files are written under a fresh staging directory.
The parent verifies its manifest, creates run.json and COMMITTED.json, renames
to results/<run_id>, and only then commits the DB reference. Integrity is checked
on reads. This establishes the application completion barrier; it is not a
power-loss or adversarial filesystem guarantee. Malformed/missing weather or
example inputs are isolated by source and do not block registry/result reopening.

## Final API decisions

See backend/README.md and app.py for routes. The agreed summary/detail shape is
implemented. Source listing adds `source_errors` alongside `sources`.
`compare_run_ids` accepts only completed runs with a committed result pointer.
The parent explicitly chose this boundary; pending/running recovery uses run
history, and is not a comparison selection. Invalid selection returns 409 and
leaves the prior project unchanged. The first implementation permits at most two
candidates. Drafts may be incomplete and do not mutate existing fixed results.

Only queued work is cancellable. Running cancellation returns 409 and does not
change state. Graceful close waits for the running job. Unfinished states found
at a new start become interrupted; there is no automatic rerun.
Physical stopped trajectories are completed jobs with `landing:null`; no last
record is promoted to a landing. No Monte Carlo probability is inferred from n=1.

POST/PUT require application/json; cancellation sends `{}`. No CORS wildcard is
configured. Vite uses its same-origin proxy. Missing frontend build gets a clear
root-page message; unknown API paths return 404. Runtime data defaults outside
the repository and can be set with BALLOON_DATA_DIR or the factory/service argument.

## Executed checks and evidence

Final invocation used dedicated
`P450/backend-venv/Scripts/python.exe -B -X utf8 -m pytest backend/tests -p no:cacheprovider`
with new `P450/backend-test-4` and `backend-test450-final.xml`.
**7 passed, 1 dependency deprecation warning, 9.29 seconds**. The warning is the
Starlette TestClient alias for AnyIO BlockingPortal, not a failed check.

- Real spawn worker calculated full saved Wakayama A and B flights. A payload1 kg:
  839 records, duration8363.851454160776 s, landed. B payload1.5 kg: 1038 records,
  duration10353.195255236786 s, landed. Both maximum altitude30000 m. Exact result
  hashes, input and summaries are in backend-evidence450.json.
- Draft edited while running; both old inputs preserved. Request replay returned
  the same run; conflicting replay rejected. Project revision CAS tested.
- Both results and comparison selection reopened in a new service even when the
  source catalog was unavailable. Completed artifact marker bytes remained equal.
- Actual boundary-stop case: Wakayama launch lon136.24/ASL500, otherwise defaults.
  112 records, 1045.2813720703125 s, LONGITUDE_OUT_OF_RANGE. Last valid location
  lat33.81800347661943/lon136.24999998874216/ASL4772.136116156674 m. Service result
  equals direct-kernel result exactly, retains stop reason and null landing.
- Corrupt result rejected; a publish failure injected before marker left staging
  hidden and preserved the older result. Source JSON failure isolated.
- Queue bound, queued cancellation, second-owner lock, no automatic restart rerun,
  running recovery state and truthful running cancellation checked. Running
  recovery used a persisted running-state fixture, not a forced process-kill test.
- API source/path rejection, UTC validation, incompatible diameter/constant-speed
  rejection, JSON requirement and API-typo404 checked through TestClient.

Earlier finite failures: venv ensurepip and normal pip/pytest execution hit Windows
temporary-directory PermissionError. Dedicated-environment install and finite
tests succeeded after explicit tool escalation. No base dependency was installed.
The first executable suite exposed a second-owner lock read error; using fstat
before locking fixed it. Subsequent complete suites passed. The final test also
improved the support-stop case from empty initial support failure to a trajectory
that exits the saved field. No implementation Python changed during root's
independent UI test window after the freeze message.

## Remaining boundaries

Root owns independent HTTP/live UI review, document registration and publication.
This backend evidence does not claim browser QA, scientific accuracy, portable
project import/export, past-weather or seasonal application completion, MC,
running-job termination, network service security, or power-loss durability.
Requirements are exact version pins, not wheel hashes. The package was tested in
Python3.12.12 on Windows with NumPy2.4.4/SciPy1.17.1. User-selected paths and URLs
are not accepted as weather sources. The reference framework's scientific kernel
was not copied or scientifically adopted.
