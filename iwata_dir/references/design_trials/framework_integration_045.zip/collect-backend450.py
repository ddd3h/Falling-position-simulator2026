import hashlib
import json
from pathlib import Path

root = Path.cwd()
output = Path(__file__).parent
test_root = output / 'backend-test-4'
two_dir = next(test_root.glob('test_two_real_flights_*')) / 'results'
flights = []
for folder in sorted(two_dir.iterdir()):
    result = json.loads((folder / 'result.json').read_text(encoding='utf-8'))
    run = json.loads((folder / 'run.json').read_text(encoding='utf-8'))
    flights.append({'run_id': folder.name, 'input': run['submitted_input'],
                    'frozen_input_hash': run['frozen_input_hash'],
                    'result_status': result['status'], 'summary': result['summary'],
                    'sha256': hashlib.sha256((folder / 'result.json').read_bytes()).hexdigest()})
# The integrity test deliberately replaced result.json after its successful read.
# Its untouched CSV and fixed run.json retain the boundary case as evidence;
# the test and JUnit establish rejection of the tampered JSON.
files = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted((root / 'backend').rglob('*'))
         if p.is_file() and '__pycache__' not in p.parts and '.venv' not in p.parts}
report = {'schema': 'backend.acceptance-evidence/1',
          'tests': {'passed': 7, 'duration_s': 9.29, 'junit': 'backend-test450-final.xml',
                    'warning': 'Starlette TestClient AnyIO BlockingPortal deprecation'},
          'two_real_flights': flights, 'source_sha256': files,
          'scope': 'Offline saved GFS, actual spawn worker; not scientific validation or a power-loss guarantee'}
(output / 'backend-evidence450.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': report['tests'], 'flights': [{'label': r['input']['label'], 'summary': r['summary']} for r in flights],
                  'files': len(files)}, ensure_ascii=False, indent=2))
