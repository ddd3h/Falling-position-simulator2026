from pathlib import Path
import hashlib, json, shutil
from pypdf import PdfReader

R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(__file__).resolve().parent
O=P/'program-build-03'
B=P/'basis-C2'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
build=json.loads((O/'build.json').read_text(encoding='utf-8'))
assert build['selected_guides']==['PROGRAM_GUIDE']
assert not build['warnings']['PROGRAM_GUIDE']
assert sha(R/'docs/PROGRAM_GUIDE.tex')==build['sources']['PROGRAM_GUIDE.tex']==sha(P/'guide-source-03/docs/PROGRAM_GUIDE.tex')
for name,digest in build['outputs'].items():
    assert sha(O/name)==digest
reader=PdfReader(O/'PROGRAM_GUIDE.pdf')
assert len(reader.pages)==16 and len(list(O.glob('page-*.png')))==16
assert all(page.extract_text().strip() for page in reader.pages)
index=json.loads((R/'docs/IMPLEMENTATION_INDEX.json').read_text(encoding='utf-8'))
code=index['structure']['physical_modules']+index['structure']['manual_interpretation']['typescript_modules']
assert all(sha(R/row['path'])==row['source_sha256'] for row in code)
protected=['docs/THEORY_GUIDE.tex','docs/THEORY_GUIDE.pdf','docs/THEORY_GUIDE.txt','docs/PROJECT_PLAN.md','docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf']
assert all((R/p).read_bytes()==(B/p).read_bytes() for p in protected)
before={name:sha(R/'docs'/name) for name in build['outputs']}
for name in build['outputs']:
    assert name in {'PROGRAM_GUIDE.pdf','PROGRAM_GUIDE.txt'}
    shutil.copyfile(O/name,R/'docs'/name)
assert all(sha(R/'docs'/name)==digest for name,digest in build['outputs'].items())
paths=['docs/PROGRAM_GUIDE.tex','docs/PROGRAM_GUIDE.pdf','docs/PROGRAM_GUIDE.txt','docs/IMPLEMENTATION_NOTES.md','docs/IMPLEMENTATION_INDEX.json','docs/COMMANDS.md','docs/BUILD.md']
report={'schema':'balloon.documentation.review/1','basis_commit':'346e9484d3fc3444fd7a12c9e85710e479685666','review_scope':['PROGRAM-CORE','IMPLEMENTATION-NOTES','COMMANDS-CORE','BUILD','IMPLEMENTATION_INDEX source correspondence'],'reviewer':'continuity430 (document author); parent independently reviewed text and FE/BE authors reviewed their boundaries','approved_markers':'root message approved version 0.45 after reviewing PROGRAM changes, NOTES, C09 and BUILD','asset_operation_marker':'PDF skill edit marker executed successfully once immediately before first TeX edit; not repeated for regeneration','build_manifest':str(O/'build.json'),'visual_review':{'pages':list(range(1,17)),'method':'All final Poppler PNG pages viewed through view_image at 100 dpi','findings':'No clipped/overlapping text or diagrams. After build02, only arrow label positions/shortening were corrected; build03 all16 pages reread.','limits':'Document rendering review, not browser UI validation or scientific revalidation'},'publication':{'paths':['docs/'+n for n in build['outputs']],'before':before,'after':build['outputs'],'readback_equal':True},'documents':{p:{'sha256':sha(R/p),'size':(R/p).stat().st_size,'basis_sha256':sha(B/p)} for p in paths},'index':{'entries':len(index['entries']),'python_modules':len(index['structure']['physical_modules']),'typescript_modules':len(index['structure']['manual_interpretation']['typescript_modules']),'all_source_fingerprints_match':True,'python_signature_test':'index450-signature-check-final.txt: 1 pass; latest index refresh changes TS fingerprint for build08, not Python definitions/signatures','source_fingerprints':{row['path']:row['source_sha256'] for row in code}},'protected_unchanged':{p:sha(R/p) for p in protected},'remaining':'Root metadata/global checks, live application observations, Git save/readback are separate work; these 7 paths are ready for metadata and freeze.'}
(P/'documentation450-final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'published':report['publication']['paths'],'pages':16,'files':len(paths),'index_entries':len(index['entries']),'source_fingerprints':len(code),'protected_unchanged':len(protected),'hashes':build['outputs']},ensure_ascii=False))
