"""Read source inventory/imports and write only a metadata proposal in P450."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

root = Path.cwd()
sys.path.insert(0, str(root))
from tools.check_state import source_files, RUNTIME_ROOTS

out = Path(__file__).parent
basis = json.loads((out / 'basis450.json').read_text(encoding='utf-8'))
health = json.loads((root / 'docs/CONTENT_HEALTH.json').read_text(encoding='utf-8'))
previous = {x['path'] for x in basis['files']}
errors = []
current = source_files(root, sorted(previous), lambda ok, msg: errors.append(msg) if not ok else None)
added = sorted(current - previous)
existing_ids = {x['path']: x['id'] for x in health['units'] if x.get('parent') is None and x.get('path')}

definitions = {
 '.gitignore': ('RUNTIME-IGNORE', 'ローカル依存・生成ビルド・PythonキャッシュをGit保存対象から除外する。'),
 'backend/README.md': ('BACKEND-README', 'ローカルサービスの導入・起動・保存契約と検証の限界を案内する。'),
 'backend/__init__.py': ('BACKEND-PACKAGE', '既存計算核を利用するローカルアプリケーションのPythonパッケージを識別する。'),
 'backend/app.py': ('BACKEND-APP', 'HTTPの受付をアプリケーションサービスへ接続し完成済み画面を配信する。'),
 'backend/application.py': ('BACKEND-SERVICE', '草案・固定実行・有限待機・状態遷移と再起動後の読込をHTTP非依存で管理する。'),
 'backend/contracts.py': ('BACKEND-CONTRACTS', '直接実行と草案保存のHTTP外枠・型・件数制約を定義する。'),
 'backend/pyproject.toml': ('BACKEND-PROJECT', 'ローカルサービスのPython版と直接依存・試験依存を宣言する。'),
 'backend/requirements.lock': ('BACKEND-DEPENDENCIES', '実行と試験に用いるPython依存集合の解決済み版を固定する。'),
 'backend/storage.py': ('BACKEND-STORAGE', 'レジストリと固定出力の完成境界を管理し保存結果の整合を検査する。'),
 'backend/tests/test_application.py': ('BACKEND-TEST-SERVICE', '保存GFSによる実計算・保存再閲覧・停止・受付と失敗境界を検証する。'),
 'backend/worker.py': ('BACKEND-WORKER', '固定入力と保存場を検証して既存核の一飛行計算と出力を別processで実行する。'),
 'frontend/index.html': ('FRONTEND-HTML', '日本語比較画面のHTML入口とReact起動先を指定する。'),
 'frontend/package-lock.json': ('FRONTEND-DEPENDENCIES', '画面の開発・構築・試験に用いるnpm依存集合を固定する。'),
 'frontend/package.json': ('FRONTEND-PROJECT', '画面のNode要件・依存と開発・構築・試験コマンドを宣言する。'),
 'frontend/src/App.tsx': ('FRONTEND-APP', '条件草案・固定結果・地図・履歴を二条件比較の操作行程として構成する。'),
 'frontend/src/ConfigEditor.tsx': ('FRONTEND-CONFIG-EDITOR', '放球条件と実装済みモデルの直接入力を草案として編集する。'),
 'frontend/src/HistoryPanel.tsx': ('FRONTEND-HISTORY', '固定結果の時系列と表示時刻を描画して実行情報付きの図を保存する。'),
 'frontend/src/MapPanel.tsx': ('FRONTEND-MAP', '共有地図へ固定軌道・場の支持範囲と着地または停止点を描画する。'),
 'frontend/src/api.ts': ('FRONTEND-API', '草案・保存場・実行・固定結果をローカルHTTP契約で送受信する。'),
 'frontend/src/domain.test.ts': ('FRONTEND-TEST-DOMAIN', '日時変換・表示補間・条件差分と保存場表示の基本契約を検証する。'),
 'frontend/src/domain.ts': ('FRONTEND-DOMAIN', '画面の入力・結果型と日時・差分・表示用補間の共通処理を定義する。'),
 'frontend/src/main.tsx': ('FRONTEND-MAIN', 'React画面をHTML入口へ接続して地図と画面のスタイルを読み込む。'),
 'frontend/src/style.css': ('FRONTEND-STYLE', '条件比較・地図・履歴と状態表示の画面レイアウトを定義する。'),
 'frontend/src/useWorkspace.ts': ('FRONTEND-WORKSPACE', '送信・監視・保存・再読込を調整して草案と固定結果の表示を接続する。'),
 'frontend/src/workspaceState.test.ts': ('FRONTEND-TEST-STATE', '後着完了・明示選択・保存中編集と送信意図の状態遷移を検証する。'),
 'frontend/src/workspaceState.ts': ('FRONTEND-STATE', '草案・固定結果・比較選択と送信意図の状態遷移を管理する。'),
 'frontend/tsconfig.json': ('FRONTEND-TYPESCRIPT', '画面と構築設定のTypeScript型検査範囲と出力方針を定義する。'),
 'frontend/vite.config.ts': ('FRONTEND-VITE', '開発配信・API転送・画面構築と単体試験の設定を定義する。'),
}
assert not errors, errors
assert set(added) == set(definitions), {'unexpected': sorted(set(added)-set(definitions)), 'missing':sorted(set(definitions)-set(added))}
new_ids = {path: values[0] for path, values in definitions.items()}
ids = {**existing_ids, **new_ids}
assert len(set(new_ids.values())) == len(new_ids)
assert not set(new_ids.values()) & set(existing_ids.values())

def existing_path(module):
    name = module.replace('.', '/')
    for suffix in ('.py', '/__init__.py'):
        if name + suffix in ids:
            return name + suffix

def path_from_relative(source, target):
    path = (root / source).parent / target
    path = path.resolve().relative_to(root).as_posix()
    for ending in ('', '.ts', '.tsx', '.css'):
        if path + ending in ids:
            return path + ending

def direct_imports(path, text):
    found = []
    if path.endswith('.py'):
        for node in ast.walk(ast.parse(text)):
            if isinstance(node, ast.Import):
                for name in node.names:
                    target = existing_path(name.name)
                    if target:
                        found.append((target, f'{path}:{node.lineno} import {name.name}', 'python_import'))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ''
                if node.level:
                    parent = path.rsplit('/', 1)[0].split('/')
                    module = '.'.join(parent[:len(parent)-node.level+1] + module.split('.'))
                target = existing_path(module)
                if target:
                    found.append((target, f'{path}:{node.lineno} from {module}', 'python_import'))
    elif path.endswith(('.ts', '.tsx')):
        pattern = r'(?:from\s+|import\s+)[\"\'](\.[^\"\']+)[\"\']'
        for match in re.finditer(pattern, text):
            target = path_from_relative(path, match.group(1))
            if target:
                line = text.count('\n', 0, match.start()) + 1
                found.append((target, f'{path}:{line} {match.group(0)}', 'typescript_import'))
    return found

explicit = {
 'backend/application.py': [(p, 'literal offline catalog definition and read_json', 'data_read') for p in (
      'examples/hokkaido-simple.json', 'examples/wakayama-isothermal.json',
      'references/flight_fixture/hokkaido-weather.json.gz', 'references/flight_fixture/wakayama-weather.json.gz')],
 'backend/tests/test_application.py': [('references/flight_fixture/wakayama-weather.json.gz', 'direct simulate parity case loads this saved bundle', 'test_data_read')],
 'backend/README.md': [(p, 'documented entry point, command or storage boundary', 'documented_interface') for p in (
      'backend/app.py','backend/application.py','backend/worker.py','backend/storage.py','backend/requirements.lock','backend/tests/test_application.py')],
 'backend/requirements.lock': [('backend/pyproject.toml', 'resolved runtime/test set includes the direct declarations', 'dependency_resolution')],
 'frontend/package-lock.json': [('frontend/package.json', 'lock root package mirrors declared project dependency set', 'dependency_resolution')],
 'frontend/index.html': [('frontend/src/main.tsx', 'script type=module src=/src/main.tsx', 'html_entry')],
 'frontend/package.json': [('frontend/tsconfig.json', 'build script runs tsc -b using the local TypeScript project', 'build_configuration'),
                          ('frontend/vite.config.ts', 'dev/build/preview/test scripts use Vite/Vitest local config', 'build_configuration')],
}
entries = []
for path in added:
    content = (root/path).read_bytes()
    text = content.decode('utf-8')
    observations = direct_imports(path, text) + explicit.get(path, [])
    observed = []
    for target, why, kind in observations:
        assert target in ids, target
        item = {'id': ids[target], 'path': target, 'kind': kind, 'evidence': why}
        if item not in observed:
            observed.append(item)
    entry = {'id': new_ids[path], 'path':path, 'purpose':definitions[path][1],
             'sha256_at_inventory':hashlib.sha256(content).hexdigest(),
             'depends_on':sorted({item['id'] for item in observed}), 'dependency_evidence':observed,
             'review_scope':'registration proposal; not an unqualified review-complete declaration'}
    if path.startswith('backend/'):
        entry['verification_reference'] = ['backend-delivery450.md','backend-evidence450.json','backend-test450-final.xml']
        entry['verification_limit'] = 'Read each item against its recorded hash; the seven application checks do not separately certify every dependency pin or packaging path.'
    entries.append(entry)

optional = [
 {'path':'frontend/src/api.ts','candidate_depends_on':['BACKEND-APP','BACKEND-CONTRACTS'],
  'reason':'HTTP /api/v1 routes and run/project request envelopes match these Python interfaces; this is an explicit protocol relation, not a module import.'},
 {'path':'frontend/src/domain.ts','candidate_depends_on':['BACKEND-CONTRACTS','FLIGHT-CONFIG','FLIGHT-TRAJECTORY'],
  'reason':'Config/Project/Run/ResultEnvelope types and compatibility checks represent these input/output schemas; no direct cross-language import is present.'},
]
proposal = {
 'schema':'balloon.new-assets-proposal/1', 'captured_at_utc':datetime.now(timezone.utc).isoformat(),
 'basis_commit':basis['candidate'], 'basis_tree':basis['tree'],
 'basis_registered_count':len(previous), 'source_count_at_inventory':len(current),
 'added_count':len(entries),'deleted_from_basis':sorted(previous-current),
 'inventory_function':'tools.check_state.source_files', 'inventory_errors':errors,
 'inventory_function_sha256':hashlib.sha256((root/'tools/check_state.py').read_bytes()).hexdigest(),
 'excluded_runtime_roots':sorted(RUNTIME_ROOTS),
 'inventory_limit':'Frontend is being revised concurrently. Re-enumerate paths and recheck all hashes at root freeze; this is a point-in-time proposal, not a final registration or review certificate.',
 'dependency_policy':'depends_on lists directly observed internal imports, literal data reads, HTML entry or explicit build/documentation relations; external packages/stdlib have no invented health IDs; unimported scientific internals are not added transitively.',
 'entries':entries, 'protocol_dependencies_for_root_decision':optional,
 'notes':[
   '.gitignore lists runtime paths but does not import or execute check_state; its empty dependency list is intentional.',
   'CSS is imported by main; selectors do not create reverse source dependencies.',
   'TypeScript include globs identify the validation target set and are not expanded into every source as dependents.',
   'Source snapshot hashes read all kernel Python files as provenance; worker semantic dependencies here follow its actual direct imports, not every hashed file.',
   'No health ID contains an implementation version; all existing FLIGHT IDs are resolved from the current registry by exact path.'
 ]}
assert all((root/e['path']).read_bytes() and hashlib.sha256((root/e['path']).read_bytes()).hexdigest() == e['sha256_at_inventory'] for e in entries)
target = out/'newassets450-proposal.json'
target.write_text(json.dumps(proposal, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':str(target),'captured_at_utc':proposal['captured_at_utc'],'added':len(entries),'source_count':len(current),'errors':errors,'deleted':proposal['deleted_from_basis']},ensure_ascii=False,indent=2))
