# 0.45 frontend: 実装方針・参考構成・有限検証

2026-09-29。frontend430担当。開始時は読取設計のみ、主担当が S35 s35-implementation450-plan / D-184 を記録した後、frontend/ の新規現役ソースの編集へ進んだ。基準 main M420 `4e3e4db0d047af9479bcd68bfc2553eeb71efcc9`、PR30先端0.44 C2 `346e9484d3fc3444fd7a12c9e85710e479685666` / tree `7e090262c5da55a089b9f4a9292f06fa14a53c96` は主担当のlive確認を入力とする。本担当は既存の科学核、原ZIP、docs、Git、外部接続設定を編集していない。

## 器から実際の利用行程へ

今回の採用は React / TypeScript / Vite の現役ソースを private repo の frontend/ に置くこと。参考public `ddd3h/Falling-position-simulator2026` main `94887cbb97a8b8ba98d84ef7662e2df200f000d7` の、単一可変params/results、Tawhiri直結、人工MC/最適化を取り込むことではない。

初回は保存された実GFSと既存核で、同地点の一軸違いの二つの n=1 結果を作り、草案・固定入力・場・モデル・状態・イベント・地図・履歴を比較する。ユーザーが上昇速度だけに固定されないよう、現核の定速/等温浮力、指定高度/径、基準下降速度/定CdAの必要量を編集できる。全モデル拡張、少数MC、50/90/95%経験域、禁止域群、延期列、独立風、過去飛行、3Dは今回の実装に含めない。これらを達成したような空のメニューや架空の雲は置かない。

現在のUIは縦に、共通の準備 → A/B条件と表示結果のカード → 幅全体の共有地図 → 高度履歴・共通時刻バー、と続く。二つの小さな条件カードは横に並ぶが、画面全体を固定幅サイドバーと細い地図へ二分しない。狭い画面ではカードを縦に並べる。条件編集は必要時だけ開き、計算ボタンと表示中の版・停止/着地は閉じても読める。地図はviewportに応じた高さと、280–1100pxの操作可能な高さ指定を持つ。ResizeObserverでLeafletへ実寸変更を通知する。

## 旧模型から保持した価値と置き換えた部分

`references/design_trials/hover_surface_pick_correction_0401.zip` の索引は VISION174–178行。原ZIPの選択6実体（README、forecast/index.html、app.js、style.css、scene-document.js、export390.js）をP450/trial-sourceへ新規抽出して実読した。原ZIPは変更していない。旧READMEが記す局所hover成功、2D復帰失敗、r2の限定再評価、人工データの限界は当時の観察であり、今回のReact UI観察とはしない。

| 旧実体から読む効用 | 今回の実装 |
|---|---|
| index.html13–19行: 注目候補の条件・結果、条件棚、共有地図、表示切替が近い | A/B草案と固定結果を同じカードに置き、直下の地図/履歴へ色を継ぐ。編集中でも旧結果は保持 |
| app.js14–21行: draftとresultを別に持つ / results履歴 | immutable run/result参照を中心にし、草案の版・入力/場との差を示す。過去runを選び直せる |
| index.html19行: 地図の自動高と任意伸縮 | 全幅地図、viewport高、rangeによる高さ調整、ResizeObserver。旧CSSをまとめて複写しない |
| index.html20–21行: 同じ群・時刻で地図と履歴を読む | 初回は各候補一飛行の共通経過時間バー。保存recordsを表示用に内挿し、イベント/診断用元記録を変更しない |
| scene-document.js: candidate/result/sample IDとrender層の分離 | run IDで同じrecordsを2DとSVGへ渡す。色は候補、実線/破線は上昇/下降。停止点を着地へ変換しない |
| export・旧保存操作: 図と入力/結果の関係 | 履歴SVGの内部に候補色、相、JST、ASL単位、run ID、metadataを含める。project保存は草案と固定結果の参照 |

旧模型の全操作を移植したという意味ではない。写真3Dの面内hover、選択群、2D/3D往復は次の接続時に元の観察と反例から評価する。今回、資料HTMLへのbrowser policy拒否を別host等で迂回していない。本担当は新UIのブラウザ操作も行っておらず、主担当が実行中である。

## 小さい実APIと状態の責務

backend430と次を合意し、backend/app.pyの実transportも読んだ。

- GET `/api/v1/weather-sources`: ID、固定hash、run、有効時刻、lat/lon/pressure範囲、default_config、個別source_errors。任意filesystem pathをHTTPで送らない。
- POST `/api/v1/runs`: client_request_id、candidate_id/revision、label、weather_source_id、config。202は受付であり、飛行着地成功ではない。同一request IDを再送して別試行にしない。
- GET `/runs` と `/runs/{id}`: 運用上のqueued/running/completed/failed等。詳細specにsubmitted_inputと正規化configを固定。
- GET `/runs/{id}/result`: n=1、trial/run、weather/source snapshot、現行 `balloon.flight.result/1`。job completedでもflight stoppedがあり、landing=nullを維持。
- GET/PUT `/project`: optimistic revisionと、最大二候補の草案・completed結果のcompare_run_ids。queued/runningは結果比較へ混ぜず、reload時はrunsからpoll再開。POSTし直さない。

`useWorkspace.ts` がAPI・再開・保存・個別読込エラーを扱い、`workspaceState.ts` がproject/run map/result map/選択epochを一つのreducerで変更する。Appは画面構成を担う。主担当の批評を受け、古いclosureのrun一覧で比較集合を消す初稿を改めた。人間が計算待ち中に旧結果を明示選択した場合、後着結果は保存された履歴へ追加し、表示選択を上書きしない。同じ旧結果を表示し続ける明示ボタンも置いた。読めない一結果があっても草案と他の結果を開く。

revisionが違うだけで物理条件が変わったとはしない。run.spec.submitted_inputのconfigとweather IDを比較する。方式切替の初期値は画面で説明し、定速へ切替えても既存の破裂径を30km高度へ黙って置換しない。未対応の組合せと空数値は計算ボタンを止め、値を保持する。現核が可能な範囲を超えて将来組合せまで拒否する設計ではない。

読み戻したAPI8451はhealth=0.45.0、和歌山/北海道2source、project revision0を返し、型契約と合った。これはread-only形状確認であり、本担当が二実飛行のブラウザ受入を完了したという意味ではない。

## source・runtime・依存

現役の登録sourceは17ファイル。package/lock、tsconfig、vite設定、index、App/main/style、ConfigEditor、MapPanel、HistoryPanel、api/domain、useWorkspace、workspaceState、domain/workspaceStateの2試験。`node_modules/` と `dist/` は生成/依存物。tsbuildinfoは `node_modules/.cache/tsconfig.tsbuildinfo` に置く。元模型ZIPやfrontendのTemp評価コピーを現役編集先にはしない。

依存は React19.2.8 / React DOM19.2.8 / Leaflet1.9.4。開発は TypeScript6.0.2 / Vite8.2.0 / plugin-react6.0.4 / Vitest4.1.10 と型定義を固定し、npm lockfileを保存する。Zustandは必須にせず、小さいreducerを採用。Plotly、Navara、Three、Tawhiri clientを依存へ含めない。実計算はPython核の責務、SVGは保存結果の表示の責務とする。

Windows x64ではoptional native package `@rolldown/binding-win32-x64-msvc`1.2.11、`lightningcss-win32-x64-msvc`1.33.0が入った。全OSを試したとはしない。Nodeは既存bundled24.19.0。npmがPATHに無かったのでP450/npm-runtimeへnpm12.1.0をpnpm11.25.0のscripts無効installで用意し、その実npm CLIを以降のci/build/testに使った。新FE依存をpnpmでインストールしたという意味ではない。整形用Prettier3.6.2も同じTemp runtimeにだけ置き、repo依存は増やしていない。dlxの既定cache先へのEPERMは整形着手前に起きたが、Tempへの通常tool installで整形した。自動承認レビューによる拒否ではない。

起動の標準形はfrontendで `npm ci`、`npm run dev`（127.0.0.1:8450、/apiを8451へproxy）。`npm run build`、`npm test`。previewは127.0.0.1:8452から8451へproxy。本番はbackend8451が生成distを同じoriginで配る。npmの固定lock installの説明は[公式npm ci](https://docs.npmjs.com/cli/v11/commands/npm-ci/)も参照したが、実行版12.1.0の結果と下記logを今回の証拠とする。

## 実行した範囲

1. **参考の未変更コピー**: 固定frontendをP450/frontend-reference-ciへコピー。project scriptsとlockのinstall script対象（es5-ext、macOS専用fsevents）を読んだ。npm12.1.0 `ci --no-audit --no-fund --cache P450/npm-cache` は411packages、exit0。npm12既定によりes5-ext postinstallだけblockされた（内容は既存copyで読取。時区に応じたstderrメッセージでbuildに不要）。これをnpm10等の全lifecycle成功と読まない。
2. 参考 `npm run build` / `npm run test -- --run`: 通常sandboxではViteがWindows実path対応のため呼ぶ `net use` 子processがspawn EPERM。失敗ログ保持。同じ検査を実行権限付きで再試行し、build exit0、7files/54tests pass。予測通信なし。元の74source全byteがcopyと一致。0.43時のpnpm hoisted参考値とは別の、元lockを使うnpm経路が今回確認できた。
3. **新FE**: 明示versionからpackage-lockだけ生成し、標準npm ciに上記cache/audit/fundの限定flagを付けて57packages、exit0。install script警告なし。型check＋Vite build成功。最終整形・入力対策後は `npm-build-active-04.log`。25modules、JS374.09kB/gzip115.66kB、CSS21.25kB/gzip8.15kB。実browserの通信速度・性能値ではない。
4. 新FE試験: 最終 `npm-test-active-02.log` は2files/12tests pass。JST日跨ぎ、不等間隔履歴の内挿/終端、経度180度のcursor、phase境界、変更検出、未対応径の保持、A/B並行完了、後着完了と明示選択、逆順の選択fetch、欠損一結果と他結果/草案保持、保存中の後続編集、入力/場の同一性を検査。実Reactイベント・実HTTP飛行・描画品質・SVG実保存の受入は別。

## 引渡し・残る境界

主担当へ現役distを渡し、実UIで A/B計算 → 条件編集と旧結果保持 → 履歴時刻 → SVG → 保存 → 再開の有限観察を依頼した。背景は既定「通信なし」、利用者が明示的に標準地図/写真を選べる。画像失敗でも軌道/履歴を残すが、全タイル・全端末の表示を確認したとはしない。Google/APIキー不要。

projectは固定結果IDの比較集合と草案を保存する。現時点では一時的な非表示チェック、map中心/zoom/高さ、時刻バー、背景選択は保存されない。別PCへのportable import/export、実行中取消の画面、SVG以外の画像形式は未実装。二結果比較・再閲覧を、この先の分散・群診断・風分析の完成へ広げない。

保存証拠は本書、`frontend-evidence450.py/json`、npm関連log。巨大なnode_modules、npm/pnpm cache、参考distは証拠ZIPへ不要。原zip抽出6実体は検討時の出典参照であり、元ZIPに同じ内容が保持される。最終ソースhashは独立evidence生成後に主担当が必要に応じ更新する。

## 最終批評への修正とソース固定（2026-09-29）

初回build04/12試験の記録を上書きせず、以降の変更をここへ分ける。主担当からは初回A/B実計算→保存→再読込の成功を受領した。本担当の直接ブラウザ観察ではない。その後の表示・非同期処理に対する批評を反映し、最新buildを主担当の実操作へ引き渡した。

- Appの固定結果欄に着地点の緯度/経度/ASLを常時表示。stoppedは着地点なしと最終有効位置を別表示する。準備欄に保存GFSのrun/validをJST/UTCで併記した。
- `domain.supportAreas` は表示結果のweather_snapshot.boundsだけから水平範囲を取り、同じ場/hash/範囲を重複させずMapPanelに灰破線を描く。高度・時間・欠測の支持まで矩形で示さない。初回の視点fitは軌道を対象とし、支持領域全体を強制して軌道を小さくしない。
- `SubmissionIntents` は不明なPOST応答を再送するときだけ同IDを使う。受付応答が読めた後は意図を解放し、同条件でも次の明示計算は新しいIDとする。HTTP 5xx、通信断、正常statusでもJSONを読めない場合は受理済みの可能性があるので保持する。`reject` は確定4xxの拒否だけ解放する。遅い旧ACKが新しい意図を消さない。
- reloadで発見した仕事のwatchは`restore` intentで結果一覧へ追加するだけ。保存してある旧比較結果を完了時に暗黙で交換しない。新たな明示startだけが自動選択を予約し、それも後からの人間選択epochを優先する。
- 同hookの再接続では `RunWatchOwners` がrunとload generationの監視所有を保持する。旧watchが通信/sleep中でも新世代は監視を始められ、旧finallyが新所有を解放しない。`selectResult`、`save`、`start`のエラー応答にも世代検査を付け、load後のepoch再利用で旧応答が勝たない。loadでpending/savingを初期化する。これは小さい操作寿命の境界で、永続的なイベント管理方式の導入ではない。

最新検査は `npm-test-active-04.log`（2 files / 17 tests pass）と `npm-build-active-07.log`（型検査とVite成功）。25 modules、JS `index-D2iVSvFo.js` 376.77 kB / gzip116.41 kB、CSS `index-FoJ2Ie0z.css`21.25 kB / gzip8.15 kB。build05は新テストの広すぎるfixture型assertionでTS2352となり、helper引数を必要なweather_snapshotへ狭めてbuild06で解消した。失敗logも保持する。最終2試験は世代をまたぐ監視再開/旧finallyと、5xxでの同ID維持・4xxでの新意図化。これらは状態/helperの有限反例であり、React hookの実通信遅延注入や実UI・予測科学の受入ではない。

以上でfrontend17ソースを一旦freezeした。追加source pathなし。後続修正があれば検査とreceiptを改める。保存する比較は草案と固定run参照で、一時非表示・地図視点/高さ・背景・時刻バーの永続化は含まない。地理院背景操作について主担当が受けた自動承認拒否を別経路で迂回していない。今回本担当は背景の外部取得を実行していない。

主担当のbuild07実UIで、座標/停止/水平境界/終了位置の区別を確認したとの報告を受領し、履歴図の最終目盛144と単位が重なるという具体指摘だけ追加修正した。HistoryPanelの下余白を65にし、目盛の下に独立した「経過時間 [分]」行を置いた。最終 `npm-build-active-08.log` は成功、JS `index-B4Uq6UDf.js`376.79 kB/gzip116.42 kB。状態/科学数値処理を変えない表示修正なので17試験を機械的に繰り返していない。17sourceのreceiptも再生成し、再freeze。実SVG保存/旧選択の再読は主担当がこの最終buildで続行する。
