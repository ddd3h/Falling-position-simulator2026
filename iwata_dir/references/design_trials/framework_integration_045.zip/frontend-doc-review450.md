# 0.45 FE担当の限定文書照合

2026-09-29。repo文書編集なし。frontendの実装担当として、他担当の説明を最新実装と照合した。全repo文書の再確認印ではない。

読取: IMPLEMENTATION_NOTES.md 21–67、COMMANDS.md 270–322（C-09）、BUILD.md 13–23、PROGRAM_GUIDE.tex 75–87（WEB-FRONTEND）、IMPLEMENTATION_INDEX.json 5718–5817（typescript_modules）。番号は読取時点。最終文書編集はcontinuity430担当へ引き渡した。

採用できる説明: 草案/固定結果/運用状態の区別、n=1に限定すること、保存場の水平支持を全高度/時間へ拡大しないこと、経過時間カーソルが表示内挿であること、再接続はPOSTを再送せず保存比較を保つこと、source/runtimeとnpm依存導入を区別すること、試験と実UI/科学的受入を分けること。起動portは通常8451、開発8450、preview8452で現設定と一致。17ソースの構成を新しい全般state frameworkへ膨らませていない。

小修正提案をcontinuityへ通知:

1. PROGRAM_GUIDE.tex79のapi.ts箱にある入力捕捉/再読pollは、実際useWorkspaceの責務。78へ移すか、79を相対JSON送受信とHTTP statusエラーの説明へ限定する。
2. 比較保存は草案と固定結果参照であり、一時非表示/地図視点・高さ/背景/時刻バーは復元対象外。一文をNOTESまたはCOMMANDSへ置くと「同じ比較」の範囲が過大にならない。
3. INDEXのTS source_sha256は最終変更後に再採取する。最新修正はuseWorkspace、workspaceState、workspaceState.testの3実体で、追加pathなし。手動TypeScript読解をPython AST保証へ変換しない現記述は維持。

最終ソースにはRunWatchOwnersとload generationによる後着遮断、SubmissionIntents.rejectによる5xx保持が入った。NOTESへ全関数名を複写する必要はないが、「後着が選択を奪わない」の操作寿命が現在の実装で成立する範囲を守る。helperの有限反例17試験とbuild07成功を受領印の代用にしない。ブラウザ実観察と最終文書再読は主担当/資料担当の別証拠となる。
