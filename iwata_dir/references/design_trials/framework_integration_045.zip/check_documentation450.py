from pathlib import Path
import hashlib, importlib.util, io, json, re, sys, unittest

R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(__file__).resolve().parent
B=P/'basis-C2'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['docs/PROGRAM_GUIDE.tex','docs/IMPLEMENTATION_NOTES.md','docs/IMPLEMENTATION_INDEX.json','docs/COMMANDS.md','docs/BUILD.md']
index=json.loads((R/paths[2]).read_text(encoding='utf-8'))
fingerprints=[]
for row in index['structure']['physical_modules']+index['structure']['manual_interpretation']['typescript_modules']:
    current=digest(R/row['path'])
    fingerprints.append({'path':row['path'],'expected':row['source_sha256'],'actual':current,'equal':current==row['source_sha256']})
tex=(R/paths[0]).read_text(encoding='utf-8')
anchors=set(re.findall(r'\\Page\{[^}]*\}\{([^}]+)\}',tex)+re.findall(r'\\hypertarget\{([^}]+)\}',tex))
targets=set(re.findall(r'\\Go\{([^}]+)\}',tex))
protected=['docs/THEORY_GUIDE.tex','docs/THEORY_GUIDE.pdf','docs/THEORY_GUIDE.txt','docs/PROJECT_PLAN.md','docs/PROJECT_PLAN.tex','docs/PROJECT_PLAN.pdf']
proof={p:{'basis':digest(B/p),'current':digest(R/p),'equal':(B/p).read_bytes()==(R/p).read_bytes()} for p in protected}
sys.path.insert(0,str(R))
spec=importlib.util.spec_from_file_location('api_index_review450',R/'tests/test_flight_cli.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
stream=io.StringIO()
case=module.FlightCliTests('test_published_api_index_resolves_actual_signatures_and_tests')
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite([case]))
(P/'index450-signature-check-final.txt').write_text(stream.getvalue(),encoding='utf-8',newline='\n')
out={'basis':'346e9484d3fc3444fd7a12c9e85710e479685666','scope':'Documentation source and actual symbol/path/hash correspondence, not UI/scientific acceptance','documents':{p:{'basis':digest(B/p),'current':digest(R/p),'CRLF':(R/p).read_bytes().count(b'\r\n')} for p in paths},'indexed_module_fingerprints':fingerprints,'index_entries':len(index['entries']),'pdf_anchor_targets':sorted(targets),'missing_anchors':sorted(targets-anchors),'protected_unchanged':proof,'signature_test':{'run':result.testsRun,'success':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors)}}
assert all(x['equal'] for x in fingerprints), 'Index has stale source fingerprints'
assert not out['missing_anchors'], 'PROGRAM internal targets missing'
assert all(x['equal'] for x in proof.values()), 'Unassigned THEORY/PLAN changed'
assert result.wasSuccessful(), 'API index signature verification failed'
(P/'documentation450-check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'source_fingerprints':len(fingerprints),'entries':len(index['entries']),'pages':len(re.findall(r'\\Page\{',tex)),'anchor_targets':len(targets),'signature_tests':result.testsRun,'protected':len(proof),'success':True}))
