# 33追加objectの明示受理に限定した候補変更

主担当が採用した方針に従い、P450/save450.pyの `previous_original`、`original`、`execute` のsnapshot節だけを変更した。その他28関数と全global文のASTは前候補と同一。元.git、repo本文、過去票を変更せず、helperのimport/実行・Git操作・publishも行っていない。確認は差分の全文読取、データ照合、AST構文解析まで。

新候補SHA256は `f23aa7f9b58f32ca1eb5dfe0bb8675f8c015d161c7f1497f3c4cc7a64d81b319`。前候補 `6b36918cc4a70364415c3af88a1d5652074c5835db87268e0590d247faa46340` は `save450-pre-additions-review.py` にそのまま保持した。今回だけのdiffは `save450-additions.diff`、P440原型からの全diffは `save450-final.diff`、限定変更のAST照合は `save450-additions-static-review.json`。

## 必須の主担当票

`original-git450-additions-approval.json` を**未承認案**として作成した。現在は `approved: false`、`reviewed_by: null` で、snapshotは受け入れない。主担当が候補と33件を読み、`approved: true`、`reviewed_by: /root` を明示してから使う。受理票には候補helperのhash、旧0.44 snapshotのhash、固定差分票のhash、調査2JSONと調査記録MDのhash、正確な33件のpath/SHA、905/938件、期待全体fingerprintを含めた。

差分票hashは `6974eada550cc4defed17c255f15556ac3f1de4e1a41b897d99ae0f2ad0d46b3`、938ファイルの期待fingerprintは `cd85d7b94c8fc62824b4054e8b2353685bf7ff0c562f4bfebe5a2a7896a18369`。このfingerprintは旧905行＋固定33行を、旧 `original_state` と同じWindows Path順に並べて計算したもの。現.gitへ何かを書いて作った値ではない。旧票と受理票の両方を残す。

## 検査の境界

snapshotはM101と全938ファイルについて、旧905行がすべて同じhash、追加がこの33行だけであることを求める。許容33行には既存pathの上書きや削除を一切認めず、objects以下の固定pathに限る。差分票のbyte hashをコード側にも固定しており、承認票の件数だけを書き換えて追加を広げられない。

新snapshotへ旧票hash・受理票hash・差分票hashを記録する。その後の `original` は、同じ主担当票と同じ期待938行を毎回再構成し、snapshotと現在の全体に完全一致を求める。以後のファイル追加・変更・削除、承認票/evidence/helperの変更は拒否する。既存のfreeze前後、commit/push直前、読戻し後、finallyの検査呼出はそのまま。main/親/166source/6管理path/lease/pending/全blob読戻しの保存経路を変更していない。

scopeには「旧905不変＋書込主体不明の既発生33を明示受理し、今回保存期間の938を固定した」と書き、過去から元.git全体が不変だったという主張を取り下げている。新しい一般除外、object削除、旧snapshot更新、任意のrebaselineはない。

主担当のrelease evidenceへ、この承認済み票と固定差分・調査票を含めれば、受理判断から保存までの参照も外側で追える。snapshot自体も承認票hashを含むため、既存の `original_snapshot_sha256` の束縛は維持される。承認の最終byteはfreeze前に確定し、以後は変更しない。この担当は受理票へrootの承認印を代入していない。
