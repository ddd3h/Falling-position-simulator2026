# 0.36 設計材料の再調査

最初に `root-review.md` を読む。現在案と過去案の一覧はリポジトリの `docs/SIMULATOR_VISION.html#needs360` / `#model-archive`、行動と次担当は `BOOTSTRAP_RUNBOOK.html#S34`、採否は D-175。

| 調べたこと | 保存先 |
|---|---|
| 過去の意見の目的・具体案・後継判断 | history/read-review.md |
| 長期用途と現コードの関係 | horizon/read-review.md |
| 複数モデルの不足という仮説への反証、高さ比較条件 | horizon/second-review.md |
| 主担当のまとめへの批評と反映 | horizon/root-critique.md |
| 原風資料の9図の問い、対象を変える反例 | reference/read-review.md |
| ユーザーの原意見・原PNG | feedback/ |
| 指定した三画面寸法での地図高 | observations/height-measurements.json / PNG |

調査基準は main M350 `9b2feeb09626184caad07df89dc027a1afee6958`。その tree と全103実体を主担当が照合し、三つの0.35 ZIPをP360/sourceへ展開した。`baseline-receipt.json` がその観測記録。各担当が同じGitHub照合を独立に行ったとはしない。

本ZIPは `needs-review-036/` 以下に展開される。他の模型ZIPを含まない。報告中の `base-0.35.0/` は固定M350のrepo、`source/` は0.35の三ZIPを同所へ展開した集合を指す。独立した旧版の取得は固定コミットを指定する。外側TEMPの絶対パスは当時の実行場所であり将来のインストール先指定ではない。

操作模型・科学核は今回変更していない。画像は有限な観察の証拠であり、全端末の評価でも実気象結果でもない。原PDFの描画画像は読取確認に使った頁のみで、原本はrepo `references/user_supplied/wind_analysis_report.pdf`。権利・由来はその登録を引き継ぎ、コードのライセンスを提供資料へ上書きしない。

`observe-height.cjs` は記録環境のNode/Playwright/Edge絶対パスとP360展開構成を使った。再実行する場合は原証拠と別の展開コピーで、これらの参照を実環境へ合わせる。地図通信を意図的に遮断する配置観察なので、生成画像を正常な背景表示の証拠に使わない。reference担当の観察スクリプトも同様に当時の環境パスを保持する。

`manifest.json` はそれ自身を除いた内容のbytes/SHA256を持つ。ZIPそのものの指紋・文書検査・Git保存実績はリポジトリのACT-360/S34と外側receiptへ記録し、自己参照で更新を繰り返さない。
