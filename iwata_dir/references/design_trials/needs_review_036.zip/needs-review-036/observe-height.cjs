const {chromium}=require('C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
(async()=>{
 const out=path.join(__dirname,'observations');fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 const rows=[];
 for(const viewport of [{width:1366,height:768},{width:1920,height:1080},{width:1920,height:1440}]){
  const page=await browser.newPage({viewport});
  // Geometry inspection does not need fresh map imagery.
  await page.route('https://cyberjapandata.gsi.go.jp/**',r=>r.abort());
  await page.goto(pathToFileURL(path.join(__dirname,'source/workflow-ui-035/forecast/index.html')).href);
  await page.waitForSelector('#mapSlot');
  await page.evaluate(()=>new Promise(requestAnimationFrame));
  rows.push(await page.evaluate(()=>({viewport:{width:innerWidth,height:innerHeight},map:(()=>{let r=document.querySelector('#mapSlot').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};})(),bodyHeight:document.body.scrollHeight,documentHeight:document.documentElement.scrollHeight})));
  await page.screenshot({path:path.join(out,`height-${viewport.width}x${viewport.height}.png`),fullPage:true});
  await page.close();
 }
 await browser.close();
 fs.writeFileSync(path.join(out,'height-measurements.json'),JSON.stringify({scope:'Current fixed 0.35 initial state; three specified CSS viewports; network map deliberately unavailable; no screen-size inference from user image; no runtime changes',rows},null,2));
 console.log(JSON.stringify(rows));
})().catch(e=>{console.error(e);process.exitCode=1;});
