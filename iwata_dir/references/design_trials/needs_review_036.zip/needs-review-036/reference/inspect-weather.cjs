const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {chromium}=require('C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
const base='C:/Users/genia/AppData/Local/Temp/balloon-needs-360';const dir=base+'/reference';
const files=['app.js','index.html','fixture.js','style.css'];const source=Object.fromEntries(files.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(base+'/source/workflow-ui-035/weather/'+f)).digest('hex')]));
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
const page=await browser.newPage({viewport:{width:1280,height:620}});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
await page.goto('file:///'+base+'/source/workflow-ui-035/weather/index.html');await page.waitForFunction(()=>window.WindUI?.cache?.selected?.length);
await page.evaluate(()=>WindUI.focusWorkspace());await page.screenshot({path:dir+'/annual-1280.png',fullPage:true});
const annual=await page.evaluate(()=>({state:{...WindUI.state},panels:[...document.querySelectorAll('#annual-plots article')].map(e=>({title:e.querySelector('h3').textContent,rect:e.getBoundingClientRect().toJSON()})),clickHandlers:[...document.querySelectorAll('#annual-plots [data-period]')].filter(e=>e.onclick||e.getAttribute('role')).length}));
await page.locator('[data-view="monthly"]').click();await page.locator('[data-monthly="rose"]').click();await page.locator('#rose-level').fill('14');await page.locator('#rose-level').dispatchEvent('input');await page.waitForTimeout(100);await page.evaluate(()=>WindUI.focusWorkspace());await page.screenshot({path:dir+'/rose-20hpa-1280.png'});
const rose=await page.evaluate(()=>({metadata:WindUI.metadata(),scale:WindUI.roseScale(WindUI.state.roseGrain)}));
await page.locator('[data-view="spatial"]').click();await page.locator('[data-spatial="steady"]').click();await page.evaluate(()=>WindUI.focusWorkspace());await page.waitForTimeout(1800);await page.screenshot({path:dir+'/spatial-steady-20hpa-1280.png'});
const spatial=await page.evaluate(()=>({metadata:WindUI.metadata()}));
fs.writeFileSync(dir+'/ui-reading.json',JSON.stringify({source,scope:'Read-only purpose exploration, not exhaustive acceptance or scientific data validation',annual,rose,spatial,errors},null,2));
await browser.close();console.log(JSON.stringify({source,errors,annualPanelCount:annual.panels.length,outputs:['annual-1280.png','rose-20hpa-1280.png','spatial-steady-20hpa-1280.png','ui-reading.json']}));
})().catch(e=>{console.error(e);process.exit(1)});
