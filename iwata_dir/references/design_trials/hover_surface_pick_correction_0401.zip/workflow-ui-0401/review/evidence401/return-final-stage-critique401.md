# 0.40.1-r2 最終資料の限定適合レビュー

2026-09-27 / document_audit400。対象は `release-r2/workflow-ui-0401` の README、source README、訂正レビューと、外部 `verified-return402.json`。repo / stage / ZIP は変更していない。実画面をこの担当が再操作した票ではない。

## 結論

本文の新しい観測要約は、主担当の `verified-return402.json` に記録された範囲に適合している。新たな過剰成功の必須指摘はない。ただし、下記二つは採用前に閉じる必要がある。

1. 観測票の `artificial_lab.manual_attempts_total: 3` は誤名。観察は自動1回＋手動2回＝取得合計3回であり、manual 3回ではない。主担当が訂正予定と明示している。外部正本と `review/evidence401/verified-return402.json` の収録票を同じ訂正へ揃える。
2. `review/previous-401-r1/README.md` と `manifest.json` は今回の点検時点で未生成。README二つと訂正HTMLが述べる「全832ファイルの内容を復旧できる」は、復旧補助の準備・採用が済んでから成立する。最終収録前にリンクと内容復旧を閉じる。既知の準備途中を恒久的な欠落と断定しないが、このまま最終資料としない。

## 照合した観測と境界

| 本文の要約 | 観測票との対応・判定 |
| --- | --- |
| 8402で3D→2Dを3回、地図の連続性、zoom/drag | `connected_return.roundtrips: 3` と A の連続地理・overlay相対位置の観測。3D要素数だけの証拠へ戻っていない。 |
| A/B注目、2D写真背景、3DでA非表示→2D反映 | B注目・GSI写真・A hidden と禁止領域保持の観測に対応。名称hoverの実マウス確認とは区別されている。 |
| 地図高883→763 px | map height変更の記録に対応。ウィンドウ寸法変更と同一視していない。 |
| B詳細60着地→干渉3本→共有地図、履歴図 | B detailの60 landed / hit subset3 / map and history / overviewに対応。 |
| 接続試行表示1 | 観測票の表示値。HTTP総数・課金数を証明しない留保がある。 |
| 人工CSS故障の自動復旧・隔離・手動でも誤成功にしない | artificial_labの観測に対応。元の発生原因の再現証拠とは書いていない。 |
| 実マウス面内名称の継続 | 8401利用者の旧有限観測として保持。8402の新実マウス確認へ転写していない。 |
| 未確認 | 3D中の実ウィンドウ寸法変更、原CSS不適用の原因、実写真上の全ての穴・非表示hoverを保持。viewport overrideの失敗を成功に数えない。 |

訂正HTMLの「回帰で使う場面」は実施結果の表と分離され、上表の有限観測を超える部分は未確認だと説明されている。r1の局所成功と後続の完成判定撤回も共に残る。新r2の確認を、旧r1の未確認を遡って埋める用途に使っていない。

## 導線と過去記録

- 新HTMLの模型入口、旧0.40レビュー、利用者反証画像、CSS人工lab、方法別観測票、人工WebGL、READMEのリンク先は存在する。未生成なのは上記r1復旧READMEのリンクだけ。
- 新READMEからの訂正レビューと `README-040-original.md` は存在する。source README の新しい `../../review/` 相対パスは source/cesium-probe から模型ルートreviewへ到達する。
- 外部観測票と収録 `review/evidence401/verified-return402.json` は点検時点でbyte一致。ただし上述の誤名を共に含むため、一致だけで正しい内容とは判定しない。
- README冒頭のポートは8402で、保持する8400/8401を旧hostとして区別。sourceの `0.40.1-r1-surface-render-barrier` は3D実装のhost識別であり、2Dを修復した配布候補r2と区別する文脈がある。3D sourceが今回も再変更されたとは書いていない。
- 同じ資料内の旧「今回の確認」を読み違えないよう、主README末尾で反証前の有限観察と説明し、現在のr2節へ戻している。

## 実読範囲

主README全41行、訂正HTML全12行（長いHTML行の全本文）、`verified-return402.json` 全文を実読。source READMEは新r2節・撤回節と近接する現在source説明を読み、r1→r2の全diffを確認した。source READMEのその他の旧履歴本文は今回の新規全面査読ではない。三資料ともr1→r2の変更全体を実読し、変更が追加のr2節・撤回説明・起動先・回帰場面に限られることを確認した。リンク先は実在を確認したが、参照される全資料の全文査読やブラウザ表示確認は行っていない。

| 初回読取り対象 | SHA-256 |
| --- | --- |
| README.md | cda352080588d402a79dafc0c6c803f5fcb5bf97da2119cb324631a8b36dc7a0 |
| source/cesium-probe/README.md | 298ec3df8182a0337a941f65a143d542099aa872b06c8bf0b1afd0bc31dd8511 |
| review/hover-repair401.html | 64760cf07e6a392e27827c47bbd404467c9a82dd8a1fe37375f66e4a44c56f91 |

この票は現在記録の適合批評であり、最終ZIP・Git保存・科学採用・全画面の受入ではない。未生成導線と訂正票を閉じた後は、その限定差分を確認すればよい。

## 固定時の追記

主担当の訂正後、外部と収録の両 `verified-return402.json` を読み戻した。`manual_retries: 2`、`css_fetch_attempts_total: 3` に訂正され、旧誤名はなくなった。両票はbyte一致、SHA-256 `e5c97e0e41ae970a8b013344ce0c6bd541d4bccd8037bdd61214e9cbc837f35c`。上の指摘1は解消した。

指摘2のr1復旧packageは、主担当がprepare→採用→実832内容復旧の順で実施する段階と報告している。この担当は未実行の成功を補わず、対応する後続実施票へ委ねる。本文の過剰成功・観測の取り違えについて追加指摘はなく、この限定報告を固定する。
