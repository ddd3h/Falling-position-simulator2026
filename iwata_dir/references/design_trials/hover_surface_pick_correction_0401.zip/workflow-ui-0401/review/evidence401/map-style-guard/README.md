# 0.40.1 r2: 2D地図の必須CSSを確認し、局所的に復旧する候補

2026-09-27。このフォルダの変更は未適用提案として作成した。主担当が別の `release-r2/workflow-ui-0401` へ採用して確認する。旧 `release/workflow-ui-0401`、944d…の旧ZIP、既存Google接続、リポジトリはこの担当から変更していない。

## 起きた問題と、まだ分かっていないこと

接続済み0.40.1の3Dから2Dに戻った利用者の地図が、市松状の欠損・大きくずれた地理領域となった。主担当のDOM観測では、実pane・tile-container・tileが `position:static`、mapが `overflow:visible`。画像は256pxで読み込み済みだった。ローカルvendor CSSの実体とHTTP配信は正常だった。別タブの同じ2D→3D→2Dは正常だった。

確認できた直接の不良は、必要なLeaflet CSSがそのページで適用されていないこと。なぜ未適用になったか（初期取得、キャッシュなど）は確定していない。3D切替がCSSを消した、または通常復帰時のサイズ再計算不足、と断定しない。正常な往復にresizeを追加して問題を覆い隠さない。

## 変更する責務

| 相対ファイル | 変更 |
|---|---|
| `forecast/map-style-guard401.js` | 必須CSSのcomputed確認、有限の局所再取得、停止表示、BFCache取消・復帰 |
| `forecast/index.html` | 外部CSS取得に依存しない初期隔離と注意表示、固定CSS入口、guard読込 |
| `forecast/app.js` | 初期と2D復帰で確認。復旧時だけ最新視点を保って再配置。名前hoverの退避・read禁止 |
| `review/map-style-lab401.html` | 本体moduleを使う人工故障検査。故障ボタンは製品には含めない |

正常な確認では取得0回。computed不良を初めて検知したときにローカル `forecast/vendor/leaflet.css` を自動で1回だけ再取得する。失敗後は利用者の1クリックにつき1回で、進行中は重複開始しない。8秒で取消し、並列・周期・再帰的な再試行はしない。手動回数を生涯固定上限で封鎖せず、接続回復後の再試行を残す。キー、Google接続、provider、iframe、storageには参照・変更しない。

新しいCSSは旧link直後に置き、アプリCSSとのcascade順を保つ。新しいCSSがloadしたら旧linkを一時無効化し、単独で必要なcomputed値を満たすか確認する。成功したときだけ旧linkを除去し、失敗・timeout・終了は新linkを除去して旧linkのdisabled状態を戻す。

非表示probeに加え、生成済みの実pane・tileも確認する。タイル画像の取得失敗やまだtileがないこと自体をCSS失敗にはしない。隔離がmapに付ける `overflow:hidden` は成功根拠に数えず、実mapの測定時だけ隔離clipを同期的に外し、paneを非表示のまま `finally` で戻す。CSS検査は地図の地理的正しさ・画像通信の成功を保証しない。

地図を `display:none` にせず、寸法を保ちながらpaneとcontrolsを隠す。停止中にbodyへ巨大なタイルがあふれないようにclipする。注意表示も同じHTMLのinline CSSで成立する。`#mapNameHover` はmap外にあるため、異常時に既存controllerをinvalidateし、hostのcanReadでもguardのreadyを要求する。

再取得待機中に外側の条件操作で視点を変えても、成功時点の最新center・zoomを使い、待機開始時点へ巻き戻さない。健康なensureは配置再計算を行わない。失敗後に外側でCSSが修復されていた場合も、確認だけで追加取得なしにreadyへ戻る。この経路の描画整合はlabで別に確認する。

`pagehide.persisted` は進行中の取得を取り消すが、controllerを破棄しない。`pageshow.persisted` で再確認し、自動1回の枠をリセットしない。本当に離れる場合だけlisteners/probe/controllerを破棄する。

## 再現と確認の境界

`prepare-proposal.py` は旧stageから差分入りコピー4ファイルとreceiptをこの提案フォルダに生成する。旧stageを編集しない。`test-map-style-guard401.cjs` はcontrollerとDOM loaderの17ケース・104 assertionを確認した。正常時0取得、自動1回、手動single-flight、最新視点、partial CSSの拒否、順序保持、timeout後の遅延load、BFCache、実pane不良、隔離clipの自己充足、画像未生成の区別を含む。DOMとcomputedはmockであり、ブラウザ視認ではない。

人工labは固定vendor LeafletとCanvasタイルを使い、外部地図画像もGoogle接続も使わない。操作順は次のとおり。

1. 初期状態で必須CSS適用済み・再取得0を確認。A〜Dと連続する紫線・256pxタイルを見てpan/zoomする。
2. 「Leaflet CSSだけ無効化して確認」→自動1回で戻ること、中心・zoom・基準点を確認する。
3. 「実paneだけをstaticにする」→地図を隠して停止。再取得しても競合が残る限り復旧しない。解除後に再確認し、追加通信なしに戻ることを確認する。
4. 「地図のoverflowだけをvisibleにする」でも同様に停止する。probeや隔離clipだけで成功にしない。
5. 故障中も外側の「基準点Bへ移動」を使い、復旧後が古いA視点に戻らないことを確認する。

輸送エラー・timeout・BFCache取消は限定mockで確認しており、このlabに任意URL取得や通信妨害用の製品hookは入れていない。実ページの2D→3D→候補/表示切替→2D、pan/zoom、非表示中の画面サイズ変化は主担当が別に視認する。そこまでの合格やGoogle写真表示の確認を、この提案やmock成功だけから宣言しない。

元の確認設計の不足は、3Dの表示要素数・接続維持・build一致を確認したあと、利用者が戻る2Dで同じ地物・輪郭・尺度を読めることを直接検査しなかった点にある。今回のguardは異常を成功扱いしないための限定修復であり、画面全体の受入の代替ではない。
