'use strict';
// Behavioral mocks: browser computed CSS and final geographic rendering remain
// the job of the separate Leaflet lab / actual forecast acceptance.
const assert=require('node:assert/strict');
const {createController,mount}=require('./map-style-guard401.js');
const cases=[];let assertions=0;
const check=(value,message)=>{assert.ok(value,message);assertions++;};
const equal=(a,b,message)=>{assert.deepEqual(a,b,message);assertions++;};
const test=(name,run)=>cases.push({name,run});
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
function controllerFixture(){
 let healthy=false,view={center:[1,2],zoom:4};const loads=[],timers=new Map(),events=[],restored=[];let nextTimer=0;
 const controller=createController({check:()=>healthy,load:({signal,attempt})=>{const d=deferred();const item={...d,signal,attempt};loads.push(item);signal.addEventListener('abort',()=>d.reject(new Error('cancelled')),{once:true});return d.promise;},capture:()=>structuredClone(view),restore:v=>restored.push(v),present:s=>events.push(s),setTimer:f=>{const id=++nextTimer;timers.set(id,f);return id;},clearTimer:id=>timers.delete(id)});
 const transaction=()=>{const calls={commit:0,rollback:0};return {calls,commit(){calls.commit++;},rollback(){calls.rollback++;}};};
 return {controller,loads,timers,events,restored,transaction,setHealthy:v=>{healthy=v;},setView:v=>{view=v;}};
}
test('healthy startup and repeated returns make no CSS request',async()=>{
 const f=controllerFixture();f.setHealthy(true);check(f.controller.ensure());check(f.controller.ensure());equal(await f.controller.retry(),true);equal(f.loads.length,0);check(f.controller.isReady());
});
test('automatic recovery is once per page; a return does not rearm it',async()=>{
 const f=controllerFixture();equal(f.controller.ensure(),false);await flush();equal(f.loads.length,1);check(f.controller.state().automaticAttempted);f.loads[0].reject(new Error('network'));await flush();equal(f.controller.state().phase,'unavailable');f.controller.ensure();f.controller.ensure();await flush();equal(f.loads.length,1);equal(f.timers.size,0);
});
test('manual retry is one in-flight request and remains available after failures',async()=>{
 const f=controllerFixture();f.controller.ensure();await flush();f.loads[0].reject(new Error('network'));await flush();
 for(let i=1;i<=3;i++){const a=f.controller.retry(),b=f.controller.retry();await flush();equal(f.loads.length,i+1);check(f.controller.state().busy);f.loads[i].reject(new Error('offline'));equal(await a,false);equal(await b,false);}
 equal(f.controller.state().attempts,4);equal(f.controller.state().busy,false);
});
test('recovery preserves the latest view chosen during a wait',async()=>{
 const f=controllerFixture(),txn=f.transaction();const run=f.controller.retry();await flush();f.setView({center:[43.3,141.8],zoom:13});f.setHealthy(true);f.loads[0].resolve(txn);equal(await run,true);equal(f.restored,[{center:[43.3,141.8],zoom:13}]);equal(txn.calls,{commit:1,rollback:0});equal(f.timers.size,0);
});
test('loaded bytes without required computed CSS are rolled back',async()=>{
 const f=controllerFixture(),txn=f.transaction();const run=f.controller.retry();await flush();f.loads[0].resolve(txn);equal(await run,false);equal(txn.calls,{commit:0,rollback:1});equal(f.restored,[]);check(!f.controller.isReady());
});
test('timeout cancels one attempt; a later completion cannot mark ready',async()=>{
 const f=controllerFixture(),txn=f.transaction();const run=f.controller.retry();await flush();[...f.timers.values()][0]();equal(await run,false);check(f.loads[0].signal.aborted);f.setHealthy(true);f.loads[0].resolve(txn);await flush();equal(txn.calls.commit,0);equal(f.controller.state().phase,'unavailable');equal(f.timers.size,0);
});
test('BFCache suspension cancels pending work without disposing the controller',async()=>{
 const f=controllerFixture();f.controller.ensure();await flush();f.controller.suspend();await flush();check(f.loads[0].signal.aborted);check(!f.controller.state().busy);f.controller.ensure();await flush();equal(f.loads.length,1);f.setHealthy(true);check(f.controller.ensure());check(f.controller.isReady());f.controller.destroy();check(!f.controller.isReady());equal(await f.controller.retry(),false);
});

class Element extends EventTarget{
 constructor(tag){super();this.tagName=tag.toUpperCase();this.parentNode=null;this.children=[];this.attrs=new Map();this.style={};this.dataset={};this.className='';this.disabled=false;this.hidden=false;this.textContent='';this.cssActive=false;}
 get nextSibling(){if(!this.parentNode)return null;return this.parentNode.children[this.parentNode.children.indexOf(this)+1]||null;}
 get href(){return this.attrs.get('href')||'';}set href(v){this.attrs.set('href',v);}
 setAttribute(k,v){this.attrs.set(k,String(v));}getAttribute(k){return this.attrs.has(k)?this.attrs.get(k):null;}removeAttribute(k){this.attrs.delete(k);}
 append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}
 insertBefore(n,next){n.remove();const index=next?this.children.indexOf(next):this.children.length;assert.ok(index>=0);n.parentNode=this;this.children.splice(index,0,n);}
 remove(){if(this.parentNode){this.parentNode.children.splice(this.parentNode.children.indexOf(this),1);this.parentNode=null;}}
 querySelector(selector){const name=selector.slice(1);for(const n of this.children){if(n.className.split(/\s+/).includes(name))return n;const child=n.querySelector(selector);if(child)return child;}return null;}
}
function domFixture({healthy=false,fault=null,href='vendor/leaflet.css'}={}){
 const head=new Element('head'),body=new Element('body'),win=new EventTarget();win.location={href:'http://127.0.0.1:8402/forecast/'};
 const doc={head,body,baseURI:win.location.href,createElement:tag=>new Element(tag)};
 const styleLink=new Element('link');styleLink.setAttribute('href',href);styleLink.cssActive=healthy;const appStyle=new Element('link');appStyle.setAttribute('href','style.css');head.append(styleLink,appStyle);
 const mapElement=new Element('div');mapElement.className='leaflet-container';mapElement.dataset.mapDisplay='checking';const pane=new Element('div'),tiles=new Element('div'),tile=new Element('img');pane.className='leaflet-pane';tiles.className='leaflet-tile-container';tile.className='leaflet-tile';tiles.append(tile);pane.append(tiles);mapElement.append(pane);body.append(mapElement);
 const notice=new Element('div'),text=new Element('p'),retryButton=new Element('button');notice.append(text,retryButton);mapElement.append(notice);
 const cssPresent=()=>head.children.some(n=>n.cssActive&&!n.disabled&&n.href.includes('/leaflet.css'));
 let currentFault=fault,view={center:[43,141],zoom:10},unavailable=0;const restored=[];
 win.getComputedStyle=e=>{
  const classes=e.className.split(/\s+/);let position=classes.some(c=>['leaflet-pane','leaflet-tile-container','leaflet-tile'].includes(c))&&cssPresent()?'absolute':'static';
  if(e===pane&&currentFault==='actual-pane')position='static';
  let overflow=classes.includes('leaflet-container')&&cssPresent()?'hidden':'visible';
  if(e===mapElement&&currentFault==='map-overflow')overflow='visible';
  // This intentionally simulates the guard's clip. Verification must opt out.
  if(e===mapElement&&e.dataset.mapDisplay!=='ready'&&e.getAttribute('data-map-style-probe')===null)overflow='hidden';
  return {position,left:position==='absolute'?'0px':'auto',top:position==='absolute'?'0px':'auto',overflowX:overflow,overflowY:overflow};
 };
 const options={document:doc,window:win,mapElement,styleLink,notice,text,retryButton,captureView:()=>structuredClone(view),restoreView:v=>restored.push(v),onUnavailable:()=>{unavailable++;},timeoutMs:15};
 const mounted=()=>mount(options),replacements=()=>head.children.filter(n=>n!==styleLink&&n!==appStyle);
 function loaded(n,active=true){n.cssActive=active;n.dispatchEvent(new Event('load'));}
 function page(type,persisted){const e=new Event(type);e.persisted=persisted;win.dispatchEvent(e);}
 return {doc,head,body,win,mapElement,pane,tiles,tile,styleLink,appStyle,notice,text,retryButton,mounted,replacements,loaded,page,restored,setFault:v=>{currentFault=v;},setView:v=>{view=v;},get unavailable(){return unavailable;}};
}
test('DOM healthy path checks actual panes and makes no replacement link',async()=>{
 const f=domFixture({healthy:true}),g=f.mounted();check(g.ensure());equal(f.replacements().length,0);check(f.notice.hidden);equal(f.mapElement.getAttribute('data-map-style-probe'),null);g.destroy();equal(f.body.children.length,1);
});
test('recovery keeps vendor cascade position and old sheet until verified commit',async()=>{
 const f=domFixture(),g=f.mounted();g.ensure();await flush();const fresh=f.replacements()[0];equal(f.head.children,[f.styleLink,fresh,f.appStyle]);check(f.styleLink.parentNode===f.head);check(f.retryButton.disabled);check(f.unavailable>0);f.setView({center:[43.2,141.9],zoom:12});f.loaded(fresh);await flush();check(g.isReady());equal(f.head.children,[fresh,f.appStyle]);equal(f.restored,[{center:[43.2,141.9],zoom:12}]);check(f.notice.hidden);g.destroy();
});
test('probe success cannot hide a malformed actual pane',async()=>{
 const f=domFixture({healthy:true,fault:'actual-pane'}),g=f.mounted();equal(g.ensure(),false);await flush();const fresh=f.replacements()[0];f.loaded(fresh);await flush();check(!g.isReady());equal(f.replacements().length,0);check(f.styleLink.parentNode===f.head);equal(f.styleLink.disabled,false);check(!f.notice.hidden);g.destroy();
});
test('the guard clipping cannot satisfy real map overflow verification',async()=>{
 const f=domFixture({healthy:true,fault:'map-overflow'}),g=f.mounted();equal(g.ensure(),false);await flush();f.loaded(f.replacements()[0]);await flush();check(!g.isReady());equal(f.mapElement.getAttribute('data-map-style-probe'),null);equal(f.replacements().length,0);g.destroy();
});
test('missing or unavailable tile images do not trigger a CSS download',async()=>{
 const f=domFixture({healthy:true});f.tile.remove();const g=f.mounted();check(g.ensure());equal(f.replacements().length,0);g.destroy();
});
test('transport failure keeps old link; another user click requests once',async()=>{
 const f=domFixture(),g=f.mounted();g.ensure();await flush();f.replacements()[0].dispatchEvent(new Event('error'));await flush();equal(f.head.children,[f.styleLink,f.appStyle]);check(!f.retryButton.disabled);f.retryButton.dispatchEvent(new Event('click',{cancelable:true}));f.retryButton.dispatchEvent(new Event('click',{cancelable:true}));await flush();equal(f.replacements().length,1);f.loaded(f.replacements()[0]);await flush();check(g.isReady());equal(g.state().attempts,2);g.destroy();
});
test('timeout removes pending link and ignores its late load event',async()=>{
 const f=domFixture(),g=f.mounted();const pending=g.retry();await flush();const late=f.replacements()[0];equal(await pending,false);equal(f.replacements().length,0);f.loaded(late);await flush();check(!g.isReady());check(f.styleLink.parentNode===f.head);g.destroy();
});
test('BFCache cancellation leaves reusable listeners; real departure cleans them',async()=>{
 const f=domFixture(),g=f.mounted();g.ensure();await flush();const stale=f.replacements()[0];f.page('pagehide',true);await flush();equal(f.replacements().length,0);f.loaded(stale);f.page('pageshow',true);await flush();equal(g.state().attempts,1);equal(f.replacements().length,0);const retried=g.retry();await flush();f.loaded(f.replacements()[0]);check(await retried);f.page('pagehide',false);check(!g.isReady());equal(f.body.children.length,1);f.retryButton.dispatchEvent(new Event('click'));await flush();equal(g.state().attempts,2);
});
test('healthy-to-broken return invalidates names and only first failure auto-retries',async()=>{
 const f=domFixture({healthy:true}),g=f.mounted();check(g.ensure());f.styleLink.disabled=true;equal(g.ensure(),false);await flush();check(f.unavailable>0);check(!g.isReady());check(!f.notice.hidden);f.loaded(f.replacements()[0]);await flush();check(g.isReady());const current=f.head.children[0];current.disabled=true;g.ensure();await flush();equal(g.state().attempts,1);check(!g.isReady());equal(f.replacements().length,1);g.destroy();
});
test('mount rejects other origins and query-bearing sources before any retry',async()=>{
 for(const href of ['https://example.com/forecast/vendor/leaflet.css','vendor/leaflet.css?token=do-not-log','other.css']){const f=domFixture({href});assert.throws(()=>f.mounted(),/fixed local/);assertions++;equal(f.body.children.length,1);equal(f.replacements().length,0);}
});
(async()=>{const results=[];for(const t of cases){await t.run();results.push(t.name);}console.log(JSON.stringify({status:'passed',cases:results.length,assertions,boundary:'Mock lifecycle/CSS semantics only; no rendered-map or Google acceptance',results},null,2));})().catch(error=>{console.error(error);process.exitCode=1;});
