# 任意requestRenderを加える局所実験（未適用）

`photo-hover-diagnostic-request-render400.js` は元の `diagnostic-proposal/photo-hover-diagnostic400.js` を別名で派生させた診断案。**完成修正ではなく、描画完了待ち・実描画時刻・準備状態による再描画gateを追加しない比較実験**である。live、repo、served stage、元診断は変更していない。

## 変更した動作

「検証：輪郭検出後に再描画」checkboxを追加した。初期OFF。OFFでは元の公開API観測だけを行う。ONかつ診断中に、対象`#map`内のsceneの`drillPick` wrapperの`finally`から公開`this.requestRender()`を1回要求する。結果0件・例外時も対象で、同じ地点の連続呼出しを間引かない。checkboxの切替自体、`pickPosition`、`sampleHeight`、別canvasでは要求しない。

元の`this`・引数・戻り値の同一性・同じ例外を保持する。再描画要求自体が投げた例外は固定分類だけを診断表示し、元の戻り値や例外を置き換えない。要求数は**呼出しを試みた回数**であり、フレーム完了やhover成立の回数ではない。

新たに利用するCesiumのAPIは公開 [`Scene.requestRender`](https://cesium.com/learn/cesiumjs/ref-doc/Scene.html#requestRender) のみ。公式資料は明示描画の要求として説明している。非公開field、provider、認証、通信、storageには触れない。カメラ操作やViewer/scene再作成も行わない。

## 置換して比較する場合の境界

1. 元診断を「診断終了・API復元」で終了させる。競合表示が出た場合は完全復元扱いにせず止める。両診断のprototype wrapperを重ねない。
2. rootが別途承認した一時読込経路でこの**別名module**を採用する。同じ`attachLocalHoverDiagnostic` exportを用い、既存`hover-labels.js` / `band-readout.js`と同じmodule階層を前提とする。この担当は配置・reload・接続を実行していない。
3. 初期OFFで同じカメラ・候補・面内地点を確認し、ON→OFFでも比較する。線上と十分な面内、通常マウスと合成入力をそれぞれ区別し、API分類と要求数を残す。接続や気象条件を同時に変えない。
4. 終了後はAPI復元を確認する。要求ONで改善しても恒久修正として採用しない。

| 比較結果 | 読み取れることと留保 |
|---|---|
| ONで改善しOFFへ戻すと再発 | 明示再描画が現象へ影響する可能性。どのフレームや状態が原因か、描画完了後の再照会が必要かは未確定 |
| ON/OFFで変わらない | この要求位置・時機では十分でない。depth取得・照会順・表示gate・入力の原因を排除できない |
| ONで悪化/不安定化 | 呼出しごとの要求が干渉する可能性。負荷と状態変化も観察対象で、改善した場面だけ残さない |
| 要求回数は増えたが描画/hoverは未確認 | requestRenderの呼出しだけが確認された。完了・表示・接続成功の証拠にしない |

実画面の比較結果はまだない。仮説の有利/不利の両方をこの表に沿って記録する。

## 局所mock確認

`test-request-render400.mjs` は実SDKやproviderを読み込まず、DOM/Scene mockで成功した。初期OFF、ON/OFFの即時反映、対象API/scene限定、空結果・Error/非Error例外時のfinally、再描画例外と元のreturn/throwの分離、gate/間引きなし、元descriptorとlistener/panel/slotの復元を確認した。許可外診断値のgetterは呼ばれず、原例外messageも表示されなかった。

結果は `mock-request-render-result.json`、元診断と派生moduleのSHA256は `experiment-manifest.json`。`build-experiment.py`はこの別ファイルを生成した手順で、既存実験を上書きしない。実際のCesium・Google・物理マウス・frame完了・live復元の確認にはならない。
