// LOCAL REQUEST-RENDER EXPERIMENT ONLY. Not a completed repair.
// Replace the prior diagnostic after its explicit finish; never stack wrappers.
// No frame-completion gate, throttle, or render-timing assertion is added.
// Never include in a product archive.
// Reads public scene results and a fixed diagnostics allowlist; no provider,
// credential, URL, error-message, console, storage, or network access.
import {resolveHover} from './hover-labels.js';
import {readBand,createClickTracker} from './band-readout.js';

const SLOT=Symbol.for('bjp.local.hover-diagnostic400');
const METHODS=['pickPosition','sampleHeight','drillPick'];
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const errorClass=error=>error instanceof TypeError?'TypeError':error instanceof RangeError?'RangeError':error instanceof Error?'Error':'non-Error throw';
const attempt=fn=>{try{return fn();}catch{return undefined;}};
const formatPoint=value=>Array.isArray(value)&&value.every(finite)?value.map(x=>x.toFixed(7)).join(', '):'未取得';
const flags=doc=>({bandsVisible:!!doc.getElementById('showBands')?.checked,regionsVisible:!!doc.getElementById('showRegions')?.checked,linesVisible:false,lineFeatureIndices:[]});

export function attachLocalHoverDiagnostic(C,payload){
 const prior=window[SLOT];
 if(prior){prior.accept(payload);return;}
 const doc=document,map=doc.getElementById('map');
 if(!map||!C?.Scene?.prototype)return;
 let active=false,disposed=false,currentPayload=payload,lastPoint=null,lastClick=null,lastInput='なし',notice='未開始。APIは元のままです。';
 let paintTimer=null,syntheticTimer=null,sequence=0,renderRequests=0,renderOutcome='未要求';
 const installed=[],listeners=[],syntheticEvents=new WeakSet(),tracker=createClickTracker();
 const observations=Object.fromEntries(METHODS.map(name=>[name,{count:0,outcome:'未呼出し',sequence:0,point:null}]));
 const panel=doc.createElement('section');
 panel.setAttribute('aria-label','局所hover診断');
 panel.style.cssText='position:fixed;right:8px;bottom:46px;width:390px;max-width:calc(100vw - 16px);max-height:46vh;overflow:auto;z-index:10000;background:#fff;color:#17303b;border:2px solid #a66b00;border-radius:6px;padding:10px;box-shadow:0 2px 12px #0006;font:12px/1.4 sans-serif';
 const title=doc.createElement('strong');title.textContent='局所hover再描画実験 · 完成修正ではありません';panel.append(title);
 const explanation=doc.createElement('p');explanation.textContent='診断開始後の公開APIだけを観測します。接続・カメラ・認証には触れません。終了で元のAPIへ戻し、このパネルを撤去します。';panel.append(explanation);
 const renderControl=doc.createElement('label');renderControl.style.cssText='display:flex;gap:6px;align-items:center';
 const requestRenderAfterPick=doc.createElement('input');requestRenderAfterPick.type='checkbox';requestRenderAfterPick.checked=false;
 requestRenderAfterPick.setAttribute('aria-label','検証：輪郭検出後に再描画');
 const renderLabel=doc.createElement('span');renderLabel.textContent='検証：輪郭検出後に再描画';renderControl.append(requestRenderAfterPick,renderLabel);panel.append(renderControl);
 requestRenderAfterPick.addEventListener('change',()=>{notice=requestRenderAfterPick.checked?'再描画実験ON。対象drillPickの終了ごとにrequestRenderを要求します。':'再描画実験OFF。元の観測だけを行います。';paint();});
 const renderHelp=doc.createElement('p');renderHelp.textContent='初期OFF。ONでは結果0件や例外の場合も輪郭検出drillPick後に公開requestRenderを要求します。描画完了待ちや再描画時刻のgateは追加しません。改善・不変・悪化のいずれも観察対象で、恒久修正ではありません。';panel.append(renderHelp);
 const status=doc.createElement('p');status.setAttribute('role','status');panel.append(status);
 const controls=doc.createElement('div');controls.style.cssText='display:flex;flex-wrap:wrap;gap:5px';panel.append(controls);
 const button=(label,action)=>{const node=doc.createElement('button');node.type='button';node.textContent=label;node.addEventListener('click',action);controls.append(node);return node;};
 const startButton=button('診断開始',start);
 button('診断値更新',paint);
 button('観測値をクリア',()=>{cancelSynthetic(false);lastPoint=null;sequence=0;for(const name of METHODS)Object.assign(observations[name],{count:0,outcome:'未呼出し',sequence:0,point:null});notice='観測値をクリアしました。最後の通常クリック位置は保持しています。';paint();});
 const synthButton=button('最後の地点へ合成静止入力',scheduleSynthetic);
 button('合成入力を取消',()=>{cancelSynthetic();paint();});
 button('診断終了・API復元',finish);
 const synthHelp=doc.createElement('p');synthHelp.textContent='合成入力は物理マウスではありません。診断中に地図を通常クリックして位置を記憶し、このボタンを押すと1秒後に同じ地点へbuttons=0のpointermoveを1回送ります。';panel.append(synthHelp);
 const table=doc.createElement('pre');table.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font:11px/1.45 monospace;margin:6px 0';panel.append(table);
 doc.body.append(panel);

 function cancelPaint(){if(paintTimer!==null)clearTimeout(paintTimer);paintTimer=null;}
 function queuePaint(){if(disposed||paintTimer!==null)return;paintTimer=setTimeout(()=>{paintTimer=null;paint();},0);}
 function cancelSynthetic(report=true){if(syntheticTimer!==null){clearTimeout(syntheticTimer);syntheticTimer=null;if(report)notice='予約した合成入力を取消しました。';}}
 function cartographicPoint(value){return value&&finite(value.longitude)&&finite(value.latitude)?[C.Math.toDegrees(value.longitude),C.Math.toDegrees(value.latitude)]:null;}
 function inScope(scene){return !!scene?.canvas&&map.contains(scene.canvas);}
 function record(name,args,value,thrown){
  if(!active)return;
  const row=observations[name];row.count++;row.sequence=++sequence;row.input=lastInput;
  if(thrown){row.outcome='例外: '+errorClass(thrown.error);row.point=null;queuePaint();return;}
  if(name==='pickPosition'){
   const hit=!!value;row.outcome=hit?'位置あり':'位置なし';
   row.point=hit?attempt(()=>cartographicPoint(C.Cartographic.fromCartesian(value))):null;
   lastPoint=row.point||null;
  }else if(name==='sampleHeight'){
   row.outcome=finite(value)?'有限高度あり':'有限高度なし';row.point=cartographicPoint(args[0]);
  }else row.outcome=Array.isArray(value)?'配列 '+value.length+' 件':'配列以外';
  queuePaint();
 }
 function makeWrapper(name,original){
  return function(...args){
   let value;
   try{
    try{value=Reflect.apply(original,this,args);}
    catch(error){attempt(()=>{if(inScope(this))record(name,args,undefined,{error});});throw error;}
    attempt(()=>{if(inScope(this))record(name,args,value,null);});
    return value;
   }finally{
    // Optional intervention only. A render failure must not replace the
    // original return value or the identical exception object.
    attempt(()=>{
     if(name==='drillPick'&&active&&requestRenderAfterPick.checked&&inScope(this)){
      renderRequests++;
      try{this.requestRender();renderOutcome='要求した（完了は未確認）';}
      catch(error){renderOutcome='要求時例外: '+errorClass(error);}
      queuePaint();
     }
    });
   }
  };
 }
 function listen(target,name,fn,options){target.addEventListener(name,fn,options);listeners.push(()=>target.removeEventListener(name,fn,options));}
 function cancelInput(){cancelSynthetic(false);tracker.clear();queuePaint();}
 function start(){
  if(active||disposed)return;
  const proto=C.Scene.prototype;
  try{
   const prepared=METHODS.map(name=>{const descriptor=Object.getOwnPropertyDescriptor(proto,name);if(!descriptor||typeof descriptor.value!=='function'||(!descriptor.configurable&&!descriptor.writable))throw new TypeError('unsupported public method descriptor');return {name,descriptor,wrapper:makeWrapper(name,descriptor.value)};});
   for(const item of prepared){Object.defineProperty(proto,item.name,{...item.descriptor,value:item.wrapper});installed.push(item);}
   active=true;
   listen(map,'pointerdown',event=>{cancelSynthetic(false);lastInput='通常 pointerdown';tracker.start(event,performance.now());queuePaint();},true);
   listen(map,'pointermove',event=>{lastInput=(syntheticEvents.has(event)?'診断の合成 pointermove':'通常 pointermove')+(event.buttons?' / buttonsあり':' / buttons=0');tracker.move(event);queuePaint();},true);
   listen(map,'pointerup',event=>{lastInput='通常 pointerup';if(tracker.end(event,performance.now())){lastClick={x:event.clientX,y:event.clientY};notice='通常クリック地点を記憶しました。';}queuePaint();},true);
   for(const name of ['pointercancel','lostpointercapture','pointerleave','wheel'])listen(map,name,cancelInput,{capture:true,passive:true});
   listen(window,'blur',cancelInput,{passive:true});
   listen(window,'keydown',event=>{if(event.key==='Escape'){cancelSynthetic();tracker.clear();queuePaint();}},{passive:true});
   notice='診断中。通常操作でAPIを観測します。';
  }catch(error){
   active=false;for(const remove of listeners.splice(0))attempt(remove);
   for(const item of installed.splice(0).reverse())attempt(()=>Object.defineProperty(proto,item.name,item.descriptor));
   notice='診断を開始できませんでした（'+errorClass(error)+'）。元APIへ戻しました。';
  }
  paint();
 }
 function scheduleSynthetic(){
  if(!active||disposed||!lastClick){notice='診断開始後、地図の通常クリック地点が必要です。';paint();return;}
  cancelSynthetic(false);const point={...lastClick};notice='合成入力を1秒後に1回送ります。カメラを操作せずお待ちください。';
  syntheticTimer=setTimeout(()=>{
   syntheticTimer=null;if(!active||disposed)return;
   const bounds=map.getBoundingClientRect();
   if(point.x<bounds.left||point.x>bounds.right||point.y<bounds.top||point.y>bounds.bottom){notice='元の地点が現在の地図領域外のため合成入力を中止しました。';paint();return;}
   const event=new PointerEvent('pointermove',{bubbles:true,clientX:point.x,clientY:point.y,button:-1,buttons:0,pointerId:1,pointerType:'mouse',isPrimary:true});
   syntheticEvents.add(event);map.dispatchEvent(event);notice='合成静止入力を1回送りました。物理マウス確認ではありません。';queuePaint();
  },1000);paint();
 }
 function paint(){
  if(disposed)return;status.textContent=notice;startButton.disabled=active;synthButton.disabled=!active||!lastClick||syntheticTimer!==null;
  let pure='未取得';
  if(lastPoint){
   pure=attempt(()=>{
    const f=flags(doc),c=resolveHover(currentPayload,lastPoint,{...f,regionsVisible:false}),r=resolveHover(currentPayload,lastPoint,{...f,bandsVisible:false});
    const band=readBand(currentPayload,lastPoint,{bandsVisible:f.bandsVisible});
    return `面のみ: 分散候補 ${c.total} / 領域 ${r.total} / 純粋帯区分 ${band.kind}\n面ON ${f.bandsVisible} / 領域面ON ${f.regionsVisible}`;
   })||'純粋判定を表示できません（詳細は非出力）';
  }
  const d=window.SCENE3D_DIAGNOSTICS;
  // Only these allowlisted primitives are read. Never serialize d or its errors.
  const allowed=d?{
   hostRevision:typeof d.hostRevision==='string'?d.hostRevision:'未取得',
   cameraEventMoving:typeof d.cameraEventMoving==='boolean'?d.cameraEventMoving:null,
   overlayReady:typeof d.overlayReady==='boolean'?d.overlayReady:null,
   paused:typeof d.paused==='boolean'?d.paused:null,
   viewStability:d.viewStability?{hasPose:d.viewStability.hasPose,quietMs:d.viewStability.quietMs,settledMs:d.viewStability.settledMs,changes:d.viewStability.changes,ready:d.viewStability.ready}:null
  }:{hostRevision:'未取得'};
  const rows=METHODS.map(name=>{const row=observations[name];return `${name}: ${row.count}回 / #${row.sequence} / ${row.outcome}${row.point?' / 経緯度 '+formatPoint(row.point):''}${row.input?' / '+row.input:''}`;});
  table.textContent=[`状態: ${active?'診断中':'未開始'} / 入力: ${lastInput}`,`再描画実験: ${requestRenderAfterPick.checked?'ON':'OFF'} / 要求 ${renderRequests}回 / ${renderOutcome} / gateなし`,`最後の通常クリック: ${lastClick?lastClick.x.toFixed(1)+', '+lastClick.y.toFixed(1):'未取得'}`,...rows,`最後のpick座標: ${formatPoint(lastPoint)}`,pure,'公開診断の許可項目（viewStabilityは最後の描画時点）:',JSON.stringify(allowed,null,2),'純粋判定のpayloadは直近overlay変換引数です。表示のcommit成功は別確認。'].join('\n');
 }
 function finish(){
  if(disposed)return;active=false;cancelSynthetic(false);cancelPaint();tracker.clear();for(const remove of listeners.splice(0))attempt(remove);
  const proto=C.Scene.prototype,conflicts=[];
  for(const item of installed){const descriptor=Object.getOwnPropertyDescriptor(proto,item.name);if(descriptor?.value!==item.wrapper){conflicts.push(item.name);continue;}attempt(()=>Object.defineProperty(proto,item.name,item.descriptor));if(Object.getOwnPropertyDescriptor(proto,item.name)?.value!==item.descriptor.value)conflicts.push(item.name);}
  if(conflicts.length){notice='他の変更との競合により完全復元を確認できません: '+conflicts.join(', ')+'。追加操作を止めてください。';paint();return;}
  installed.length=0;disposed=true;panel.remove();if(window[SLOT]===api)delete window[SLOT];
 }
 const api={accept(next){if(disposed)return;currentPayload=next;queuePaint();},finish};window[SLOT]=api;paint();
}
