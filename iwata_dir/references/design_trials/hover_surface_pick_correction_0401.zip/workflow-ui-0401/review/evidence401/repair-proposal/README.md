# 0.40.1 局所修復の source 提案

この directory だけを編集・検査した。repo、旧 0.40 ZIP、stage、接続中のタブは未変更。主担当が差分をレビューして新 0.40.1 stage へ適用するための成果物である。

| 提案ファイル | 新配布先 |
|---|---|
| `main.js`, `surface-pick.js`, `surface-session.js`, `hover-controller.js` | `source/cesium-probe/src/` |
| `test.mjs`, `hover-test.mjs`, `surface-session-test.mjs` | `source/cesium-probe/` |
| `hover-lab401.html` | `review/hover-lab401.html` |

生成された scene3d は主担当が source から既存 build で生成する。`validation/` はこの提案の検査 mirror であり、配布用複製ではない。`prepare-proposal.py` は旧 0.40 source と置換の一意性を確認し main/surface-pick の提案を再生成、`prepare-lab401.py` は旧 lab を変更せず新 lab を生成、`prepare-validation.py` は提案内の test mirror を組み立てる。

検査用コマンド（PowerShell）：

```powershell
C:/Miniforge3/python.exe ./prepare-validation.py
$env:BJP_CESIUM_DEPENDENCIES='C:/Users/genia/AppData/Local/Temp/balloon-design-380/cesium-probe/node_modules'
& 'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' ./validation/test.mjs ./mock-validation401.json
```

`hover-test.mjs` の旧検査は削除せず、mock Scene に公開 `requestRender()` を追加しただけ。新規検査は `surface-session-test.mjs`。詳細な観測・固定 SDK 行番号・設計判断・未確認は `SDK-EVIDENCE401.md` に記録した。
