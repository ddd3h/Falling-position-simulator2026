# 0.40.1 surface read 修復提案：根拠と受入境界

2026-09-27。これはローカル提案であり、旧 0.40 ZIP・実接続・repo を変更していない。SDK の私有状態を読んで原因を考察したが、修復は公開 API だけを使用する。

## 観測した問題と分離

主担当から受けた実写真上の観測（この担当による独立再操作ではない）：

- 人間の物理マウスでは A/B/禁止領域とも輪郭上で名称が出て、面内では出なかった。禁止領域の中でも A/B の輪郭上では名称が出て、輪郭の交点では二名称が一吹出しに入った。
- 同じ A 50% 内側の client 点 `(892,605.8)` において通常 click は `(141.7528326,43.3223373)`、同じ点への合成静止入力では `(141.8170974,42.6167201)` を返した。双方 sampleHeight は有限。後者の純粋解決結果は outside95。camera の有意変化はなく readiness=true。
- 輪郭表示を OFF にして drillPick を通らなくすると、同じ地点への合成入力を二度続けても `(141.7528329,43.3223342)` が得られ、A の面名称が表示された。
- 輪郭 ON でも、局所診断に「drillPick 後 requestRender」の実験を入れると二度連続でほぼ同じ正しい位置と A 名称が得られた。接続試行は 1 回のまま、camera の有意変化は固定。これは原因切分け用の実験で、下記の次 frame 待機を持たないため恒久修正の確認ではない。

これらは、輪郭の識別と純粋な面内判定自体は機能し、次回の地表位置逆投影が screen pick によって不整合になる説明と整合する。B が線のみになる表示仕様差だけでは、A の面内失敗を説明できない。誤った位置に基づく outside95 を「領域外」とユーザーへ渡してはならない。

## 読んだ固定 SDK

CesiumJS 1.145.0（実 package.json で確認）。読取元：

`C:/Users/genia/AppData/Local/Temp/balloon-design-380/cesium-probe/node_modules/cesium/Build/CesiumUnminified/index.js`

以下は上記の非圧縮 bundle の 1-based 行番号。生成元名は bundle 内の source marker による。最新 upstream 一般論ではなく、今回配布と同じ固定 SDK の実装を根拠とする。

| 行 | 読取事実 | 本件への含意 |
|---|---|---|
| 233293–233334 | `pickBegin` が defaultView を用い、9×9 等の狭い screen culling volume で描画 command を実行する | drillPick も通常の defaultView に作用する |
| 233335–233372 | `pickEnd` は context.endFrame、screen pick 終了時に通常 render を要求しない | 静止した requestRenderMode では前の通常 frame に自動復帰する保証がない |
| 233692–233708 | drillPick は `this.pick` を繰り返す | 一回の名称線読取が複数の pick pass を実行する |
| 232932–232973、233009–233124 | 可視集合の near/far を使い `view.frustumCommandsList` を更新する | 狭い pick pass と通常の view の depth 解釈が異なり得る |
| 233511–233596 | pickPosition は defaultView の pick depth と同 view の `frustumCommandsList` の near/far を組み合わせ逆投影する。通常の非半透明深度経路では新たな通常描画はしない | depth と frustum の整合が必要。片方だけ以前の意味で使うと座標が変わり得る |
| 233175–233182、250757–250761 | pick depth は view に属し、pass 条件次第で更新される | 「深度 texture は絶対に変更されない」とまでは断定しない。問題は pass 間の状態の整合 |
| 233807–233865、234091–234114 | sampleHeight の ray 経路は別の offscreen view を使い、終了時に defaultView へ戻す | sampleHeight を維持し drillPick だけ除いた A/B 試験と整合 |
| 251681–251689、251771–251824 | update は描画を省いた frame でも位置 cache を無効化する。requestRenderMode で shouldRender=false なら通常描画と postRender はない | pickPosition の一時 cache の効き方に修正を依存させられない |
| 251791–251823、251830–251832 | request flag を frame 冒頭で消し、shouldRender の終端で postRender、requestRender は flag を立てる | postRender 後の microtask で次の pick を行い requestRender すれば、次 frame の要求として残る |
| 251815–251823 | render は tryAndCatchError で囲まれ、失敗後でも postRender が発火し得る | postRender 一つだけでは成功 frame の保証にならない。renderError と組み合わせる |
| 254422–254458 | 既定 render loop は widget.render 後も次の RAF を予約する（停止／破棄／例外を除く） | 次の request flag は次 RAF で扱える。提案側から連続 render loop を作る必要はない |
| 290177–290194、290691–290712 | Viewer の既定 LEFT_CLICK は scene.pick、LEFT_DOUBLE_CLICK は entity tracking を行う。登録は表示 widget の有無と別 | 独自 click 読取を持つ host は未使用の両 action を解除し、session 管理外の screen pick を避ける |

SDK 内部のどの texture／uniform の組が実写真上で不整合になったかを GPU デバッガで確定したわけではない。逆投影前後の公開結果、screen pick の ON/OFF、および再描画の ON/OFF が根拠であり、修正は通常 render で整合を取り直す設計とする。

## 修復案の責務

1. `surface-session.js` は Viewer/provider を所有せず、公開 API 読取りの順序と取消だけを所有する。一連の「位置取得→現在 mesh の高さ→必要なら線 pick」を同期 transaction とし、click と hover が同じ queue を使う。
2. `pickedNameBoundaryIndices` は成功／例外にかかわらず finally で session を dirty にし、公開 requestRender を要求する。次の位置取得は次の正常 postRender の後まで待つ。private view／frustum／pick cache には書かない。
3. 今回位置と名称は screen pick **より前**の整合した位置から計算済みなので、その結果は表示できる。dirty を表示の可否判定に混ぜると毎回自己取消になるため分離する。
4. postRender の中で read を直接実行せず、microtask に移す。postRender callback から描画処理へ再入しない。空 queue と clean read は新しい requestRender を発行しない。
5. 失敗 frame の postRender では解除しない。renderError で待機 read を拒否し、新しい read も拒否する。次の正常 frame で復帰する。pause、破棄、drag、wheel、blur、snapshot 変更、有意な camera 変更で対応 read を取り消す。取消 job は queue から即時除去する。
6. hover は静止待ち後に readiness を評価し、非同期結果が古い pointer／snapshot に属していれば捨てる。初回 readiness が足りない静止点は、host の ready 通知で再試行できる。click は新しい gesture と競合すれば取り消す。
7. Viewer が登録する未使用 LEFT_CLICK／LEFT_DOUBLE_CLICK を解除する。独自 click tracker、camera drag／wheel の handler、クリックの readout は保持する。

`pickedNameBoundaryIndices` の session 未指定呼出しは既存互換のため requestRender だけを行う。これは連続した位置 read の保証を持たない。本修復の production と新 lab401 は必ず同じ session を渡す。今後 screen pick を追加する場合も同じ host session の transaction／barrier に参加させる必要がある。

## 検査と未確認

- proposal 内の test mirror で固定 SDK を使用し、旧全項目と新しい API 順序 mock を実行。現結果は `mock-validation401.json`。これは現実の GPU bug を再現するテストではなく、「screen pick が位置状態を壊す」mock を用いた app の順序・取消規則の反例テストである。
- 同一点の連続読取、dirty 時の SDK 呼出抑止、正常 frame を挟んだ復帰、click/hover の競合、drillPick 例外時の finally、abort/破棄、renderError 後の postRender、静止 point の readiness 復帰、同期／非同期 controller の両経路を確認する。
- 新 `hover-lab401.html` は実際の public WebGL pick と同 session を使う人工形状試験。旧 lab400 は当時の診断として保持し、401 の証拠に読み替えない。
- この担当は live Google を操作していない。新 host の実写真上で、線 ON の面内を繰り返し hover、region 重なり／穴、hover 直後 click、drag/wheel、停止復帰／表示更新を別途確認する必要がある。物理マウスでの確認と合成 PointerEvent の確認は別に記録する。
- requestRender は provider の作成・接続・認証を行わない。ただし正常描画が既存 tileset の通常 load 判定を進める可能性はあり、HTTP 回数／課金回数ゼロとは主張しない。
