# 2D 復帰時の CSS 隔離・再取得案 — 独立批評

2026-09-27 / document_audit400 / 未適用案の読み取りレビュー。

## 判定の対象と限界

対象は `map-return-proposal` の 21:26 修正版である。controller / mount の全文、inline CSS、生成 helper、app/index の変更部分を実読した。既存 stage の Leaflet vendor CSS、app の地図移動・resize・3D 往復、style の地図・3D 関連を補助的に読んだ。repo / stage / ZIP / 接続画面は変更していない。本票は試験の実行・実画面の観測票ではない。後続の試験結果と実画面確認は別に扱う。

現在案は、観測された「Leaflet の必須 computed style が失われている状態」を正常な地図として使わせず、局所 CSS だけを読み直すための限定修復として妥当である。静的レビューの必須指摘は下記のとおり解消した。**CSS 適用喪失の発生原因・発生時点を確定したという判定ではなく、地図全体の正しさを computed 検査が証明するという判定でもない。**

## 反例から修正した点

| 反例 | 最終案の対応 | 読み取り上の判定 |
| --- | --- | --- |
| CSS を head 末尾へ追加すると、元の vendor → app の順序が逆転し、地図が出てもアプリ側の上書きが失われる。 | `old.parentNode.insertBefore(next, old.nextSibling)` とし、旧 link の直後で代替する。旧 link は replacement 単独の computed 確認と再配置の成功まで保持する。 | 解消。復旧が別の表示仕様を導入しない。 |
| 取得開始時に中心・zoom を保存すると、待機中に「全域」や候補を操作した利用者の新しい視点を完了時に打ち消す。 | `restore(capture())` を適用直前に実行する。 | 解消。待機時間中の最新の選択を保持する。 |
| 隔離用 `overflow:hidden!important` が、本来の map overflow の破損を覆い隠し、自分の防御で自分の検査を通す。 | 同期 computed 読取り中のみ `data-map-style-probe` を付け、clipping の対象から除外する。pane の visibility 隔離は保持し、finally で属性を復元する。 | 解消。検査と隔離の責務を区別している。 |
| `pagehide` で常に destroy すると、BFCache から戻ったページの controller が永久 disposed になる。 | persisted の pagehide は suspend、pageshow は ensure。通常破棄だけ destroy。 | 解消。自動試行回数もページ内で保持される。 |

自動試行をページ内一回に制限し、以後は失敗時だけ明示手動を残す方針を支持する。「ページ内合計二回で永久停止」は採用しない。資源が後で修復されても利用者が再試行できないためである。手動は一クリック一要求、inflight 中 disabled、8 秒 timeout、並列・再帰 retry なしという制限が目的に合う。健康時の ensure / retry は CSS 取得を起こさない。

## 実装の範囲は適切か

- 成功判断は link の load イベントや `sheet` の有無だけでなく、replacement を単独適用した状態の computed を読む。旧・新の部分的な CSS が補い合って成功と見えることを避けている。
- map 外の probe と実 map の pane / 存在する tile を組み合わせ、タイルが未生成であることや画像サーバの失敗を CSS 失敗とは数えない。これは CSS 再取得の目的に合う。ただし全スタイル・全タイルの完全性検査ではない。
- 隔離 CSS を index に inline で置くため、保護自体が追加 CSS 取得に依存しない。map の display を消さず、寸法を保持して pane と controls を隠す。壊れた図を通常状態として提示しない。
- controller は iframe / Viewer / provider / key / storage に接触しない。取得 URL を既存の同一 origin・protocol の `/forecast/vendor/leaflet.css` に限定し、任意 URL を受け付けない。Google 接続の再作成を含まない。
- resize は局所 CSS の実適用成功時に限定される。正常対照の往復が成立している以上、通常の 2D 復帰すべてへ追加 invalidateSize を入れる根拠はない。
- closeScene3d の変更は ensure の追加、初期処理の変更は mount と ensure、hover は guard が ready のときだけ読めるという限定変更である。

## 受入を閉じるための少数の観測

試験件数を増やすことより、同じ利用行為を最後まで成立させる確認が必要である。

1. 通常の初期 2D と 3D→2D を、海岸線または既知の道路、分散・禁止領域の重なりで読む。pan / zoom 後もタイルの大きさ・継ぎ目・地理的位置が連続することを実画面で確認する。3D の要素数や接続試行数だけを代替証拠にしない。
2. 別 lab で vendor CSS を故障させ、壊れた地図が隔離され、自動一回で直る場合は手動なしで戻ることを確認する。復旧不能時は notice と手動のみが残り、繰返し自動取得しないことを確認する。接続中の実画面を故障注入に用いない。
3. 取得待機中に外側の視点操作を一つ行い、成功後に最新意図が保たれることを確認する。BFCache の persisted suspend→resume と遅れて届く load の境界は、限定試験または lab の観測で区別する。

初期正常・故障隔離・局所復旧が成立しても、「今回の原不具合が再発しない」や「全地形・全画面を受入済み」とは書かない。CSS 喪失原因が未確定であること、復旧後の地図描画をどこまで観測したかを記録する。

## 読み取り版の SHA-256

| path（map-return-proposal 以下） | SHA-256 |
| --- | --- |
| map-style-guard401.js | 70f53849f37fa8b6bf5b48ec13cc8afbf7a46caf61c6c09cc0033d021b2fc8f6 |
| guard-inline.css | ca3e454d457db5da9df4091e6dfe071924aa7ff5153f47f8aaf243795e4bdc0f |
| prepare-proposal.py | 3305aeaab52ac6190f5231f959c8b75c590ffe83e3c548dfaf995e0b86210346 |
| files/forecast/app.js | 946f89539b0f4864520b72332726a4261dbff1800ea971a4d10fa4596cf23dbe |
| files/forecast/index.html | 32bf2cceefb1b52cc609cc73182dcef77982bf389549d3812d1d0f77e8438709 |

この票は上記版の静的批評である。候補が変更された場合は差分を再読する。実際の試験成功、最終採用、最終 ZIP/Git 保存は本票の確認範囲に含めない。

### 追加の読み取り

21:31 の `test-map-style-guard401.cjs` 全文を読んだ。健康時取得ゼロ、自動一回、手動の single-flight、最新視点、computed 不足、timeout 後の遅延完了、cascade 順序、実 pane のみの破損、隔離 overflow の偽陽性、タイル未生成、BFCache と実離脱、取得先制約を反例として扱っている。今回の限定変更に対応した確認内容であり、試験数を目的とする増設は不要と判断する。この担当は試験を実行しておらず、mock による lifecycle / CSS semantics の確認と、ブラウザの実 CSS 適用・地理描画の確認を分ける注記も維持されている。

### 最終追加候補と結果票の限定確認

最終 `README.md`、`verification-receipt.json`、`proposal-receipt.json`、`files/review/map-style-lab401.html` を全文実読した。確認済み module / app / index の byte は前票から不変で、verification receipt が列挙する 6 hash は現実体と一致した。担当が実行した 17 ケース / 104 assertion と構文 3 件の成功という結果票を確認した。この担当による再実行ではない。receipt SHA-256 は `d889a2f4bb2db3525359301ba36331e41b9cc9fa3e48611a050d67294fdbdc92`、README は `14015eea72f6f7de0014b7f3369f10202536363f7b33540d7abc3aa1f5abe5a7`。

lab は本体 module と固定 vendor Leaflet を使い、Canvas に人工タイルを描く。ネットワーク地図・Google・任意 URL を用いず、故障操作は lab 内に限る。実 pane のみ / 実 overflow のみの競合と CSS 無効化を分け、故障解除後の「既に healthy なので追加取得ゼロ」も観測できる。正常時に line / landmark / tile の連続性を人が見られるため、状態数値だけの自己充足に陥りにくい確認構成になっている。本文も元不具合の原因未確定と、実地理表示・本体往復の未確認を維持しており、追加の必須指摘はない。

lab を実際に操作した結果と本体の往復視認は依然として主担当の別証拠であり、この追記はそれらの受入を代行しない。
