# 0.40.1-r1 内容 tree 復旧補助の独立限定批評

2026-09-27 / document_audit400。prepare / restore の全文を実読した。実行・stage・repo・旧 ZIP の変更は行っていない。外部参照、既存ファイル上書き、復旧内容の欠落に確認を限定する。

初稿 restore は、`HERE/overrides` 自体が package 外を指す symlink / junction になった場合、`root.resolve()` を許可境界として外部 source を受け入れる。leaf の `is_symlink()` ではこの反例を排除できなかった。担当へ修正を返し、最終案は local root と source の解決先の両方を package 配下へ束縛するよう改訂された。manifest 自体も同じ境界の確認後に読む。差分の再読で指摘の解消を確認した。

prepare は固定旧 ZIP の全体 SHA、832 path の一意性・Windows を含む path 安全性、symlink 属性、各 member の CRC 読取り・size・SHA を確認してから新規外部 output を作る。共通 byte 以外は旧 override として保持するため、r2 から削除された旧 file も失わない。restore は既存 output を拒否し、同じ package の検証済み入力から指定832だけを新規 directory へ構築し、最終の path / size / SHA を照合する。r2 固有 file の混入、内容 tree の復旧を ZIP byte 再現と称する記述は見当たらない。

この限定範囲で追加の必須修正はない。出力途中の失敗は成功とはならず、既存 output を再利用せず新規 attempt とする運用が必要である。合成試験の再実行・実 r2 の準備／復旧・最終 ZIP の照合は、この票の担当による確認に含めない。

| 読み取り最終ファイル | SHA-256 |
| --- | --- |
| prepare_r1_recovery.py | 0cce316844ba6f65d988347547a5fab430b29063901829478ed76f4a80c9d0c8 |
| restore_r1_tree.py | ff8abd552efe8c6c13ebd8cd55688060859378ed61018721cdb8106525deebb4 |

旧 restore `665a63c03c2939bd96ef97bbdd98b0706acdfe96b2833e249ba6b8aa48a57c6e` は指摘前の版であり、この最終判定を適用しない。
