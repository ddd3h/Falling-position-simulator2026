# r1内容tree復旧 helper の準備結果

これは外部提案の静的確認と合成試験であり、実r2の最終snapshot・配置・復旧はしていない。repo・old/new stage・原証拠・既存ZIPは変更していない。

| 提案ファイル | SHA256 |
|---|---|
| prepare_r1_recovery.py | 0cce316844ba6f65d988347547a5fab430b29063901829478ed76f4a80c9d0c8 |
| restore_r1_tree.py | ff8abd552efe8c6c13ebd8cd55688060859378ed61018721cdb8106525deebb4 |

`test_r1_recovery.py` の最終実行票は `selftest-20260927T124113999760Z/result.json`。Python構文読取、原ZIP832memberのCRC/size/SHA読戻し、合成832file復旧、r2-onlyの除外が成功した。既存出力等7種の拒否、外部override root拒否、各module16種の危険名拒否も通過した。試験用directoryは外部提案の配下に新規作成して保持し、削除は行っていない。

独立批評により、overrides directory自体が外部へ向いた場合の境界不足を修正した。root.resolveとsource.resolveの双方をr2境界と照合し、manifest自身も読込み前に同じ検査を通す。実junctionを作った試験ではなく、外部rootを与えた拒否とコードの限定再読で確認している。

document_audit400が修正差分と上表の最終hashを再読し、当該指摘の解消と限定範囲で追加must-fixなしを確認した。独立担当は試験を再実行しておらず、この判断は静的レビューに限る。

prepareは最終r2と原ZIPの比較から旧差分byteを外部の不存在directoryへ集める。restoreはr2内の固定共通byteと同梱旧byteだけで、外側の不存在directoryへ全832fileを復旧する。元ZIPの圧縮順・日時等は復元対象ではなく、ZIP全体SHAの再現とは呼ばない。追加の保存frameworkやネットワーク、Google接続、stageへの自動適用は含めていない。

rootが最終r2の内容変更を終えてからprepareを実行し、その出力をレビューしてr2へ配置し、restoreの全832照合を実行する。実際の差分数・新ZIP件数・実r2復旧結果はここでは未確定。配置後に共通fileを変更した場合は失敗にして止まるため、新attemptで準備からやり直す。
