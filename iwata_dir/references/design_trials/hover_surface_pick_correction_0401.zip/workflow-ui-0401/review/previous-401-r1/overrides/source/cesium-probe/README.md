# 写真3D操作模型 0.40.1

固定依存は CesiumJS 1.145.0（Apache-2.0）。Googleタイルをこの配布物へ保存していない。`licenses/`、生成先 `scene3d/CESIUM-LICENSE.md`、`CESIUM-ThirdParty.json` と `THIRD_PARTY_NOTICES.txt` を保持する。

## 0.40.1の位置読取りと再描画

現在のhostは `0.40.1-r1-surface-render-barrier`。旧0.40では輪郭の識別を終えた後、次の地理位置読取りがずれる反例が実写真で判明した。面の許容幅を広げず、通常描画・地理位置・輪郭探索の順序を修復する。後段の0.39/0.40の検査・観察は当時の履歴であり、新hostの成功へ読み替えない。

| module | 所有する責務 | 所有しないもの |
|---|---|---|
| `main.js` | Viewerごとに1個のsurface sessionを作り、hoverと短い左クリックを同じ読取り窓口へ渡す。snapshot/表示/移動/解除の取消を結ぶ | 科学モデル、干渉判定、再計算 |
| `surface-session.js` | 次の位置読取りを通常描画の完了まで待たせる。同期readerを順番に実行し、戻り値をPromiseで渡す | Viewer/provider生成、キー、名称の規則、描画済み名称の表示可否 |
| `surface-pick.js` | 公開pickPosition/sampleHeightで地理位置と現在mesh高さを読み、別に公開drillPickで既知の輪郭を識別する | SDK内部状態の書換え、楕円体による取得不能の代用、Google地物名 |
| `hover-controller.js` | 静止時間、pointerの世代、AbortSignal、非同期結果の表示寿命を管理する | カメラやsessionの生成 |
| `view-stability.js` | 公開カメラ姿勢の有意な変化と静止を判定する | 再描画完了や地物の意味の判定 |

一つの読取りでは、正常な描画後の地理位置を先に取得し、その場所の面と近傍の輪郭から名前を求める。drillPickの終了時は成功・例外とも `finally` で `afterScreenPick()` を呼び、sessionをdirtyにして公開 `requestRender()` を要求する。いま取得できた名前は通常の表示条件で示し、**次の位置読取りだけ**を通常描画の `postRender` まで待たせる。dirtyを名前の表示条件へ混ぜて自己取消を繰り返さない。

待機中の移動、表示/受領snapshotの変更、pause、破棄はAbortSignalと世代で古い仕事を取り消す。取消済みjobは待ち行列から直ちに除く。`renderError` は待機を棄却し、その失敗frameに続いて発生することがある最初の `postRender` を正常完了として扱わない。さらに後の正常描画で解除する。`destroy()` は待機とイベントlistenerを解放する。自動retryや新規接続はしない。

Viewer既定のEntity選択用 `LEFT_CLICK` と追跡用 `LEFT_DOUBLE_CLICK` は、この模型では使わず解除する。これらの内部pickがsessionを迂回しないようにするためであり、hostの短い左クリックによる帯区分読取りや、カメラのdrag/右操作/wheelは別に維持する。main/surface-session等は「表示だけ更新」の対象外なので、旧8400への任意requestRender実験と新hostの適用は区別する。

## 0.40.1の確認範囲（2026-09-27、有限の実写真確認まで）

| 対象・方法 | 確認できたこと | この票からは言えないこと |
|---|---|---|
| 新sourceの純粋試験 | `mock-validation401.json` の400条件成功。順序/取消/failed frameと既存意味判定を含む | GPU、写真mesh、物理マウスの成功 |
| 既存8400写真hostの局所実験・合成pointer | drillPick後requestRenderをONにし、同じ場所のA名を2回連続表示 | 次の読取り前の完了保証、恒久401の成功 |
| 同じ8400実験・利用者の実マウス報告 | Aと赤い禁止領域の面内で名称が出る。重なりは両名が一つの吹出しに出る | 恒久401、全地形・全操作での受入 |
| 新401人工WebGL lab・主担当CUA | 屋根でA＋領域を2回連続、穴ではAのみ、dragで退避、領域面OFFの屋根でAのみ | Google写真の深度や地物の適合 |
| 新401 standalone hostの人工背景・主担当CUA | 実装本体の屋根クリックで「経験輪郭50%内」。13描画要素、Google接続0 | 実写真上のクリック、連続hoverの全面受入 |
| 新401 forecast→3D受渡し・主担当CUA | 初回はchild ready未達、console errors 0。未接続のまま再読込後payload受渡し成功。Google接続0 | 初回失敗の原因解明、写真接続・読取りの成功 |
| 新401恒久hostの実写真・主担当CUA | 8401で写真mesh・57描画要素を視認。A面内のクリックで「クリック地点 · 注目 A 標準案 · 経験輪郭 50%内」。2D→3D往復後も57要素・接続試行1を保持 | 全視点・全地形、HTTP総数や月の請求数 |
| 同じ新401 host・利用者の実マウス報告 | 青いA面と赤い領域面を交互に指して面内表示が続き、名称の反復もない | 新hostの穴・非表示を実写真で確かめた記録ではない。これらは人工labの範囲 |
| 別作業コピーの独立test→build | 固定Cesium 1.145.0、400条件成功。scene3d全417member差分0、shared resolver一致、stage/source不変 | ブラウザー、写真、物理マウス、通信/課金の確認ではない |

観察は主担当のCUA記録と利用者の報告を分けて要約した。このREADMEの編集担当が実写真を再操作した記録ではない。独立再生成は `independent-rebuild401-receipt.json` のtest→build票に帰属し、人工fixtureを新たに生成した票ではない。後のREADME・source-inventory改訂は実行codeを変えず、その差分を別に照合する。Google画像・tile・キーを保存せず、通常描画による通常tile取得までゼロとは主張しない。

旧8400の局所診断は終了し、差し替えた公開APIは復元した。主担当が旧配信overlayを元のbyteへ戻し、診断2fileをhash照合付きで除去した。旧接続は保持しており、新401の恒久hostと同一の動作版にはしていない。新401の実写真上の穴・非表示は未確認として残す。

## 再生成

このディレクトリで `pnpm install --frozen-lockfile`、`pnpm test`、`node make-fixture.mjs`、`pnpm build` を実行する。packageManagerはpackage.jsonに固定している。buildは `../../scene3d/` へ入口・CSS・src・人工fixture・固定Cesium vendorを複写し、build-inventory.jsonを作る。node_modulesは配布対象ではない。

今回の担当環境では依存を再取得せず、`BJP_CESIUM_DEPENDENCIES` に既存の固定1.145.0を持つnode_modulesディレクトリを指定して、`node test.mjs` / `node build.mjs`（既存の人工fixtureを保持） を実行した。通常の展開先ではこの変数を省略し、上記lockから再生成する。

模型のルート `workflow-ui-0401/` をローカルHTTPで公開して `forecast/` から開く。file://ではmoduleを実行できないためローカルHTTPが必要。独立の `scene3d/index.html?probe=synthetic` は人工の平面・屋根・段差と点/線/穴付き面の機構試験で、Googleへ接続しない。Googleの提供精度・実写真への適合を証明するfixtureではない。

## 引き継いだv2受渡しと表示

親2Dが候補・結果・選択・可視性・注目の正本。sceneは全catalogと表示geometryを受け、再計算しない。概要のgeometryは可視で計算済みの候補だけ。詳細は現在候補と選択IDだけで、概要の可視フラグがfalseでも当該選択群を描く。詳細から候補/可視状態は編集しない。

概要からの操作は `bjp-scene3d-intent`、schema `bjp-scene3d-v2`、baseSnapshotId、requestId、action `focus` / `visibility`、candidateId、visibilityの場合のvalueで送る。親の確定snapshotとackを待つ。staleや応答未確認で自動再送しない。hidden focusを自動表示せず、塗りなしの理由を明記する。親子一覧で短い遅延値を使い、詳細の単独候補には親を含むfull labelを使う。

経験輪郭の面は親が作る `contour-band` を受け取る。50%内・50–90%間・90–95%間は外周と穴で区切る。OFFになった輪郭をbandの穴の線として描き直さない。確率密度や校正済み予報確率の表示ではない。分位面と禁止領域面は別toggle。禁止色と詳細点の干渉外縁は親のlevel色を使う。

新しいsnapshotだけを理由にカメラをfitしない。初回接続と明示的な地域ボタンはfitする。保存視点は親のcollectionKeyで判定し、表示・注目だけの変化では保ち、結果・領域・選択集合の本質的変更で解除する。埋込み時の出口は親の一つ。2Dへ戻ることは接続解除ではない。

## 接続と表示更新

Googleは有効な結果を受け取り、ユーザーがキーを入力して接続を押すまで呼ばない。キーは入力欄から読み取った直後に空にし、module実行中だけ使う。ストレージ・結果・診断・ログへ保存しない。接続中の二重開始、自動再接続、自動retryを行わない。rootRequestAttemptsは当該iframe内の明示helper開始数であり、HTTP総数・請求確定数・月残量ではない。

同一iframeを保つ2D往復はpause/resumeで、既存Viewer/tilesetを保持する。批評の最初の表示成功を理由に接続を解除しない。ページ/親ページ/iframe再読込、明示解除、終了は接続保持と異なる操作である。

footerの詳細にある「表示改修の確認 → 表示だけ更新」は、同じviewerへ `src/overlays.js`、`src/catalog.js`、`style.css` の新しい版だけを適用する。旧DataSourceを残したまま新しい定義・DOMを準備し、準備失敗時は適用しない。直近の旧layerを保持して描画失敗時の復帰先にする。これらの操作はGoogle helperやhost再読込を呼ばない。

更新対象外はmain host、protocol、provider、HTML入口、補助module、Cesium engine、親forecastコード。対象外のコードをファイルへ保存しても既存liveへ反映されたとは扱わない。キーを保持する公開global handleや、任意URLからのmodule読込口は用意していない。適用版は `SCENE3D_DIAGNOSTICS.presentation`、accepted snapshotとrenderedSnapshotIdは別に記録する。

## 検査の範囲

`test.mjs` はキーなしの純粋検査。v2 catalog/detail/hidden、bandの穴とOFF境界、色と透明度、親のcollectionKeyによる視点、絶対intentのcatalog、overlay準備/差替え/rollback、認証値の非保存と安全なエラー、fixtureのSSEを確認する。0.39第7票は167条件成功。WebGL/写真mesh/利用目的への全般的受入ではない。

`runtime-check.cjs` は担当が初期に行った独立Playwright試験の方法を残す履歴資料である。現在の作業は主担当から「ブラウザー操作はCUAのみ」と指示されており、この経路を再実行しない。実施済みは9条件の局所成功後にiframe待ち条件で停止した版まで。Google0であっても、これを主担当CUAや最新修復後の実物成功として混同しない。

新しい実物確認と受入は主担当のCUA記録を参照する。最初の独立画像ではmesh/点のあとに線と面が準備されたため、最新hostはDataSourceDisplay.readyに応じた準備状態を表示する。ready自体は地物の判読性の証明ではない。

## 近接地点の読取り

短い左クリックで、確定した表示版の注目候補の輪郭区分を地図外の一行へ示す。全体の経験輪郭の区分であり、局所の落下確率密度ではない。公開pickPosition/sampleHeightで現在のmesh位置を確認し、overlayを高さの根拠から除外する。取得不能を95%外にしない。shared境界、穴、非表示帯、詳細/hidden focusを区別し、面をOFFにして読むときはOFFと併記する。

表示変更で古い読取りと小印を消す。drag/右操作/修飾/長押しは読取りにせず、通常の移動操作を保つ。このhostのクリック機能・band-readout.jsは限定表示更新の対象外であり、機能修復のためliveを無断で再読込しない。

表示差替えの失敗時は、形状だけでなく一覧・選択数・説明・表示receiptも旧版へ戻す。acceptedSnapshotId/receivedSnapshotは新受領のまま別に持つ。旧表示と新受領が違う間の操作を止め、未反映を伝える。候補のpendingは入力が既存結果へまだ反映されていない状態として行に表示する。

## 保存前の検査票と観察段階（0.39）

最終sourceの純粋検査は scene-unit390-r7.json の167条件成功。独立担当のクリック読取り反例は weather-band-readout390-evidence/checks-after.json の21条件成功で、修復前の票も保持する。前者は実装側の条件検査、後者は独立したsource反例の再検査であり、いずれもGoogle接続や実meshの視認を含まない。

主担当のCUAでは、読み込み済みの人工3D hostで屋根上の50%内、地面の50–90%間・90–95%間・95%外、空の取得不能を別々に確認し、小印と読取位置の一致を観察した。表示module更新後の人工背景・配置・保存視点ボタンの保持と読取りリセット、pan dragで読取りが勝手に変わらないことも主担当の有限観察である。当時のhostには最新の「クリック地点」接頭辞が未適用だったため、最新hostの全変更をこの観察で検証済みとは扱わない。最後の修飾キー反例の修復は上記167/21条件へ帰属する。Google写真mesh上の適合・実接続数・後続受入は主担当の別記録へ戻す。

保存前の独立再生成は、元のsource/runtimeを置換せず、別作業コピーで固定依存を用いて test → make-fixture → build と全runtimeのbyte照合を行う。結果は reviews/scene-rebuild390-final.json、各コマンドlog、scene-rebuild390-test.json に分離する。この再生成はGoogle無し・ブラウザー無しであり、実表示の追加証拠ではない。source-inventory.jsonは本READMEを含むsourceの全ファイルを記録し、自己だけを除外する。旧0.38由来のinventoryは reviews/source-inventory390-from038.json に元byteのまま保持する。

## 詳細カードの修復（r8）

主担当の同一Google接続での批評を受け、詳細欄を操作のない対象カードへ変更した。概要用の可視チェックとdisabled候補ボタンを外し、候補色・full label・選択 n/N 着地点を示す。選択0を保持し、pendingは前回結果であることを伝える。概要の可視操作、注目、bandLegend、geometry、main/provider/HTML/CSSは変更していない。

第8票 scene-unit390-r8.json は179条件成功。概要の可視状態に左右されない詳細表現、0/少数選択、遅延子の名前、pending、操作callbackなし、受領payload不変を追加確認した。これはキーなしsource検査であり、修復後のGoogle実画面は主担当の後続観察へ帰属する。catalog.jsは「表示だけ更新」の対象で、既存host/providerの再読込を必要としない。

r8変更前のsource/runtime指紋と旧inventoryは reviews/scene-stage390-r8-before.json と reviews/scene-r8-before/ に保持。新しい独立作業コピー rebuild390-r8/ の再生成・byte照合は reviews/scene-rebuild390-r8.json へ記録し、前回scene-rebuild390-final.jsonを上書きしない。

## 名称のホバー表示（0.40）

面・輪郭の識別をクリック読取りとは別に行う。マウスまたは hover 対応ペンを約 260 ms 静止すると、描画済み snapshot の分位面・指定領域面の名称を表示する。非注目候補の輪郭しかない場合も、線の 9×9 px の pick 範囲で候補名を取得する。領域面を OFF にしても境界線が ON なら、その線直近に限り領域名を出す。点・経路・支持境界・Google 地物名は対象外。分位帯を同じ候補名で重複表示しない。候補 1 件と優先領域 1 件を先に割り当て、最大 2 名＋「他 n 件」。priority は親から受けた並びの優先順位であり科学的な危険度へ再解釈しない。

host は hover-controller.js の listener 一組を所有し、hover-labels.js は対象と可視状態から名前を解決する。surface-pick.js はクリックと共通の public pickPosition / sampleHeight を使い、overlay・クリック小印を mesh 高さの根拠から除く。空や深度取得不能へ楕円体を代用しない。輪郭の公開 drillPick は上限を指定せず既知の表示 Entity の contour と region の境界線だけを使う。Google の名前・metadata は読まない。カメラ操作等による通常 tile 取得まで 0 と主張しないが、hover は provider/root helper を生成しない。

tooltip は textContent、pointer-events:none、画面端で反転・内側へ収め、名称を折り返す。drag、button、wheel、修飾キー、カメラ移動、leave、blur、スクロール、pause、受領/表示更新、rollback、接続解除で消す。表示準備中または受領と描画 snapshot が違う間は出さず、新しいカーソル移動後の静止で読み直す。表示を動かさないまま常設する情報ではなく、既存クリックの小印・区分欄は書き換えない。接続やカメラは新規生成しない。

hover-test.mjs は上記の純粋な反例と controller のイベント/タイマー寿命、文字列の HTML 非解釈、public surface 失敗と contour-only pick を検査し、test.mjs の既存条件とともに実行される。253 条件の初版成功は非 WebGL の source 検査。斜め視点の地物遮蔽・重なった線・画面端と長い名称の見え方は主担当の CUA で別途確認する。実写真における受入は人工形状の成功から一般化しない。
2D 側も同じ意味で名称を読むため、build.mjs は pure resolver の配布版を模型ルートの shared/hover-labels.mjs と shared/band-readout.mjs へ同期生成する。前者の相対 import 拡張子のみ .js → .mjs へ変換する。3D は src/ の同じ正本から生成する。2D は shared/ を import し source/ を実行時依存にしない。shared 生成物を独立に編集しない。scene3d/build-inventory.json の外にあるこの 2 ファイルは再生成照合票で別に byte 比較する。
第 2 巡の独立批評は「見えている領域境界の名前が読めない」「極端に長い名称の末尾が無言で切れる」を指摘した。境界線の対象を contour と region に揃え、面内部の不可視判定とは分離した。無言のクリップを撤去し、全文折返しでも地図の高さに収まらない場合だけ明示的な中間省略で先頭と末尾を保持する。全文は aria-label に保持する。有限表示領域のため無制限の全文を同時表示できないという限界は残り、長名の区別に効くかは実物で別途検討する。第 2 票は 261 条件成功（既存 179、追加 82）。

再生成初回は make-fixture.mjs が外部依存指定を未対応だったため、別コピーで Cesium import が失敗した。make-fixture を test と同じ BJP_CESIUM_DEPENDENCIES 経路に揃え、固定依存から生成可能にした。旧失敗ログを保持し、人工形状の式・値と Google 非利用は変えていない。
## 0.40当時の記録：実物で停止した静止判定の修復（r3）

261 条件の source 試験後、主担当の人工 WebGL lab で tooltip が一度も出ない欠陥を発見した。dataSourceReady は true だったが、SDK の moveStart 1 / moveEnd 0 のまま moving が続き、公開 camera の up/right に 10^-16 程度の差が観察された。r2 は moveEnd と frame 間の完全一致に依存していたため、視認上は静止した状態も読み取れなかった。純粋テストの成功と再生成一致を実物完成の証拠にはしない。

view-stability.js は公開 positionWC / directionWC / upWC / fov / aspect を有意差の基準から比較する。位置 1e-5 m・単位方向/画角 1e-10 を超える累積変化を移動とし、最後の変化から 260 ms の静止で読取りを許す。基準を微小差ごとに更新しないので、遅い移動も蓄積して検出する。これは数値ノイズの許容であり、物理量や軌道精度の許容誤差ではない。SDK moving は診断へ残し gate にしない。dataSource の準備、snapshot 同一性、pause、更新中/失敗、public mesh 取得条件は保持する。破棄時にtrackerを消去し、frame変化と読取り直前の両方で観測する。

lab 限定の先行修復では、主担当が current mesh 上の候補 A と穴つき領域の 2 名を DOM で確認した。その後同じ tracker を純粋 module として production source / lab へ共用した。r3 は 340 条件成功（前回 261 + 安定判定と controller 結合の 79）。数値 jitter、SDK moveEnd 不在、累積 slow motion、回転・roll・画角・viewport、invalid pose、解除・再静止を確認する。

実 Google の loaded r2 は主担当が保持中であり、ディスク r3 へ保存・buildしても適用されない。reload / 再接続 / 限定表示更新を勝手に行わない。hostRevision 0.40.0-r3-view-stability を持つ新しい無キー host の確認は主担当の別観察へ帰属させる。Google renderer の微小差・連続描画そのものが解消したとは主張しない。