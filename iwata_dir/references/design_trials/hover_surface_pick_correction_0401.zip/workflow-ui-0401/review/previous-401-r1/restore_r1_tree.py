"""Restore the 832-file 0.40.1-r1 content tree, not the original ZIP bytes.

Run from the r2 package's review/previous-401-r1 directory. The output must not
exist. All inputs are contained in this same extracted r2 package.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,shutil
HERE=Path(__file__).resolve().parent
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def safe_name(name):
    p=PurePosixPath(name)
    parts=name.split('/')
    reserved={'CON','PRN','AUX','NUL'}|{f'{s}{n}' for s in ('COM','LPT') for n in range(1,10)}
    if not name or p.is_absolute() or any(c in name for c in '\\<>:"|?*') or any(ord(c)<32 for c in name) or any(x in ('','..','.') or x[-1:] in (' ','.') or x.split('.')[0].upper() in reserved for x in parts):raise ValueError('Unsafe member name')
    return p
def file_below(root,name,package):
    safe_name(name);raw=root/name;resolved=raw.resolve()
    boundary=package.resolve();local_root=root.resolve()
    if not local_root.is_relative_to(boundary) or not resolved.is_relative_to(boundary) or not resolved.is_relative_to(local_root) or raw.is_symlink() or not raw.is_file():raise ValueError('Missing or escaping source: '+name)
    return raw
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    r2=HERE.parents[1]
    if HERE!=r2/'review/previous-401-r1':raise ValueError('Keep the packaged directory layout')
    manifest=json.loads(file_below(HERE,'manifest.json',r2).read_text(encoding='utf-8'))
    if manifest.get('format')!='bjp-r1-content-tree-v1' or manifest.get('expected_files')!=832 or manifest.get('original_zip_sha256')!='944d664adbd8a8a91fb6cb81095f48fee00b189e12a62fa36ffa79720b3ef8da':raise ValueError('Unexpected content manifest')
    rows=manifest['files'];names=[row['path'] for row in rows]
    if not (len(rows)==len(set(names))==len({n.casefold() for n in names})==832):raise ValueError('Wrong file count or duplicate path')
    planned=[]
    for row in rows:
        name=row['path'];safe_name(name)
        if row['source']=='r2-common':source=file_below(r2,name,r2)
        elif row['source']=='r1-override':source=file_below(HERE/'overrides',name,r2)
        else:raise ValueError('Unknown source kind')
        if source.stat().st_size!=row['bytes'] or digest(source)!=row['sha256']:raise ValueError('Frozen source differs: '+name)
        planned.append((name,source))
    output=a.output.resolve()
    if output.exists() or output.is_relative_to(r2.resolve()):raise ValueError('Output must be a new directory outside the r2 package')
    output.mkdir(parents=True,exist_ok=False)
    for name,source in planned:
        target=output/name
        if not target.resolve().is_relative_to(output):raise ValueError('Output path escaped')
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    actual={f.relative_to(output).as_posix():f for f in output.rglob('*') if f.is_file()}
    if set(actual)!=set(names):raise ValueError('Restored path set differs')
    for row in rows:
        file=actual[row['path']]
        if file.stat().st_size!=row['bytes'] or digest(file)!=row['sha256']:raise ValueError('Restored bytes differ: '+row['path'])
    print(json.dumps(dict(restored_files=832,all_sha256_size_equal=True,output=str(output),meaning='r1 file-content tree; not original ZIP-byte reproduction')))
if __name__=='__main__':main()
