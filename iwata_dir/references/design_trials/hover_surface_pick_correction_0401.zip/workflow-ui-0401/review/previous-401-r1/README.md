# 未受入0.40.1-r1のファイル内容を復旧する

832memberの旧候補は、2D復帰の反証後に全体の受入を撤回した版です。面内hoverの限定成功と後続の失敗を一緒に振り返るために保持します。元ZIP SHA256は `944d664adbd8a8a91fb6cb81095f48fee00b189e12a62fa36ffa79720b3ef8da` です。

このフォルダーを r2 の `review/previous-401-r1` に置いたまま、Pythonで `restore_r1_tree.py --output NEW_DIRECTORY` を実行します。NEW_DIRECTORYはまだ存在しない、r2の外側の新規フォルダーです。既存フォルダーの上書き・削除はしません。

manifestにある832fileだけを、同じr2内の共通byteと `overrides/` の旧byteから組み立て、全path/size/SHA256を照合します。r2だけのfileは復旧先へ加えません。共通元が後で変わっていればエラーにして止まり、最新fileで代用しません。成功後の閲覧は、復旧したREADMEに従いHTTP経由で行います。復旧成功は当時の画面表示の再検証ではありません。

これは旧ファイル内容treeの復旧です。元ZIPの圧縮方式・順序・格納時刻まで復元し、ZIP全体のSHA256が944d…になる保証ではありません。元ZIPのbyte原本は別の外部保全に保持します。この構成は表示成功、科学的受入、Google再接続の許可を示しません。
