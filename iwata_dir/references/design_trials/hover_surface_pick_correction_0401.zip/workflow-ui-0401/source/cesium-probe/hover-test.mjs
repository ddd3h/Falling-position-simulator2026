import assert from 'node:assert/strict';
import {resolveHover,containsSurface,tooltipPosition,shortenHoverText} from './src/hover-labels.js';
import {createHoverController} from './src/hover-controller.js';
import {pickSurface,pickedNameBoundaryIndices} from './src/surface-pick.js';

export function runHoverTests(){
 let checks=0;const eq=(actual,expected)=>{assert.deepEqual(actual,expected);checks++;};
 const ring=[[0,0],[10,0],[10,10],[0,10],[0,0]],hole=[[3,3],[7,3],[7,7],[3,7],[3,3]];
 const geometry={type:'Polygon',coordinates:[ring,hole]},feature=(kind,properties={},g=geometry)=>({type:'Feature',properties:{kind,...properties},geometry:structuredClone(g)});
 const band=feature('contour-band',{candidateId:'A',resultId:'rA',fillOpacity:.2}),region=feature('region',{regionId:'z',label:'同じ名前',levelName:'注意',priority:2,fillOpacity:.2});
 const candidate=id=>({candidateId:id,resultId:'r'+id,label:'親案 ＋30分 '+id,visible:true,available:true,focused:id==='A'});
 const payload={context:{kind:'overview'},snapshotId:'old',candidates:[candidate('A'),candidate('B')],geojson:{features:[band,region]}};
 const before=JSON.stringify(payload);
 eq(containsSurface([1,1],geometry),true);eq(containsSurface([5,5],geometry),false);eq(containsSurface([3,5],geometry),true);eq(containsSurface([11,1],geometry),false);
 eq(resolveHover(payload,[1,1]).targets.map(t=>t.text),['落下分散：親案 ＋30分 A','領域：同じ名前 · 注意']);
 eq(resolveHover(payload,[5,5]).total,0);eq(resolveHover(payload,null).total,0);eq(resolveHover(payload,[NaN,1]).total,0);
 eq(resolveHover(payload,[1,1],{bandsVisible:false}).targets.map(t=>t.kind),['region']);
 eq(resolveHover(payload,[1,1],{regionsVisible:false}).targets.map(t=>t.kind),['candidate']);
 eq(resolveHover(payload,[11,1],{regionsVisible:false,lineFeatureIndices:[1]}).targets.map(t=>t.kind),['region']);
 eq(resolveHover(payload,[1,1],{regionsVisible:false,linesVisible:false,lineFeatureIndices:[1]}).targets.map(t=>t.kind),['candidate']);
 eq(resolveHover(payload,[11,1],{regionsVisible:false,lineFeatureIndices:[]}).total,0);
 const cloned=structuredClone(payload);cloned.geojson.features.push(structuredClone(band),structuredClone(region));
 eq(resolveHover(cloned,[1,1]).total,2);eq(resolveHover(cloned,[1,1]).otherCount,0);
 cloned.geojson.features.push(feature('region',{regionId:'other',label:'同じ名前',priority:8}),feature('region',{regionId:'third',label:'低順位',priority:1}));
 eq(resolveHover(cloned,[1,1]).targets.map(t=>t.key),['["candidate","A","rA"]','["region","other"]']);eq(resolveHover(cloned,[1,1]).otherCount,2);
 const multi=feature('region',{regionId:'multi'}, {type:'MultiPolygon',coordinates:[[ring,hole],[ring]]});
 const mp=structuredClone(payload);mp.geojson.features=[multi];eq(resolveHover(mp,[5,5]).total,1);eq(resolveHover(mp,[1,1]).total,1);
 const line=feature('contour',{candidateId:'B',resultId:'rB'});const lined=structuredClone(payload);lined.geojson.features.push(line,structuredClone(line));
 eq(resolveHover(lined,[1,1],{lineFeatureIndices:[2,3]}).otherCount,1);
 eq(resolveHover(lined,[11,1],{lineFeatureIndices:[2,3]}).targets[0].label,'親案 ＋30分 B');
 eq(resolveHover(lined,[11,1],{lineFeatureIndices:[2],linesVisible:false}).total,0);
 eq(resolveHover(lined,[1,1],{lineFeatureIndices:[0,1,999]}).total,2);
 const hidden=structuredClone(lined);hidden.candidates[0].visible=false;hidden.candidates[1].available=false;
 eq(resolveHover(hidden,[1,1],{lineFeatureIndices:[2]}).targets.map(t=>t.kind),['region']);
 const detail=structuredClone(lined);detail.context={kind:'detail',selection:{count:0,sampleIds:[]}};
 eq(resolveHover(detail,[1,1],{lineFeatureIndices:[2]}).targets.map(t=>t.kind),['region']);
 const transparent=structuredClone(payload);for(const f of transparent.geojson.features)f.properties.fillOpacity=0;
 eq(resolveHover(transparent,[1,1]).total,0);
 const noNames=structuredClone(payload);noNames.candidates[0].label='';noNames.geojson.features[1].properties.label='';
 eq(resolveHover(noNames,[1,1]).targets.map(t=>t.text),['落下分散：候補 A','領域：領域 z · 注意']);
 eq(JSON.stringify(payload),before);
 const bounds={left:100,top:50,right:500,bottom:300,width:400,height:250};
 eq(tooltipPosition({x:480,y:285},{width:200,height:60},bounds),{left:267,top:212});
 eq(tooltipPosition({x:101,y:51},{width:900,height:700},bounds),{left:106,top:56});
 eq(shortenHoverText('0123456789',7),'012…789');eq(shortenHoverText('short',8),'short');eq(shortenHoverText('😀😀😀😀😀😀😀😀😀',7),'😀😀😀…😀😀😀');

 class Events{constructor(){this.events=new Map();}addEventListener(name,fn){if(!this.events.has(name))this.events.set(name,new Set());this.events.get(name).add(fn);}removeEventListener(name,fn){this.events.get(name)?.delete(fn);}emit(name,event={}){for(const fn of this.events.get(name)||[])fn(event);}count(){return [...this.events.values()].reduce((n,s)=>n+s.size,0);}}
 class Element{constructor(){this.children=[];this.hidden=true;this.style={};this.ownerDocument={createElement:()=>new Element()};}setAttribute(k,v){this[k]=v;}replaceChildren(){this.children=[];}append(e){this.children.push(e);}getBoundingClientRect(){return {width:200,height:70};}}
 const target=new Events(),viewport=new Events(),tooltip=new Element(),timers=new Map();target.getBoundingClientRect=()=>bounds;viewport.innerWidth=800;viewport.innerHeight=600;
 let nextTimer=0,samples=0,allow=true,name='<img src=x onerror=alert(1)>',delays=[];
 const h=createHoverController({target,viewport,tooltip,canRead:()=>allow,sample:()=>{samples++;return {targets:[{text:name},{text:'領域：第二対象'}],otherCount:3};},setTimer:(fn,ms)=>{const id=++nextTimer;timers.set(id,fn);delays.push(ms);return id;},clearTimer:id=>timers.delete(id)});
 const event={clientX:480,clientY:285,pointerType:'mouse',buttons:0},fire=()=>{for(const [id,fn] of [...timers]){timers.delete(id);fn();}};
 target.emit('pointermove',event);eq(samples,0);eq(tooltip.hidden,true);eq(delays,[260]);fire();eq(samples,1);eq(tooltip.hidden,false);eq(tooltip.children.map(c=>c.textContent),[name,'領域：第二対象','他 3 件']);eq('innerHTML' in tooltip.children[0],false);eq(tooltip.style.left,'267px');
 for(const action of ['pointerdown','pointerup','wheel','pointerleave','pointercancel','lostpointercapture']){target.emit('pointermove',event);target.emit(action);fire();eq(tooltip.hidden,true);}
 for(const action of ['blur','resize','scroll','keydown']){target.emit('pointermove',event);viewport.emit(action);fire();eq(tooltip.hidden,true);}
 for(const extra of [{pointerType:'touch'},{buttons:1},{ctrlKey:true},{shiftKey:true},{metaKey:true},{altKey:true}]){target.emit('pointermove',{...event,...extra});fire();eq(tooltip.hidden,true);}
 target.emit('pointermove',event);h.invalidate();fire();eq(samples,1);
 target.emit('pointermove',event);allow=false;fire();eq(samples,1);eq(tooltip.hidden,true);allow=true;
 target.emit('pointermove',event);name='new snapshot';h.invalidate();fire();eq(tooltip.hidden,true);target.emit('pointermove',event);fire();eq(tooltip.children[0].textContent,'new snapshot');
 target.emit('pointermove',event);h.destroy();h.destroy();fire();eq(tooltip.hidden,true);eq(target.count(),0);eq(viewport.count(),0);eq(timers.size,0);

 const C={Cartesian2:class{constructor(x,y){this.x=x;this.y=y;}},Cartographic:{fromCartesian:p=>p},Math:{toDegrees:v=>v*180/Math.PI}};
 let sampleCalls=0,receivedExclude=null;const excluded=[{id:'overlay'}];
 const scene={requestRender(){},pickPositionSupported:true,sampleHeightSupported:true,canvas:{getBoundingClientRect:()=>({left:50,top:20,width:400,height:300})},pickPosition:()=>({longitude:1,latitude:.5}),sampleHeight:(p,x)=>{sampleCalls++;receivedExclude=x;return 42;}};
 const picked=pickSurface(C,scene,{x:80,y:40},excluded);eq(picked.screen.x,30);eq(picked.screen.y,20);eq(picked.height,42);eq(receivedExclude,excluded);eq(picked.point,[180/Math.PI,90/Math.PI]);
 eq(pickSurface(C,scene,{x:0,y:0}),null);eq(sampleCalls,1);scene.pickPosition=()=>undefined;eq(pickSurface(C,scene,{x:80,y:40}),null);eq(sampleCalls,1);
 scene.pickPosition=()=>({longitude:1,latitude:.5});scene.sampleHeight=()=>undefined;eq(pickSurface(C,scene,{x:80,y:40}),null);
 scene.pickPositionSupported=false;eq(pickSurface(C,scene,{x:80,y:40}),null);
 const contour={show:true,polyline:{},properties:{kind:{getValue:()=> 'contour'},sourceFeatureIndex:{getValue:()=>4}}},unknown={...contour},point={show:true,point:{},properties:{kind:'landing',sourceFeatureIndex:5}};
 let args;scene.drillPick=(...a)=>{args=a;return [{id:contour},{id:contour},{id:unknown},{id:point},{primitive:{label:'provider metadata'}}];};
 eq(pickedNameBoundaryIndices(scene,{x:0,y:0},[contour,point]),[4]);eq(args.slice(1),[undefined,9,9]);contour.show=false;eq(pickedNameBoundaryIndices(scene,{x:0,y:0},[contour]),[]);
 const regionLine={show:true,polyline:{},properties:{kind:'region',sourceFeatureIndex:7}};scene.drillPick=()=>[{id:regionLine}];eq(pickedNameBoundaryIndices(scene,{x:0,y:0},[regionLine]),[7]);
 const regionFill={show:true,polygon:{},properties:{kind:'region',sourceFeatureIndex:7}};scene.drillPick=()=>[{id:regionFill}];eq(pickedNameBoundaryIndices(scene,{x:0,y:0},[regionFill]),[]);
 return checks;
}
