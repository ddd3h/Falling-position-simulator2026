import assert from 'node:assert/strict';
import {createSurfaceSession} from './src/surface-session.js';
import {createHoverController} from './src/hover-controller.js';
import {pickSurface,pickedNameBoundaryIndices} from './src/surface-pick.js';

// This mock deliberately corrupts screen-depth interpretation after drillPick.
// It tests the application's public API ordering, not Cesium's GPU internals.
export async function runSurfaceSessionTests(){
 let checks=0;const eq=(actual,expected)=>{assert.deepEqual(actual,expected);checks++;};
 const flush=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
 class Event{constructor(){this.callbacks=new Set();}addEventListener(f){this.callbacks.add(f);return ()=>this.callbacks.delete(f);}raise(){for(const f of this.callbacks)f();}}
 const C={Cartesian2:class{constructor(x,y){this.x=x;this.y=y;}},Cartographic:{fromCartesian:p=>p},Math:{toDegrees:v=>v}};
 const boundary={show:true,polyline:{},properties:{kind:'contour',sourceFeatureIndex:2}};
 function sceneMock(){
  const state={poison:false,picks:0,requests:0,drills:0,inPostRender:false,readsInPostRender:0,trace:[],throwDrill:null};
  const scene={postRender:new Event(),renderError:new Event(),pickPositionSupported:true,sampleHeightSupported:true,canvas:{getBoundingClientRect:()=>({left:20,top:30,width:500,height:300})},
   pickPosition(){state.picks++;state.trace.push('position');if(state.inPostRender)state.readsInPostRender++;return {longitude:state.poison?999:141,latitude:state.poison?-999:43};},
   sampleHeight(){state.trace.push('height');return 50;},
   drillPick(){state.drills++;state.trace.push('drill');state.poison=true;if(state.throwDrill)throw state.throwDrill;return [{id:boundary}];},
   requestRender(){state.requests++;state.trace.push('request');},
  };
  const render=()=>{state.trace.push('normal-render');state.poison=false;state.inPostRender=true;scene.postRender.raise();state.inPostRender=false;};
  return {scene,state,render};
 }
 const {scene,state,render}=sceneMock(),session=createSurfaceSession(scene),client={x:80,y:70};
 const readWithLines=()=>{const surface=pickSurface(C,scene,client,[],session);return {point:surface.point,lines:pickedNameBoundaryIndices(scene,surface.screen,[boundary],session)};};
 eq(await session.read(readWithLines),{point:[141,43],lines:[2]});eq(state.poison,true);eq(session.isClean(),false);eq(state.requests,1);
 const previousPicks=state.picks;eq(pickSurface(C,scene,client,[],session),null);eq(state.picks,previousPicks);
 let settled=false;const next=session.read(readWithLines).then(result=>{settled=true;return result;});await flush();eq(settled,false);eq(state.picks,previousPicks);
 render();eq(state.picks,previousPicks);eq(await next,{point:[141,43],lines:[2]});eq(state.readsInPostRender,0);eq(state.requests,2);eq(session.isClean(),false);
 // Hover and click share one queue; click cannot slip between dirty depth and normal render.
 const order=[];const click=session.read(()=>{order.push('click');return pickSurface(C,scene,client,[],session).point;});
 const after=session.read(()=>{order.push('hover');return readWithLines();});await flush();eq(order,[]);
 render();eq(await click,[141,43]);eq((await after).point,[141,43]);eq(order,['click','hover']);
 // A queued result that lost its pointer or host must not call the scene later.
 const abort=new AbortController();let cancelledRuns=0;const cancelled=session.read(()=>cancelledRuns++,{signal:abort.signal});
 const cancelledCheck=assert.rejects(cancelled,{name:'AbortError'});abort.abort();await cancelledCheck;checks++;
 render();await flush();eq(cancelledRuns,0);
 // Exceptions also leave a barrier and schedule the repair frame; preserve the same error.
 const drillError=new Error('fixed local test sentinel');state.throwDrill=drillError;
 await assert.rejects(session.read(readWithLines),e=>e===drillError);checks++;eq(session.isClean(),false);eq(state.requests,4);
 state.throwDrill=null;render();await flush();eq(session.isClean(),true);
 // A fully restored frame permits a click immediately; no polling/render request for clean reads.
 const requestCount=state.requests;eq(await session.read(()=>pickSurface(C,scene,client,[],session).point),[141,43]);eq(state.requests,requestCount);
 // Public postRender is also emitted for a failed frame; it must not unlock reads.
 session.afterScreenPick();const failureWait=session.read(()=>{throw new Error('failed frame must not execute');});const failureCheck=assert.rejects(failureWait,{name:'AbortError'});scene.renderError.raise();await failureCheck;checks++;
 scene.postRender.raise();await flush();eq(session.isClean(),false);await assert.rejects(session.read(()=>0),{name:'AbortError'});checks++;render();await flush();eq(session.isClean(),true);
 session.afterScreenPick();const doomed=session.read(()=>{throw new Error('must not execute');});const doomedCheck=assert.rejects(doomed,{name:'AbortError'});session.destroy();await doomedCheck;checks++;
 eq(scene.postRender.callbacks.size,0);eq(scene.renderError.callbacks.size,0);eq(session.isClean(),false);await assert.rejects(session.read(()=>0),{name:'AbortError'});checks++;session.destroy();
 // Show that the unguarded legacy ordering reproduces a wrong second position in this model.
 const legacy=sceneMock();eq(pickSurface(C,legacy.scene,client).point,[141,43]);legacy.scene.drillPick();eq(pickSurface(C,legacy.scene,client).point,[999,-999]);

 class Events{constructor(){this.events=new Map();}addEventListener(name,fn){if(!this.events.has(name))this.events.set(name,new Set());this.events.get(name).add(fn);}removeEventListener(name,fn){this.events.get(name)?.delete(fn);}emit(name,event={}){for(const fn of this.events.get(name)||[])fn(event);}count(){return [...this.events.values()].reduce((n,s)=>n+s.size,0);}}
 class Element{constructor(){this.children=[];this.hidden=true;this.style={};this.ownerDocument={createElement:()=>new Element()};}setAttribute(k,v){this[k]=v;}replaceChildren(){this.children=[];}append(e){this.children.push(e);}getBoundingClientRect(){return {width:180,height:40};}}
 const target=new Events(),viewport=new Events(),tooltip=new Element(),timers=new Map();target.getBoundingClientRect=()=>({left:0,top:0,right:500,bottom:330,width:500,height:330});viewport.innerWidth=600;viewport.innerHeight=400;
 let clock=0,allow=true,sampleCalls=0;const rig=sceneMock(),reads=createSurfaceSession(rig.scene);
 const label=point=>({targets:[{text:'落下分散：'+point.join(',')}],otherCount:0});
 const controller=createHoverController({target,viewport,tooltip,canRead:()=>allow,sample:(point,{signal})=>reads.read(()=>{sampleCalls++;const surface=pickSurface(C,rig.scene,point,[],reads);pickedNameBoundaryIndices(rig.scene,surface.screen,[boundary],reads);return label(surface.point);},{signal}),setTimer:fn=>{const id=++clock;timers.set(id,fn);return id;},clearTimer:id=>timers.delete(id)});
 const fire=async()=>{for(const [id,fn] of [...timers]){timers.delete(id);fn();}await flush();};
 const event={clientX:80,clientY:70,pointerType:'mouse',buttons:0};
 target.emit('pointermove',event);await fire();eq(sampleCalls,1);eq(reads.isClean(),false);eq(tooltip.hidden,false);eq(tooltip.children[0].textContent,'落下分散：141,43');
 target.emit('pointermove',event);await fire();eq(sampleCalls,1);eq(tooltip.hidden,true);rig.render();await flush();eq(sampleCalls,2);eq(tooltip.children[0].textContent,'落下分散：141,43');
 // A pending read is cancelled by drag even if a normal frame later arrives.
 target.emit('pointermove',event);await fire();eq(sampleCalls,2);target.emit('pointerdown',{buttons:1});rig.render();await flush();eq(sampleCalls,2);eq(tooltip.hidden,true);
 // A stationary point received while readiness was false can resume via host notification.
 allow=false;target.emit('pointermove',event);await fire();eq(sampleCalls,2);allow=true;controller.ready();await fire();eq(sampleCalls,3);eq(tooltip.hidden,false);
 // A late Promise from an older pointer/snapshot never flashes the old tooltip.
 target.emit('pointermove',event);await fire();controller.invalidate();rig.render();await flush();eq(sampleCalls,3);eq(tooltip.hidden,true);
 // Pausing at completion suppresses the result even if no other event fired.
 target.emit('pointermove',event);allow=false;await fire();eq(sampleCalls,3);allow=true;controller.ready();await fire();eq(sampleCalls,4);
 target.emit('pointermove',event);await fire();controller.destroy();reads.destroy();await flush();eq(tooltip.hidden,true);eq(target.count(),0);eq(viewport.count(),0);eq(timers.size,0);eq(rig.scene.postRender.callbacks.size,0);eq(rig.scene.renderError.callbacks.size,0);
 return checks;
}

if(import.meta.url===new URL(process.argv[1],'file:///').href)console.log(JSON.stringify({checks:await runSurfaceSessionTests(),kind:'public-API-ordering-mock-only',googleConnections:0}));
