# Framework assessment evidence 0.43

This archive preserves reference material and review evidence, not the product implementation or a publishable application package.

- Private accepted basis M420: 4e3e4db0d047af9479bcd68bfc2553eeb71efcc9 (131 registered files).
- Public reference: ddd3h/Falling-position-simulator2026, main 94887cbb97a8b8ba98d84ef7662e2df200f000d7 (188 files).
- template-source.zip is the unmodified fixed public source download and contains its GPL-3.0 LICENSE. fixed-bases.json preserves file identities verified against GitHub trees. The current project remains private.
- Authoritative current decisions and process are INTEGRATION 7.2, D182 and S35 in the repository. Review reports include proposals made before the final human answer and are not competing specifications.

Backend: extract the reference source, copy backend-check/review_counterexamples.py beside its backend package, then run it using the dependencies declared by the reference. The program substitutes fake modules/HTTP responses and does not contact weather or prediction services. Results are in backend-check/counterexamples.json. The existing core suite had 24 passes; API tests were not run due to missing dependencies.

Frontend: logs preserve failures and the successful bounded checks. 54 existing tests passed. Temporary pnpm lock/hoisted layout was used with lifecycle scripts disabled. Direct TypeScript/Vite build succeeded without source edits; this does not verify the documented npm ci path. pnpm-workspace.yaml is evidence of temporary reconciliation behavior, not an adopted project configuration. Read frontend-review.md for the actual browser observations and their limits.

No Google key, paid map session, node_modules, generated application dist or private source corpus is bundled. Build or test success does not establish scientific adoption or completion of the desired analysis workflows. See final-assessment-review.md for the last critique and root's accepted amendments.
