# Frontend assessment of fixed reference 94887cbb97a8b8ba98d84ef7662e2df200f000d7

Date: 2026-09-29. Author role: independent frontend reviewer. Source tree: `template/` in this temporary assessment folder, supplied by the lead as verified 188-blob snapshot. Requirements read from accepted M420 `4e3e4db0d047af9479bcd68bfc2553eeb71efcc9`, `docs/research/BRIEF.md` and `UI_WALKTHROUGH.md`. No source edit, external prediction, paid map request, credential read, commit or push was performed. Results below separate observed code, bounded execution, and recommendations. Existing memory was used only for review boundaries, not current project facts.

## Conclusion (proposal)

React + TypeScript + Vite is a sensible frontend foundation for the intended analysis product, and this repository is useful as a working component/example collection. Adopt it selectively as a starting skeleton, not as an already established application architecture that only needs more fields. The considerable missing work is the contract between editable conditions, immutable results, selected sample groups, computations, stored weather and saved projects. These responsibilities are already absent in the reference; replacing the formal scientific kernel with this app's browser-side/Tawhiri behavior would discard requirements rather than accelerate them.

Keep the existing scientific Python kernel as the computation authority and introduce a typed frontend service interface around it. A local Python service is a viable first deployment proposal; neither React nor FastAPI itself requires a public service. Keep Tawhiri as an explicit comparison adapter, not an invisible fallback. The reference's React widgets, Leaflet layers, plot components, JST helpers, pure sampling helpers and bounded tests can reduce startup work, while the result schema and run lifecycle need redesign before feature expansion.

## What is actually implemented (source facts)

- `frontend/package.json:7-14` defines Vite dev/build, TypeScript checking, Oxlint, Vitest and an explicit Cloudflare deploy command. Dependencies include React 19.2.8, Zustand 5.0.14, Leaflet 1.9.4 / React-Leaflet 5.0.0, Plotly and Navara/Three. These are declared source versions, not a claim that each is the newest release.
- `src/App.tsx:22-79`: one sidebar containing launch input, collapsible MC, sizing, optimization and sensitivity, plus one map and optional plot drawer. This is an actual React app rather than only an empty Vite template.
- `src/store/paramsStore.ts:14-54`: one mutable launch condition. `src/store/resultsStore.ts:19-45,47-92`: one global result bucket for current single/hourly/MC/optimizer output. `src/store/uiStore.ts:3-20`: display booleans, but no selected sample IDs, candidate IDs, immutable revisions, shared map camera or saved-project state.
- `src/api/backend.ts:19-32`: health request plus TODO for simulate/MC/optimize clients. No callers of this module were found in `frontend/src`. `VITE_API_BASE` does not currently route prediction to FastAPI. `useRunPrediction.ts:2,67-69,109-111`, `mcWorker.ts:4,34`, `useSensitivity.ts:3,37,78`, `gridSearch.ts:6,125` all call the Tawhiri client.
- `src/api/tawhiri.ts:9,61-101`: direct external endpoint. `parseFlight` (`25-40`) strips the response down to trajectory/endpoint data; `Flight` in `tawhiriTypes.ts:48-55` has no weather dataset/run, model version, original request or stable result ID.
- `src/mc/sampling.ts:8-39`: seed/index-stable parameter draws independent of worker partition, Gaussian rate/altitude perturbations with clamps, or fixed-shape Weibull burst altitude. This is useful deterministic sampling scaffolding, not proof of an adopted uncertainty model or fixed weather.
- `src/mc/useMonteCarlo.ts:17,34,53-59`: max 500 samples, up to four workers, each sends external requests. This worker implementation parallelizes network requests; it is not a browser implementation of the formal trajectory kernel or a scalable archive-weather service.
- `src/time/jst.ts:10-29` implements JST input/display through date-fns-tz; four existing tests exercise -9h, day/month boundary and display.
- `src/components/map/MapView.tsx:26-41`: Leaflet/OSM tiles, launch marker, safety circles, trajectories, ellipses, heatmap.
- `src/components/map/Map3D.tsx:135-165`: Navara globe with GSI DEM and OSM raster, camera initialized at the launch location, height 120 km. This is terrain + raster, not the current project's optional photographic 3D buildings/trees capability.
- `src/components/charts/ChartsPanel.tsx:25-33`, `AltitudeProfile.tsx:25-52`: altitude traces, MC landing scatter and distance histogram. Up to approximately 30 MC trajectories are drawn, plus central prediction. This is useful output inspection, but not selected-group temporal analysis or wind analysis.
- `docs/source/architecture.rst:7-10,38-63,74-95` still describes buildless jQuery, no backend and old paths. README correctly describes React/FastAPI. These docs are materially out of date for implementation recovery. `frontend/README.md` is also generic Vite template text.

## Main gaps and why they matter to the intended user journey

### F1. Comparisons have no durable identity (high consequence)

Facts: `resultsStore.ts:81-91` clears the global current result. `useRunPrediction.ts:64,91` and `useMonteCarlo.ts:35` call this on each run. The form continues to update `paramsStore`; `Flight` contains no request snapshot. Calculator application (`CalcPanel.tsx:114-122`) retains only rounded ascent rate and burst altitude, losing the sizing inputs that produced them.

Consequence: the user cannot retain A while computing B, distinguish edited conditions from the displayed old A, or identify whether an apparent difference is model, launch condition or forecast update. Input/result separation is required even if the final UI remains visually simple. A screen that has React state is not yet a project/result model.

Proposal: keep draft conditions separately from immutable candidate revisions and `run` records. Each result refers to frozen model/input/weather identity, sampled IDs and outcomes. Display a short human-readable difference; keep hashes in details/export rather than overwhelming the normal form. Preserve candidate focus separately from which candidates are visible.

### F2. MC failures disappear from the analytic population (high consequence)

Facts: `mcWorker.ts:36-42` emits error index/message, but `useMonteCarlo.ts:85-87` only increments progress and discards them. Statistics (`108-113`) and classification (`120-140`) use successful `mcSamples`. `ScenarioInfo.tsx:20-22,64-68` uses only classified successful samples as the denominator of a label reading “安全着地率”. `useRunPrediction.ts:113-121` also silently skips hourly failures.

Consequence: missing/unsupported trials cannot be distinguished from available landings; a narrower surviving cloud can look reassuring. It is impossible to select a failed group for follow-up, or preserve the total requested population for reproducible comparison. In our requirements, landing/total and stops/unknowns must remain distinct.

Proposal: store an outcome per requested sample: landed, physical stop, support stop, computation error, cancelled, pending. Preserve error and ID, and state the denominator of summaries. Do not classify a failed trial as noninterference or infer full coverage from successful endpoints.

### F3. “Safety” is a coarse category shortcut, not arbitrary-region interference (high consequence)

Facts: `landingSafety.ts:30-49,67-98` uses prepackaged circle zones, land polygons and a fixed elevation threshold. It returns `safe` when elevation is null and other checks miss; `elevation.ts:41-57` returns null on failures. The existing test `landingSafety.test.ts` explicitly expects null elevation to give `safe` at the test point. `SafetyZonesLayer.tsx:30-58` renders circles; no KML/GeoJSON user-import flow is implemented. The optimizer score (`objectives.ts:24-38,48-58`) is endpoint distance plus hand-set category penalties. A failed optimizer row (`gridSearch.ts:172-179`) has `onLand:false`, and `OptimizerPanel.tsx:314-322` can render it as “海” despite no flight.

Consequence: reference terminology can overstate what was checked. The formal user asks for interference against their own forbidden regions and exploration of the affected samples, not a generic binary assurance or unexplained single ranking. Overlapping region membership should not be lost to a category priority chain.

Proposal: reuse map-layer patterns; replace data/analysis contract with versioned arbitrary region geometry, explicit coverage/unknown state and per-region sample membership. Use a modest label such as “指定領域との照合” with visible counts and unresolved cases. Keep optimization as a later optional aid after comparable outcomes and uncertainty are available.

### F4. The cancellation contract can mix jobs (high consequence)

Facts: MC `cancel` (`useMonteCarlo.ts:22-29`) terminates existing workers and immediately sets the shared running flag false. It has no abort signal for the central request (`39-44`); after it resolves, worker creation continues (`53-65`). Terminating workers also leaves the promise waiting for every `done` (`64-101`) unresolved. The ParameterForm cancel button appears whenever any global run is active (`ParameterForm.tsx:34,114`) but invokes only its own `useRunPrediction` controller; it cannot cancel the MC workers. `useRunPrediction.ts:50-53` still marks the shared flag false. There is no run-ID guard on result writes. Optimizer uses separate local running state (`OptimizerPanel.tsx:38,278`), allowing overlapping operations.

Consequence (code-derived, not browser reproduction): cancelling MC during central request can still start workers; cancelling through the general button can unlock a new run while old MC writes continue into the shared result store. This is precisely the edited-condition/old-job confusion our planned repeated comparison would amplify.

Proposal: one job controller with stable run ID, explicit cancellation request and terminal acknowledgment, signal propagated into all I/O, settlement of worker promises and stale-result rejection. The frontend can remain responsive and show old immutable results without permitting them to overwrite a new run.

### F5. 2D/3D switches discard analytical context (high consequence for required journey)

Facts: `App.tsx:67-73` unmounts one map to mount the other. `MapView.tsx:27-28` always initializes [42.7,143.2], zoom 9. `Map3D.tsx:156-165` initializes at current launch, height 120000; no common camera is stored. `Map3D.buildGeojson` (`45-99`) draws lines and category points, omitting the ellipse/heatmap/safety region overlays that appear in 2D. Feature properties are empty, so candidate/sample naming and hover are not represented by this conversion.

Consequence: the user who zoomed into a suspect landing area cannot keep the same local question when switching and returning. Having a 3D button does not satisfy reading terrain/objects together with the same distribution and forbidden regions.

Proposal: keep 2D core usable independently. Define a renderer-neutral layer and selection model; preserve location/scale/focus across 2D/3D, and validate distribution/region/trajectory/identity parity. Assess Navara as one optional renderer; do not presume the library cannot be extended, but do not count the reference implementation as photographic-3D acceptance.

### F6. Overview-to-group detail is missing

Facts: stores lack selected sample IDs. `plotlyDefaults.ts:14` explicitly removes lasso/select controls. `AltitudeProfile.tsx:35-43` draws a subset of MC trajectories but has no connection to selected landing categories/regions, no shared time bar and no wind-at-sample analysis. `MapView.tsx:11-18` makes every map click edit launch location, without an analysis/edit mode.

Consequence: looking at a point popup can reveal its three perturbed parameters, but cannot answer “what differs in the interfering group, and where along the flight did that difference emerge?” Drawing fewer lines is a display strategy; it is not the same as selecting an analytic population or doing coarse-to-fine computation.

Proposal: retain sample IDs from overview through region counts, map selection, histories and export. Use cached outcome summaries for overview, then fetch/compute only required histories; use explicit interaction modes to avoid moving a launch point while investigating the map. Sampling priority and progressive displays must not silently treat first-completed trials as an unbiased completed population.

### F7. Past flight, seasonal planning and independent wind have no underlying path

Facts: `useRunPrediction.ts:38-44` only permits current time -12h to +7d. Requests and `Flight` are shaped around Tawhiri standard/float trajectories. There are no frontend data structures for archive weather periods, selected years, observational records, weather-only plots or hierarchical weather-case/aircraft samples. There are no routes/workspaces for these journeys in App.tsx.

Consequence: this app can help prototype a near-term single forecast interface. It does not support extending a live forecast screen merely by widening a date picker to ten years. Observed time cutoff, original archive time, weather valid time and launch time are different identities.

Proposal: retain one project context, but separate the questions/screens as needed. A wind-only view must not require an aircraft. Seasonal outputs must keep source years/windows and weather-case weights, and past flight must distinguish forecast available then from post-flight diagnosis. Heavy weather/trajectory arrays belong in the computation/storage layer; React state holds references, summaries and the currently inspected slice.

### F8. Seed reproducibility is not result or project reproduction

Facts: seed/index draws are deterministic (`sampling.ts:8-16`), but request metadata is discarded (`tawhiri.ts:25-40`), there is no persisted store, and no localStorage/IndexedDB/project import/export path was found. `exportUrls` (`tawhiri.ts:113-119`) is uncalled frontend helper code; it creates new external KML/CSV request URLs rather than exporting the stored output. Plotly's default modebar is configured without removing its image export, but no project provenance is attached and actual browser figure export was not tested.

Consequence: re-running the same seed at a later date can use a different weather dataset; a saved picture cannot reconstruct a project. README functionality cannot substitute for retained data.

Proposal: separate static figure export, immutable result bundle, reusable settings and full project continuation. Save actual outputs and provenance with a manifest. Missing heavy source data should be detectable on another PC, while existing figure/results remain readable. Do not force all ten-year weather arrays into the browser to achieve portable read-only reports.

## What to reuse and what to replace (proposal)

| Area | Reuse | Required change |
|---|---|---|
| React/TS/Vite structure | Component organization, local dev/build and tests | Domain types/service contract, explicit direct dependency declarations, useful current docs |
| Leaflet | Existing tile/layer patterns, marker/line interaction examples | Candidate identities, region import/membership, selection mode, shared viewpoint and result snapshots |
| Plotly | Histogram/scatter/profile components and figure-export affordance | Linked selections, defined populations/units/time conventions, common scales and provenance, measured bundle/loading behavior |
| Zustand | Convenient UI state tooling | Avoid one mutable catch-all result; normalize immutable results and job references, keep large histories outside always-live UI state |
| MC helpers | Seed/index deterministic draw scaffolding, mocked client tests | Accepted source quantities/distributions/dependencies, weather identity, explicit per-sample outcomes, job cancellation and storage |
| Backend placeholder | Narrow seam concept | Implement a real typed adapter to the formal Python kernel; avoid maintaining two divergent scientific implementations |
| Sizing UI | Alternate direct-rate vs product-derived entry pattern | Preserve source inputs/units/assumptions and derived values; do not import legacy constants as scientific acceptance |
| Navara | Renderer experiment | Verify local context/overlay/identity requirements; photograph mesh capability remains unproven |
| “Safety” and optimizer | Some geometry and table patterns | Replace semantics and data provenance before decisions; compare distributions before adding authoritative-looking rankings |

## Finite next integration slice (proposal, not implemented)

1. Add a frontend-independent result fixture from one fixed weather case, two model configurations and sample outcomes including stops/errors. Preserve the current formal kernel separately.
2. Build one comparison journey: same place/time/weather, A/B distributions, arbitrary forbidden region, requested/landed/interfering/unknown counts, group selection and a shared history view. Keep editable draft inputs distinguishable from displayed results.
3. Confirm UI-only view/selection changes do not recompute trajectories. Connect the same service interface to a local computation job with real cancel/run IDs.
4. Export a figure plus fixed result bundle; reload it and show the same conditions, population, region version and result. Reuse conditions for a new result without overwriting the old one.
5. Validate local 2D/3D return context as an optional renderer experiment. Do not require paid backgrounds for the main comparison slice.

This slice exercises the design decisions most likely to be costly to undo. In parallel, a small independently usable wind view can validate the weather-only requirement without pretending the reference already implements the seasonal archive pipeline. Full ten-year computation and full future model menus are not prerequisites for choosing React.

## Execution evidence and limits

- Source copy `frontend-check/`: copied from fixed `template/frontend`, source unmodified. `package-lock.json` imported into a temporary pnpm lock, dependencies installed with scripts disabled. Runtime is bundled Node; pnpm 11.25.0. This is not a repository dependency migration.
- Existing Vitest suite: `7 files / 54 tests passed`, log `frontend-check/test-escalated.log`. The initial ordinary attempt was blocked by Windows `spawn EPERM` while Vite resolved paths, not by a failed assertion. Re-running the same test command with execution permission succeeded. No automatic approval rejection occurred.
- `pnpm run lint` returned exit 0, log `frontend-check/lint.log`. It emitted only the command line, so no richer claim about lint coverage is made.
- Initial build in pnpm isolated layout failed with five TS2307 diagnostics for direct type imports from `plotly.js`. The package declares `@types/react-plotly.js`, with `@types/plotly.js` transitively available in its npm lock. This result demonstrates reliance on dependency hoisting; it is not proof that the documented npm build fails. A separate hoisted-layout check is recorded below when complete.
- Existing tests are pure math/sampling/JST/geometry and mocked API behavior. They do not cover React interactions, real geographic datasets, cancellation lifecycle, linked selection, project persistence or actual backend integration. Passing 54 does not establish scientific model validity, external API availability, 3D rendering, browser usability or full requirement acceptance.
- No online prediction was executed. Initial layout conclusions were source-derived; the later bounded browser check below adds observed evidence without claiming result-analysis acceptance.

## Second pass: challenge the proposed migration sequence

The central need is to move from temporary UI artifacts to reproducibly started, Git-reviewed production source. A proposal that spends the next phase completing a universal contract without delivering such a source tree would miss that need. “Contract first” should mean a small explicit boundary in the first working slice, not a database, plugin system, distributed scheduler and schemas for every future model before any working comparison.

A minimal useful boundary can be concrete now: frozen condition snapshot, source weather/model identity, sample IDs and terminal outcomes, result identity, selected IDs, and a file-backed saved result. Start with a typed adapter and versioned JSON fixture/result reader. Add persistence services and job infrastructure only where the real interaction requires them. TypeScript declarations alone do not validate external input; runtime validation at the file/API boundary is needed, but can initially cover the actual supported shape.

A single real flight end-to-end is an integration check, not the first acceptance of usefulness. The first useful demonstration should retain two comparable candidate results, show both against the same user-defined region, carry its interfering sample IDs into a history view, and reopen the same saved result. These can be small ensembles; the purpose is interaction/identity and honest population handling, not a statistical accuracy claim from a small N. If only one scientific model is currently supported, label a parameter comparison honestly and avoid fabricating a second scientific model merely to exercise two UI tabs.

The alternative “make this reference prettier and add menus, then introduce identities later” looks faster only for a screenshot. Each later feature (delay, changed weather, selected group, saved output) would then require repairing the one-current-result assumption. The alternative “build an entirely generic future architecture first” also loses: it freezes assumptions before users exercise them. The small two-result journey resolves this tension because it reveals the necessary boundary with limited implementation.

An adapter for 2D/3D is worthwhile, but avoid a lowest-common-denominator abstraction of all map libraries. A shared geographic geometry plus stable candidate/sample properties, visibility, selected IDs and meaningful view target is sufficient initially. Preserve altitude meaning and ground-projected overlays explicitly. First confirm the 2D comparison; then recheck the existing prototype's local hover/return behavior in whichever 3D renderer is retained. Do not postpone all UI migration until photographic 3D is complete.

Do not let near-term comparison consume the independent wind requirement. A small fixed period/profile drawn from stored real weather can test a wind-only entry path, shared units/time provenance and figure export without aircraft input. This is a separate useful slice; it need not wait for ten years of ingestion, but it should not be mislabeled seasonal-planning acceptance. Archive-case hierarchy, original valid times and weight identities must remain extensible in stored references, rather than being hardwired to a live forecast date window.

### Main source repository options (proposal, not a permission or repository change)

| Option | Advantage for the actual need | Cost / condition |
|---|---|---|
| Existing private scientific repo hosts React frontend | UI, kernel interface, fixtures and accepted scientific/documentation changes can be reviewed in one commit; keeps the present source of truth | Keep UI tooling/build outputs separated from source; preserve reference attribution/licensing; verify its actual accepted branch/copy before writing |
| Public reference repo branch becomes main product source | Reuses upstream project/collaboration environment; appropriate if the same maintainers explicitly want this shared product | Existing forecast-oriented behavior, ownership, deployment and documentation become coordination constraints; must define how private scientific source/data and coordinated changes are handled |
| New separate UI repository | Clean frontend ownership and release cadence | Adds schema/version compatibility and cross-repo review burden immediately; little benefit for the first local two-result slice unless distinct frontend ownership is intended |

Provisional preference: put the minimal React app beside the formal kernel in the existing private project and import selected reference ideas/components under a fixed-source record, rather than copying all reference workflows or treating the public repo's main as the scientific source of truth. This is a workflow preference, not a claim that public collaboration is unsuitable or that current user permission to edit the reference is absent. If collaborators intend one shared public application, the public branch may be preferable once ownership, source distribution and coordinated changes are explicit. Branch authority and product fitness are separate decisions.

### Additional execution note

A separate `frontend-npm-layout/` copy was made only for the dependency-hoisting question. The first `pnpm run build` there triggered pnpm's automatic dependency-layout reconciliation and did not reach a meaningful application build; its script-approval message is a package manager behavior, not an automatic tool-approval rejection. After explicit hoisted install with lifecycle scripts disabled, direct `node node_modules/typescript/bin/tsc -b` passed (exit 0), log `frontend-npm-layout/typecheck-direct.log`. This was not `npm ci`; standard documented npm build remains unverified. No product source was changed to make the check pass.


## Bounded browser check after direct build

The copied, unmodified application source passed direct TypeScript and Vite production build in the explicitly hoisted dependency layout. Vite initially hit the same Windows child-process `spawn EPERM`; the identical command with execution permission passed. No automatic approval rejection occurred. Log: `frontend-npm-layout/vite-direct-escalated.log`. This remains a temporary pnpm-based dependency setup, not a verified `npm ci && npm run build` result.

Build output: 437 modules, approximately 3.52 s reported build time, Vite warning on chunks above 500 kB. Example minified chunks: Map3D 4,173.88 kB (gzip 1,113.53 kB); plotlyDefaults 4,652.76 kB (gzip 1,392.25 kB); spark.module 5,052.13 kB (gzip 1,805.64 kB). These are build artifact sizes, not measured browser loading/network performance. App.tsx mounts TornadoChart inside a closed details element, so the existence of lazy imports alone does not establish desired initial loading behavior.

Served only the generated static dist on `http://127.0.0.1:8768/`, opened in a temporary hidden in-app browser. No forecast, MC, optimization or sensitivity execution button was pressed. No key was read or configured. OSM and GSI background resources are the implemented map background path; no paid/Google service was used.

Observed at the browser's default 1280 × 720 viewport:

1. Initial view displayed the actual React launch form, Hokkaido presets, OSM map and launch marker. The app is visibly a working frontend shell.
2. The 320 px sidebar occupied its own scrolling column; at initial scroll, prediction/action/view buttons were below the visible field list. Clicking the view button through its accessible label scrolled the sidebar down. There is no overall problem with scrolling itself, but launch conditions above and view controls below are not simultaneously visible at this viewport.
3. Opening the graph drawer (without results) displayed its empty-state text. Its 460 px overlay covered the map's right side, including the default launch marker. The map did not reframe into the remaining roughly 500 px visible region. This makes the present layout a weak starting default for simultaneous map/detail comparison, even though the same React components can be rearranged.
4. Toggling the packaged safety zones displayed many orange/red circles on the 2D map; source-level circle-data assessment is borne out. No arbitrary region import or calculation was performed.
5. Clicked Leaflet Zoom in once, obtaining a visibly closer view. Switched to Navara 3D: first capture was black during initialization; a subsequent observation displayed an oblique OSM-covered terrain view. The safety circles visible in 2D were absent. Horizontal/vertical overflow scrollbars appeared. Browser console had one warning: `THREE.WARNING: Multiple instances of Three.js being imported.` No broad claim about all graphics environments follows.
6. Returned to 2D. Tiles and safety circles rendered, but the earlier zoom level was lost and the original wider view returned. This directly confirms the context-loss mechanism inferred from component unmount/reinitialization. The check did not exercise actual trajectory or distribution overlays.

These observations support selective component reuse and a revised interaction/state layout. They neither reject React as a framework nor validate the final product's scientific or user-journey requirements. Browser screenshots were observed in the tool transcript; no separate image files were exported. The temporary browser tab was closed after inspection.

Preview server shutdown returned after Ctrl+C. Its request log also directly showed `/assets/TornadoChart-Dbz_F0dp.js` and `/assets/plotlyDefaults-DKEc49Sn.js` requested on initial page load (03:11:41), before any analysis execution or graph panel toggle. Thus the deferred Plotly loading limitation above is observed in this build, not only inferred from the closed-details mount. This is a loading-path observation, not a measured end-user performance claim.
