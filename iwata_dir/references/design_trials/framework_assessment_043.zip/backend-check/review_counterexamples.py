"""Offline review probes for the fixed reference snapshot; no external I/O.

Run: python -B review_counterexamples.py
The fetch probe supplies a fake client and httpx module; it never opens a socket.
"""
import asyncio
from dataclasses import replace
from datetime import datetime, timezone, timedelta
import json
import math
from pathlib import Path
import sys
import types

import numpy as np
from bfps.core.trajectory import FlightParams, simulate
from bfps.core.wind import ConstantWind, WindProfile, OPEN_METEO_LEVELS, fetch_openmeteo_profile
from bfps.core.montecarlo import Distributions, run_montecarlo
from bfps.core.optimize import grid_search, distance_to_point

BASE = FlightParams(33.1, 132.5, 0, datetime(2026, 8, 5, tzinfo=timezone.utc), 5, 30000, 5)
profile = WindProfile(np.array([0., 50000.]), np.array([5., 5.]), np.array([0., 0.]))
zero = Distributions(0, 0, 0, 0)
observed = {}


class TimeRampWind:
    def __init__(self):
        self.offsets = []

    def wind_at(self, lat, lon, alt, t):
        elapsed = (t - BASE.launch_time).total_seconds()
        self.offsets.append(elapsed)
        return elapsed / 100, 0


ramp = TimeRampWind()
traj = simulate(replace(BASE, burst_altitude_m=1100), ramp, dt=10)
expected = math.degrees((traj.flight_time_s**2 / 200) / (6371000 * math.cos(math.radians(BASE.launch_lat))))
observed['time_provider'] = {
    'flight_time_s': traj.flight_time_s,
    'distinct_query_offsets_s': sorted(set(ramp.offsets)),
    'actual_dlon_deg': traj.landing[1] - BASE.launch_lon,
    'expected_dlon_deg_for_u_equals_elapsed_over_100': expected,
}
assert set(ramp.offsets) == {0.0} and traj.landing[1] == BASE.launch_lon and expected > 0

grid = grid_search(BASE, zero, profile, [BASE.launch_time, BASE.launch_time+timedelta(hours=6)], [5], distance_to_point(BASE.launch_lat, BASE.launch_lon), n_per_cell=2)
observed['time_optimization'] = [vars(c) for c in grid.grid]
assert grid.grid[0].score == grid.grid[1].score

slow = replace(BASE, ascent_rate_ms=.1, burst_altitude_m=45000)
slow_traj = simulate(slow, ConstantWind(0, 0), dt=3600)
slow_mc = run_montecarlo(slow, zero, profile, n=2, dt=3600)
observed['timeout_becomes_landing'] = {
    'single_final_altitude_m': float(slow_traj.alts[-1]),
    'single_burst_index': slow_traj.burst_index,
    'single_warnings': slow_traj.warnings,
    'mc_landings': slow_mc.landings.tolist(),
    'mc_flight_time_stats': slow_mc.flight_time_stats,
    'mc_warnings': slow_mc.warnings,
}
assert slow_traj.burst_index == -1 and slow_traj.alts[-1] > 0 and slow_traj.warnings and not slow_mc.warnings

fine = simulate(replace(BASE, burst_altitude_m=30007), ConstantWind(10, 0), dt=1)
stride = max(1, len(fine.times_s)//500)
kept = list(range(0, len(fine.times_s), stride))
observed['response_downsample_formula'] = {
    'integration_points': len(fine.times_s), 'stride': stride,
    'last_true_time_s': float(fine.times_s[-1]),
    'last_response_time_s': float(fine.times_s[kept[-1]]),
    'true_burst_index': fine.burst_index,
    'mapped_burst_time_s': float(fine.times_s[kept[fine.burst_index//stride]]),
    'true_burst_time_s': float(fine.times_s[fine.burst_index]),
    'final_altitude_m': float(fine.alts[-1]),
}
assert kept[-1] != len(fine.times_s)-1

# httpx is absent locally; injecting an empty module is sufficient because an
# explicit fake client is supplied. Any attempted default client access fails.
sys.modules['httpx'] = types.ModuleType('httpx')


class FakeResponse:
    def __init__(self, payload): self.payload = payload
    def raise_for_status(self): pass
    def json(self): return self.payload


class FakeClient:
    def __init__(self, hours, missing=None):
        self.calls = []
        hourly = {'time': hours}
        for i, pressure in enumerate(OPEN_METEO_LEVELS):
            hourly[f'wind_speed_{pressure}hPa'] = list(range(len(hours)))
            hourly[f'wind_direction_{pressure}hPa'] = [270] * len(hours)
            hourly[f'geopotential_height_{pressure}hPa'] = [i * 1000] * len(hours)
        if missing:
            del hourly[missing]
        self.payload = {'hourly': hourly}

    async def get(self, url, params):
        self.calls.append({'url': url, 'params': params})
        return FakeResponse(self.payload)


async def fetch_probes():
    hours = [f'2026-08-05T{h:02}:00' for h in range(24)]
    jst = datetime.fromisoformat('2026-08-05T09:30:00+09:00')
    client = FakeClient(hours)
    fetched = await fetch_openmeteo_profile(33.1, 132.5, jst, client=client)
    observed['non_utc_fetch'] = {
        'input': jst.isoformat(), 'equivalent_utc': jst.astimezone(timezone.utc).isoformat(),
        'fake_selected_wind_u': float(fetched.u[0]),
        'requested_date': client.calls[0]['params']['start_date'],
    }
    assert fetched.u[0] == 9
    no_target = FakeClient(['2026-08-05T00:00', '2026-08-05T01:00'])
    fallback = await fetch_openmeteo_profile(33.1, 132.5, jst, client=no_target)
    observed['missing_time_fallback'] = {'selected_u': float(fallback.u[0]), 'warnings': fallback.warnings}
    assert fallback.u[0] == 0
    missing = FakeClient(hours, 'wind_speed_1000hPa')
    try:
        await fetch_openmeteo_profile(33.1, 132.5, jst, client=missing)
    except Exception as exc:
        observed['missing_variable'] = {'type': type(exc).__name__, 'message': str(exc)}
    else:
        raise AssertionError('Expected missing-variable indexing failure')


asyncio.run(fetch_probes())
result = json.dumps(observed, ensure_ascii=False, indent=2, default=str)
Path('counterexamples.json').write_text(result+'\n', encoding='utf-8')
print(result)
