"""Additional checks for the A/B explanatory calculations."""
import unittest,math
import balloon_model as b
import theory_analysis as t

class TheoryTests(unittest.TestCase):
    def test_forward_inverse_identity(self):
        for mass in [1.,3.5,4.,7.]:
            for k in [138/23.6,140/23.6]:
                for speed in [.5,5.,8.]:
                    L=b.empirical_free_lift(speed,mass,k)
                    self.assertAlmostEqual(b.empirical_speed(L,mass,k),speed,places=5)
    def test_shape_thresholds_reconstruct_original_criterion(self):
        ve=math.pi*2.2*1.4**2/6;vs=math.pi*2.2**3/6
        self.assertAlmostEqual(130*(t.threshold_volume('ellipsoid_thickness')/ve)**(-2/3),5,places=9)
        self.assertAlmostEqual(130*(t.threshold_volume('sphere_thickness')/vs)**(-2/3),5,places=9)
        self.assertAlmostEqual(2.2*(t.threshold_volume('major_axis')/ve)**(1/3),10,places=9)
        self.assertAlmostEqual(1.4*(t.threshold_volume('minor_axis')/ve)**(1/3),10,places=9)
        m=t.compute()['matched_membrane']
        self.assertAlmostEqual(m['ellipsoid_reference_area_m2']*m['matched_ellipsoid_reference_thickness_um']*1e-6,
                               m['common_material_volume_m3'],places=12)
    def test_duplicate_sphere_criteria(self):
        self.assertEqual(t.threshold_volume('sphere_diameter'),t.threshold_volume('equivalent_sphere'))
    def test_inverse_sensitivity(self):
        r=t.compute();k=138/23.6
        def logv(logk):return math.log(4+b.empirical_free_lift(5,4,math.exp(logk)))
        numeric=t.numeric_derivative(logv,math.log(k),.0001)
        self.assertAlmostEqual(numeric,r['sensitivities']['dlnV_dlnk_at_W_v'],places=4)
    def test_closed_balloon_adiabatic_invariant(self):
        r=t.compute();rows=r['thermal_profiles'];v0=rows[0]['closed_adiabatic_volume_m3'];p0=101325.
        for row in rows:
            ratio=row['pressure_pa']/p0*(row['closed_adiabatic_volume_m3']/v0)**(5/3)
            self.assertAlmostEqual(ratio,1,places=10)
    def test_blowdown_energy_and_eos(self):
        gamma=5/3
        for row in t.compute()['blowdown']:
            n=row['adiabatic_remaining_fraction'];T=row['adiabatic_temperature_ratio'];p=row['pressure_ratio']
            self.assertAlmostEqual(n*T,p,places=12)
            self.assertAlmostEqual(T,n**(gamma-1),places=12)

if __name__=='__main__':unittest.main()
