"""Read-only Excel inventory. Requires openpyxl; never saves a source workbook.
Usage: python audit_workbooks.py --old PATH --new PATH --out audit
Formula caches are labelled explicitly and are NOT Excel recalculation.
"""
import argparse,csv,hashlib,json
from pathlib import Path
import openpyxl

def inventory(path,label):
    wf=openpyxl.load_workbook(path,data_only=False,read_only=False)
    wv=openpyxl.load_workbook(path,data_only=True,read_only=False)
    rows=[];sheets=[]
    for s in wf:
        formula_count=0;errors=[]
        for row in s:
            for c in row:
                if c.value is None:continue
                v=c.value
                if isinstance(v,openpyxl.worksheet.formula.ArrayFormula):v=v.text
                is_formula=isinstance(v,str) and v.startswith('=')
                formula_count+=is_formula
                cache=wv[s.title][c.coordinate]
                if cache.data_type=='e':errors.append({'cell':c.coordinate,'error':cache.value})
                rows.append(dict(workbook=label,sheet=s.title,cell=c.coordinate,
                                 formula="'"+v if is_formula else '',literal='' if is_formula else v,
                                 cached_value=cache.value,number_format=c.number_format,
                                 note=c.comment.text if c.comment else ''))
        sheets.append(dict(name=s.title,dimension=s.calculate_dimension(),formulas=formula_count,cached_errors=errors))
    meta=dict(label=label,filename=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),sheets=sheets)
    wf.close();wv.close()
    return rows,meta

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--old',required=True,type=Path);p.add_argument('--new',required=True,type=Path);p.add_argument('--out',type=Path,default=Path('audit'))
    a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True)
    rows=[];meta=[]
    for label,path in [('A',a.old),('B',a.new)]:
        r,m=inventory(path,label);rows+=r;meta.append(m)
    with (a.out/'formula_inventory.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (a.out/'source_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(f'{len(rows)} occupied cells inventoried; sources unchanged.')

if __name__=='__main__':main()
