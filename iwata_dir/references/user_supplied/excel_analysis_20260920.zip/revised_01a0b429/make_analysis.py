"""Reproduce paper figures and numerical comparisons.
Requires numpy, matplotlib; reads source snapshot values explicitly recorded below.
These constants are source evidence, not model-generated observations.
Run beside balloon_model.py: python make_analysis.py --out .
"""
import argparse,json,math,os
from pathlib import Path
import balloon_model as b

def build(out):
    out=Path(out);data=out/'data';graphs=out/'graphs'
    data.mkdir(exist_ok=True,parents=True);graphs.mkdir(exist_ok=True,parents=True)
    config=json.loads(Path(__file__).with_name('example_config.json').read_text(encoding='utf-8'))
    s=b.run(config,data)
    n=s['gas_moles'];cd=s['effective_cd'];p=101800.;t=278.15
    # Workbook A, 作業用シート D11,D12,D14,G11,G12,D15, saved state.
    old={'source_speed_m_s':140/23.6*math.sqrt(2.07)/(2+2.07)**(1/3),
         'mass_corrected_speed_m_s':b.empirical_speed(2.07,3.5,140/23.6),
         'source_dry_mass_kg':3.5,'source_standard_fill_l':5000}
    old['speed_overestimate_pct']=(old['source_speed_m_s']/old['mass_corrected_speed_m_s']-1)*100
    burst_names=['楕円体：膜厚','等価球：直径','楕円体：長軸','楕円体：短軸','球：膜厚','球：直径']
    burst_values=[27.7,31.3,25.5,34.1,33.45,31.3]
    source_b={'fill_l':5965.819339,'free_lift_kg':2.562937541,'burst_km':31.3,
              'burst_names':burst_names,'burst_values_km':burst_values,
              'isothermal_4cyl_l':5742.574257,'adiabatic_4cyl_l':5377.643472}
    diam=[8+i*.05 for i in range(81)]
    ds=[{'diameter_m':d,'burst_geometric_km':b.burst_altitude(n,d)/1000} for d in diam]
    b.write_csv(data/'diameter_sweep.csv',ds)
    fills=[4+i*.05 for i in range(101)]
    fs=[dict(fill_l=v*1000,burst_d9_44_km=b.burst_altitude(b.gas_moles(v,p,t),9.44)/1000,
             burst_d10_km=b.burst_altitude(b.gas_moles(v,p,t),10)/1000,
             burst_d11_km=b.burst_altitude(b.gas_moles(v,p,t),11)/1000,
             ground_speed_m_s=b.launch_speed(v,4,p,t,cd)) for v in fills]
    b.write_csv(data/'fill_sweep.csv',fs)
    cds=[.2+i*.005 for i in range(81)]
    cs=[dict(cd=c,fill_l=b.volume_for_speed(5,4,p,t,c)*1000) for c in cds]
    b.write_csv(data/'cd_sweep.csv',cs)
    atmos=[dict(geopotential_km=h/1000,pressure_hpa=b.atmosphere(h,False)[1]/100,
                temperature_k=b.atmosphere(h,False)[0]) for h in range(0,40001,250)]
    b.write_csv(data/'standard_atmosphere.csv',atmos)
    # A 破裂高度計算 A5:A29, B/C columns. Manually entered pressures preserved.
    ah=[40,35,32.2,30.5,30.25,30,29.75,29.5,29.25,29,28.75,28.5,28.25,28,26,23.5,22,20.5,18,16,15,13.5,12.7,12,0]
    ap=[2.8714,5.7459,8.6314,10,10.5,11.97,11.5,12,12.5,13.904,13.5,14,14.5,16.161,21.883,30,40.475,50]+[((44.331514-h)/11.880516)**5.255877 for h in ah[18:]]
    pressure_rows=[dict(source_altitude_km=h,source_pressure_hpa=pa,standard_pressure_hpa=b.atmosphere(h*1000,False)[1]/100,
                        relative_difference_pct=(pa/(b.atmosphere(h*1000,False)[1]/100)-1)*100) for h,pa in zip(ah,ap)]
    b.write_csv(data/'source_A_pressure_comparison.csv',pressure_rows)
    z0=s['burst_altitude_m'];h0=b.EARTH_RADIUS*z0/(b.EARTH_RADIUS+z0)
    thermal=[dict(delta_t_k=dt,burst_geometric_km=b.burst_altitude(n,10,dt)/1000) for dt in [-10,0,10]]
    cyl=[]
    for zi in [1,1.05,1.10]:
        cap=b.cylinder_capacity(10,14.7,.2,273.15,278.15,p,t,z_initial=zi)
        cyl.append(dict(z_initial_assumed=zi,capacity_per_cylinder_l=cap,supply_4_l=cap*4,
                        supply_5_l=cap*5,count=math.ceil(s['fill_volume_l']/cap)))
    b.write_csv(data/'cylinder_sensitivity.csv',cyl)
    summary={'baseline':s,'source_A':old,'source_B':source_b,
             'burst_geopotential_km':h0/1000,'burst_geometric_km':z0/1000,
             'burst_at_catalog_9_44m_km':b.burst_altitude(n,9.44)/1000,
             'thermal_sensitivity':thermal,'cylinder_sensitivity':cyl,
             'density_difference_0C':b.densities(101325,273.15)[0]-b.densities(101325,273.15)[1],
             'density_difference_5C':b.densities(p,t)[0]-b.densities(p,t)[1],
             'cd_sweep':cs,'diameter_sweep':ds,'atmosphere':atmos,'old_pressure':pressure_rows,
             'profile':b.upper_air_profile(n,4,cd,10),'fill_sweep':fs}
    (data/'analysis_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    make_plots(summary,graphs)
    return summary

def make_plots(r,path):
    os.environ.setdefault('MPLCONFIGDIR',str(Path(path).parent/'.plot_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.font_manager as fm
    # Prefer a locally installed Japanese font; portable fallback English labels are unnecessary if JP font installed.
    for font in ['C:/Windows/Fonts/YuGothM.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']:
        if Path(font).exists():fm.fontManager.addfont(font);plt.rcParams['font.family']=fm.FontProperties(fname=font).get_name();break
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'svg.fonttype':'path','figure.dpi':140})
    blue='#1565a9';red='#c0523e';teal='#168578'
    def save(fig,name):
        fig.tight_layout(pad=1.6)
        fig.savefig(path/(name+'.png'),dpi=200,bbox_inches='tight');fig.savefig(path/(name+'.svg'),bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.8))
    vals=[r['source_A']['source_speed_m_s'],r['source_A']['mass_corrected_speed_m_s']]
    ax.bar(['A 保存式','A 質量参照のみ修正'],vals,color=[red,blue],width=.52)
    for i,v in enumerate(vals):ax.text(i,v+.08,f'{v:.3f}',ha='center',fontsize=14)
    ax.set(ylim=(0,6.1),ylabel='上昇速度 (m/s)',title='気球質量の参照修正で速度は約10%低下')
    fig.text(.5,.005,'Aの保存条件：1500 g気球＋2000 g吊下物、5000 L＠0℃。k=140/23.6は維持。',ha='center',fontsize=9)
    save(fig,'01_ascent_formula_audit')
    fig,axs=plt.subplots(1,2,figsize=(11,4.8))
    a=r['atmosphere'];o=r['old_pressure']
    axs[0].semilogy([x['geopotential_km'] for x in a],[x['pressure_hpa'] for x in a],color=blue,label='USSA1976層別式')
    axs[0].scatter([x['source_altitude_km'] for x in o],[x['source_pressure_hpa'] for x in o],color=red,s=20,label='A保存値')
    axs[0].set(xlabel='高度 (km)',ylabel='気圧 (hPa)',title='標準大気との比較');axs[0].legend()
    sel=[x for x in o if 28<=x['source_altitude_km']<=31]
    axs[1].plot([x['source_altitude_km'] for x in sel],[x['source_pressure_hpa'] for x in sel],'o-',color=red,label='A保存値')
    sel2=[x for x in a if 28<=x['geopotential_km']<=31]
    axs[1].plot([x['geopotential_km'] for x in sel2],[x['pressure_hpa'] for x in sel2],color=blue,label='USSA1976')
    axs[1].set(xlabel='高度 (km)',ylabel='気圧 (hPa)',title='Aの表には気圧の非単調点がある');axs[1].legend()
    fig.text(.5,.005,'比較用USSA横軸はジオポテンシャル高度。Aの高度定義は未記載。',ha='center',fontsize=9)
    save(fig,'02_atmosphere_audit')
    fig,ax=plt.subplots(figsize=(9,5.8))
    names=r['source_B']['burst_names'];vals=r['source_B']['burst_values_km']
    ax.barh(names[::-1],vals[::-1],color=blue)
    for i,v in enumerate(vals[::-1]):ax.text(v+.15,i,f'{v:.2f}',va='center')
    ax.set(xlim=(0,38),xlabel='シートに保存された高度 (km)',title='破裂条件の選び方で25.5～34.1 km')
    fig.text(.5,.008,'6通りの仮定比較。信頼区間ではない。等価球径と球径は同じ計算を含む。',ha='center',fontsize=9)
    save(fig,'03_burst_criteria')
    fig,axs=plt.subplots(1,2,figsize=(11,4.8))
    cs=r['cd_sweep'];ds=r['diameter_sweep'];s=r['baseline']
    axs[0].plot([x['cd'] for x in cs],[x['fill_l']/1000 for x in cs],color=blue)
    axs[0].scatter([s['effective_cd']],[s['fill_volume_l']/1000],color=red,zorder=5,label=f"基準 Cd={s['effective_cd']:.3f}")
    axs[0].set(xlabel='一定抗力係数 Cd（仮定）',ylabel='現地充填体積 (m³)',title='5 m/sに必要なガス量');axs[0].legend()
    axs[1].plot([x['diameter_m'] for x in ds],[x['burst_geometric_km'] for x in ds],color=teal)
    axs[1].scatter([9.44,10],[r['burst_at_catalog_9_44m_km'],r['burst_geometric_km']],color=red,zorder=5)
    axs[1].set(xlabel='破裂径 (m)',ylabel='幾何高度 (km)',title='同じガス量で破裂径を変更')
    fig.text(.5,.004,'W=4 kg、5℃、1018 hPa。感度範囲は分析者が設定。確率や推奨充填値を表さない。',ha='center',fontsize=9)
    save(fig,'04_parameter_sensitivity')
    fig,ax=plt.subplots(figsize=(8.5,5))
    for key,label,c in [('burst_d9_44_km','破裂径9.44 m（KCI1500参考）',red),('burst_d10_km','破裂径10 m（シート値）',blue),('burst_d11_km','破裂径11 m（感度例）',teal)]:
        ax.plot([x['fill_l']/1000 for x in r['fill_sweep']],[x[key] for x in r['fill_sweep']],label=label,color=c)
    ax.axvline(r['baseline']['fill_volume_l']/1000,color='#777777',ls='--',lw=1)
    ax.set(xlabel='5℃・1018 hPaでの充填体積 (m³)',ylabel='破裂の幾何高度 (km)',title='ガスを増やすほど破裂高度は下がる');ax.legend()
    fig.text(.5,.005,'上空He温度＝標準大気温度、差圧・漏洩なし。型式未確定のためメーカー値は比較用。',ha='center',fontsize=9)
    save(fig,'05_fill_burst_tradeoff')
    fig,ax=plt.subplots(figsize=(8.5,5))
    for cd,c in [(.3,teal),(r['baseline']['effective_cd'],blue),(.6,red)]:
        rows=b.upper_air_profile(r['baseline']['gas_moles'],4,cd,10)
        ax.plot([x['terminal_speed_m_s'] for x in rows],[x['altitude_m']/1000 for x in rows],label=f'Cd={cd:.3f}一定',color=c)
    ax.set(xlabel='相対空気の終端上昇速度 (m/s)',ylabel='幾何高度 (km)',title='一定Cdモデルの高度依存（校正前）');ax.legend()
    fig.text(.5,.005,'標準大気内の1 km以上を計算。実測の上昇曲線ではない。鉛直風、熱遅れ、多段懸吊抗力を省略。',ha='center',fontsize=9)
    save(fig,'06_upper_air_model')
    fig,ax=plt.subplots(figsize=(8.5,5))
    labels=['原B・等温4本\n0℃・1010 hPa','基準整合\n理想気体・4本','基準整合\n理想気体・5本','Z=1.10仮定\n5本']
    vals=[r['source_B']['isothermal_4cyl_l'],s['cylinder_capacity_l']*4,s['cylinder_capacity_l']*5,r['cylinder_sensitivity'][-1]['supply_5_l']]
    ax.bar(labels,[v/1000 for v in vals],color=[red,blue,blue,teal],width=.6)
    ax.axhline(s['fill_volume_l']/1000,color='#222222',ls='--',label=f"必要量 {s['fill_volume_l']/1000:.3f} m³")
    for i,v in enumerate(vals):ax.text(i,v/1000+.08,f'{v/1000:.3f}',ha='center')
    ax.set(ylim=(0,8.5),ylabel='各条件で計算した供給体積 (m³)',title='4本不足は基準状態をそろえても変わらない');ax.legend()
    fig.text(.5,.005,'10 L×14.7→0.2 MPa。整合例は初温0℃・終温5℃、ゲージ圧。Z=1.10は感度仮定。',ha='center',fontsize=9)
    save(fig,'07_cylinder_inventory')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path(__file__).parent);a=p.parse_args();build(a.out)
