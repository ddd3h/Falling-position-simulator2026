"""Conditional interval benchmarks; NOT a reconstruction of GPS flight tracks.

Run: python analysis.py [--input data_directory] [--output result_directory]
Requires numpy and matplotlib. Default input is the script's own directory.
Temperature is an ISA lower-atmosphere proxy, not observed weather.
"""
from pathlib import Path
import argparse, csv, json, math, sys, os
os.environ.setdefault('MPLCONFIGDIR', str(Path.cwd()/'work/matplotlib_cache'))

local_deps = Path.cwd() / 'work/python-deps'
if local_deps.exists():
    sys.path.insert(0, str(local_deps))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, default=Path(__file__).parent)
parser.add_argument('--output', type=Path, default=Path(__file__).parent / 'results')
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
for font in ('Yu Gothic', 'Meiryo', 'Noto Sans CJK JP', 'DejaVu Sans'):
    if any(f.name == font for f in font_manager.fontManager.ttflist):
        plt.rcParams['font.family'] = font
        break
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                     'figure.dpi': 160, 'axes.unicode_minus': False})

def read_csv(name):
    with (args.input / name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write_csv(name, rows):
    if not rows:
        return
    with (args.output / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def yes(x):
    return str(x).lower() == 'true'

# ISA tropospheric temperature proxy on the tabulated altitude coordinate.
# Height datum is unknown; no spurious geoid/ellipsoid precision is claimed.
T0, LAPSE, G, R = 288.15, 0.0065, 9.80665, 287.05287
def temp(z):
    return T0 - LAPSE * np.asarray(z)

def thermal_integral(z):
    return T0*z - LAPSE*z*z/2

def invert_thermal(f):
    return 2*f / (T0 + math.sqrt(T0*T0 - 2*LAPSE*f))

def thermal_predict(z, a, dt=600):
    z_next = invert_thermal(thermal_integral(z) + a*dt)
    if not (0 <= z_next < 11000):
        raise ValueError('Tropospheric formula used outside its intended range')
    return z_next

def rho_ratio(z):
    return (temp(z)/T0)**(G/(R*LAPSE)-1)

def fall_integral(low, high):
    # Integral sqrt(rho/rho0) dz, closed form on this tropospheric model.
    q = (G/(R*LAPSE)-1)/2
    return T0/LAPSE/(q+1)*((temp(low)/T0)**(q+1)-(temp(high)/T0)**(q+1))

rows = read_csv('ascent_intervals.csv')
flights = read_csv('flights.csv')
by_flight = {}
for row in rows:
    by_flight.setdefault(row['flight_id'], []).append(row)
models = ['constant_fixed', 'constant_updated', 'inverseT_fixed', 'inverseT_updated']
labels = ['定速・初回固定', '定速・前区間で更新', '1/T・初回固定', '1/T・前区間で更新']
colors = ['#768793', '#176785', '#cc9c58', '#a94c39']
predictions, per_flight = [], []
for fid, group in by_flight.items():
    valid = [r for r in group if yes(r['eligible_header_600s_proxy'])]
    if not valid:
        continue
    first = valid[0]
    a0, b0 = float(first['z_start']), float(first['z_end'])
    v0 = (b0-a0)/600
    A0 = (thermal_integral(b0)-thermal_integral(a0))/600
    for j in range(1, len(group)):
        target, past = group[j], group[j-1]
        if not yes(target['eligible_causal_pair_from_previous']):
            continue
        assert yes(past['eligible_header_600s_proxy']) and yes(target['eligible_header_600s_proxy'])
        z0, z1, z2 = map(float, (past['z_start'], past['z_end'], target['z_end']))
        assert z1 == float(target['z_start'])
        vp = (z1-z0)/600
        Ap = (thermal_integral(z1)-thermal_integral(z0))/600
        estimates = [z1+v0*600, z1+vp*600,
                     thermal_predict(z1, A0), thermal_predict(z1, Ap)]
        rec = dict(flight_id=fid, flight_label=target['flight_label'],
                   past_cell=past['source_cell'], target_cell=target['source_cell'],
                   anchor_cell=first['source_cell'], current_z_m=z1, target_z_m=z2,
                   duration_assumed_s=600, observed_interval_speed_m_s=(z2-z1)/600)
        for model, estimate in zip(models, estimates):
            rec[model+'_z_m'] = estimate
            rec[model+'_error_m'] = estimate-z2
        predictions.append(rec)
    subset = [p for p in predictions if p['flight_id'] == fid]
    if subset:
        result = dict(flight_id=fid, flight_label=first['flight_label'], n_pairs=len(subset))
        for model in models:
            errors = np.array([p[model+'_error_m'] for p in subset])
            result[model+'_mae_m'] = float(np.mean(abs(errors)))
            result[model+'_bias_m'] = float(np.mean(errors))
        per_flight.append(result)

summary = {'scope': 'Conditional next-600s interval forecast; no absolute telemetry times; '
                    'ISA temperature proxy; not landing prediction accuracy.',
           'n_flights_in_workbook': len(flights), 'n_valid_ascent_intervals': sum(yes(r['eligible_header_600s_proxy']) for r in rows),
           'n_evaluation_flights': len(per_flight), 'n_pairs': len(predictions), 'models': {}}
for model in models:
    errs = np.array([p[model+'_error_m'] for p in predictions])
    summary['models'][model] = {'pooled_mae_m': float(np.mean(abs(errs))),
        'pooled_bias_m': float(np.mean(errs)), 'pooled_rmse_m': float(np.sqrt(np.mean(errs**2))),
        'flight_equal_weight_mae_m': float(np.mean([r[model+'_mae_m'] for r in per_flight]))}

# Leave-one-flight-out aggregation is a robustness diagnostic, not model fitting.
loo = []
for omitted in per_flight:
    group = [r for r in per_flight if r['flight_id'] != omitted['flight_id']]
    b = np.mean([r['constant_fixed_mae_m'] for r in group])
    u = np.mean([r['constant_updated_mae_m'] for r in group])
    loo.append({'omitted_flight': omitted['flight_id'], 'relative_MAE_reduction': float(1-u/b)})
summary['leave_one_flight_out_update_reduction_range'] = [min(r['relative_MAE_reduction'] for r in loo), max(r['relative_MAE_reduction'] for r in loo)]
summary['updated_constant_better_flights'] = sum(r['constant_updated_mae_m'] < r['constant_fixed_mae_m']-1e-6 for r in per_flight)
summary['updated_constant_tied_flights'] = sum(abs(r['constant_updated_mae_m']-r['constant_fixed_mae_m']) < 1e-6 for r in per_flight)
summary['updated_constant_worse_flights'] = sum(r['constant_updated_mae_m'] > r['constant_fixed_mae_m']+1e-6 for r in per_flight)
identifiable = [p for p in predictions if p['past_cell'] != p['anchor_cell']]
summary['n_pairs_with_a_newer_calibration_window'] = len(identifiable)
summary['n_flights_with_a_newer_calibration_window'] = len(set(p['flight_id'] for p in identifiable))

desc = read_csv('descent_intervals.csv')
series_anomaly_flights = {r['flight_id'] for r in desc if 'nonpositive_height_progress_in_declared_phase' in r['flags']}
diagnostics = []
for row in desc:
    if not yes(row['eligible_interval_under_stated_duration']):
        continue
    # An explicit 'unknown' is not rescued by a numeric substring.
    if 'explicit_unknown' in row['flags']:
        continue
    high, low = float(row['z_start']), float(row['z_end'])
    dt = float(row['duration_for_consistency_s'])
    s0 = float(fall_integral(low, high)/dt)
    diagnostics.append(dict(flight_id=row['flight_id'], source_cell=row['source_cell'],
         z_start=high, z_end=low, duration_s=dt, duration_status=row['duration_status'],
         observed_interval_speed_m_s=(high-low)/dt, effective_s0_ISA_m_s=s0,
         flags=row['flags'], series_nonmonotonic_elsewhere=row['flight_id'] in series_anomaly_flights))
summary['n_descent_diagnostics'] = len(diagnostics)
summary['n_descent_flights'] = len(set(r['flight_id'] for r in diagnostics))
summary['descent_effective_s0_minmax_m_s'] = [min(r['effective_s0_ISA_m_s'] for r in diagnostics), max(r['effective_s0_ISA_m_s'] for r in diagnostics)]
desc_flight = []
for fid in sorted(set(r['flight_id'] for r in diagnostics)):
    a = [r for r in diagnostics if r['flight_id'] == fid]
    s = [r['effective_s0_ISA_m_s'] for r in a]
    desc_flight.append(dict(flight_id=fid, n_intervals=len(a), s0_min=min(s), s0_max=max(s),
                           s0_median=float(np.median(s)), ratio_max_min=max(s)/min(s)))

write_csv('ascent_predictions.csv', predictions)
write_csv('ascent_by_flight.csv', per_flight)
write_csv('leave_one_flight_out.csv', loo)
write_csv('descent_diagnostics.csv', diagnostics)
write_csv('descent_by_flight.csv', desc_flight)
(args.output/'results.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')

# Figure 1: observed interval speeds; height midpoint is for plotting only.
fig, axes = plt.subplots(3, 3, figsize=(11.5, 8.4), sharex=True, sharey=False)
for ax, pf in zip(axes.flat, per_flight):
    rr = [r for r in by_flight[pf['flight_id']] if yes(r['eligible_header_600s_proxy'])]
    z = [(float(r['z_start'])+float(r['z_end']))/2000 for r in rr]
    v = [(float(r['z_end'])-float(r['z_start']))/600 for r in rr]
    ax.plot(z, v, 'o-', color=colors[1], label='高度差/600秒')
    A = (thermal_integral(float(rr[0]['z_end']))-thermal_integral(float(rr[0]['z_start'])))/600
    grid = np.linspace(min(z), max(z), 80)
    ax.plot(grid, A/temp(grid*1000), '--', color=colors[2], label='初回合わせ1/T参考形状')
    ax.set_title('第'+str(int(pf['flight_id'].split('_')[1]))+'回'); ax.set_xlabel('区間中点高度 [km]')
    ax.set_ylabel('上昇速度 [m/s]'); ax.grid(alpha=.18)
for ax in list(axes.flat)[len(per_flight):]:
    ax.set_visible(False)
handles, names = axes.flat[0].get_legend_handles_labels()
fig.legend(handles, names, loc='upper center', bbox_to_anchor=(.5,1.01), ncol=2, frameon=False)
fig.suptitle('10分区間と整合する上昇データ：高度依存は便ごとに異なる', y=1.045)
fig.tight_layout(rect=[0, 0, 1, .95]); fig.savefig(args.output/'ascent_profiles.png', bbox_inches='tight'); plt.close(fig)

# Figure 2: the individual flights remain visible to prevent pseudoreplication.
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), gridspec_kw={'width_ratios':[1,1.7]})
vals = [summary['models'][m]['flight_equal_weight_mae_m'] for m in models]
axes[0].barh(labels[::-1], vals[::-1], color=colors[::-1])
for j, val in enumerate(vals[::-1]):
    axes[0].text(val+4, j, f'{val:.1f}', va='center')
axes[0].set_xlim(0, max(vals)*1.2); axes[0].set_xlabel('次10分高度のMAE [m]・便を等重み')
axes[0].set_title(str(len(per_flight))+'便を等重みで集計')
x = np.arange(len(per_flight))
for k, model in enumerate(models):
    axes[1].bar(x+(k-1.5)*.19, [r[model+'_mae_m'] for r in per_flight], .18, label=labels[k], color=colors[k])
axes[1].set_xticks(x, ['第'+str(int(r['flight_id'].split('_')[1]))+'回\n(n='+str(r['n_pairs'])+')' for r in per_flight])
axes[1].set_ylabel('次10分高度のMAE [m]'); axes[1].set_title('便ごとの結果'); axes[1].legend(fontsize=8)
fig.suptitle('条件付き比較：35区間から25組。実際の着地誤差ではない')
fig.tight_layout(); fig.savefig(args.output/'ascent_benchmark.png', bbox_inches='tight'); plt.close(fig)

fig, ax = plt.subplots(figsize=(10,4.8))
for fid in sorted(set(r['flight_id'] for r in diagnostics)):
    rr = sorted([r for r in diagnostics if r['flight_id']==fid], key=lambda r:r['z_end'])
    flagged = fid in series_anomaly_flights
    ax.plot([(r['z_start']+r['z_end'])/2000 for r in rr], [r['effective_s0_ISA_m_s'] for r in rr],
            'x' if flagged else 'o-', label='第'+str(int(fid.split('_')[1]))+'回'+('（系列に疑義）' if flagged else ''), alpha=.85)
ax.set(xlabel='区間中点高度 [km]', ylabel='区間から逆算した海面相当下降速度 [m/s]',
       title='下降の密度補正後にも残る便間差・区間差（標準大気による診断）')
ax.grid(alpha=.2); ax.legend(ncol=5, loc='upper center', bbox_to_anchor=(.5,-.17), fontsize=9)
fig.tight_layout(); fig.savefig(args.output/'descent_effective_s0.png', bbox_inches='tight'); plt.close(fig)

# Analytical checks that are independent of the scoring data.
for z in (0, 100, 1500, 8000, 10000):
    assert abs(invert_thermal(thermal_integral(z))-z)<1e-8
for low, high in ((0,1000), (3000,6000), (0,10000)):
    zz = np.linspace(low,high,20001)
    trap = np.trapezoid(np.sqrt(rho_ratio(zz)),zz) if hasattr(np,'trapezoid') else np.trapz(np.sqrt(rho_ratio(zz)),zz)
    assert abs(fall_integral(low,high)-trap)<1e-5
assert all(float(p['target_z_m'])>float(p['current_z_m']) for p in predictions)
assert len({(p['flight_id'],p['target_cell']) for p in predictions})==len(predictions)
print(json.dumps(summary, ensure_ascii=False, indent=2))
