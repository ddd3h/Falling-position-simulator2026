# 既存飛行データの条件付き解析

主解説は `../balloon_handbook.html` の18–21章です。

- source_data.xlsx / ascent_empirical_paper.pdf：ユーザー提供原本の同一複製。変更していません。
- workbook_audit.html / empirical_paper_review.html：原本セル・論文頁に遡れる監査。
- flights / intervals：欠測・原セル・原文字列・採否を保持したCSV/JSON。上昇90枠、下降60枠。
- ascent_predictions.csv：9便・25組の条件付き次600秒予測。先頭区間は放球時とは限りません。
- descent_diagnostics.csv：標準大気による海面相当速度の逆算。予測スコアではありません。
- symposium_flights.csv / JSON：公開資料から確認した6便。詳細な数値全軌跡・着水座標は今回未取得。
- analysis.py：図3点と集計を再生成する参照プログラム。numpy / matplotlib を使用。

配布ルートで実行：

```text
python existing_data/analysis.py --input existing_data --output regenerated/existing_data
```

約14.8%は、この標本における定速モデルの更新前後の「便等重み・次10分高度MAE」の差です。着地点改善率でも、放球前予報の改善率でもありません。10分表記、標準温度代用、未知の高度基準という条件付きで、成層圏・秒単位更新への検証ではありません。
