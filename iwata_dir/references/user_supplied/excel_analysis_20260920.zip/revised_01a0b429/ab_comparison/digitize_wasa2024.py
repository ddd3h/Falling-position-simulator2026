"""Read an existing PDF figure, without inferring any gas/mass input from speed.

The output is a graph reading, not raw GNSS, a source-reported mean, or a
statistical confidence interval. Coordinates were checked on the source image.
"""
from pathlib import Path
import csv, json, sys
if hasattr(sys.stdout,"reconfigure"):sys.stdout.reconfigure(encoding="utf-8")
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
rgb = np.asarray(Image.open(HERE / "wasa2024_fig4_2_original.jpg").convert("RGB"))
r, g, b = [rgb[:, :, k].astype(float) for k in range(3)]
orange = (r > 180) & (g > 65) & (g < 180) & (b < 125) & (r-g > 50) & (g-b > 25)
orange[:14] = False
orange[490:] = False
orange[:, :112] = False
orange[:, 476:] = False  # ascent only, before apex
x0, x6000, y40000, y0 = 112.0, 790.0, 13.0, 486.0
seconds_per_pixel = 6000.0 / (x6000-x0)
metres_per_pixel = 40000.0 / (y0-y40000)
trace=[]
for x in range(112,476):
    ys=np.flatnonzero(orange[:,x])
    if len(ys):
        y=float(np.median(ys))
        trace.append((x, y, (x-x0)*seconds_per_pixel, (y0-y)*metres_per_pixel))
a=np.array(trace)
with (HERE/"wasa2024_figure_altitude_trace.csv").open("w",newline="",encoding="utf-8") as f:
    writer=csv.writer(f)
    writer.writerow(["image_x_px","orange_median_y_px","elapsed_time_s_graph","altitude_m_graph"])
    writer.writerows(trace)
# Plateau values are consolidated before inverse interpolation.
heights=sorted(set(a[:,3]))
xs=np.array([float(np.mean(a[a[:,3]==h,0])) for h in heights])
def time_at_height(h):
    return (float(np.interp(h,heights,xs))-x0)*seconds_per_pixel
bands=[]
for lo,hi in [(500,3000),(1000,3000),(1000,5000),(5000,10000),(10000,15000),(15000,20000)]:
    tlo,thi=time_at_height(lo),time_at_height(hi)
    dt=thi-tlo
    speed=(hi-lo)/dt
    # Explicit reading-sensitivity exercise, NOT measurement uncertainty or CI:
    # moving either time endpoint by +/-2 image pixels changes duration by +/-4.
    dtime=4*seconds_per_pixel
    bands.append({
        "altitude_band_m":[lo,hi],
        "graph_time_endpoints_s":[tlo,thi],
        "graph_mean_ascent_m_s":speed,
        "rounded_graph_mean_ascent_m_s":round(speed,1),
        "speed_if_each_time_endpoint_moves_2px_m_s":[(hi-lo)/(dt+dtime),(hi-lo)/(dt-dtime)],
        "reading_sensitivity_is_not_statistical_ci":True,
    })
out={
    "source":"WASA 2024, p.3, Fig.4.2",
    "source_url":"https://jaxa.repo.nii.ac.jp/record/2001216/files/SA6000204015.pdf",
    "observation_type":"digitized published GNSS altitude curve; not source-reported numerical means",
    "axis_calibration_pixels":{"t0":x0,"t6000":x6000,"h0":y0,"h40000":y40000},
    "axis_scale":{"seconds_per_pixel":seconds_per_pixel,"metres_per_pixel":metres_per_pixel},
    "algorithm":"Orange pixels -> median y per x -> consolidate repeated height -> linear inverse interpolation -> delta altitude / delta time.",
    "limits":[
        "Original GNSS samples, time stamps, datum and smoothing settings are unavailable.",
        "Graph includes data gaps; interpolation bridges the image curve only.",
        "No source-reported launch height; band endpoints are plotted GNSS altitude.",
        "The speed is ground-relative vertical speed, not corrected for vertical wind.",
        "Pixel sensitivity ignores sensor error, plot preprocessing and axis calibration error.",
        "Image threshold/line width can affect readings; round reported results to 0.1 m/s.",
        "A launch-condition terminal-speed formula is not directly equivalent to a kilometre-wide mean.",
    ],
    "bands":bands
}
(HERE/"wasa2024_digitization.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=False,indent=2))
