"""A vs consistent formula vs a single calibrated coefficient.

All empirical scores are conditional on explicitly supplied mass/gas hypotheses.
Not an identification of the original unit, balloon mass, or flight-wide skill.
Run from distribution root:
  python ab_comparison/comparison.py --input existing_data --output regenerated/ab
Requires numpy and matplotlib. The original workbooks are never modified.
"""
from pathlib import Path
import argparse,csv,json,math,sys,os
if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
os.environ.setdefault('MPLCONFIGDIR',str(Path.cwd()/'work/matplotlib_cache'))
if (Path.cwd()/'work/python-deps').exists():sys.path.insert(0,str(Path.cwd()/'work/python-deps'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent.parent/'existing_data')
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'results')
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
for f in ('Yu Gothic','Meiryo','Noto Sans CJK JP','DejaVu Sans'):
    if any(x.name==f for x in font_manager.fontManager.ttflist):plt.rcParams['font.family']=f;break
plt.rcParams.update({'font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':160})

def read(name):
    with (args.input/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save_csv(name,rows):
    if not rows:return
    with (args.output/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def yes(s):return str(s).lower()=='true'

flights={r['flight_id']:r for r in read('flights.csv')};intervals=read('ascent_intervals.csv')
# The four consecutive flights with the same recorded 8f label and both inputs.
# These choices use metadata availability, not prediction error.
ids=['flight_04','flight_05','flight_06','flight_07']
inputs=[]
def covered_mean(rows,lo,hi):
    cursor=lo;elapsed=0.;used=[]
    for r in sorted(rows,key=lambda x:float(x['z_start'])):
        a,b=float(r['z_start']),float(r['z_end']);left=max(a,lo);right=min(b,hi)
        if right<=left:continue
        if abs(cursor-left)>1e-6:raise ValueError('Gap in common altitude band')
        v=(b-a)/600
        elapsed+=(right-left)/v;cursor=right;used.append(r['source_cell'])
    if abs(cursor-hi)>1e-6:raise ValueError('Incomplete common altitude band')
    return (hi-lo)/elapsed,elapsed,','.join(used)

for fid in ids:
    f=flights[fid];row=int(f['source_row']);r=[q for q in intervals if q['flight_id']==fid and yes(q['eligible_header_600s_proxy'])]
    assert f['balloon_type_raw']=='エミリー(8f)'
    raw_fields=json.loads(f['raw_fields_by_column'])
    mass=float(json.loads(f['mass_explicit_numbers_g'])[0])/1000
    gas=float(f['gas_number_with_explicit_unit'])
    v,dt,cells=covered_mean(r,2000,8000)
    v_all,dt_all,cells_all=covered_mean(r,float(r[0]['z_start']),float(r[-1]['z_end']))
    reported_dt=sum((min(float(t['z_end']),8000)-max(float(t['z_start']),2000))/float(t['v_reported']) for t in r if min(float(t['z_end']),8000)>max(float(t['z_start']),2000))
    inputs.append(dict(flight_id=fid,flight_number=int(fid.split('_')[1]),source_sheet=f['source_sheet'],
        mass_cell='V'+str(row),mass_raw=f['mass_raw'],recorded_mass_kg=mass,
        gas_cell='X'+str(row),gas_raw=f['gas_raw'],recorded_gas_number=gas,
        balloon_cell='W'+str(row),balloon_raw=f['balloon_type_raw'],
        target_v_2_8km_m_s=v,target_elapsed_2_8km_s=dt,target_cells=cells,target_reported_speed_m_s=6000/reported_dt,
        target_first_valid_m_s=(float(r[0]['z_end'])-float(r[0]['z_start']))/600,
        first_valid_cell=r[0]['source_cell'],first_valid_start_m=float(r[0]['z_start']),first_valid_end_m=float(r[0]['z_end']),
        target_all_valid_m_s=v_all,all_valid_cells=cells_all))
save_csv('comparison_inputs.csv',inputs)

def physics(mb,gas_kind='standard_L',mass_scope='payload',q_scale=1.,target='target_v_2_8km_m_s',gas4=2000.,mass5=.950):
    out=[]
    for r in inputs:
        record_mass=mass5 if r['flight_id']=='flight_05' else r['recorded_mass_kg']
        g=gas4 if r['flight_id']=='flight_04' else r['recorded_gas_number']
        # Retain original A's 1.114 kg/m3 to isolate denominator changes.
        # The shared ideal-gas value is an explicitly separate sensitivity case.
        if gas_kind=='literal_mL':Q=1.114*g/1e6*q_scale
        elif gas_kind=='standard_L':Q=1.114*g/1000*q_scale
        elif gas_kind=='Q_grams':Q=g/1000*q_scale
        else:raise ValueError(gas_kind)
        W=record_mass+mb if mass_scope=='payload' else record_mass
        mp=W-mb;L=Q-W
        if mp<0 or L<=0 or Q-mb<=0:
            return None,'payload_negative' if mp<0 else 'not_positive_free_lift'
        xC=math.sqrt(L)/Q**(1/3)/23.6
        xA=math.sqrt(L)/(Q-mb)**(1/3)/23.6
        out.append(dict(flight_id=r['flight_id'],Q_kg=Q,W_kg=W,payload_kg=mp,balloon_kg=mb,L_kg=L,
                        x_common=xC,x_A=xA,observed_v_m_s=r[target],ratio_A_common=xA/xC))
    return out,None

MODELS=['A140','C140','C138','C_cal_LOFO','A_cal_LOFO','mean_only_LOFO']
LABELS={'A140':'元A（K140）','C140':'質量参照のみ修正（K140）','C138':'共通式（K138）',
        'C_cal_LOFO':'共通式・他3便で係数校正','A_cal_LOFO':'A式・他3便で係数校正','mean_only_LOFO':'他3便の単純平均'}
def evaluate(phys):
    x=np.array([r['x_common'] for r in phys]);xa=np.array([r['x_A'] for r in phys]);y=np.array([r['observed_v_m_s'] for r in phys])
    n=len(y);preds={'A140':140*xa,'C140':140*x,'C138':138*x,'C_cal_LOFO':np.empty(n),'A_cal_LOFO':np.empty(n),'mean_only_LOFO':np.empty(n)}
    Ks=[];Kas=[]
    for i in range(n):
        train=np.arange(n)!=i
        k=float(np.dot(x[train],y[train])/np.dot(x[train],x[train]));ka=float(np.dot(xa[train],y[train])/np.dot(xa[train],xa[train]))
        preds['C_cal_LOFO'][i]=k*x[i];preds['A_cal_LOFO'][i]=ka*xa[i];preds['mean_only_LOFO'][i]=float(y[train].mean());Ks.append(k);Kas.append(ka)
    metrics={}
    for name,p in preds.items():
        e=p-y;metrics[name]={'mae_m_s':float(abs(e).mean()),'rmse_m_s':float(np.sqrt((e*e).mean())),'bias_m_s':float(e.mean())}
    rows=[]
    for i,r in enumerate(phys):
        q=dict(r);q['K_common_from_other_3']=Ks[i];q['K_A_from_other_3']=Kas[i]
        for name in MODELS:q[name+'_pred']=float(preds[name][i]);q[name+'_error']=float(preds[name][i]-y[i])
        rows.append(q)
    return {'metrics':metrics,'K_common_full_fit_descriptive_only':float(x@y/(x@x)),
            'K_common_held_out_range':[min(Ks),max(Ks)],'K_A_full_fit_descriptive_only':float(xa@y/(xa@xa)),
            'A_C_cal_prediction_max_difference':float(max(abs(preds['C_cal_LOFO']-preds['A_cal_LOFO'])))},rows

primary_config=dict(mb=.5,gas_kind='standard_L',mass_scope='payload',q_scale=1.)
phys,error=physics(**primary_config);assert not error
primary,predictions=evaluate(phys)
for p in predictions:
    # Diagnostic inversion only: never feed target-derived masses to scoring.
    for K in (140,138):
        L_req=(23.6*p['observed_v_m_s']/K)**2*p['Q_kg']**(2/3)
        p['implied_balloon_mass_at_K'+str(K)+'_diagnostic_only']=p['Q_kg']-p['payload_kg']-L_req
save_csv('conditional_predictions.csv',predictions)
save_csv('conditional_metrics.csv',[dict(model=m,label=LABELS[m],**primary['metrics'][m]) for m in MODELS])

# Sweep the whole prescribed scenario grid without selecting an optimum.
sensitivity=[]
for scope in ('payload','total_dry'):
    for kind in ('standard_L','Q_grams'):
        for scale in (.8,.9,1.,1.1,1.2):
            for im in range(5,136):
                mb=im/100
                ph,err=physics(float(mb),kind,scope,scale)
                row=dict(mass_scope=scope,gas_hypothesis=kind,q_scale=scale,balloon_mass_kg=round(float(mb),3),
                         valid_all_four=not bool(err),invalid_reason=err or '')
                for m in MODELS:row[m+'_mae_m_s']=None
                row['K_common_full_fit']=None
                if ph:
                    result,_=evaluate(ph)
                    for m in MODELS:row[m+'_mae_m_s']=result['metrics'][m]['mae_m_s']
                    row['K_common_full_fit']=result['K_common_full_fit_descriptive_only']
                sensitivity.append(row)
save_csv('assumption_sensitivity.csv',sensitivity)

# Other declared readings of ambiguous mass/volume values, and other targets.
variants=[]
configs=[('main',dict()),('gas4_2100',dict(gas4=2100.)),('mass5_936g',dict(mass5=.936)),
         ('gas4_2100_mass5_936g',dict(gas4=2100.,mass5=.936)),
         ('target_first_valid',dict(target='target_first_valid_m_s')),('target_all_valid',dict(target='target_all_valid_m_s')),
         ('mass_is_total_dry',dict(mass_scope='total_dry')),('gas_is_Q_grams',dict(gas_kind='Q_grams')),
         ('ideal_density',dict(q_scale=1.11369452755/1.114)),('use_reported_interval_speeds',dict(target='target_reported_speed_m_s'))]
for name,change in configs:
    config=dict(primary_config);config.update(change);ph,err=physics(**config);assert not err
    metric,_=evaluate(ph);r=dict(variant=name,**config)
    for m in MODELS:r[m+'_mae_m_s']=metric['metrics'][m]['mae_m_s']
    r['K_common_full_fit']=metric['K_common_full_fit_descriptive_only'];variants.append(r)
# CSV needs all config keys for consistency.
keys=list(dict.fromkeys(k for r in variants for k in r))
save_csv('declared_variants.csv',[{k:r.get(k,'') for k in keys} for r in variants])

# No assumed mass can make the four records share one positive K under the main
# volume/payload interpretation for the relative ordering of flights 4 and 5.
# Q4 < Q5, W4 < W5, but for all admissible common mb, their x ordering is reversed
# relative to observed v4 > v5. Report the broad checked range, not a proof itself.
order_grid=[]
for mb in np.linspace(0,1.42799,1000):
    ph,_=physics(float(mb))
    order_grid.append(ph[1]['x_common']>ph[0]['x_common'])

summary={'scope':'Conditional 4-flight 2–8 km band mean; unknown units/mass are scenarios, not recovered facts.',
 'comparison_date':'2026-09-20','target':'6000 m divided by interpolated travel time, piecewise constant within valid 600s bins',
 'fully_specified_user_flights':0,'flight_ids':ids,'primary_assumptions':primary_config,
 'observed_band_means':[r['target_v_2_8km_m_s'] for r in inputs], 'primary':primary,
 'literal_mL_all_four_admissible':physics(.5,'literal_mL')[0] is not None,
 'main_interpretation_max_balloon_mass_positive_lift_kg':min(1.114*r['recorded_gas_number']/1000-r['recorded_mass_kg'] for r in inputs),
 'scenario_grid_count':len(sensitivity),'scenario_grid_valid_count':sum(r['valid_all_four'] for r in sensitivity),
 'flight5_predicted_faster_than_flight4_over_main_balloon_mass_range':all(order_grid),
 'primary_K_full_fit_is_not_held_out_performance':True,'cross_validation_not_chronological_forecast':True,
 'no_new_experiments':True}
admissible=[r for r in sensitivity if r['valid_all_four']]
reversals=[r for r in admissible if r['A140_mae_m_s']<r['C140_mae_m_s']]
summary['A_closer_scenarios_count_not_probability']=len(reversals)
summary['A_closer_example']=min(reversals,key=lambda r:r['A140_mae_m_s']-r['C140_mae_m_s']) if reversals else None
for scope in ('payload','total_dry'):
    selected=[r for r in sensitivity if r['valid_all_four'] and r['mass_scope']==scope and r['gas_hypothesis']=='standard_L' and r['q_scale']==1]
    summary[scope+'_standard_L_sweep']={'n':len(selected),
      'A140_mae_range':[min(r['A140_mae_m_s'] for r in selected),max(r['A140_mae_m_s'] for r in selected)],
      'C140_mae_range':[min(r['C140_mae_m_s'] for r in selected),max(r['C140_mae_m_s'] for r in selected)],
      'C_cal_mae_range':[min(r['C_cal_LOFO_mae_m_s'] for r in selected),max(r['C_cal_LOFO_mae_m_s'] for r in selected)],
      'C_cal_better_than_mean_cases':sum(r['C_cal_LOFO_mae_m_s']<r['mean_only_LOFO_mae_m_s'] for r in selected),
      'A140_better_than_C140_cases':sum(r['A140_mae_m_s']<r['C140_mae_m_s'] for r in selected)}
(args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

colors=['#ba6647','#6899a7','#366b82','#254a67','#ac9454','#8c9398']
fig,axes=plt.subplots(1,2,figsize=(12.3,4.7),gridspec_kw={'width_ratios':[1.3,1]})
x=np.arange(4)
axes[0].plot(x,[r['observed_v_m_s'] for r in predictions],'ko-',label='記録からの2–8 km平均',linewidth=2)
for model,color in zip(MODELS[:4],colors):
    axes[0].plot(x,[r[model+'_pred'] for r in predictions],'o--',color=color,label=LABELS[model])
axes[0].set(xticks=x,xticklabels=['第'+str(r['flight_number'])+'回' for r in inputs],ylabel='上昇速度 [m/s]',title='仮例：標準L・記載質量は吊下物・膜0.50 kg')
axes[0].legend(fontsize=8,loc='upper left',bbox_to_anchor=(0,-.12));axes[0].grid(alpha=.2)
names=MODELS[:4]+['mean_only_LOFO'];values=[primary['metrics'][m]['mae_m_s'] for m in names]
axes[1].barh([LABELS[m] for m in names][::-1],values[::-1],color=(colors[:4]+[colors[5]])[::-1])
for i,v in enumerate(values[::-1]):axes[1].text(v+.025,i,f'{v:.3f}',va='center')
axes[1].set(xlim=(0,max(values)*1.18),xlabel='4便のMAE [m/s]',title='校正値は対象便を除いて推定')
fig.suptitle('条件付き実測比較：係数校正と、モデル形状の優位性は別',y=1.015)
fig.tight_layout();fig.savefig(args.output/'conditional_comparison.png',bbox_inches='tight');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(12,4.5),sharey=True)
for ax,scope,title in zip(axes,['payload','total_dry'],['記載質量＝吊下物','記載質量＝膜を含む乾燥総質量']):
    rows=[r for r in sensitivity if r['valid_all_four'] and r['mass_scope']==scope and r['gas_hypothesis']=='standard_L' and r['q_scale']==1.]
    for model,color in zip(MODELS,colors):
        ax.plot([r['balloon_mass_kg'] for r in rows],[r[model+'_mae_m_s'] for r in rows],color=color,
                linestyle=':' if model.endswith('LOFO') else '-',label=LABELS[model])
    ax.axvline(.5,color='#555',linewidth=.7,alpha=.6);ax.set(title=title,xlabel='仮定した共通膜質量 [kg]',ylabel='4便のMAE [m/s]');ax.grid(alpha=.2)
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,-.08),ncol=3,fontsize=9)
fig.suptitle('標準L解釈の膜質量感度：横軸は推定値・確率分布ではない')
fig.tight_layout();fig.savefig(args.output/'mass_sensitivity.png',bbox_inches='tight');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(11.5,4.6))
mu=np.linspace(0,.65,100)
axes[0].plot(mu,100*((1-mu)**(-1/3)-1),color=colors[0],linewidth=2)
axes[0].set(xlabel='膜質量 / 正味ガス揚力  mb/Q',ylabel='元Aの速度上振れ [%]',title='同じKの比較：上振れは一定でない');axes[0].grid(alpha=.2)
for i,r in enumerate(predictions):
    axes[0].plot(r['balloon_kg']/r['Q_kg'],100*(r['ratio_A_common']-1),'o',color='#254a67',label='4便の仮例（膜0.50 kg）' if i==0 else None)
axes[0].plot(1.5/5.57,100*((1-1.5/5.57)**(-1/3)-1),'s',color='#111',label='A原本の保存入力');axes[0].legend()
for scope,style in [('payload','-'),('total_dry','--')]:
    rs=[r for r in sensitivity if r['valid_all_four'] and r['mass_scope']==scope and r['gas_hypothesis']=='standard_L' and r['q_scale']==1]
    axes[1].plot([r['balloon_mass_kg'] for r in rs],[r['K_common_full_fit'] for r in rs],style,label='記載質量＝'+('吊下物' if scope=='payload' else '乾燥総質量'))
axes[1].axhline(140,color=colors[0],linestyle=':',label='原A K140');axes[1].axhline(138,color=colors[2],linestyle=':',label='B K138')
axes[1].set(xlabel='仮定した共通膜質量 [kg]',ylabel='4便全体に合わせた有効K',title='較正Kも入力解釈に依存する');axes[1].legend(fontsize=9);axes[1].grid(alpha=.2)
fig.tight_layout();fig.savefig(args.output/'compensation_identifiability.png',bbox_inches='tight');plt.close(fig)
print(json.dumps(summary,ensure_ascii=False,indent=2))
