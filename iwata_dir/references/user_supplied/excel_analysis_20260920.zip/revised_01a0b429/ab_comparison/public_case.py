"""Conditional WASA 2024 illustration; not a held-out score or calibration.

Uses declared nominal inputs and a separately digitized published GNSS curve.
Run: python ab_comparison/public_case.py --output regenerated/public_case.json
Only Python's standard library is required.
"""
from pathlib import Path
import argparse, json, math

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path,default=Path(__file__).with_name('public_case.json'))
a=p.parse_args()
digitized=json.loads(Path(__file__).with_name('wasa2024_digitization.json').read_text(encoding='utf-8'))
band=next(b for b in digitized['bands'] if b['altitude_band_m']==[1000,5000])
Q=1.114*13.540
mb=2.000
mp=3.624
L=Q-mb-mp
out={
 'source_url':'https://jaxa.repo.nii.ac.jp/record/2001216/files/SA6000204015.pdf',
 'source_locations':'p.2 Table 3.1; p.3 Table 3.5 and Figure 4.2',
 'conditional_only':True,
 'not_in_four_flight_cross_validation':True,
 'reported_inputs':{'He_quantity_L':13540,'payload_g':3624,'balloon_model':'Cosmoprene 2000'},
 'assumptions':{'quantity_is_standard_L':True,'balloon_kg':mb,'balloon_mass_is_nominal_class_not_measured':True,'suspended_payload_kg':mp,'suspended_mass_scope_unconfirmed':True,'same_K':140,'A_original_density_difference_kg_m3':1.114},
 'computed':{'Q_kg':Q,'L_kg':L,'A140_m_s':140/23.6*math.sqrt(L)/(Q-mb)**(1/3),'C140_m_s':140/23.6*math.sqrt(L)/Q**(1/3)},
 'independent_graph_reading':band,
 'limits':[
  'Launch-condition terminal speeds are treated as constant across 1-5 km only for this illustration.',
  'Graph reading is not raw GNSS or a source-reported numerical mean.',
  'Actual gas quantity, reference temperature and pressure are unspecified.',
  'Nominal balloon class is not a measured envelope mass; payload scope may omit chute/lines.',
  'Pixel perturbation is a reading sensitivity, not a confidence interval or total observation uncertainty.',
  'No empirical coefficient was fit or transferred from the four 8f flights.'
 ]
}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out['computed']))
