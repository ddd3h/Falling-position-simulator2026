# A/C式の条件付き比較と再現手順

2026年9月20日。主説明は[解説書22章](../balloon_handbook.html#chapter-22)。元A、整合共通式、他3便で1係数を校正した式、他3便の単純平均を、同じ4便の2–8 km平均上昇速度で比較します。単位・ガス状態・膜質量・質量範囲は仮定であり、原記録の確定値へ書き換えていません。

## 結果の位置づけ

主例（標準L、質量欄＝吊下物、膜0.50 kg）では、元A K140のMAE 2.868 m/s、共通式K140は2.532 m/s、他3便で校正した共通式は0.297 m/s、他3便の単純平均は0.187 m/s。元Aの優位や、質量・ガス量を使う式の追加の予測力は確認できません。膜0.50 kgは実測・最適化した値ではなく説明用の仮定です。1910条件の適合シナリオを試しており、条件数は確率ではありません。

## 収録内容

- `comparison_inputs.csv`：原セル・原表記・比較高度帯・目的変数。
- `conditional_predictions.csv`、`conditional_metrics.csv`：6モデルの予測と誤差。
- `assumption_sensitivity.csv`：2620条件。全4便が収支を満たす1910条件と不成立条件。
- `declared_variants.csv`、`summary.json`：別記値・対象区間などの感度、集計。
- [入力監査](input_audit.html)、[式の識別性](theory_review.html)、[公開6便の監査](public_evidence.html)。
- `public_case.json`：WASA 2024を別型式・別高度帯として扱う条件付き参考。4便の校正・集計へ混ぜていません。
- `wasa2024_digitization.json`、`wasa2024_figure_altitude_trace.csv`：公開図を今回読み取った値。生GNSSではありません。
- `wasa2024_fig4_2_original.jpg`：図読取りの照合用に抽出した図4.2。[松永ほか、2024年度大気球シンポジウム、p.3](https://jaxa.repo.nii.ac.jp/record/2001216/files/SA6000204015.pdf)に帰属します。元画像を確認し、座標対応を保持しています。

## 再計算

配布フォルダーのルートで、Python 3、numpy、matplotlibを用いて次を実行します。本文中の数字は丸めていますがCSV/JSONは計算値を保持しています。

```text
python ab_comparison/comparison.py --input existing_data --output regenerated/ab_comparison
python ab_comparison/public_case.py --output regenerated/public_case.json
```

図の読取りを再生成する場合だけPillowも必要です。`python ab_comparison/digitize_wasa2024.py`はこのフォルダーの図から読取りJSON/CSVを再生成します。再計算は入力の意味を確定する操作ではありません。図読取りの±2画素は感度例であり、信頼区間ではありません。

## 適用範囲

10分は原表の列見出しを採用した区間長です。地上の設計速度を高度帯の一定速度として利用する場合の診断であり、抗力係数そのものの同定や着地点精度の実証ではありません。1便ずつ保留する比較には後日の便が学習に入る場合があり、時系列の運用再現ではありません。原Excel・修正版Excelの係数は今回変更していません。新たな実験を前提にせず、同条件の既存便で単純基準を上回れるかを採用条件とします。
