"""A/B mathematical comparison. Core calculations require only balloon_model.py.
Run: python theory_analysis.py --out . [--plots]
Graphs additionally require numpy/matplotlib. All curves are model calculations.
"""
import argparse,json,math,os
from pathlib import Path
import balloon_model as b

def threshold_volume(mode,diameter_m=10.,thickness_ratio=26.,length_m=2.2,width_m=1.4):
    if mode in ('equivalent_sphere','sphere_diameter'):return math.pi*diameter_m**3/6
    if mode=='sphere_thickness':return math.pi*length_m**3/6*thickness_ratio**1.5
    ve=math.pi*length_m*width_m**2/6
    if mode=='ellipsoid_thickness':return ve*thickness_ratio**1.5
    if mode=='major_axis':return ve*(diameter_m/length_m)**3
    if mode=='minor_axis':return ve*(diameter_m/width_m)**3
    raise ValueError('Unknown threshold mode')

def numeric_derivative(fun,x,step):return (fun(x+step)-fun(x-step))/(2*step)

def compute():
    p,t,delta0=101800.,278.15,1.115
    ra,rg=b.densities(p,t);delta=ra-rg
    m=4.;k=138/23.6;L=b.empirical_free_lift(5,m,k);Q=m+L
    n=b.gas_moles(Q/delta,p,t)
    common=[]
    for mass in [3.5,4.]:
        for kval in [140/23.6,138/23.6]:
            free=b.empirical_free_lift(5,mass,kval)
            Vstd=(mass+free)/delta0
            Vsite=(mass+free)/delta
            forward=b.empirical_speed(delta0*Vstd-mass,mass,kval)
            common.append(dict(dry_mass_kg=mass,original_K=round(kval*23.6),k=kval,
                               target_m_s=5.,free_lift_kg=free,standard_fill_l=Vstd*1000,
                               site_fill_ideal_l=Vsite*1000,forward_recheck_m_s=forward))
    steps=[('A保存式',5000,3.5,140,1.114,2.0),
           ('質量参照だけ修正',5000,3.5,140,1.114,3.5),
           ('密度差をB値へ',5000,3.5,140,1.115,3.5),
           ('乾燥質量を4kgへ',5000,4.,140,1.115,4.),
           ('係数を138へ',5000,4.,138,1.115,4.),
           ('ガス量をB逆算値へ',Q/delta0*1000,4.,138,1.115,4.)]
    path=[]
    for label,vl,mass,K,d0,denmass in steps:
        free=d0*vl/1000-mass
        v=b.empirical_speed(free,denmass,K/23.6)
        path.append(dict(step=label,standard_fill_l=vl,physical_dry_mass_kg=mass,
                         denominator_mass_kg=denmass,K=K,density_difference_0C=d0,
                         free_lift_kg=free,speed_m_s=v))
    curves=[]
    for vl in range(4000,8001,50):
        row={'standard_fill_l':vl}
        for mass,K,label in [(3.5,140,'W3_5_K140'),(4.,140,'W4_K140'),(4.,138,'W4_K138')]:
            free=delta0*vl/1000-mass
            row[label]=b.empirical_speed(free,mass,K/23.6) if free>=0 else None
        curves.append(row)
    modes=['ellipsoid_thickness','equivalent_sphere','major_axis','minor_axis','sphere_thickness','sphere_diameter']
    names=['楕円体の膜厚','等価球の直径','楕円体の長軸','楕円体の短軸','球の膜厚','球の直径']
    old=[27.7,31.3,25.5,34.1,33.45,31.3]
    thresholds=[]
    for mode,name,h in zip(modes,names,old):
        v=threshold_volume(mode);d=(6*v/math.pi)**(1/3)
        z=b.burst_altitude(n,d)
        thresholds.append(dict(mode=mode,label=name,threshold_volume_m3=v,equivalent_diameter_m=d,
                               common_geometric_km=z/1000,common_geopotential_km=b.EARTH_RADIUS*z/(b.EARTH_RADIUS+z)/1000,
                               source_B_saved_km=h))
    e=math.sqrt(1-(1.4/2.2)**2)
    area_e=2*math.pi*(1.4/2)**2*(1+2.2/(1.4*e)*math.asin(e))
    area_s=math.pi*2.2**2
    thickness_e=130*area_s/area_e
    membrane=dict(sphere_reference_area_m2=area_s,ellipsoid_reference_area_m2=area_e,
                  sphere_reference_thickness_um=130.,common_burst_thickness_um=5.,
                  common_material_volume_m3=area_s*130e-6,
                  matched_ellipsoid_reference_thickness_um=thickness_e,
                  sphere_burst_m3=threshold_volume('sphere_thickness'),
                  matched_ellipsoid_burst_m3=threshold_volume('ellipsoid_thickness',thickness_ratio=thickness_e/5))
    membrane['matched_ellipsoid_relative_change']=membrane['matched_ellipsoid_burst_m3']/membrane['sphere_burst_m3']-1
    standard_factor=t/273.15*101325/p
    sheet_site=Q/delta0*standard_factor
    sheet_moles=b.gas_moles(sheet_site,p,t)
    standard_delta_ideal=b.densities(101325,273.15)[0]-b.densities(101325,273.15)[1]
    model_series=[dict(series='source_density_approximation',standard_density_difference=delta0,
                       standard_l=Q/delta0*1000,site_l=sheet_site*1000,gas_moles=sheet_moles),
                  dict(series='consistent_ideal_gas',standard_density_difference=standard_delta_ideal,
                       standard_l=Q/standard_delta_ideal*1000,site_l=Q/delta*1000,gas_moles=n)]
    volume_path=[]
    previous=None
    for label,mass,K,d0,target,site in [
            ('A修正後を出発点',3.5,140,1.114,b.empirical_speed(2.07,3.5,140/23.6),False),
            ('目標速度5m/s',3.5,140,1.114,5.,False),
            ('乾燥質量4kg',4.,140,1.114,5.,False),
            ('係数138',4.,138,1.114,5.,False),
            ('密度差1.115',4.,138,1.115,5.,False),
            ('現地体積へ表示換算',4.,138,1.115,5.,True)]:
        free=b.empirical_free_lift(target,mass,K/23.6)
        volume=(mass+free)/d0*1000*(standard_factor if site else 1)
        volume_path.append(dict(step=label,volume_l=volume,change_l=None if previous is None else volume-previous,
                                state='5C_1018hPa' if site else '0C_1013.25hPa'))
        previous=volume
    h_b=b.EARTH_RADIUS*b.burst_altitude(n,10)/(b.EARTH_RADIUS+b.burst_altitude(n,10))
    temp=b.atmosphere(h_b,False)[0]
    slope=(.001+b.G0/b.R_AIR)/temp # valid at this 20--32 km H
    geomfactor=(b.EARTH_RADIUS/(b.EARTH_RADIUS-h_b))**2
    a=.5-L/(3*Q)
    sensitivities={'free_lift_ratio_L_over_Q':L/Q,'dlnv_dlnL_at_W_k':a,
                   'dlnV_dlnv_at_W_k':(L/Q)/a,'dlnV_dlnk_at_W_v':-(L/Q)/a,
                   'dlnV_dlnCd_at_W_v_state':.5*(L/Q)/a,
                   'dv_dm_at_fixed_gas_m_s_per_kg':-5/(2*L),
                   'burst_m_per_ln_diameter_geometric':3/slope*geomfactor,
                   'burst_m_per_ln_moles_geometric':-1/slope*geomfactor}
    # Thermal constitutive comparison: each branch starts at standard sea level.
    # State evaluation only; not an integrated trajectory. A branch with L<=0 cannot
    # be interpreted as buoyancy-driven ascent to the evaluated height.
    profiles=[]
    for H in range(0,35001,250):
        ta,pa,rhoa=b.atmosphere(H,False)
        ts={'equilibrium':ta,'isothermal':288.15,'closed_adiabatic':288.15*(pa/101325)**.4}
        row=dict(geopotential_km=H/1000,ambient_k=ta,pressure_pa=pa)
        for mode,tg in ts.items():
            v=n*b.R*tg/pa
            row[mode+'_temperature_k']=tg
            row[mode+'_volume_m3']=v
            row[mode+'_free_lift_kg']=rhoa*v-4-n*b.M_HE
        profiles.append(row)
    def adfree(H):
        ta,pa,rhoa=b.atmosphere(H,False);tg=288.15*(pa/101325)**.4
        return rhoa*n*b.R*tg/pa-4-n*b.M_HE
    neutral=b.bisect_root(adfree,0,20000)
    pi=14.7e6+p;pf=.2e6+p;ratio=pf/pi;gamma=5/3
    ci=b.cylinder_capacity(10,14.7,.2,273.15,273.15,p,t)
    ce=b.cylinder_capacity(10,14.7,.2,273.15,278.15,p,t)
    ca,tf=b.adiabatic_capacity(10,14.7,.2,273.15,p,t)
    blowdown=[]
    for idx in range(1,101):
        r=idx/100
        blowdown.append(dict(pressure_ratio=r,isothermal_remaining_fraction=r,
                            adiabatic_remaining_fraction=r**(1/gamma),adiabatic_temperature_ratio=r**((gamma-1)/gamma)))
    heat_cases=[dict(case='等温ボンベ',final_k=273.15,capacity_l=ci),
                dict(case='終温5℃の端点収支',final_k=278.15,capacity_l=ce),
                dict(case='断熱流出の理想極限',final_k=tf,capacity_l=ca)]
    return dict(common_conditions=common,path_decomposition=path,forward_curves=curves,
                thresholds=thresholds,thermal_profiles=profiles,adiabatic_neutral_geopotential_km=neutral/1000,
                sensitivities=sensitivities,blowdown=blowdown,cylinder_cases=heat_cases,
                baseline=dict(dry_mass_kg=m,free_lift_kg=L,net_gas_lift_kg=Q,fill_ideal_l=Q/delta*1000,
                              fill_standard_sheet_l=Q/delta0*1000,gas_moles=n,k=k,pressure_pa=p,temperature_k=t),
                surface_areas=dict(sphere_m2=area_s,ellipsoid_m2=area_e,ratio=area_s/area_e),
                matched_membrane=membrane,model_series=model_series,volume_decomposition=volume_path,
                cylinder_pressure_ratio=ratio,
                notes=['All matched comparisons are reconstructed mathematical calculations, not Excel-engine recalc.',
                       'common_conditions.standard_fill_l and site_fill_ideal_l use different density models; see model_series for consistent conversions.',
                       'Source B heights are cached original values. Recomputed common heights use the same gas moles, atmosphere, and altitude definition for all six thresholds.',
                       'Thermal curves are constitutive state comparisons. Constant-temperature and fully adiabatic cases are not flight forecasts.'])

def plots(r,out):
    os.environ.setdefault('MPLCONFIGDIR',str(out.parent/'.theory_plot_cache'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.font_manager as fm
    for font in ['C:/Windows/Fonts/YuGothM.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']:
        if Path(font).exists():fm.fontManager.addfont(font);plt.rcParams['font.family']=fm.FontProperties(fname=font).get_name();break
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'svg.fonttype':'path'})
    colors=['#1666ab','#259183','#bd604c']
    def save(fig,name):
        fig.tight_layout(pad=1.6)
        for ext in ['png','svg']:fig.savefig(out/(name+'.'+ext),dpi=200,bbox_inches='tight')
        plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    for key,label,c in [('W3_5_K140','W=3.5 kg, K=140',colors[0]),('W4_K140','W=4.0 kg, K=140',colors[1]),('W4_K138','W=4.0 kg, K=138',colors[2])]:
        ax.plot([x['standard_fill_l']/1000 for x in r['forward_curves']],[x[key] for x in r['forward_curves']],label=label,color=c)
    ax.axhline(5,color='#333',linestyle='--',label='Bの目標5 m/s')
    for x in r['common_conditions']:
        if x['dry_mass_kg']==3.5 and x['original_K']==138:continue
        ax.scatter(x['standard_fill_l']/1000,5,color='#222',s=25,zorder=5)
    ax.set(xlabel='標準充填体積 Vstd (m³、0℃・1013.25 hPa)',ylabel='上昇速度 (m/s)',title='Aの順算とBの逆算は同じ曲線を逆向きに使う');ax.legend()
    fig.text(.5,.004,'共通密度差1.115 kg/m³、k=K/23.6。Aの参照不具合を除いて比較。',ha='center',fontsize=9)
    save(fig,'08_forward_inverse')
    fig,ax=plt.subplots(figsize=(10,5))
    labels=['A保存式','質量参照修正','密度差をBへ','総質量4 kg','係数138','Bの充填量']
    vals=[x['speed_m_s'] for x in r['path_decomposition']]
    ax.plot(range(6),vals,'o-',color=colors[0]);ax.set_xticks(range(6),labels)
    for i,v in enumerate(vals):ax.text(i,v+(.15 if i==1 else -.19 if i==2 else .08),f'{v:.3f}',ha='center')
    ax.set(ylabel='上昇速度 (m/s)',ylim=(3.7,5.65),title='保存値の差を一つずつの変更に分解する')
    fig.text(.5,.004,'変更順序を固定した経路比較。相互作用があるため各差は普遍的・独立な寄与率ではない。',ha='center',fontsize=9)
    save(fig,'09_condition_decomposition')
    fig,ax=plt.subplots(figsize=(9,5.5))
    vals=[x['threshold_volume_m3'] for x in r['thresholds']]
    labels=[x['label'] for x in r['thresholds']]
    ax.barh(labels[::-1],vals[::-1],color=colors[0])
    for i,v in enumerate(vals[::-1]):ax.text(v+8,i,f'{v:.1f} m³',va='center')
    ax.set(xlabel='破裂と判定する体積 Vb (m³)',xlim=(0,940),title='6方式の違いを共通の体積閾値へ換算する')
    fig.text(.5,.004,'参照長2.2 m、幅1.4 m、t0/tb=26、径・軸の閾値10 m。元シートの仮定を代数的に再現。',ha='center',fontsize=9)
    save(fig,'10_burst_volume_thresholds')
    fig,axs=plt.subplots(1,2,figsize=(11,5))
    for mode,label,c in [('equilibrium','外気温に追従',colors[0]),('isothermal','気球ガス温度一定',colors[1]),('closed_adiabatic','閉鎖気球の完全断熱',colors[2])]:
        x=[v['geopotential_km'] for v in r['thermal_profiles']]
        axs[0].plot(x,[v[mode+'_temperature_k'] for v in r['thermal_profiles']],label=label,color=c)
        axs[1].plot(x,[v[mode+'_free_lift_kg'] for v in r['thermal_profiles']],label=label,color=c)
    axs[0].set(xlabel='ジオポテンシャル高度 (km)',ylabel='He温度 (K)',title='3つの熱仮定');axs[0].legend(fontsize=9)
    axs[1].axhline(0,color='#333',linestyle='--');axs[1].set(xlabel='ジオポテンシャル高度 (km)',ylabel='自由浮力 L (kg相当)',title='完全断熱では途中で正の自由浮力を失う')
    fig.text(.5,.003,'全ケースを標準海面15℃から開始した仮想状態比較。浮力0以降や破裂閾値以降への到達を示す軌道ではない。',ha='center',fontsize=9)
    save(fig,'11_thermal_assumptions')
    fig,axs=plt.subplots(1,2,figsize=(11,5))
    rows=r['blowdown'];x=[v['pressure_ratio'] for v in rows]
    axs[0].plot(x,[v['isothermal_remaining_fraction'] for v in rows],label='等温：nf/ni=Pf/Pi',color=colors[0])
    axs[0].plot(x,[v['adiabatic_remaining_fraction'] for v in rows],label='断熱流出：(Pf/Pi)^(1/γ)',color=colors[2]);axs[0].legend(fontsize=9)
    axs[0].set(xlabel='絶対圧比 Pf/Pi',ylabel='残存mol比 nf/ni',title='同じ終了圧でも残るmol数が違う')
    vals=[v['capacity_l'] for v in r['cylinder_cases']]
    axs[1].bar(['等温0℃','終温5℃','断熱極限'],vals,color=[colors[0],colors[1],colors[2]])
    for i,v in enumerate(vals):axs[1].text(i,v+10,f'{v:.1f}',ha='center')
    axs[1].set(ylabel='5℃1018 hPaへ換算した供給量 (L)',ylim=(0,1650),title='10 Lボンベ1本の理想計算')
    fig.text(.5,.003,'初温0℃、初圧14.7・終圧0.2 MPaゲージ、γ=5/3、Z=1。実機の壁・配管との熱交換を省略。',ha='center',fontsize=9)
    save(fig,'12_cylinder_thermal_models')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=Path(__file__).parent);p.add_argument('--plots',action='store_true');a=p.parse_args()
    data=a.out/'theory_data';figs=a.out/'theory_graphs';data.mkdir(parents=True,exist_ok=True);figs.mkdir(parents=True,exist_ok=True)
    r=compute()
    (data/'theory_results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    for key in ['common_conditions','path_decomposition','thresholds','thermal_profiles','blowdown','cylinder_cases','model_series','volume_decomposition']:
        b.write_csv(data/(key+'.csv'),r[key])
    if a.plots:plots(r,figs)
    print(json.dumps({k:r[k] for k in ['common_conditions','path_decomposition','thresholds','sensitivities','cylinder_cases','adiabatic_neutral_geopotential_km']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
