"""Transparent latex-balloon reference model. SI units; Python 3.10+, stdlib only.

This is a deterministic comparison model, not a calibrated flight forecast.
Atmosphere: US Standard Atmosphere 1976 layers, 0--47 km geopotential.
Gas: ideal He; envelope overpressure and gas-air temperature difference optional.
Cylinder: measured endpoint inventory with optional compressibility factors Z.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path

R = 8.31446261815324
M_HE = 0.004002602
M_AIR = 0.0289644
R_AIR = 287.05287
G0 = 9.80665
EARTH_RADIUS = 6356766.0
MAX_GEOMETRIC_ALTITUDE_M = EARTH_RADIUS*47000/(EARTH_RADIUS-47000)
LAYERS = [(0., 11000., -0.0065), (11000., 20000., 0.),
          (20000., 32000., 0.001), (32000., 47000., 0.0028)]

def positive(name, value, allow_zero=False):
    if not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    if value < 0 or (value == 0 and not allow_zero):
        raise ValueError(f"{name} must be {'nonnegative' if allow_zero else 'positive'}")
    return float(value)

def bisect_root(f, lo, hi, tol=1e-8):
    """Bracketed root, finite inputs. Does not assume an Excel cached result."""
    flo, fhi = f(lo), f(hi)
    if flo == 0: return lo
    if fhi == 0: return hi
    if not all(map(math.isfinite, (flo, fhi))) or flo*fhi > 0:
        raise ValueError("Root is not bracketed in the model domain")
    for _ in range(200):
        mid = (lo+hi)/2
        fm = f(mid)
        if not math.isfinite(fm): raise ValueError("Nonfinite root function")
        if hi-lo < tol: return mid
        if flo*fm <= 0: hi = mid
        else: lo, flo = mid, fm
    raise ArithmeticError("Bisection did not converge")

def atmosphere(altitude_m, geometric=True):
    """Returns (T[K], p[Pa], rho[kg/m3]); dry standard air, not today's weather."""
    positive('altitude_m', altitude_m, True)
    h = EARTH_RADIUS*altitude_m/(EARTH_RADIUS+altitude_m) if geometric else altitude_m
    if h > 47000+1e-8: raise ValueError("Atmosphere limited to 47 km geopotential")
    h = min(h,47000.)
    t, p = 288.15, 101325.0
    for low, high, lapse in LAYERS:
        dh = min(h, high)-low
        if dh <= 0: break
        if lapse == 0:
            p *= math.exp(-G0*dh/(R_AIR*t))
        else:
            tnew = t+lapse*dh
            p *= (tnew/t)**(-G0/(R_AIR*lapse))
            t = tnew
        if h <= high: break
    return t, p, p/(R_AIR*t)

def densities(pressure_pa, air_temperature_k, gas_temperature_k=None, overpressure_pa=0.):
    positive('pressure_pa', pressure_pa)
    positive('air_temperature_k', air_temperature_k)
    tg = air_temperature_k if gas_temperature_k is None else positive('gas_temperature_k', gas_temperature_k)
    positive('overpressure_pa', overpressure_pa, True)
    return pressure_pa/(R_AIR*air_temperature_k), (pressure_pa+overpressure_pa)*M_HE/(R*tg)

def empirical_speed(free_lift_kg, dry_mass_kg, coefficient):
    positive('free_lift_kg', free_lift_kg, True)
    positive('dry_mass_kg', dry_mass_kg)
    positive('coefficient', coefficient)
    return coefficient*math.sqrt(free_lift_kg)/(dry_mass_kg+free_lift_kg)**(1/3)

def empirical_free_lift(speed_m_s, dry_mass_kg, coefficient):
    positive('speed_m_s', speed_m_s, True)
    positive('dry_mass_kg', dry_mass_kg)
    positive('coefficient', coefficient)
    if speed_m_s == 0: return 0.
    hi = 1.
    while empirical_speed(hi, dry_mass_kg, coefficient) < speed_m_s:
        hi *= 2
        if hi > 1e9: raise ValueError("Unreasonable empirical input")
    return bisect_root(lambda x: empirical_speed(x, dry_mass_kg, coefficient)-speed_m_s, 0., hi)

def sphere_area(volume_m3):
    positive('volume_m3', volume_m3)
    return math.pi*(3*volume_m3/(4*math.pi))**(2/3)

def launch_speed(volume_m3, dry_mass_kg, pressure_pa, temperature_k, cd,
                 gas_temperature_k=None, overpressure_pa=0.):
    positive('volume_m3', volume_m3)
    positive('dry_mass_kg', dry_mass_kg)
    positive('cd', cd)
    ra, rg = densities(pressure_pa, temperature_k, gas_temperature_k, overpressure_pa)
    lift = (ra-rg)*volume_m3-dry_mass_kg
    if lift <= 0: return 0.
    return math.sqrt(2*G0*lift/(ra*cd*sphere_area(volume_m3)))

def volume_for_speed(speed_m_s, dry_mass_kg, pressure_pa, temperature_k, cd):
    positive('speed_m_s', speed_m_s, True)
    positive('dry_mass_kg', dry_mass_kg)
    positive('cd', cd)
    ra, rg = densities(pressure_pa, temperature_k)
    neutral = dry_mass_kg/(ra-rg)
    if speed_m_s == 0: return neutral
    hi = neutral*2
    while launch_speed(hi,dry_mass_kg,pressure_pa,temperature_k,cd)<speed_m_s:
        hi *= 2
        if hi > 1e7: raise ValueError("Unreasonable launch input")
    return bisect_root(lambda v: launch_speed(v,dry_mass_kg,pressure_pa,temperature_k,cd)-speed_m_s,neutral,hi)

def implied_cd(coefficient, pressure_pa, temperature_k):
    positive('coefficient', coefficient)
    ra, rg = densities(pressure_pa, temperature_k)
    return 2*G0/(ra*math.pi*coefficient**2)*(4*math.pi*(ra-rg)/3)**(2/3)

def gas_moles(volume_m3, pressure_pa, gas_temperature_k, overpressure_pa=0.):
    positive('volume_m3', volume_m3)
    positive('gas_temperature_k', gas_temperature_k)
    positive('pressure_pa', pressure_pa)
    positive('overpressure_pa', overpressure_pa, True)
    return (pressure_pa+overpressure_pa)*volume_m3/(R*gas_temperature_k)

def volume_at_altitude(moles, altitude_m, delta_t_k=0., overpressure_pa=0., isothermal_k=None):
    positive('moles', moles)
    positive('overpressure_pa', overpressure_pa, True)
    ta, pa, _ = atmosphere(altitude_m)
    tg = ta+delta_t_k if isothermal_k is None else isothermal_k
    positive('gas_temperature_k', tg)
    return moles*R*tg/(pa+overpressure_pa)

def burst_altitude(moles, burst_diameter_m, delta_t_k=0., overpressure_pa=0., isothermal_k=None):
    positive('burst_diameter_m', burst_diameter_m)
    vb = math.pi*burst_diameter_m**3/6
    f = lambda z: volume_at_altitude(moles,z,delta_t_k,overpressure_pa,isothermal_k)-vb
    if f(0) >= 0: return 0.
    return bisect_root(f, 0., MAX_GEOMETRIC_ALTITUDE_M)

def upper_air_profile(moles, dry_mass_kg, cd, burst_diameter_m, step_m=250,
                      delta_t_k=0., overpressure_pa=0.):
    """Equilibrium terminal speed in standard air, no vertical wind or time dynamics.
    Starts at 1 km to distinguish from measured ground fill state. Not ascent time.
    """
    positive('step_m', step_m)
    if step_m<1 or int(step_m)!=step_m:raise ValueError('step_m must be a positive integer')
    positive('dry_mass_kg', dry_mass_kg)
    positive('cd', cd)
    zb = burst_altitude(moles,burst_diameter_m,delta_t_k,overpressure_pa)
    rows=[]
    for z in range(1000,int(zb)+1,int(step_m)):
        ta, pa, rho = atmosphere(z)
        v = volume_at_altitude(moles,z,delta_t_k,overpressure_pa)
        d = (6*v/math.pi)**(1/3)
        free = rho*v-dry_mass_kg-moles*M_HE
        g = G0*(EARTH_RADIUS/(EARTH_RADIUS+z))**2
        speed=math.sqrt(2*g*free/(rho*cd*sphere_area(v))) if free>0 else 0.
        mu = 1.716e-5*(ta/273.15)**1.5*(273.15+110.4)/(ta+110.4)
        rows.append(dict(altitude_m=z,air_temperature_k=ta,pressure_pa=pa,
                         volume_m3=v,diameter_m=d,free_lift_kg=free,
                         terminal_speed_m_s=speed,reynolds=rho*speed*d/mu))
    return rows

def cylinder_inventory(volume_l, pressure_mpa, temperature_k, atmospheric_pressure_pa,
                       gauge=True, z_factor=1.):
    positive('volume_l',volume_l)
    positive('pressure_mpa',pressure_mpa,True)
    positive('temperature_k',temperature_k)
    positive('z_factor',z_factor)
    positive('atmospheric_pressure_pa',atmospheric_pressure_pa)
    p = pressure_mpa*1e6+(atmospheric_pressure_pa if gauge else 0)
    positive('absolute_pressure_pa',p)
    return p*(volume_l/1000)/(z_factor*R*temperature_k)

def cylinder_capacity(volume_l, initial_mpa, final_mpa, initial_k, final_k,
                      ambient_pa, gas_k, gauge=True, z_initial=1., z_final=1.):
    ni=cylinder_inventory(volume_l,initial_mpa,initial_k,ambient_pa,gauge,z_initial)
    nf=cylinder_inventory(volume_l,final_mpa,final_k,ambient_pa,gauge,z_final)
    if nf>ni: raise ValueError('Final inventory exceeds initial inventory')
    positive('gas_k',gas_k)
    return (ni-nf)*R*gas_k/ambient_pa*1000

def adiabatic_capacity(volume_l, initial_mpa, final_mpa, initial_k, ambient_pa,gas_k,gamma=5/3):
    """Ideal insulated rigid-tank blowdown limit; no wall heat or real-gas EOS."""
    if gamma<=1: raise ValueError('gamma must exceed 1')
    pi=initial_mpa*1e6+ambient_pa
    pf=final_mpa*1e6+ambient_pa
    if not (pi>pf>0): raise ValueError('Require initial absolute P > final absolute P > 0')
    tf=initial_k*(pf/pi)**((gamma-1)/gamma)
    return cylinder_capacity(volume_l,initial_mpa,final_mpa,initial_k,tf,ambient_pa,gas_k),tf

def write_csv(path, rows):
    if not rows: return
    with Path(path).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run(config, output_dir):
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    m=config['dry_mass_kg'];p=config['fill_pressure_pa'];t=config['fill_temperature_k']
    vtar=config['target_speed_m_s'];k=config['empirical_coefficient'];d=config['burst_diameter_m']
    lift=empirical_free_lift(vtar,m,k)
    ra,rg=densities(p,t)
    v=(m+lift)/(ra-rg)
    n=gas_moles(v,p,t)
    cd=implied_cd(k,p,t)
    zb=burst_altitude(n,d)
    cyl=config['cylinder']
    args=[cyl['volume_l'],cyl['initial_gauge_mpa'],cyl['final_gauge_mpa'],cyl['initial_temperature_k']]
    cap=cylinder_capacity(*args,cyl['final_temperature_k'],p,t,z_initial=cyl.get('z_initial',1.),z_final=cyl.get('z_final',1.))
    if cap<=0: raise ValueError('Cylinder supplies no gas for these endpoints; check pressure and temperature')
    adcap,tf=adiabatic_capacity(*args,p,t)
    summary=dict(dry_mass_kg=m,free_lift_kg=lift,fill_volume_l=v*1000,
                 gas_moles=n,helium_mass_kg=n*M_HE,effective_cd=cd,
                 ground_speed_m_s=launch_speed(v,m,p,t,cd),burst_altitude_m=zb,
                 cylinder_capacity_l=cap,cylinder_count=math.ceil(v*1000/cap),
                 adiabatic_limit_capacity_l=adcap,adiabatic_limit_final_temperature_k=tf,
                 assumptions='Ideal He; spherical envelope; constant effective Cd; gas equals standard air temperature aloft; no wind, leakage, payload drag, thermal transients; burst diameter is a nominal deterministic threshold, not probability.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    write_csv(out/'upper_air_profile.csv',upper_air_profile(n,m,cd,d))
    rows=[]
    for c in [0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6]:
        vol=volume_for_speed(vtar,m,p,t,c)
        rows.append(dict(cd=c,fill_volume_l=vol*1000,burst_altitude_m=burst_altitude(gas_moles(vol,p,t),d)))
    write_csv(out/'cd_sensitivity.csv',rows)
    rows=[]
    for dm in [d*.9,d*.95,d,d*1.05,d*1.1]:
        for delta in [-10.,0.,10.]:
            rows.append(dict(burst_diameter_m=dm,gas_air_delta_t_k=delta,burst_altitude_m=burst_altitude(n,dm,delta)))
    write_csv(out/'burst_sensitivity.csv',rows)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path(__file__).with_name('example_config.json'))
    parser.add_argument('--out',type=Path,default=Path('balloon_results'))
    a=parser.parse_args()
    run(json.loads(a.config.read_text(encoding='utf-8')),a.out)
