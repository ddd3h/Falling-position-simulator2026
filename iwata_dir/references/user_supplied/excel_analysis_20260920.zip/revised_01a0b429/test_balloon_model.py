"""Run: python -m unittest discover -s . -p test_balloon_model.py"""
import unittest
import math
import balloon_model as b

class PhysicsTests(unittest.TestCase):
    def test_standard_atmosphere_reference(self):
        for h,t,p in [(0,288.15,101325),(11000,216.65,22632.06),(20000,216.65,5474.889),(32000,228.65,868.019),(47000,270.65,110.906)]:
            actual=b.atmosphere(h,geometric=False)
            self.assertAlmostEqual(actual[0],t,places=7)
            self.assertLess(abs(actual[1]/p-1),2e-5)
    def test_layer_continuity_and_pressure_monotonicity(self):
        for h in [11000,20000,32000]:
            below=b.atmosphere(h-0.001,False);above=b.atmosphere(h+0.001,False)
            self.assertLess(above[1],below[1]);self.assertLess(abs(above[0]-below[0]),1e-4)
    def test_empirical_inverse_varied_conditions(self):
        for mass in [0.1,1,4,10]:
            for speed in [0,0.1,2,5,12]:
                l=b.empirical_free_lift(speed,mass,138/23.6)
                self.assertAlmostEqual(b.empirical_speed(l,mass,138/23.6),speed,places=5)
    def test_implied_cd_reproduces_empirical_law(self):
        p,t,k=101800,278.15,138/23.6
        ra,rg=b.densities(p,t)
        for l in [1,2.562937541,5]:
            v=(4+l)/(ra-rg)
            self.assertAlmostEqual(b.launch_speed(v,4,p,t,b.implied_cd(k,p,t)),b.empirical_speed(l,4,k),places=8)
    def test_mass_conservation_and_burst_event(self):
        n=b.gas_moles(6,101800,278.15)
        for z in [1000,10000,30000]:
            t,p,_=b.atmosphere(z);v=b.volume_at_altitude(n,z)
            self.assertAlmostEqual(p*v/(b.R*t),n,places=8)
        z=b.burst_altitude(n,10)
        self.assertAlmostEqual((6*b.volume_at_altitude(n,z)/math.pi)**(1/3),10,places=7)
    def test_cylinder_gauge_offset_cancels_at_equal_temperatures(self):
        g=b.cylinder_capacity(10,14.7,0.2,278.15,278.15,101800,278.15,True)
        a=b.cylinder_capacity(10,14.7,0.2,278.15,278.15,101800,278.15,False)
        self.assertAlmostEqual(g,a,places=9)
        self.assertAlmostEqual(g,10*14.5e6/101800,places=9)
    def test_sensitivity_direction(self):
        n=b.gas_moles(6,101800,278.15)
        self.assertLess(b.burst_altitude(n*1.1,10),b.burst_altitude(n,10))
        self.assertGreater(b.burst_altitude(n,11),b.burst_altitude(n,10))
        self.assertLess(b.burst_altitude(n,10,10),b.burst_altitude(n,10))
    def test_bad_inputs(self):
        for fun,args in [(b.empirical_free_lift,(-1,4,5)),(b.atmosphere,(-1,)),(b.gas_moles,(1,101325,-10)),(b.burst_altitude,(200,-10)),(b.launch_speed,(-1,4,101325,288.15,.4)),(b.volume_for_speed,(0,-1,101325,288.15,.4)),(b.volume_for_speed,(0,1,101325,288.15,0)),(b.implied_cd,(-1,101325,288.15)),(b.upper_air_profile,(200,4,.4,10,.1))]:
            with self.assertRaises(ValueError):fun(*args)
    def test_top_atmosphere_geometric_domain(self):
        z=47200.;t,p,_=b.atmosphere(z);n=p*(math.pi*10**3/6)/(b.R*t)
        self.assertAlmostEqual(b.burst_altitude(n,10),z,places=5)
    def test_unequal_temperature_cylinder_inventory(self):
        vi=.01;pa=101800.;pi=14.7e6+pa;pf=.2e6+pa
        expected=(pi*vi/(1.1*b.R*273.15)-pf*vi/(b.R*278.15))*b.R*278.15/pa*1000
        self.assertAlmostEqual(b.cylinder_capacity(10,14.7,.2,273.15,278.15,pa,278.15,z_initial=1.1),expected,places=8)

if __name__=='__main__':unittest.main()
