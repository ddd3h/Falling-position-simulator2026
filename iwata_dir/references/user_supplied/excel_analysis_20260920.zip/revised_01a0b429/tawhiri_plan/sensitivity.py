"""Deterministic altitude-kernel illustration, NOT a meteorological forecast.

Synthetic, stationary, horizontally uniform two-component wind; local east/north
plane; monotone ascent/descent; no vertical air motion, glide, inflation delay or
horizontal inertia. Density uses the supplied USSA model. This does not reproduce
Tawhiri's density approximation or its four-dimensional wind/terrain integration.

Run from this file's directory or elsewhere: python sensitivity.py
Requires numpy, matplotlib. Only writes files alongside this script.
"""
from pathlib import Path
import csv, json, math, os, sys
ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
import balloon_model as physics
import numpy as np
trapezoid = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
os.environ.setdefault('MPLCONFIGDIR', str(OUT / '.plot_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
for fn in ['C:/Windows/Fonts/YuGothM.ttc', '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']:
    if Path(fn).exists():
        fm.fontManager.addfont(fn)
        plt.rcParams['font.family'] = fm.FontProperties(fname=fn).get_name()
        break
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'axes.grid':True,'grid.alpha':.2,'svg.fonttype':'path'})

Z_KNOT = np.array([0,1,3,6,9,12,16,20,24,28,32,36], float)*1000
U_KNOT = np.array([4,8,10,0,-15,-25,-8,6,18,15,-10,-14], float)
V_KNOT = np.array([1,2,-3,-5,2,8,12,8,-10,-14,-6,3], float)
LAYER_EDGES = np.array([200,3000,8000,12000,18000,24000,28000,32000],float)
BASE = {'ascent_m_s':5., 'sea_level_descent_m_s':5., 'burst_m':32000., 'end_m':200.}
LAUNCH_M = 200.
RHO0 = physics.atmosphere(0)[2]
DISCLAIMER='合成例：実風・予測確率・Tawhiriの実行結果ではない'

def wind(z):
    return np.column_stack([np.interp(z,Z_KNOT,U_KNOT),np.interp(z,Z_KNOT,V_KNOT)])

def density(z):
    return np.array([physics.atmosphere(float(h))[2] for h in z])

def descent(z, s0):
    return s0*np.sqrt(RHO0/density(z))

def grid(lo, hi, step):
    return np.unique(np.concatenate(([lo,hi],np.arange(lo,hi,step),Z_KNOT[(Z_KNOT>lo)&(Z_KNOT<hi)])))

def part(lo,hi,phase,parameters,step=10.):
    z=grid(lo,hi,step)
    speed=np.full_like(z,parameters['ascent_m_s']) if phase=='up' else descent(z,parameters['sea_level_descent_m_s'])
    inv=1/speed
    return trapezoid(wind(z)*inv[:,None],z,axis=0), float(trapezoid(inv,z))

def calculate(parameters=None,step=10.):
    p=BASE.copy();p.update(parameters or {})
    assert all(math.isfinite(v) for v in p.values())
    assert p['ascent_m_s']>0 and p['sea_level_descent_m_s']>0
    assert 0<=p['end_m']<p['burst_m']<=Z_KNOT[-1] and LAUNCH_M<p['burst_m']
    up,tu=part(LAUNCH_M,p['burst_m'],'up',p,step)
    down,td=part(p['end_m'],p['burst_m'],'down',p,step)
    return {'parameters':p,'up_m':up.tolist(),'down_m':down.tolist(),'total_m':(up+down).tolist(),
            'up_seconds':tu,'down_seconds':td,'total_seconds':tu+td}

def savefig(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight',facecolor='white')
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)

def write_csv(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def main():
    baseline=calculate();base=np.array(baseline['total_m'])
    layers=[]
    for lo,hi in zip(LAYER_EDGES[:-1],LAYER_EDGES[1:]):
        u,tu=part(lo,hi,'up',BASE);d,td=part(lo,hi,'down',BASE)
        layers.append({'lo_m':float(lo),'hi_m':float(hi),'up_east_m':u[0],'up_north_m':u[1],
                       'down_east_m':d[0],'down_north_m':d[1],'total_east_m':u[0]+d[0],
                       'total_north_m':u[1]+d[1],'up_seconds':tu,'down_seconds':td})
    total_layers=np.array([[r['total_east_m'],r['total_north_m']] for r in layers])
    layer_residual=(total_layers.sum(axis=0)-base).tolist()
    cancellation=float(np.linalg.norm(base)/sum(np.linalg.norm(a) for a in total_layers))
    analytic=np.column_stack([
        -np.array(baseline['up_m'])/BASE['ascent_m_s'],
        -np.array(baseline['down_m'])/BASE['sea_level_descent_m_s'],
        wind(np.array([BASE['burst_m']]))[0]*(1/BASE['ascent_m_s']+1/descent(np.array([BASE['burst_m']]),BASE['sea_level_descent_m_s'])[0]),
        -wind(np.array([BASE['end_m']]))[0]/descent(np.array([BASE['end_m']]),BASE['sea_level_descent_m_s'])[0]
    ])
    keys=list(BASE);delta=[.001,.001,1.,1.]
    finite=np.column_stack([(np.array(calculate({k:BASE[k]+h})['total_m'])-np.array(calculate({k:BASE[k]-h})['total_m']))/(2*h) for k,h in zip(keys,delta)])
    tests={'layer_sum_residual_m':layer_residual,'jacobian_analytic':analytic.tolist(),
           'jacobian_finite_difference':finite.tolist(),'jacobian_abs_difference':np.abs(finite-analytic).tolist(),
           'grid_10_to_5m_endpoint_change_m':(np.array(calculate(step=5)['total_m'])-base).tolist(),
           'grid_5_to_2_5m_endpoint_change_m':(np.array(calculate(step=2.5)['total_m'])-np.array(calculate(step=5)['total_m'])).tolist()}
    assert max(abs(x) for x in layer_residual)<1e-5
    assert np.max(np.abs(finite[:,:2]-analytic[:,:2]))<.001
    # Burst lies on a piecewise-linear knot: central derivative is the common
    # limit; the finite 1 m difference includes small curvature terms.
    assert np.max(np.abs(finite[:,2:]-analytic[:,2:]))<.001
    assert max(abs(x) for x in tests['grid_5_to_2_5m_endpoint_change_m'])<.02

    sweeps={
      'ascent_m_s':np.linspace(4,6,41),
      'sea_level_descent_m_s':np.linspace(4,8,41),
      'burst_m':np.linspace(28000,35000,71),
      'end_m':np.linspace(0,500,51),
    }
    curves={key:[calculate({key:float(v)}) for v in vals] for key,vals in sweeps.items()}
    perturbations={'ascent_m_s':.5,'sea_level_descent_m_s':1.,'burst_m':1000.,'end_m':100.}
    nine=[{'case':'baseline',**baseline}]
    for key,h in perturbations.items():
        for sign in [-1,1]:nine.append({'case':key+(' minus' if sign<0 else ' plus'),**calculate({key:BASE[key]+sign*h})})

    # Optional fifth diagnostic: redistribute ascent residence time while keeping
    # total ascent duration EXACTLY fixed. This is a designed shape perturbation,
    # not an inferred atmospheric or balloon error distribution.
    split=11000.;length_lo=split-LAUNCH_M;length_hi=BASE['burst_m']-split
    up_lo,t_lo=part(LAUNCH_M,split,'up',BASE);up_hi,t_hi=part(split,BASE['burst_m'],'up',BASE)
    equal_time=[]
    for beta in [-.2,0.,.2]:
        c_lo=1+beta;c_hi=1-beta*length_lo/length_hi
        x=c_lo*up_lo+c_hi*up_hi+np.array(baseline['down_m'])
        total_up=c_lo*t_lo+c_hi*t_hi
        assert abs(total_up-baseline['up_seconds'])<1e-9
        equal_time.append({'beta':beta,'lower_ascent_m_s':BASE['ascent_m_s']/c_lo,
                           'upper_ascent_m_s':BASE['ascent_m_s']/c_hi,
                           'ascent_seconds':total_up,'east_m':float(x[0]),'north_m':float(x[1]),
                           'delta_east_m':float(x[0]-base[0]),'delta_north_m':float(x[1]-base[1])})

    # Joint finite changes: an interaction residual does not require a probability
    # distribution. Zero residual is expected for up/down scales at fixed burst
    # in this special additive model; changing burst couples the two residence terms.
    joint=[]
    for vu in [4.,4.5,5.,5.5,6.]:
        for hb in [28000.,30000.,32000.,34000.,35000.]:
            both=calculate({'ascent_m_s':vu,'burst_m':hb})
            oa=np.array(calculate({'ascent_m_s':vu})['total_m'])
            ob=np.array(calculate({'burst_m':hb})['total_m'])
            interaction=np.array(both['total_m'])-oa-ob+base
            joint.append({'ascent_m_s':vu,'burst_m':hb,'east_m':both['total_m'][0],
                          'north_m':both['total_m'][1],'interaction_east_m':interaction[0],
                          'interaction_north_m':interaction[1],
                          'interaction_norm_m':float(np.linalg.norm(interaction))})
    report={'disclaimer':DISCLAIMER,'assumptions':__doc__,'baseline':baseline,'layers':layers,
            'cancellation_ratio':cancellation,'derivative_columns':keys,'tests':tests,
            'nine_run_design':nine,'sweeps':curves,'joint_grid':joint,
            'equal_total_time_shape_cases':equal_time,
            'max_joint_interaction_m':max(r['interaction_norm_m'] for r in joint)}
    (OUT/'synthetic_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    write_csv('synthetic_wind.csv',[{'z_m':float(z),'east_m_s':float(u),'north_m_s':float(v)} for z,u,v in zip(Z_KNOT,U_KNOT,V_KNOT)])
    write_csv('layer_contributions.csv',layers)
    write_csv('joint_grid.csv',joint)
    write_csv('equal_time_shape.csv',equal_time)
    write_csv('nine_run_design.csv',[{'case':r['case'],**r['parameters'],'east_m':r['total_m'][0],'north_m':r['total_m'][1],'total_seconds':r['total_seconds']} for r in nine])

    fig,axs=plt.subplots(1,3,figsize=(14,6),gridspec_kw={'width_ratios':[1,1.4,1.4]})
    zz=np.linspace(0,35000,351);ww=wind(zz)
    axs[0].plot(ww[:,0],zz/1000,label='東向き u',color='#2369A4');axs[0].plot(ww[:,1],zz/1000,label='北向き v',color='#C06220')
    axs[0].axvline(0,color='gray',lw=.8);axs[0].axhline(BASE['burst_m']/1000,color='black',ls=':',lw=1)
    axs[0].set(xlabel='風成分 [m/s]',ylabel='高度 z [km]',title='① 合成風プロファイル');axs[0].legend(loc='upper right',fontsize=9)
    yy=np.arange(len(layers));labels=[f"{r['lo_m']/1000:g}–{r['hi_m']/1000:g}" for r in layers]
    for ax,component,label in zip(axs[1:],['east','north'],['東西','南北']):
        ax.barh(yy-.18,[r[f'up_{component}_m']/1000 for r in layers],height=.34,label='上昇中',color='#2369A4')
        ax.barh(yy+.18,[r[f'down_{component}_m']/1000 for r in layers],height=.34,label='降下中',color='#C06220')
        ax.set_yticks(yy,labels);ax.axvline(0,color='black',lw=.8)
        ax.set(xlabel='符号付き水平変位 [km]',ylabel='高度帯 [km]',title=f'層別の{label}変位');ax.legend(fontsize=9)
    fig.suptitle('風の向きが変わると、層ごとの寄与は相殺する\n'+DISCLAIMER,fontsize=14)
    fig.tight_layout(rect=(0,0,1,.91));savefig(fig,'01_wind_and_layers')

    fig,axs=plt.subplots(2,2,figsize=(11,9))
    titles=['上昇速度 4–6 m/s','海面基準降下速度 4–8 m/s','破裂高度 28–35 km','降下終端高度 0–500 m']
    colors=['#2369A4','#C06220','#6C4593','#367A56']
    for ax,key,title,color in zip(axs.flat,keys,titles,colors):
        curve=curves[key];xy=(np.array([r['total_m'] for r in curve])-base)/1000
        ax.plot(xy[:,0],xy[:,1],color=color,lw=1.8)
        ax.scatter(xy[:,0],xy[:,1],c=sweeps[key],cmap='viridis',s=12)
        ax.scatter([0],[0],marker='*',s=150,color='#D52832',zorder=3,label='基準')
        ax.annotate('最小値',xy[0],xytext=(7,7),textcoords='offset points',fontsize=9)
        ax.annotate('最大値',xy[-1],xytext=(7,-13),textcoords='offset points',fontsize=9)
        ax.set(xlabel='基準からの東西変化 [km]',ylabel='基準からの南北変化 [km]',title=title)
        ax.axvline(0,color='gray',lw=.6);ax.axhline(0,color='gray',lw=.6);ax.legend(fontsize=8)
    fig.suptitle('一つずつ条件を変更した着地点の移動（各パネルで軸範囲が異なる）\n'+DISCLAIMER,fontsize=13)
    fig.tight_layout(rect=(0,0,1,.92));savefig(fig,'02_endpoint_sensitivity')

    fig,axs=plt.subplots(1,2,figsize=(12,5.5))
    for hb in [28000.,30000.,32000.,34000.,35000.]:
        rr=[r for r in joint if r['burst_m']==hb]
        axs[0].plot([(r['east_m']-base[0])/1000 for r in rr],[(r['north_m']-base[1])/1000 for r in rr],'-o',label=f'{hb/1000:g} km',ms=4)
    axs[0].scatter([0],[0],marker='*',s=150,color='red',zorder=5)
    axs[0].set(xlabel='基準からの東西変化 [km]',ylabel='基準からの南北変化 [km]',title='25条件の設計格子：確率分布ではない');axs[0].legend(title='破裂高度',fontsize=8)
    for vu in [4.,4.5,5.,5.5,6.]:
        rr=[r for r in joint if r['ascent_m_s']==vu]
        axs[1].plot([r['burst_m']/1000 for r in rr],[r['interaction_norm_m']/1000 for r in rr],'-o',label=f'{vu:g} m/s',ms=4)
    axs[1].set(xlabel='破裂高度 [km]',ylabel='単独変更の和との差の大きさ [km]',title='同時変更には交互作用がある');axs[1].legend(title='上昇速度',fontsize=8)
    fig.suptitle('破裂高度と滞在時間の変更は独立加算にならない\n'+DISCLAIMER,fontsize=13)
    fig.tight_layout(rect=(0,0,1,.90));savefig(fig,'03_joint_sensitivity')
    print(json.dumps({'baseline':baseline,'cancellation_ratio':cancellation,'max_joint_interaction_m':report['max_joint_interaction_m'],'tests':tests},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
