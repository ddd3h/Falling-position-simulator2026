# Tawhiri公開コードの独立監査

確認日：2026-09-19（日本時間）。公開リポジトリを読み取り、現行公開HEADを固定した。既存成果物および原本は変更していない。コード確認と純粋な密度関数の数値検算を実施し、予報データを読み込む実飛行再現・実配備バイナリの監査は行っていない。

## 結論

未知パラメータを増やさずに試す価値があるのは、**予報P/Tからの密度へ置換し、海面等価降下速度の正規化と復元を同じ密度定義へ揃えること**、高度基準の整合、地表近傍の風外挿と着地イベントの数値収束である。現行Tawhiriには、既に四次Runge–Kutta、時空間の風補間、地形による着地判定がある。これらの「新規導入」を改善案には数えない。

また、SondeHubの利用側には既に、観測からの上昇率更新と、降下中の海面等価降下速度の更新がある。それを独自実装の新機能のようには扱わない。既存処理の密度・時刻・高度の整合を改善対象にする。

## 1. 監査した版と稼働サービスの区別

| 対象 | 固定したHEAD commit | commit日時 |
|---|---|---|
| cuspaceflight/tawhiri（upstream） | `668b44e5b88a66e0d885a9f9b16ff507d856bbbd` | 2021-06-29 16:01:43 +01:00 |
| projecthorus/tawhiri（SondeHub側公開fork） | `03170ee9a33e55ccf4407474673b8c9dcee9b268` | 2023-01-24 13:16:35 +10:30 |
| projecthorus/sondehub-infra（呼出側・配備定義） | `cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7` | 2026-09-12 09:48:00 +10:00 |
| cuspaceflight/ruaumoko（DEM） | `dc489d927169174b14db4cfc38dda13af3ee4c03` | 2014-10-24 13:37:01 +01:00 |
| cuspaceflight/tawhiri-downloader | `63c741dc1d0ae38488581ca55f1465a8120929bf` | 2021-08-01 14:49:41 +01:00 |
| projecthorus/tawhiri-container（旧分離コンテナrepo） | `efcdf31cfae74f28044fbebf0357653851eafe84` | 2021-08-02 20:09:56 +10:00 |

これは各リポジトリの取得時HEADであり、全てのファイルがこの日時に変更されたという意味ではない。

SondeHubインフラは `tawhiri.v2.sondehub.org` を呼び、配備定義はECRの `tawhiri:latest` を使う。タグはmutableで、公開Terraformから稼働コンテナのソースSHAを確定できない。forkは独自Dockerfileでチェックアウト内容をビルドする一方、旧 `tawhiri-container` はupstreamのmaster.zipを取得する。名前だけでどちらのコードが現在配備されているかを断定しない。レスポンスmetadataにもソースSHAはなく開始/終了時刻のみである。[利用側](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/ham_predict_updater/__init__.py#L20)、[配備イメージ・共有データ](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/predictor.tf#L212-L324)、[mutableタグ](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/predictor.tf#L358-L369)、[fork Dockerfile](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/Dockerfile#L19-L23)、[旧コンテナ](https://github.com/projecthorus/tawhiri-container/blob/efcdf31cfae74f28044fbebf0357653851eafe84/Dockerfile#L16-L20)、[metadata](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/tawhiri/api.py#L481-L488)

本監査で「現行」は**上記の現行公開コード**を指す。実サービスの稼働版との同一性は未確認である。

## 2. standard_profileの式

### 2.1 上昇

高度の微分は入力した上昇率で一定、`dh/dt = ascent_rate`。緯度・経度の微分にはその時刻・位置・高度の風を加える。破裂高度は外から与える閾値であり、ガス熱力学や膜応力から予測していない。速度式に気球質量、自由浮力、He温度、可変Cd等を追加しているわけではない。[upstream models.py 36–40,161–182](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/models.py#L36-L40)、[プロファイル結合](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/models.py#L161-L182)

### 2.2 下降

上向きを正とすると

`dh/dt = - c / sqrt(rho_NASA(h))`, `c = descent_rate × 1.1045`。

コード内の変数名は `drag_coefficient` だが、ここでのcは無次元の抗力係数Cdではない。二乗抗力の終端速度における `sqrt(2mg/(Cd A))` に相当するまとめた尺度である。公称海面降下速度を1つ与えることで、m、Cd、Aを別々の未知数にせず下降曲線を定めている。毎時刻に即座に終端速度へ達すると仮定し、開傘過渡、加速度、揚力、水平の空気に対する滑空は解かない。[make_drag_descent全体](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/models.py#L43-L70)

密度は高度だけのNASA簡易3層式で、気圧pをkPa、温度Tcを℃として次の通り。

| 高度h [m] | Tc [℃] | p [kPa] |
|---|---|---|
| h≤11000 | 15.04−0.00649h | 101.29×((Tc+273.1)/288.08)^5.256 |
| 11000<h≤25000 | −56.46 | 22.65×exp(1.73−0.000157h) |
| 25000<h | −131.21+0.00299h | 2.488×((Tc+273.1)/216.6)^−11.388 |

`rho_NASA = p/[0.2869(Tc+273.1)]` [kg/m³]。予報の温度・気圧を参照していない。upstreamとprojecthorus forkでこの関数は同一。[forkの同関数43–70](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/tawhiri/models.py#L43-L70)

### 2.3 「海面降下速度」の厳密な意味

APIの `descent_rate` は高度全域に適用する一定降下速度ではない。上記の密度依存曲線を規格化する正の入力パラメータである。厳密には係数1.1045の丸め・密度式の不整合により、h=0の出力速度は入力と完全一致しない。入力5 m/sならh=0で4.986339 m/sとなる。`1.1045²=1.21992025` に対し、関数自身の海面密度は1.226613787 kg/m³である。この約0.273%は独立に再現した実装上の差であって、実飛行誤差の推定ではない。

公式API文書は海面基準の終端降下モデルを明記するが、一般パラメータ表の説明だけではこの正規化の細部は読み取れない。コードを根拠にする。[公式API docs](https://tawhiri.readthedocs.io/en/latest/api.html)

## 3. 風の補間・座標・単位

### 3.1 データ配置

upstreamとforkで `dataset.py` と `interpolate.pyx` は同一。標準配列は `(65時刻,47圧力面,3変数,361緯度,720経度)`。時刻は予報初期時刻から0,3,…,192時間、緯度は−90…90°を0.5°刻み、経度は0…359.5°を0.5°刻み。圧力面は1000から1 hPaであり、変数はheight/u/vのみ。温度、湿度、鉛直風はこの標準配列に含まれない。[dataset.py 61–95](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/dataset.py#L61-L95)

これらは公開コードの配列契約であり、現在一般に配布されるGFSの全解像度・全変数を自動的に利用するという意味ではない。自前の気象処理を接続する場合、黙って別解像度を同じ配列へ渡さず、風取得のインターフェースも変える必要がある。

### 3.2 4次元補間

まず時刻・緯度・経度の8隅を線形補間し、各圧力面のheightを得る。目標高度を挟む2面を二分探索し、その2面のu/vを高さに対して線形補間する。時間・緯度・経度・高さの補間が既にあり、最近傍の風場をそのまま取る実装ではない。最高/最低面の外は同じ2面から線形外挿を許し、最高面を超えた場合のみ警告countを増やす。[interpolate.pyx 90–125,143–201](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/interpolate.pyx#L90-L201)、[公式実装解説](https://tawhiri.readthedocs.io/en/latest/implementation.html)

現在の最低面は1000 hPaで、地表付近でこれより下への外挿が発生しうる。dataset.py 66–71では10/80/100 m AGL風の利用がTODOとして残る。したがって「地表風を地形上の高度として整合させ、予報が地中になる層を除外し、地表近傍の外挿を検証する」は追加fitなし候補だが、既にある4D補間を導入する話ではない。

### 3.3 時刻と地球座標

積分器のtはUNIX秒。風取得時には予報初期時刻のUNIX秒を引き、3600で割って相対時間[h]へ直す。uは東向き、vは北向きのm/s。`R=6371009+h` として `dlat/dt=(180/pi)v/R`、`dlon/dt=(180/pi)u/(R cos(lat))` を返し、積分状態は緯度経度[度]と高度[m]である。鉛直風の寄与は0。[models.py 76–90](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/models.py#L76-L90)

経度の周回と日付変更線付近の補間は既に処理している。時間最終点や極付近など、補間区間を組めない境界には別途受入試験が必要である。[interpolate.pyx 127–156](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/interpolate.pyx#L127-L156)、[solver.pyx 47–80](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/solver.pyx#L47-L80)

### 3.4 高度基準の注意

API文書は高度を海抜mと呼ぶ。一方、downloaderはGFS HGTをheightとして読んで値をそのまま配列へ移し、GFS公式インベントリはHGTをジオポテンシャル高度[gpm]と定義する。確認したdownloader→補間の経路にはジオポテンシャル高度から幾何高度への明示変換はない。したがって、自前気象処理ではGNSS楕円体高・標高/海抜・ジオポテンシャル高度を混同しない契約を先に定める。z=30 kmをHに換算した差は標準半径近似で約140.9 mだが、これがそのまま何mの着地点誤差になるかは風の鉛直シア等に依存し未評価である。[HGT選択](https://github.com/cuspaceflight/tawhiri-downloader/blob/63c741dc1d0ae38488581ca55f1465a8120929bf/grib_index.ml#L33-L37)、[変数判別と配列格納](https://github.com/cuspaceflight/tawhiri-downloader/blob/63c741dc1d0ae38488581ca55f1465a8120929bf/grib_message.ml#L137-L146)、[格納時は値をそのまま転送](https://github.com/cuspaceflight/tawhiri-downloader/blob/63c741dc1d0ae38488581ca55f1465a8120929bf/grib_message.ml#L210-L231)、[NOAA GFS変数定義](https://www.nco.ncep.noaa.gov/pmb/products/gfs/gfs.t12z.pgrb2full.0p50.f000.shtml)

これは確認した公開経路についての指摘であり、利用者が入力前に高度を補正している可能性や、実配備での独自前処理まで否定するものではない。

## 4. 地形終端は既にある

upstreamのstandard_profileは下降にRuaumokoの地形高度を参照し、地表高が気球高度を超えると停止する。海抜0 mまで常に落とすだけの実装ではない。SondeHub forkはこれに `alt<=0` の停止も加える。[upstream models.py 115–122,178–182](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/models.py#L115-L122)、[fork models.py 136–143](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/tawhiri/models.py#L136-L143)

Ruaumoko公開標準設定はViewfinder Panoramas由来の15秒角データ（1度240点）。queryは緯度経度から格子位置を丸めて最近傍値を返し、標準getは双線形DEM補間ではない。15秒角は南北約463 mに相当する。地物・狭い尾根の影響や標高基準はこの解像度とデータ品質の制約を受ける。ただし、実配備のDEMファイルを取得・照合していないため、実サービスのDEM版・実解像度の確定値としては扱わない。[Ruaumoko README 13–14,52–63](https://github.com/cuspaceflight/ruaumoko/blob/dc489d927169174b14db4cfc38dda13af3ee4c03/README.md#L52-L63)、[dataset.pyx 44–95](https://github.com/cuspaceflight/ruaumoko/blob/dc489d927169174b14db4cfc38dda13af3ee4c03/ruaumoko/dataset.pyx#L44-L95)

改善候補は「DEM新規導入」ではなく、**既存地形終端の解像度・標高基準・補間・海岸扱い・イベント検出の検証と必要な更新**である。細かいDEMが常に実飛行誤差を縮めるとの保証もない。

## 5. 積分実装

四次Runge–Kutta、既定dt=60秒。位置・高度をまとめて4段の微分評価で進める。誤差推定に基づく適応刻みではない。各ステップの終点で終端条件を検査し、条件成立時には直前点と新点の**線形補間上**で二分探索する。ODEを小刻みに再積分してイベント点を求める構造ではない。[solver.pyx 102–182](https://github.com/cuspaceflight/tawhiri/blob/668b44e5b88a66e0d885a9f9b16ff507d856bbbd/tawhiri/solver.pyx#L102-L182)

`termination_tolerance=0.01` は秒ではなく0–1の補間比の区間幅。既定60秒なら7回二分後の区間は60/128=0.46875秒。最終のmid点を返すため、返り値が必ず閾値の同じ側にある保証はない。これを「0.01秒精度」と書いてはならない。

SondeHub forkのsolverはsolveの引数にdtを追加し、reverse_profileで−60秒を渡す拡張があるが、通常のstandard_profileは上記と同じ60秒RK4である。RK4導入自体は改善案にしない。[fork solver.pyx 24–34](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/tawhiri/solver.pyx#L24-L34)

追加fitなしの数値検証として60→30→15秒の着地点・飛行時間収束、終端閾値への片側/両側残差、最後の区間を再積分するevent locatorを比較できる。地形が細かい場合、ステップ両端が地形より上でも途中で尾根へ接触する可能性があるため、終点だけで判定する構造も検証する。ただし、刻みを細かくした差を気象・実飛行予測の誤差改善と同一視しない。

## 6. SondeHub利用側と既存の更新処理

### 6.1 既に観測率を使っている

通常SondeHubとSondeHub-Amateurは別の呼出側コードを持つ。両者とも降下時には観測降下率を標準大気密度で海面等価へ戻し、Tawhiriへ送る。上昇中は観測上昇率を利用し、破裂高度と未観測の降下率には既定値やフライト設定を使用する。通常SondeHubの基本値は5 m/s・26 km・6 m/s、Amateurは5 m/s・30 km・5 m/sで異なる（機種/フライト設定による上書きあり）。[通常SondeHub 67–71,896–933](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/predict_updater/__init__.py#L896-L933)、[Amateur 20–26,718–747](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/ham_predict_updater/__init__.py#L718-L747)

現在の公開コードではAmateurは60秒bucket・lag3、通常は10秒bucket・lag3の高度系列差分を使い、それぞれ180秒/30秒で割る。これは「両方とも直近60秒平均」と単純化できない。周囲の古いコメントより変数と演算を優先して確認した。毎分の予測更新スケジュールと、速度推定窓の長さも別である。[Amateur 459–505,598–605](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/ham_predict_updater/__init__.py#L459-L505)、[通常497–538,663–670](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/predict_updater/__init__.py#L497-L538)

### 6.2 密度正規化がエンジンと一致していない

利用側は別の層別標準大気表（0–84852 mの8個の境界高度）からrho_SH(h)を求め、`v0=abs(v_observed) sqrt(rho_SH(h)/1.225)` とする。これはエンジン内のNASA3層式とは異なる。下降予測開始高度で復元した速度と観測速度の比は

`v_reconstructed / abs(v_observed) = 1.1045 sqrt[rho_SH(h)/(1.225 rho_NASA(h))]`。

公開関数を抽出して実行した結果、0 mで0.997268、20 kmで0.992666、25 km直下で0.984117、30 kmで1.013102だった。最大誤差の網羅探索ではなく代表点での決定的な整合検算である。NASA簡易式の11 km/25 km接続にも小さい不連続がある。[Amateur密度・海面換算133–205](https://github.com/projecthorus/sondehub-infra/blob/cfc56f2eda5cb86b0dc3cd4be0b6399b4a2bcbd7/lambda/ham_predict_updater/__init__.py#L133-L205)

自前計算では、共通の参照密度rho_refと実状態密度rho(t,x,h)を定め、同じ式で正規化・復元する。例えば `c=v_ref sqrt(rho_ref)`、`v(h)=c/sqrt(rho(h))` とする。気象P/Tを導入するときにrho_refを暗黙に変更しない。既存パラメータとの厳密互換を優先する試験と、物理的に一貫した参照状態へ直す試験は分離する。どちらも新しい可調整Cd等を足す必要はない。

GPSの鉛直速度は対地速度であり、鉛直風を含む。これを直ちに純粋なパラシュートの対気終端速度と同一視しない。既存1パラメータの更新自体があることと、その推定が完全であることも別である。

### 6.3 公開fork固有の違い

forkは正の上昇/降下率を最低0.2 m/sへクリップする（upstreamは正であればそのまま）。地形取得に失敗してlaunch_altitudeを省略した場合、forkは0 mにフォールバックする。これらは厳密な再現試験で固定すべき挙動である。未知状態を黙って海抜0 mに置き換える動作は、自前計算では明示的な入力品質判定を推奨する。[fork api.py 110–118,145–169](https://github.com/projecthorus/tawhiri/blob/03170ee9a33e55ccf4407474673b8c9dcee9b268/tawhiri/api.py#L110-L169)

## 7. 追加の未知パラメータなしで比較する順序

| 順序 | 比較対象 | 既存との違い | 増える未知fit係数 |
|---|---|---|---|
| 0 | 固定commit・同じ気象・同じ初期条件で基準を再現 | 改善ではなく比較土台。位相別の時間/位置/着地点を保存 | 0 |
| 1 | 単位・UTC・高度基準、風のu/v向き、経度周回、欠測・領域外検出 | 既存補間を保持し、契約違反と黙示補正を除去 | 0 |
| 2 | 下降密度を予報P/Tへ置換、前後の正規化密度も統一 | 現行は高度だけの簡易標準大気。p/Tは外生データ | 0 |
| 3 | dt収束・地表event locator・既存DEMの検証 | 現行RK4/DEMの精度と解像度の改善 | 0 |
| 4 | 地表近傍風・地中の等圧面・外挿の扱い | 現行の最低面下への線形外挿を明示的に扱う | 0（追加観測/予報データは必要） |
| 5 | 既存上昇率・降下1パラメータの観測更新を同一定義で運用 | 更新自体は既存。位相判定・時間窓・外れ値の検証を行う | 物理fitは0。窓や閾値を調整するなら設計設定として記録 |
| 6 | 予報メンバー/発射時刻範囲/測定入力の再実行 | 単一決定論軌道に対する外生シナリオ群 | 仮定に基づく新ノイズを足さなければ0 |

「追加fit0」は「データ不要」「誤差0」を意味しない。予報T/湿度等を増やすのは入力データの増加であり、未知物性パラメータの追加とは区別する。密度を予報へ変えても、CdA/mや開傘状態の誤差は残る。高度依存Cd、膜熱収支、開傘時定数、風の独立ランダムノイズを同時に導入すると、改善原因の識別と未知数制約を損なうため最初の比較には入れない。

散らばりは実際の予報メンバーや測定不確かさを入力として作り、覆域率を未使用飛行で検証して初めて確率的な到達域として校正する。コードにensemble軸はなく、standard_profileは単一の決定論的軌道を返す。複数回実行しても、分布・信頼水準を自動で持つわけではない。

## 8. 検証の限界と証跡

- 風データ・DEMの実ファイルは取得していない。実サービスの稼働commit、予報更新遅延、配備DEMの版、性能は未確定。
- Cython solver本体をビルドして全軌道を再計算していない。積分方式・単位・終端式はコード追跡、密度と正規化の数値は純粋Python関数をAST抽出して実行した。
- 着地点誤差の改善率は算定していない。予報密度置換が常に改善するとは結論しない。固定条件のablationと未使用飛行による評価が必要。
- `work/tawhiri_numeric_audit.py` と `work/tawhiri_numeric_checks.json` に密度・海面正規化・数値許容差の検算を保存。
- URL、行、commit、リポジトリの出自、確認事項は `work/tawhiri_code_sources.json` に機械可読で保存。

公式資料は [API](https://tawhiri.readthedocs.io/en/latest/api.html)、[風データ](https://tawhiri.readthedocs.io/en/latest/wind_data.html)、[補間実装](https://tawhiri.readthedocs.io/en/latest/implementation.html) を併読した。古い説明と公開HEADの詳細が違う場合は、上記commitへ固定したコードを優先した。
