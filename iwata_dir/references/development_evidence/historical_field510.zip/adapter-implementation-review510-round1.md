# 0.51 現役JRA adapter：独立source批評 第1巡

基準は0.50 C2 `2cefd08dfd039645b85d184a7089a7aa002ab775`。初回読取から親担当の2件修復後までを記録する。repo編集・module import・試験/新計算・新取得・Gitは実行していない。現在sourceのSHAは同名JSONへ記録。

## 結論

libraryの責務分割と科学的な初回範囲は妥当。`ModelLevelField` は列ごとのH/p再構成、`Jra3qModelField` はJRA固有の時刻・100層・係数・圧力式、`storage` はschema dispatchを担当する。元ASCII parserや取得HTTPを飛行核へ持ち込んでいない。現役sourceがworker/exportの指紋に含まれる。

親担当が採ったCLI保存・停止までの境界も妥当である。地上未支持のJRAをGFS取得GUIへ偽装しない。ただしこの段階を地上完飛行・着地分析・季節場接続の完成としない。実用不足の判断は次の実CLI出力/費用と停止を見て再評価する。

## source上で閉じた2件

| 反例 | 初回の問題 | 修復を読んだ結果 |
|---|---|---|
| 任意の100層σ係数（A=0, B=1−k/100）と元JRA HGTの組合せ | 端点/単調性だけではJRAとは異なるpを『JRA』として受理する | float正規化した原A/BのSHAを固定し、未知revisionは`UNSUPPORTED_VERTICAL_COORDINATE`。元ASCIIから別途抽出した[A,B]のSHAが `a02303033541811e03fe3e4baa76f2d678480ecd6c39a44f5a910d38a4c079ce` と一致した。新コードを実行した試験ではない |
| 元axisが0–360表記の西半球、核は−180–180表記 | 物理的に同じ経度なのに支持外になる | `_support`が同値±360を選ぶ小修正。継ぎ目を補間する変更ではない。今回の日本fixture値はこの変更の影響を受けない |

## 変換toolの残る修復提案（初回source時点）

1. `prepare_jra3q_flight_fixture.py` の読戻しはH/fields/metadataしか比較しない。軸を別の連続6h日時や別lat/lonに変えても、配列が同じならこの比較を通り得る。地表Hも比較されない。全normalized JSONの意味同一、またはtimes/levels/lat/lon/H/p/fields/地表p,H/metadataの全構造を読戻す必要がある。hybridもnormalized payloadとして保持・照合する。正常なserializeなら通常壊れないことと、読戻しで確かめた範囲は分ける。
2. `--root` は原入力と記録するsource_filesの基準だが、実行コードはPythonがimportしたmoduleである。別rootを指定すると、実際に使っていない同名sourceをprovenanceへ書ける。実module `__file__` のhashを記すか、rootと実行sourceの一致を事前に検査して拒否する。固定Rだけで使った今回の実行と、CLIとして受ける入力の契約を分ける。

この2件を親担当へ連絡済み。ここでは変更も再実行もしていない。

## 旧意味/不正入力について確認した範囲

- 各列のHで鉛直、次に水平/UTCという重み。pはlogではなくH線形を維持。Simmons–Burridgeの計算順とtop half/2は旧実装と対応する。
- shape、昇順座標、全100surface-up層、H上昇/p下降、p/T正、q∈[0,1)、欠測Noneを扱う。NaN/Inf・重複JSON鍵は現storageが拒否する。既存GFS dispatchは保持。
- 必須field名を明示した風-onlyならq欠測を要求しない。要求したq欠測は拒否。旧DEFAULT_FIELDSはqなし、新外向きfields=Noneは現行FIELD_NAMES（q含む）なので、無引数defaultが旧APIと同一だとは説明しない。flightはphaseのfieldsを明示しておりこの差は意図に合う。
- 支持列の地表下、最下Hより下、Hの内部欠測、p欠測/地下層、時刻/水平外を無言補完しない。mixed groundを返せても大気支持があるとは限らない。地表/共通下端の123.167gpm反例は保持される。
- 元toolは非finite値をNoneへ正規化することもあるが、新saved schemaはstrict JSONの数値/Noneで受ける。NaNを受理しない変更は入力形式の境界であり、既存有効原値の変更ではない。
- 空metadataでも物理配列を照会する型契約自体は成立する。ただし新bindingが元取得の真正性まで検証したことにはならない。今回の原データ来歴は固定変換toolの旧loader検証とsource hashへ結ぶ。
- 係数hashを固定したことはこのNCAR/JRA座標revisionの受入であり、将来全JRAや別格子/係数revisionの自動対応を意味しない。未知revisionは新しい別採否を要する。

## 継続して別に確認すべき境界

新bindingの時刻検査は「与えられた時刻列が連続6h」である。旧固定loaderのexpected_time_utcとの全一致とは別。先頭/末尾を落とした連続窓や別の連続窓はbindingのみでは検出できない。今回の原本変換は旧loader、将来取得は要求窓/実返却時刻のmanifest照合が担当する、と親担当が明示する方針を受領した。取得完全性をlibraryの連続性検査へ広げなければ問題ない。

現ModelLevelFieldは物理の新しい採用を避けた薄い接続であり、今必要なのは一般provider registryの追加ではない。一方、現在の小subsetには地表量も通常飛行を包む広域/時間窓もない。元係数同一・補間対照だけでは実物の飛行精度/計算負荷/分析画面の有用性を受け入れない。次の物理量消費・相遷移・ground/time/box停止・保存再読の結果を受け、母数と未到達段階を区別して追評する。

## 未実施

新source/testの実行、CLI、性能測定、API/GUI、新取得、科学精度評価は本票の範囲外。原A/Bの独立抽出SHAとsourceの静的追読だけを新観測としている。
