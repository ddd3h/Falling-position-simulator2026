# 0.51 固定JRA原UTC場の接続証拠

この束は、既存の固定JRA原応答から保存bundleを作り、既存飛行核へ接続して支持不足を確認した有限な作業記録です。原本・実出力・失敗・批評を改変せず収録しています。科学精度、地上から着地までの完飛行、任意日時の取得UI、複数年/季節MCの完成を示すものではありません。

## 読む順序

1. `adapter-critique510.md` / 実装批評round1・round2 / `interface-review510.md` で、旧問い合わせと現役保存場の境界、圧力補間、厳密列支持、未決事項を読む。
2. `prepared-01` / `prepared-02` の原gzipとreceipt、`prepare-source-01.py` で変換の前後をたどる。01のconverter原bytesを保存し、02の正本はrepoの `tools/prepare_jra3q_flight_fixture.py` をhashで参照する。2bundleの科学量・軸・surface・係数は同じで、差はmetadataだけ。
3. `real-runs-01` / `real-runs-02` の5条件それぞれについて入力、command、result、provenance、manifest、HTML、CSV、GeoJSONを読む。全5件ともstopped・CLI終了2。着地点を定義していない。地上支持拒否・時刻端・水平端・最大時間・降下の下端停止を区別する。
4. `tests-jra510` の初回失敗を残し、`jra-flight-field-tests510.json` とretryの原log/XMLを読む。最初の13成功と、同一sourceでTemp権限由来2件を通常権限へ切り替えて成功した再試験であり、15件を一括成功したとは記さない。
5. `regression-01.xml` は139件成功の時点証拠。その後HTMLのGFS固定表記を選択気象モデルの表現へ訂正し、5条件を再実行した。`package-validation.json` が01/02の全5 `result.json` のbyte一致と、実行時source差がreportだけであることを照合する。139件をcaption訂正後に全再実行したとは主張しない。
6. `example-c10-01` はC10診断例の保存出力。PowerShell `ConvertFrom-Json` による日時の自動local変換が操作確認時に起きた。その後C10の表示例を `elapsed_s` へ変更し注記を加えた。`example-c10-review510.json` と `check-example510.py` は物理result全要素が02のphysical例と同じこと、configのlabel/purposeだけが異なること、manifest6個の一致を確認した。完全JSONの同一とは区別し、result原JSONのUTC文字列を正本として読む。

## 計測と表示の限界

最終 `real-runs-02/receipt.json` は小窓を約0.014993秒で読込み、等温上昇→破裂→降下停止の積分を約0.097618秒で観測した。同じ条件のCLIプロセス全体は約0.977618秒であり、積分時間と混ぜない。一台・固定2時刻/2×2格子/100層での単発値で、実運用規模・MC・再取得・地上完飛行の性能保証には外挿しない。

HTMLは原byteを保全したが、検証時はfile URLをブラウザが拒否したため画面目視は未了だった。保存のhash検算、HTML生成成功と、実ブラウザ上の見やすさの受入を区別する。3Dや外部背景地図の再接続は行っていない。

## 原本の所在と再実行

原 `references/jra3q_model_fixture/source_bundle.json` はprivate repoの既存実体をpath/sha256で参照し、このZIPへ二重収録しない。`source-references.json` のsource指紋と実行時provenanceを照合する。runtime sourceの本体もrepo側にあり、このZIP単独で環境・コード一式を提供するものではない。

通常の再実行はrepoのCOMMANDS C10に従い、新しい `$taskOutputRoot` を作り、固定原本→新bundle→inspect→`examples/jra3q-support-flight.json` のsimulate→原resultの停止理由を読む。既存出力を上書きしない。結果閲覧のために原JSONをPowerShellで再書出ししない。

5条件を再現する場合は、ここにある `run-real510-final.py`、`jra-short-config510.json`、`prepared-02` だけを別の新規作業ディレクトリへコピーし、repoを作業ディレクトリ/PYTHONPATHにして同じPython依存で実行する。scriptは自身と同じ場所に新規 `real-runs-02` を作るので、保存された実績ディレクトリ内では再実行しない。機械の絶対パスは元の命令/来歴として保存したもので、新環境の指定先ではない。raw再取得や外部通信は必要ない。

## 収録と未収録

`package-whitelist.json` の明示実体だけを収録する。`package-manifest.json` は自身を除く全memberのsize/SHAを列挙し、ZIP外のreceiptはmanifest自身も含む全memberを検算する。入力は原byte一致で、gzipも再圧縮しない。CRC、全member、入力と関係runtime sourceの前後一致を別々に確認する。有限patternによる秘密検査は万能な不存在証明ではない。

未完のguide build/publication、metadata、将来C1/C2/PR保存票は収録しない。後続はS36と別票へ記録する。旧原Git1305＋今回診断13の区別をbasis/Git診断票に残すが、生成主体や現在remote同期を断定しない。確認印・科学採否・人間の採用・main統合は別である。
