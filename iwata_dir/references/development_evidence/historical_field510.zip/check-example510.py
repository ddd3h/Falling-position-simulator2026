from pathlib import Path
import hashlib,json,xml.etree.ElementTree as E
R=Path.cwd();P=Path('C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rd=lambda p:json.loads(p.read_text(encoding='utf-8'))
Q=P/'example-c10-01';r=rd(Q/'result.json');original=rd(P/'real-runs-02/physical_descent_gap/result.json')
assert {k:v for k,v in r.items() if k!='config'}=={k:v for k,v in original.items() if k!='config'}
config_changes={k for k in r['config'] if r['config'][k]!=original['config'].get(k)}
assert config_changes=={'label','purpose'},config_changes
m=rd(Q/'manifest.json')
for name,row in m['files'].items():
    assert (Q/name).stat().st_size==row['bytes'] and sha(Q/name)==row['sha256']
assert r['status']=='stopped' and not r['complete'] and r['summary']['landing'] is None
assert r['stop_reason']['code']=='HEIGHT_OUT_OF_RANGE'
assert r['records'][-1]['time_utc'].endswith('+00:00')
html=(Q/'report.html').read_text(encoding='utf-8')
assert '使用した気象モデルの補間地形' in html and 'GFS地形' not in html
def norm_cfg(obj):
    obj=dict(obj);obj.pop('label',None);obj.pop('purpose',None);return obj
tests=E.parse(P/'regression-01.xml').getroot()
proof={'schema':'example-c10-510/1','physical_result_equal_to_final_real_case':True,'config_difference_only':sorted(config_changes),'all_six_manifest_files_match':True,'exit_code_observed':2,'status':r['status'],'stop_reason':r['stop_reason'],'landing':None,'records':len(r['records']), 'saved_utc_not_changed_by_powershell_display':True,'caption_uses_generic_weather_model':True,'report_browser_visual':'not completed; browser file URL policy rejection preserved, no workaround','regression_source_timing':'139 prior to caption-only correction; final five CLI outputs preserve numerical JSON; this committed example uses current caption','files':{p.name:{'size':p.stat().st_size,'sha256':sha(p)} for p in Q.iterdir() if p.is_file()},'command_source_sha256':sha(R/'docs/COMMANDS.md')}
(P/'example-c10-review510.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False,indent=2))
