# 0.51 構造索引候補の限定レビュー

基準は 0.50 C2 `2cefd08dfd039645b85d184a7089a7aa002ab775`、候補は `index-candidate510.json`。repo の索引・実装・確認印は変更していない。

| 対象 | 索引に反映した責務と依存 | 限界 |
|---|---|---|
| `environment/model_levels.py` | 製品やI/Oに依存しない列支持・問い合わせ。既存 fields の単位/軸/例外 helper を使う。class の内側の定義もASTで記載。 | 支持外の地上層を追加せず、任意モデル製品の受入を意味しない。 |
| `environment/jra3q.py` | 製品・原UTC・固定鉛直座標の検査から ModelLevelField へ渡す。継承は class bases と手動接点で明記。 | `super()` は字句call抽出の解決外。独自の完全call graphとは呼ばない。 |
| `environment/storage.py` | 同じ load_weather 引数のまま保存schemaでJRAへ分岐し、既存気圧面場への経路を保持。旧公開importと署名を維持。 | API取得asset登録やダウンローダの完成を主張しない。 |
| `results/report.py` | 気象地形の図注を使用モデル一般へ訂正した現source指紋とASTへ同期。 | 数値結果・図形・物理モデルの変更ではない。 |
| `tools/prepare_jra3q_flight_fixture.py` | 旧原本検証を再利用し、現役保存形式を作って読戻す固定変換。tool → library の依存だけ。 | 一般JRA取得器ではない。現役libraryはtoolをimportしない。 |
| `tests/test_jra3q_flight_field.py` | 独立列場・旧問い合わせとの意味保持・支持反例・保存振分け・飛行停止を扱う試験の所在/import/15定義。 | 定義数は実行成功数ではない。試験の実績は別票。converterそのものを実行する専用試験だとは記していない。 |

追加したAPI行は `ModelLevelField.sample` / `ground_altitude` と `Jra3qModelField.__init__` の3件に限る。30行全てを実定義AST署名と試験所在へ照合した。新APIの `reviewed_in` は null に残し、主担当の読解・採否と区別した。旧27件の確認履歴・公開再exportは保持し、旧APIで意味を変えた行は load_weather の責務・変更版・追加試験所在だけである。

新しい WEATHER-MODEL は主担当が PROGRAM に用意する対応階層へ結ぶ。旧 frontend/3D・HTTP routes・service entry・旧supporting行を再抽出せず保持し、現役Python50→52moduleのうち変更4実体だけ構文・字句辺を更新した。変換toolと試験はruntime module数へ混ぜず、supporting側へ追加した。

生成前後で対象source指紋とrepo索引の不変を照合した。候補差分は `index-candidate510.patch`、全指紋と機械照合は `index-evidence510.json`、再現用の外側helperは `update_index510.py` にある。旧API確認履歴の維持は新実装の科学的採用を先取りするものではなく、未変更枝を全面再受入したという意味でもない。