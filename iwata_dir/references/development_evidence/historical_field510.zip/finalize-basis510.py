from pathlib import Path
import hashlib,json,datetime,zlib
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510');Q=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-operational-500');R=Path.cwd();B=P/'basis-repo';G=R/'.git'
FREEZE_SHA='20b9afb5eb5880fd9781aa3d63f644f20d5c0da927a05e1e3845272ede700c12'
REVIEW_SHA='026d61be749fcc2c1dd6e3618afb75ea587404fed484f9ce5e96aafca0bcb5a7'
COMMIT='2cefd08dfd039645b85d184a7089a7aa002ab775';TREE='e06a65986898e0cf6c5e1000ffa396012a6417a2';HEAD='ad3494d700068d873a22ed2fbbf6f0a760a41735'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def inventory():return [{'path':p.relative_to(G).as_posix(),'sha256':filehash(p)} for p in sorted(G.rglob('*')) if p.is_file()]
def fingerprint(rows):return sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
def head():
 raw=(G/'HEAD').read_text(encoding='ascii').strip()
 if raw.startswith('ref: '):
  ref=raw[5:];p=G/ref
  if p.is_file():return {'reference':ref,'commit':p.read_text(encoding='ascii').strip()}
  for line in (G/'packed-refs').read_text(encoding='ascii').splitlines():
   if line and not line.startswith(('#','^')):
    oid,name=line.split()
    if name==ref:return {'reference':ref,'commit':oid}
  raise RuntimeError('HEAD reference not found')
 return {'reference':None,'commit':raw}
def tree_hash(rows):
 root={}
 for row in rows:
  node=root; parts=row['path'].split('/')
  for part in parts[:-1]:node=node.setdefault(part,{})
  assert parts[-1] not in node
  node[parts[-1]]=(row['mode'],row['blob'])
 def visit(node):
  out=[]
  for name,value in node.items():
   isdir=isinstance(value,dict);mode,oid=('40000',visit(value)) if isdir else value
   out.append(((name+('/' if isdir else '')).encode(),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
  payload=b''.join(raw for _,raw in sorted(out));return hashlib.sha1(b'tree '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
 return visit(root)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert filehash(Q/'record-freeze500.json')==FREEZE_SHA
assert filehash(P/'git-extra-review510.json')==REVIEW_SHA
freeze=read(Q/'record-freeze500.json');receipt=read(Q/'record-git-receipt500.json');review=read(P/'git-extra-review510.json');prior=read(Q/'original-git500-diagnosis.json');initial=read(P/'git-diagnosis510-before.json')
assert receipt['commit']==COMMIT and receipt['tree']==TREE and receipt['status']=='readback_verified' and receipt['freeze_sha256']==FREEZE_SHA
rows=freeze['files'];assert len(rows)==281
assert tree_hash(rows)==TREE
before=inventory();head_before=head();old={x['path']:x['sha256'] for x in prior['current']['files']}; now={x['path']:x['sha256'] for x in before}
assert len(old)==1305 and len(now)==1318 and len(set(now)-set(old))==13
assert all(now.get(k)==v for k,v in old.items())
assert now=={x['path']:x['sha256'] for x in review['current_files']}=={x['path']:x['sha256'] for x in initial['files']}
assert fingerprint(before)==initial['fingerprint']=='b6d5789e678421598c2e0cee59009a7d2a9805066a5db040d4e085e0f9fe2a65'
assert fingerprint(prior['current']['files'])==prior['current_fingerprint']=='f01f6787954e458fee19d606fc73436e44b2041593e17541e522bd55104b65fb'
assert head_before['commit']==HEAD
expected_paths={r['path'] for r in rows};actual_paths={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()};assert actual_paths==expected_paths
for row in rows:
 data=(B/row['path']).read_bytes()
 assert len(data)==row['size'] and sha(data)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
byblob={r['blob']:r for r in rows};adds=[]
for prior_row in review['added']:
 path=prior_row['path'];data=(G/path).read_bytes();dec=zlib.decompressobj();raw=dec.decompress(data)+dec.flush();header,body=raw.split(b'\0',1);typ,n=header.decode('ascii').split();oid=hashlib.sha1(raw).hexdigest()
 assert dec.eof and not dec.unused_data and typ=='blob' and len(body)==int(n) and oid==path[8:].replace('/','')
 assert sha(data)==prior_row['compressed_sha256'] and oid==prior_row['object_sha1'] and byblob[oid]['path']==prior_row['matches_fixed_050_C2_path']
 assert body==(B/byblob[oid]['path']).read_bytes()
 adds.append({'path':path,'sha256':sha(data),'type':typ,'object_sha1':oid,'payload_sha256':sha(body),'payload_bytes':len(body),'C2_path':byblob[oid]['path']})
after=inventory();head_after=head();assert before==after and head_before==head_after
# A second fixed-basis hash pass closes mutation during diagnosis without reading current working source.
for row in rows:assert (B/row['path']).stat().st_size==row['size'] and filehash(B/row['path'])==row['sha256']
assert {p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}==expected_paths
out={'schema':'basis510/1','at_utc':start,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':COMMIT,'tree':TREE,'main':'4e3e4db0d047af9479bcd68bfc2553eeb71efcc9','basis_directory':str(B),'files':rows,'file_count':281,'source_verification':{'complete_path_set':True,'size_sha256_and_git_blob':True,'computed_git_tree':TREE,'before_after_stable':True,'current_working_R_checked':False,'reason':'R is now being edited by authorized implementation workers; fixed basis-repo, not current R, is the comparison source.'},'evidence':{'record-freeze500.json':FREEZE_SHA,'record-git-receipt500.json':filehash(Q/'record-git-receipt500.json'),'git-extra-review510.json':REVIEW_SHA,'git-diagnosis510-before.json':filehash(P/'git-diagnosis510-before.json'),'original-git500-diagnosis.json':filehash(Q/'original-git500-diagnosis.json'),'fix-basis510.py':filehash(P/'fix-basis510.py')},'original_git':{'head':HEAD,'head_reference':head_before['reference'],'fingerprint':fingerprint(before),'files':before,'file_count':1318,'previous_file_count':1305,'previous_fingerprint':prior['current_fingerprint'],'previous_files_unchanged':True,'removed':[],'changed':[],'explicit_additions':adds,'before_after_stable':True,'policy':'Preserve the fixed original 1305 and these independently diagnosed exact 13 additions. Unknown additions or changes remain outside this receipt; no automatic rebaseline is permitted. The additions are known C2 payloads, not proof of a synchronized or advanced HEAD.','producer':'unknown'},'initial_attempt':{'script':'fix-basis510.py','parent_reported_outcome':'Stopped at the old exact-1305 original Git assertion after verifying/copying the 281 fixed files; did not emit basis510.json.','independent_source_read':'The script checks all registered R bytes/blob hashes, then copies/reads back basis-repo, then asserts old .git count and fingerprint before HEAD lookup and basis ticket writing. The existing exact 281 basis copy plus no previous ticket is consistent with this reported stop. No execution log was independently read in this task.','existing_copy_reused_after_full_reverification':True,'script_reexecuted':False},'authority':'Root explicitly requested diagnosis-based fixed start after independent 13-object review. This records the distinguished original history and additions; it does not erase the previous 1305 baseline or infer a blanket allowance for later additions.','limits':'Read-only .git and fixed basis verification. No Git executable, network/API, R mutation, deletion, reset or synchronization. Current working R equality is intentionally not claimed. Remote freshness and C2 commit/tree binding use the existing frozen/readback receipt, not a new remote call. Creator of the additions remains unknown; scientific/runtime correctness is not established by hashes.'}
path=P/'basis510.json'
with path.open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'path':str(path),'sha256':filehash(path),'fixed_files':281,'tree':TREE,'git_files':len(before),'additions':len(adds),'stable':True},ensure_ascii=False))
