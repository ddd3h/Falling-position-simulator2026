# 0.51：保存JRAモデル面と現役飛行核の接続案

2026-09-30 JST。基準はPR30/0.50 C2 `2cefd08dfd039645b85d184a7089a7aa002ab775`、採用main M420 `4e3e4db0d047af9479bcd68bfc2553eeb71efcc9`。これは読取り調査・設計案であり、実装、試験実行、一般取得器、地上からの全飛行の完成を報告するものではない。R、Git、稼働server、既存Google接続は変更していない。

## 結論と最小の到達点

飛行核をJRA用に複製する必要はない。現役libraryの`load_weather`へ **固定保存形式を識別するdispatch** を足し、**列ごとに異なる高度・圧力を照会するModelLevelField** と **JRAの半層圧力・6時間解析時刻を検証するbinding** を置く。旧fixture toolは原本の照合・対照用に保持し、worker/CLI/libraryからimportしない。

最初の到達点は「元UTC・原値を保持したJRA保存場を、現在の`simulate`→原records/停止→CLI/API保存再読へ渡せる」である。**支持内の上空から60秒上昇し、`MAX_DURATION`で終了する**ことを成功条件にする。地表付近の約8 gpmの欠測は埋めない。停止と着地を同一視しない。旧GFSの保存形式と挙動を保持する。

この小さな到達点は、過去飛行と長期計画の共通基盤になる。一方、同じ場一つを用いる既存機体MCを、複数年の気象MCへ名前だけ変えてはならない。原日時の連続窓、気象実現値ID、機体draw IDの二軸は次の契約である。

## 1. 現在存在する実データと支持

| 実体 | 現在の所在と大きさ | 本調査で確認したこと |
|---|---|---|
| 元応答一式 | `references/jra3q_model_fixture/source_bundle.json`、340,890 bytes、SHA256 `81bf2a10759d8f92a9576f3285bc810bedbe30a6f3675df78416f3ccf8295811` | 15 ASCII/DAS応答がbodyとして内包され、本文289,373 bytes。各byte数とSHAがreceiptへ一致 |
| 数値 | 同bundle内、4,012値 | 上層T/HGT/u/v/qが各800値、SPが8値、静的GPが4値。半層係数/座標は別 |
| 時刻 | 2024-01-01 00:00 / 06:00 UTC | analysis valid時刻であり、予報run/leadではない。GPの原時刻1947-09-01は静的量の座標で、飛行時刻に書き換えない |
| 水平 | 緯度34.651383346207 / 35.0259928266149、経度136.875 / 137.25 | 元Gaussian格子の2×2。緯度等間隔の世界格子や北海道570格子ではない |
| 鉛直 | 全100モデル層、surface-upward | 全8列の最下H 38.562347〜211.64847 gpm、最上H 77,368.74〜77,547.04 gpm |
| 地表 | 静的GP / 9.80665 | 30.6376428240〜203.6834800875 gpm。2mT/q、10m風はこのfixtureに含まれない |
| 地上gap | 最下H−地表H | 7.8476199125〜8.0420751760 gpm。原値からDecimalで再計算。全飛行の支持を意味しない |
| 既存候補 | `tools/normalize_jra3q_model_fixture.py` 22,097 bytes | 原bundle SHA固定、全応答/単位/軸/時刻照合、半層→全層圧力、gpmでのquery。汎用交換形式ではない |
| 既存反例 | `tests/test_jra3q_model_environment.py` 17,310 bytes | アフィン場、独立Decimal圧力、原ASCII節点、欠測/地表gap/時刻拒否などの本文を読解。本調査では再実行していない |

登録されたJRA fixture directoryには元bundleのみがある。現`balloon.weather/1`に渡せるJRA正規化ファイルや、その現役飛行結果はまだ登録されていない。旧toolの`to_dict()`は自身で「diagnostic snapshot, not general input interchange」と規定しているため、そのschemaを無審査で本体の永続形式に昇格させない。

0.49で接続した2016–2025年/24半月/38面/570格子の風統計DBは別製品である。今回の元UTC場をそのDBから復元したものとは呼ばない。DBは原時刻列を含まず、年・時刻別の連続4D場にもできない。

## 2. 現役インターフェースと必要差分

| 接点・根拠 | 現在の契約 | 今回の最小差分 |
|---|---|---|
| `environment/storage.py:35` | `load_weather(path)`はstrict JSON/gzip読込み後、無条件にGFS `WeatherField`を構成 | schemaを明示dispatch。既存`balloon.weather/1`は同じGFS bindingへ、新JRA schemaは新bindingへ。不明schemaを推測しない |
| `environment/bundle.py:6` | `WeatherField(PressureLevelField)`へGFS配信時刻とcoarse terrain品質を注入 | この互換classをJRA向けに意味変更しない |
| `environment/fields.py:180,184` | `ground_altitude(UTC,lat,lon)`、`sample(UTC,lat,lon,geometric_ASL,fields=None)`。flat SI値と`quality`、metadata | ModelLevelFieldも同じ外向きprotocol。内部の列圧力/補間/支持政策は製品別 |
| `flight/trajectory.py:26` | 製品・HTTP・保存形式を知らず上記protocolを使用。weatherの例外codeを停止へ保持 | JRA分岐を足さない。地表開始の支持拒否も原records空/停止として残す |
| `cli.py:20` | `inspect`と`simulate --weather`がload_weatherを共用。完了0、保存された停止2、入力/実行error1 | JRA保存場を既存CLIで読める。`fetch/replay`はGFS専用のまま。inspectには再解析/地上gapを表示 |
| `backend/worker.py:35` | weather/config/source SHAを前後検証し同じsimulateを実行、保存。数値停止は有効な結果 | dispatchがつながれば計算本体変更不要。新library sourceも既存source_snapshot再帰収集対象 |
| `backend/application.py:148` | fixture一覧をGFS軸`pressure_pa`とrun metadataから構成 | 登録済みnormalized JRAをallowlistへ追加する場合だけsource descriptorを製品非依存に。HTTPに任意path/任意schema import口を作らない |
| `backend/application.py:191` | source IDから固定shaを選択。時刻全窓の事前検査は`kind=acquired_gfs`だけ | JRA新sourceには同じ全宣言窓検査を適用。既存GFS fixtureの支持外停止テストは不意に拒否へ変えない。kindより明示capability/入力policyで分ける余地 |
| `backend/ensemble/planning.py:26` | 全caseで一つのweather_snapshot、全max_duration窓を検査、機体drawを共有 | 今回のn=1接続に変更不要。複数歴史窓を追加する前に別設計する |
| `backend/contracts.py:9` | RunRequestのweather_source_idとopaque config、固定結果参照 | field種別を飛行configに重複追加しない。保存sourceのidentityで決まる |
| `results/export.py:38` | 元input、原result、weather bytes SHA/metadata、source SHAを保存 | JRA metadataのproduct/原時刻/方法/元原本SHAを渡す。保存済み結果GETが元DB不在で読める現境界を維持 |

**地形と大気支持は別である。** 新ground_altitudeは、同じ時空間の正重み地表Hを混合し、既存球形近似で幾何ASLへ戻す。大気sampleは各寄与列の地表・最下モデルHを厳密に検査する。混合地表より上でも、高い寄与列より低ければ拒否し得る。その保守性をGFSのterrain stencil clampへ勝手に置き換えない。surface gapを閉じない限り、最後の着地イベントを位置決定できる保証もない。

## 3. 小さい責務分割の提案

```text
元bundle（固定原本）
  └─ fixture準備だけの変換手順 → 新正規化bundle＋変換manifest
       └─ storage.load_weather(schema dispatch)
            ├─ 既存 WeatherField → PressureLevelField（GFS/1のまま）
            └─ Jra3qModelField → ModelLevelField（列圧力・strict支持）
                 └─ 共通 sample / ground_altitude / metadata
                      └─ simulate → export / worker → 既存結果再読
```

| 候補path | 責務 | ここへ入れないもの |
|---|---|---|
| `balloon_sim/environment/model_levels.py`（新） | 任意の有限モデル列のshape/単調性/正重み支持、幾何z↔H変換、列のH上のp/T/q/u/v内挿→水平→UTC、ground照会 | HTTP、JRA URL、100層固定、6h固定、GUI、積分、地表bridge |
| `balloon_sim/environment/jra3q.py`（新） | 新JRA normalized schema、analysis 00/06/12/18の連続native時刻、半層A/BとSPからSimmons–Burridge p、原本・方法metadata、上記classの構成 | 旧tool import、GRIB一般取得、今年の日付へ原時刻を置換、GFS互換の偽装 |
| `balloon_sim/environment/storage.py`（変更） | schema→既存GFS/新JRAの明示dispatch | fieldごとの数学・provider推測 |
| fixture準備用の新toolまたは外側再現script | 原bundle SHA/全receiptを検証し、旧loaderの結果を新schemaへ書き、現役bindingで検証、元→変換後SHAを記録 | runtimeのたびにfixture toolを呼ぶこと、汎用NCAR downloaderと名乗ること |
| 新library/CLI/API試験 | 下記の独立期待値と不正入力・支持境界・保存を確認 | 旧toolと新classの一致だけを唯一のoracleにすること |

最初のfixture準備段階では既存固定loaderを対照・入力生成に使ってよい。その依存は**準備tool→旧fixture tool**に限定し、library/workerは完成normalized bytesだけを読む。将来のNetCDF/GRIB decoderは同じ新schemaを生成する別の入口となる。旧ASCII parserをlibraryへ丸ごと移して永久の取得形式にしない。

現在`fields.py`の高さ変換・数値/軸/UTC helperを内部利用する程度で足りる。今回だけのためにplugin registry、汎用provider抽象階層、全PressureLevelFieldの大規模分解を先行させない。将来共通primitiveを別moduleへ移すときも、旧公開`balloon_sim.weather`のre-exportを保つ。

圧力面へ無理に載せる案は採らない。JRAの同じlevel番号のpはSPに依存して列ごとに違うため、単一`axes.pressure_pa`を作れば元の鉛直座標を変えてしまう。現在GFSのlog(p)内挿も、旧JRAの高さ線形pと同じではない。

### 新保存schemaの最低要件（命名は実装前に固定）

候補schema名は`balloon.weather.jra3q_model/1`。axesはtime UTC / model_level / latitude_deg / longitude_degで、配列順は明示する。保存内容は上層H/T/q/u/v、SP、地表Hまたは原GP＋重力定数、半層A(Pa)/B(無次元)、expected native時刻、source/provenanceと方法version。pはbindingが半層から求める正本とし、別の独立保存pを同時に無検査の正本にしない。

- half pressure `p_half[k]=A[k]+B[k]*ps`。内部fullは`exp((L ln L − U ln U)/(L−U) − 1)`、最上fullは`L/2`。ERAの算術平均やNCAR fitted full係数へ置換しない。
- query heightは幾何ASL。内部は `H=R z/(R+z)`, `R=6,371,000 m`。球形geoid近似というqualityを残す。
- 初回のmethodは「Hで各列の値とpを線形→緯度経度→UTC」、surface policyは`strict_no_extension`。半層p式とquery p補間は別の方法として記録。
- missingはnullのまま。正重み支持を一つでも欠けば拒否。ゼロ重みの未使用列・未要求qは必要以上に拒否しない。NaN/Infや重複JSON鍵は現storageで拒否。
- 型/shape、H上昇、p下降、p正、T正、q∈[0,1)、expected times全一致を検査。範囲外、内部native時刻欠落、地表下、最下H未満、H欠測を区別。
- `.sample`はflat SIと`quality:list`を返し、`.metadata`はinspect/exportが使えるdetached JSON。詳細support indicesは診断入口または任意付加metadataでよく、全積分点へ無条件に巨大配列を保存しない。
- longitudeの±360同値表現は現fieldと揃えられるが、継ぎ目補間を新設する意味ではない。fixed fixtureとの変更点としてテストする。

## 4. 独立に検証できる入力と期待値

期待値の出所を混ぜない。以下A/Dは本調査で元ASCII/Decimal/数式から抽出・算出、B/Cは既存の独立期待式を再読、E以降は受入案であり未実行。

### A. 原ASCII節点と高さ変換

00 UTC、南西格子（34.651383346207,136.875）、level51＝0-based50。元ASCII `[0][50][1]` 行の第1値（元緯度は下降順）から直接読む。

| 量 | 原値 |
|---|---:|
| H | 12611.112 gpm |
| T | 214.86037 K |
| u | 47.71206 m/s |
| v | 2.1910744 m/s |
| q | 0.0000075264843 kg/kg |
| 対応する幾何ASL | 12636.1246484362565 m |

JRA bindingを介すqueryはこの値へ丸め誤差の範囲で一致する。z→Hの往復が浮動小数点で節点を僅かに外す可能性があるため、新幾何入口の試験で「support必ず1点・bit完全一致」を強制しない。原gpm入口の節点試験とは分ける。pは原T/U等とは別に、同列SP・半層A/Bから60桁Decimal式で計算して照合する。

### B. 動くモデル高度のアフィン場

既存`tests/test_jra3q_model_environment.py:30`の人工3層・2時刻・2×2を新class用入力へ組み替える。H=1000gpm、03 UTC、35N/137Eで **p=80009 Pa、T=279.5K、u=7.5m/s、v=−4m/s、q=.0023**、正重み支持16セル・重み総和1。別の節点（00 UTC/36N/138E/H250gpm）でp=95014 Pa。同じlevelの共有pressure軸では再現できない反例である。

### C. 実場の30 km付近の問い合わせ

既存独立Decimal参照（00/06の中間03 UTC、34.8N/137E、**H=30000gpm**）は T=234.19382622059165 K、u=−45.107594381376995 m/s、v=−2.5550255797890772 m/s、q=3.986902242771835e−6 kg/kg。旧toolとの一致だけでなく、この原ASCII由来の値と比較する。

H30000gpmは幾何30141.93344898281m。幾何30000mはH29859.39696922356gpmであり、同じ期待値を使わない。幾何30kmのqueryは別に旧gpm対照または独立補間を計算し、両者の識別・全寄与列で上下層があることを試す。

### D. 元実場の60秒上昇

具体入力は同directoryの`jra-short-config510.json`。02:17:13 UTC、格子中央34.838688086410954N/137.0625E、H開始=`max(最下H全8列)+100=311.64847gpm` → z開始=311.663715569002m。定速5m/s、破裂高度30000m、最大60s。降下法は未到達だが、風だけを要求する指数密度型を明記する。

独立期待：t終端60s、UTC02:18:13、z終端611.663715569002m、phaseは上昇、burst/landing eventなし、`status=stopped`,`complete=false`,`stop_reason.code=MAX_DURATION`、landing=null。受け入れられたrecordsは残り、0風で置換しない。

全原風800値ずつの最大絶対値はu=67.10204、v=25.011665m/s。正の重みの線形補間と現球形ODEを前提とすると、60sの最大緯度移動0.01349546deg・経度移動0.04421344degは、中央からの余白0.18730474deg・0.1875degより小さい。Hも全列最下より100gpm以上・最上より十分下で、時刻も支持内なので、この試験の支持外停止は予定成功とせず調査する。これは有限領域・数値接点の検査であり現地の地上放球ではない。

実風の最終経緯度を同じadapter/solverで計算してgolden値にするだけでは独立性がない。経緯度の数学は、別の定数風モデル列（u=20,v=0、開始z0、上昇w=5）について `Δlon_rad = (u/(w cos φ)) ln((R+z0+w t)/(R+z0))`, `lat=φ` を対照にする。実場は原query/支持/再現性を、人工場は積分とadapterのつなぎ方を検証する。

### E. 拒否と保存の有限受入表

| 入力・行程 | 期待する区別 |
|---|---|
| 各元格子で地表Hと最下Hの中点 | `HEIGHT_OUT_OF_RANGE`、補間/最低層保持なし |
| 各元格子で地表H−1 | `BELOW_MODEL_SURFACE`（またはlibraryで明示対応したcode）、gapと区別 |
| 中央の混合地表zから放球 | 非landed・原code保持。地形上だから大気も支持されるとはしない |
| 00/06のexact query | 両端可。時刻±1µs外は`TIME_OUT_OF_RANGE` |
| 00→12のみで06を欠くbundle | 内部欠落を長いedgeとして内挿せず構築拒否 |
| 05:59:30開始/60s | library単体は支持境界までaccepted records＋`TIME_OUT_OF_RANGE`停止。APIで全窓を要求するsourceなら受付前422。この二つを同じ試験と呼ばない |
| 正重み列のq欠測、q未要求/要求 | 未要求ならu/v経路可能、要求なら欠測拒否。乾燥大気へ無言置換しない |
| H軸途中欠測、単一列不足、NaN/重複鍵、変換後SHA改変 | 各構築/query/固定保存の適切な層で拒否。残り列へ重みを再配分しない |
| CLI inspect→simulate→同一入力の再実行 | metadataはJRA、停止結果も全ファイル保存・CLI2、原input/normalized SHA一致。Rや既存出力を上書きしない |
| API source登録→run→再起動→固定run再読 | 同一source bytesとconfig/source snapshotへ束縛。sourceが失われても保存済みresultの読取りを妨げず、新実行は拒否 |
| 既存GFSと公開re-export | CLI/worker/既存saved project/resultの契約保持。新adapterのためにGFS時間/地表方針を変更しない |

## 5. API/UIへ出すなら先に閉じる接点

第一段階がlibrary+CLIなら、GUIへ未接続sourceを見せる必要はない。APIまで進める場合は、GFS例と同じ無名fixture欄へ混ぜず、「JRA-3Q 保存解析場・2時刻2×2・上空60秒の接続検査例」と分かるsource descriptorを用いる。

source snapshotには少なくともid/label/bytes/SHA、product/time_kind、native valid times、lat/lon bounds、vertical kind、surface policy、原bundle SHA、変換method/source SHA、terrainと支持限界を含める。`run_utc:null`を明示して予報runを創作しない。pressure boundsが必要なら全列のmin/maxという診断であり固定pressure軸/全位置の高度保証ではないとする。現frontend WeatherSource型の`bounds.pressure_pa`必須や「保存GFS」の文言は、APIを見せる段で限定訂正する。

明示的な検査例としてのdefault_configを付けるなら上記60秒入力だけであり、「現地の地上放球ではない」を名前/目的に残す。一般取得assetのdefault_config=nullを、勝手な機体/高さで埋める慣行へ拡張しない。既存草案へsourceだけを適用する操作で、日時・機体・地点を上書きしない。

この小subsetは通常の4h飛行には短い。02:17:13から4hは06:17:13まで必要なので、00/06だけでは不足する。時刻支持検査が正しく拒否するのを、便利さのために無効化しない。

## 6. 先送りを明示する事項

- 地上全飛行：2mT/q・10m風、静的地形と最下層の関係、surface policyを別採否。最下層約8mが10m風anchorより低い列を無視しない。
- 一般取得：NCAR URL、認証、NetCDF decode、月/日block連結、取得見積り・取消・再利用。前回公式情報の観測日を今回の稼働確認へ上書きしない。
- 過去実飛行：「当時知り得た予報」の情報締切/公開証拠と後日の再解析validを別metadataへ。JRA内fcst製品は当時運用GFSの代わりではない。
- 今年7月：launch時刻maskと、飛行中に必要な原UTC連続窓の支持を分ける。元yearを今年へ書き換えず、scenario mappingを保持。層・場所・u/v・時間を独立に引き直さず、一組の場を一飛行で使う。
- 気象窓×機体drawの二軸、欠測/未実行/範囲外を含む予定母数、対応比較。既存256件制限は運用上限であり必要標本数の科学的決定ではない。

## 根拠と読取りの限界

入口はP500の`historical-route-review.json`。現物のsource/bytes/SHAと固定C2コピー一致は`interface-material510.json`へ置いた。原ASCII節点・8列gap・global風範囲の独立抽出は`inspect-interface510.py` / `inspect-bounds510.py`（標準library、repo module importなし）で再現できる。

本調査は現役storage/field/flight/CLI/worker/登録/ensemble planの接点と関連testを読み、原JSONから数値を抽出した範囲である。旧test全実行、新adapter、新simulate/API/GUI動作、新取得、科学的精度、運用安全、main統合を確認していない。sourceの現在性はP510/basis-repoに対する照合であり、この担当はGitへ新照会していない。原DBの全過去年データが得られたという主張もしない。
