"""Finite 0.51 evidence packaging; explicit members, read-only R, no simulation/network/Git."""
from pathlib import Path, PurePosixPath
import datetime as dt, gzip, hashlib, json, os, re, zipfile
import xml.etree.ElementTree as ET

P=Path(__file__).resolve().parent
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
OUTPUT=P/'historical_field510-candidate.zip'
RECEIPT=P/'historical-field510-archive-receipt.json'
CASES=('short_constant','physical_descent_gap','ground_rejected','time_boundary','horizontal_boundary')
PRODUCTS=('input.json','result.json','provenance.json','manifest.json','report.html','trajectory.csv','trajectory.geojson')
TOP=(
'basis510.json','git-diagnosis510-before.json','git-extra-review510.json',
'fix-basis510.py','finalize-basis510.py','review-git-extra510.py',
'prepare-source-01.py','run-real510.py','run-real510-final.py','jra-short-config510.json',
'regression-01.xml','jra-flight-field-tests510.json','run-jra-tests510.py','close-jra-tests510.py',
'adapter-critique510.md','adapter-critique510-evidence.json',
'adapter-implementation-review510-round1.md','adapter-implementation-review510-round1.json',
'adapter-implementation-review510-round2.md','adapter-implementation-review510-round2.json',
'interface-review510.md','interface-review510-receipt.json','interface-material510.json','inspect-interface510.py','inspect-bounds510.py','close-interface510.py',
'index-review510.md','index-evidence510.json','index-limited-independent-review510.json','index-candidate510.patch',
'theory-formula-check510.json','theory-candidate510-edits.json','theory-candidate-review510.md','theory-candidate-review510.json','THEORY_GUIDE-candidate.patch',
'package-historical510.py')
# Fixed finite paths, not a directory walk for archive inclusion.
MEMBERS=list(TOP)
for stage in ('prepared-01','prepared-02'):
    MEMBERS.extend(f'{stage}/{n}' for n in ('weather.json.gz','receipt.json'))
for stage in ('real-runs-01','real-runs-02'):
    MEMBERS.append(f'{stage}/receipt.json')
    for case in CASES:
        MEMBERS.extend(f'{stage}/{case}{suffix}' for suffix in ('.json','-command.json'))
        MEMBERS.extend(f'{stage}/{case}/{name}' for name in PRODUCTS)
MEMBERS.extend(f'example-c10-01/{name}' for name in PRODUCTS)
MEMBERS.extend(f'tests-jra510/{name}' for name in ('before.json','command.json','receipt.json','results.xml','stdout.log','stderr.log'))
MEMBERS.extend(f'tests-jra510-retry/{name}' for name in ('results.xml','output.log'))
# Root may explicitly name a later finite C10 receipt before the final pack.
EXTRA_C10=('example-c10-review510.json','check-example510.py')
MEMBERS.extend(EXTRA_C10)


def sha(data): return hashlib.sha256(data).hexdigest()
def enc(value): return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def rd(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def checked(root,name):
    rel=PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name: raise ValueError('unsafe member path')
    path=root/name
    if not path.is_file() or path.is_symlink() or path.is_junction(): raise ValueError('non-ordinary input: '+name)
    if not path.resolve().is_relative_to(root.resolve()): raise ValueError('escaped input root')
    return path

def inventory(names,root):
    return {n:{'bytes':checked(root,n).stat().st_size,'sha256':sha(checked(root,n).read_bytes())} for n in sorted(names)}

def check_output_manifest(stage):
    manifest=rd(P/stage/'manifest.json')
    for name,row in manifest['files'].items():
        data=checked(P,stage+'/'+name).read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']: raise ValueError('experiment output differs: '+stage+'/'+name)
    if set(manifest['files']) != set(PRODUCTS)-{'manifest.json'}: raise ValueError('unexpected result member set')
    return {'stage':stage,'manifest_sha256':sha((P/stage/'manifest.json').read_bytes()),'all_six_declared_files_equal':True}

def main():
    start=dt.datetime.now(dt.timezone.utc).isoformat()
    if OUTPUT.exists() or RECEIPT.exists(): raise FileExistsError('archive/receipt already exists; no overwrite')
    if len(set(MEMBERS))!=len(MEMBERS): raise ValueError('duplicate whitelist member')
    before=inventory(MEMBERS,P)
    inputs={n:checked(P,n).read_bytes() for n in sorted(MEMBERS)}
    for n,data in inputs.items():
        if {'bytes':len(data),'sha256':sha(data)}!=before[n]: raise ValueError('input changed while reading: '+n)
    basis=json.loads(inputs['basis510.json'])
    if basis['commit']!='2cefd08dfd039645b85d184a7089a7aa002ab775' or basis['file_count']!=281: raise ValueError('wrong fixed basis')
    run1=json.loads(inputs['real-runs-01/receipt.json']);run2=json.loads(inputs['real-runs-02/receipt.json'])
    source_names={n.replace('\\','/') for n in run2['sources']}
    source_names.update(('references/jra3q_model_fixture/source_bundle.json','tools/normalize_jra3q_model_fixture.py','tools/normalize_gfs_fixture.py','tools/prepare_jra3q_flight_fixture.py','tests/test_jra3q_flight_field.py','examples/jra3q-support-flight.json'))
    source_before=inventory(source_names,R)
    source_bundle='references/jra3q_model_fixture/source_bundle.json'
    if source_before[source_bundle]['sha256']!='81bf2a10759d8f92a9576f3285bc810bedbe30a6f3675df78416f3ccf8295811':raise ValueError('fixed original changed')
    run_changes={n:{'before':run1['sources'].get(n),'after':h} for n,h in run2['sources'].items() if run1['sources'].get(n)!=h}
    if set(run_changes)!={'balloon_sim\\results\\report.py'}: raise ValueError('unexpected between-run source changes')
    manifests=[check_output_manifest(f'{stage}/{case}') for stage in ('real-runs-01','real-runs-02') for case in CASES]
    manifests.append(check_output_manifest('example-c10-01'))
    same=[]
    for case in CASES:
        a=inputs[f'real-runs-01/{case}/result.json']; b=inputs[f'real-runs-02/{case}/result.json']
        if a!=b:raise ValueError('physical result changed across caption repair: '+case)
        value=json.loads(b)
        if value['status']!='stopped' or value['complete'] is not False or value['summary'].get('landing') is not None:raise ValueError('unexpected flight completion')
        same.append({'case':case,'result_sha256':sha(b),'byte_identical':True,'status':value['status'],'stop_code':value['stop_reason']['code'],'records':len(value['records'])})
    weather=[]; decoded=[]
    for stage in ('prepared-01','prepared-02'):
        data=inputs[stage+'/weather.json.gz']; rec=json.loads(inputs[stage+'/receipt.json'])
        if sha(data)!=rec['bundle_sha256'] or len(data)!=rec['bundle_bytes']:raise ValueError('prepared bundle mismatch')
        v=json.loads(gzip.decompress(data));decoded.append(v)
        weather.append({'stage':stage,'bytes':len(data),'sha256':sha(data),'source_bundle_sha256':rec['source_bundle_sha256']})
    if any(decoded[0][k]!=decoded[1][k] for k in decoded[0] if k!='metadata'):raise ValueError('weather science changed between preparation runs')
    if sha(inputs['prepare-source-01.py'])!=decoded[0]['metadata']['preparation']['source_files']['tools/prepare_jra3q_flight_fixture.py']:raise ValueError('old converter bytes not preserved')
    regression=ET.fromstring(inputs['regression-01.xml'])
    suites=list(regression.iter('testsuite'))
    if len(suites)!=1 or suites[0].get('tests')!='139' or any(suites[0].get(k)!='0' for k in ('errors','failures','skipped')):raise ValueError('unexpected regression evidence')
    findings=[]
    patterns={
      'google_api_key':rb'AIza[0-9A-Za-z_-]{35}',
      'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
      'github_token':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
      'aws_access_key':rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
      'bearer_value':rb'(?i)Authorization\s*[:=]\s*[\"\x27]?Bearer\s+[A-Za-z0-9._~-]{16,}',
      'credential_value':rb'(?i)[\"\x27](?:api_key|access_token|refresh_token|client_secret|password)[\"\x27]\s*:\s*[\"\x27][A-Za-z0-9_./+=~-]{12,}[\"\x27]'}
    for name,data in inputs.items():
        scan=gzip.decompress(data) if name.endswith('.gz') else data
        for rule,pattern in patterns.items():
            if re.search(pattern,scan):findings.append({'path':name,'rule':rule})
    if findings:raise ValueError('credential-like matches need review; '+json.dumps(findings))
    validation={'schema':'historical-field510-package-validation/1','output_manifest_checks':manifests,'five_physical_results_byte_identical':same,'between_run_source_changes':run_changes,'prepared_bundles':weather,'prepared_nonmetadata_content_equal':True,'old_prepare_source_exact':True,'regression_139':suites[0].attrib,'test_retry_meaning':'13 initial passes plus two unchanged-source normal-permission retries; not a single 15-case all-pass run','secret_scan':{'rules':list(patterns),'files_scanned':len(inputs),'gzip_payload_scanned':2,'matches':[],'limits':'Finite high-confidence byte patterns over whitelisted text/gzip. Not a general absence-of-secrets proof; no image or browser review performed.'},'limits':['The packaging process does not rerun numerical calculations/tests.','HTML reports preserved without claiming browser visual acceptance.','JRA source remains a 2x2/2-time fixed input; all five flights stopped, no terrain landing.']}
    source_ref={'schema':'historical-field510-repository-references/1','basis_commit':basis['commit'],'basis_tree':basis['tree'],'repository':'GENIANY/space-balloon-simulator-jp private repository','raw_source_bundle':{'path':source_bundle,**source_before[source_bundle],'included_in_zip':False},'runtime_as_observed_in_run02':{n.replace('\\','/'):h for n,h in run2['sources'].items()},'repository_source_at_pack':source_before,'matching_run02_at_pack':{n.replace('\\','/'):source_before[n.replace('\\','/')]['sha256']==h for n,h in run2['sources'].items()},'basis_earlier_receipt_references':basis['evidence'],'limits':['Repository files are path/hash references, not a second source/raw archive.','Resolve future source from the private repository version containing these hashes; no not-yet-created Git SHA is invented.','Earlier P500/Git receipt hashes are historical references; packaging does not rerun Git diagnosis or prove current remote state.']}
    readme='''# 0.51 固定JRA原UTC場の接続証拠

この束は、既存の固定JRA原応答から保存bundleを作り、既存飛行核へ接続して支持不足を確認した有限な作業記録です。原本・実出力・失敗・批評を改変せず収録しています。科学精度、地上から着地までの完飛行、任意日時の取得UI、複数年/季節MCの完成を示すものではありません。

## 読む順序

1. `adapter-critique510.md` / 実装批評round1・round2 / `interface-review510.md` で、旧問い合わせと現役保存場の境界、圧力補間、厳密列支持、未決事項を読む。
2. `prepared-01` / `prepared-02` の原gzipとreceipt、`prepare-source-01.py` で変換の前後をたどる。01のconverter原bytesを保存し、02の正本はrepoの `tools/prepare_jra3q_flight_fixture.py` をhashで参照する。2bundleの科学量・軸・surface・係数は同じで、差はmetadataだけ。
3. `real-runs-01` / `real-runs-02` の5条件それぞれについて入力、command、result、provenance、manifest、HTML、CSV、GeoJSONを読む。全5件ともstopped・CLI終了2。着地点を定義していない。地上支持拒否・時刻端・水平端・最大時間・降下の下端停止を区別する。
4. `tests-jra510` の初回失敗を残し、`jra-flight-field-tests510.json` とretryの原log/XMLを読む。最初の13成功と、同一sourceでTemp権限由来2件を通常権限へ切り替えて成功した再試験であり、15件を一括成功したとは記さない。
5. `regression-01.xml` は139件成功の時点証拠。その後HTMLのGFS固定表記を選択気象モデルの表現へ訂正し、5条件を再実行した。`package-validation.json` が01/02の全5 `result.json` のbyte一致と、実行時source差がreportだけであることを照合する。139件をcaption訂正後に全再実行したとは主張しない。
6. `example-c10-01` はC10診断例の保存出力。PowerShell `ConvertFrom-Json` による日時の自動local変換が操作確認時に起きた。その後C10の表示例を `elapsed_s` へ変更し注記を加えた。`example-c10-review510.json` と `check-example510.py` は物理result全要素が02のphysical例と同じこと、configのlabel/purposeだけが異なること、manifest6個の一致を確認した。完全JSONの同一とは区別し、result原JSONのUTC文字列を正本として読む。

## 計測と表示の限界

最終 `real-runs-02/receipt.json` は小窓を約0.014993秒で読込み、等温上昇→破裂→降下停止の積分を約0.097618秒で観測した。同じ条件のCLIプロセス全体は約0.977618秒であり、積分時間と混ぜない。一台・固定2時刻/2×2格子/100層での単発値で、実運用規模・MC・再取得・地上完飛行の性能保証には外挿しない。

HTMLは原byteを保全したが、検証時はfile URLをブラウザが拒否したため画面目視は未了だった。保存のhash検算、HTML生成成功と、実ブラウザ上の見やすさの受入を区別する。3Dや外部背景地図の再接続は行っていない。

## 原本の所在と再実行

原 `references/jra3q_model_fixture/source_bundle.json` はprivate repoの既存実体をpath/sha256で参照し、このZIPへ二重収録しない。`source-references.json` のsource指紋と実行時provenanceを照合する。runtime sourceの本体もrepo側にあり、このZIP単独で環境・コード一式を提供するものではない。

通常の再実行はrepoのCOMMANDS C10に従い、新しい `$taskOutputRoot` を作り、固定原本→新bundle→inspect→`examples/jra3q-support-flight.json` のsimulate→原resultの停止理由を読む。既存出力を上書きしない。結果閲覧のために原JSONをPowerShellで再書出ししない。

5条件を再現する場合は、ここにある `run-real510-final.py`、`jra-short-config510.json`、`prepared-02` だけを別の新規作業ディレクトリへコピーし、repoを作業ディレクトリ/PYTHONPATHにして同じPython依存で実行する。scriptは自身と同じ場所に新規 `real-runs-02` を作るので、保存された実績ディレクトリ内では再実行しない。機械の絶対パスは元の命令/来歴として保存したもので、新環境の指定先ではない。raw再取得や外部通信は必要ない。

## 収録と未収録

`package-whitelist.json` の明示実体だけを収録する。`package-manifest.json` は自身を除く全memberのsize/SHAを列挙し、ZIP外のreceiptはmanifest自身も含む全memberを検算する。入力は原byte一致で、gzipも再圧縮しない。CRC、全member、入力と関係runtime sourceの前後一致を別々に確認する。有限patternによる秘密検査は万能な不存在証明ではない。

未完のguide build/publication、metadata、将来C1/C2/PR保存票は収録しない。後続はS36と別票へ記録する。旧原Git1305＋今回診断13の区別をbasis/Git診断票に残すが、生成主体や現在remote同期を断定しない。確認印・科学採否・人間の採用・main統合は別である。
'''
    generated={'README.md':readme.encode('utf-8'),'source-references.json':enc(source_ref),'package-validation.json':enc(validation),'package-whitelist.json':enc({'schema':'explicit-evidence-whitelist510/1','paths':sorted(MEMBERS),'excluded':'No directory wildcard; no raw original source bundle, earlier ZIPs, guide build/publication, metadata or future Git receipts.'})}
    all_data=inputs|generated
    manifest={'schema':'byte-preserved-evidence510/1','started_at_utc':start,'basis_commit':basis['commit'],'input_count':len(inputs),'generated_before_manifest':len(generated),'members':{n:{'bytes':len(d),'sha256':sha(d),'kind':'preserved_original' if n in inputs else 'generated_packaging_description'} for n,d in sorted(all_data.items())},'self_excluded':'package-manifest.json is not self-hashed; external archive receipt lists every ZIP member including this manifest.'}
    all_data['package-manifest.json']=enc(manifest)
    partial=OUTPUT.with_suffix('.zip.partial')
    if partial.exists():raise FileExistsError('preserved partial exists')
    with zipfile.ZipFile(partial,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in sorted(all_data.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,9,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,data)
    members={}
    with zipfile.ZipFile(partial) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or set(names)!=set(all_data):raise ValueError('archive member set changed')
        if z.testzip() is not None:raise ValueError('archive CRC failure')
        for name in names:
            data=z.read(name)
            if data!=all_data[name]:raise ValueError('archive byte mismatch: '+name)
            members[name]={'bytes':len(data),'sha256':sha(data)}
    after=inventory(MEMBERS,P);source_after=inventory(source_names,R)
    if before!=after or source_before!=source_after:raise ValueError('source/input changed during packaging; partial preserved')
    if OUTPUT.exists():raise FileExistsError('final archive concurrently created')
    os.rename(partial,OUTPUT)
    receipt={'schema':'historical-field510-archive-receipt/1','status':'verified_external_candidate_not_git_saved','started_at_utc':start,'finished_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'path':str(OUTPUT),'bytes':OUTPUT.stat().st_size,'sha256':sha(OUTPUT.read_bytes()),'preserved_input_count':len(inputs),'generated_count':len(generated)+1,'member_count':len(members),'all_members':members,'crc':'all_pass','input_before':before,'input_after':after,'repository_source_before':source_before,'repository_source_after':source_after,'all_before_after_equal':True,'packaging_script_sha256':before['package-historical510.py']['sha256'],'secret_scan':validation['secret_scan'],'limits':validation['limits']+['No R file was written; no scientific tests, API, browser, HTTP or Git command was run by packaging.','The checksum inventory and observations do not establish scientific accuracy or whole-application acceptance.']}
    with RECEIPT.open('xb') as f:f.write(enc(receipt))
    print(json.dumps({k:receipt[k] for k in ('status','path','bytes','sha256','preserved_input_count','generated_count','member_count','all_before_after_equal')},ensure_ascii=False))

if __name__=='__main__': main()
