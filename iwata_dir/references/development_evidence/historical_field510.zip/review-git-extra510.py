from pathlib import Path
import json,hashlib,zlib,datetime
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
Q=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-operational-500')
R=Path.cwd(); G=R/'.git'; B=P/'basis-repo'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def digest_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def inventory():return [{'path':p.relative_to(G).as_posix(),'sha256':digest_file(p)} for p in sorted(G.rglob('*'),key=lambda p:p.relative_to(G).as_posix()) if p.is_file()]
def resolve_head():
 text=(G/'HEAD').read_text(encoding='ascii').strip()
 if text.startswith('ref: '):
  ref=text[5:]; direct=G/ref
  if direct.is_file():return {'symbolic_ref':ref,'commit':direct.read_text(encoding='ascii').strip()}
  for line in (G/'packed-refs').read_text(encoding='ascii').splitlines():
   if line and not line.startswith(('#','^')) and line.split()[1]==ref:return {'symbolic_ref':ref,'commit':line.split()[0]}
  raise ValueError('unresolved ref')
 return {'symbolic_ref':None,'commit':text}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
prior=load(Q/'original-git500-diagnosis.json');observed=load(P/'git-diagnosis510-before.json');freeze=load(Q/'record-freeze500.json');receipt=load(Q/'record-git-receipt500.json')
assert receipt['commit']=='2cefd08dfd039645b85d184a7089a7aa002ab775' and receipt['status']=='readback_verified'
assert receipt['freeze_sha256']==digest_file(Q/'record-freeze500.json')
old={x['path']:x['sha256'] for x in prior['current']['files']}; head_before=resolve_head(); before=inventory(); now={x['path']:x['sha256'] for x in before}
assert len(old)==1305 and len(now)==1318
assert not(set(old)-set(now));assert all(now[k]==v for k,v in old.items())
assert now=={x['path']:x['sha256'] for x in observed['files']}
added=sorted(set(now)-set(old));assert added==sorted(observed['added']) and len(added)==13
rows=freeze['files']; assert len(rows)==281
source_before=[]
for x in rows:
 p=R/x['path']; bp=B/x['path']
 src={'path':x['path'],'size':p.stat().st_size,'sha256':digest_file(p),'basis_size':bp.stat().st_size,'basis_sha256':digest_file(bp)}
 assert src['basis_size']==x['size'] and src['basis_sha256']==x['sha256']
 source_before.append(src)
byblob={x['blob']:x for x in rows}; c1={x['blob']:x['path'] for x in load(Q/'freeze500.json')['files']}
classifications=[]
for path in added:
 p=G/path; compressed=p.read_bytes();d=zlib.decompressobj();raw=d.decompress(compressed)+d.flush();header,body=raw.split(b'\0',1);typ,declared=header.decode('ascii').split();oid=hashlib.sha1(raw).hexdigest();oid_path=path[8:].replace('/','')
 assert d.eof and not d.unused_data and len(body)==int(declared) and oid==oid_path
 assert typ=='blob' and oid in byblob
 match=byblob[oid];assert sha(body)==match['sha256'] and len(body)==match['size'] and body==(B/match['path']).read_bytes()
 classifications.append({'path':path,'compressed_bytes':len(compressed),'compressed_sha256':sha(compressed),'mtime_utc':datetime.datetime.fromtimestamp(p.stat().st_mtime,datetime.timezone.utc).isoformat(),'type':typ,'declared_bytes':int(declared),'actual_bytes':len(body),'object_sha1':oid,'payload_sha256':sha(body),'zlib_eof':d.eof,'trailing_bytes':len(d.unused_data),'git_header_length_and_path_hash_valid':True,'matches_fixed_050_C2_path':match['path'],'fixed_basis_payload_exact':True,'current_R_payload_exact':body==(R/match['path']).read_bytes(),'also_matches_050_C1_path':c1.get(oid)})
source_after=[{'path':x['path'],'size':(R/x['path']).stat().st_size,'sha256':digest_file(R/x['path']),'basis_size':(B/x['path']).stat().st_size,'basis_sha256':digest_file(B/x['path'])} for x in rows]
after=inventory();head_after=resolve_head();assert before==after and source_before==source_after and head_before==head_after
assert head_before['commit']=='ad3494d700068d873a22ed2fbbf6f0a760a41735'
out={'schema':'git-extra-review510/1','reviewer':'ui_continuity_review','at_utc':start,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Read-only Python pathlib/hashlib/zlib inspection; no Git executable, mutation, import of save helpers, external request or object payload output. Complete file-set/hash inventory before and after object inspection and fixed source checks.','fixed_basis':{'version':'0.50.0','commit':receipt['commit'],'tree':receipt['tree'],'files':len(rows),'freeze_sha256':digest_file(Q/'record-freeze500.json'),'receipt_sha256':digest_file(Q/'record-git-receipt500.json')},'input_evidence':{'git-diagnosis510-before.json':digest_file(P/'git-diagnosis510-before.json'),'original-git500-diagnosis.json':digest_file(Q/'original-git500-diagnosis.json')},'prior_count':len(old),'current_count':len(now),'prior_fingerprint':prior['current_fingerprint'],'observed_fingerprint':observed['fingerprint'],'prior_changed':[],'prior_removed':[],'added_count':len(added),'added':classifications,'type_counts':{'blob':13,'tree':0,'commit':0,'incomplete':0},'head_before':head_before,'head_after':head_after,'all_1305_preserved':True,'matches_parent_before_inventory':True,'inspection_before_after_equal':True,'current_files':before,'fixed_source_281':{'basis_matches_all_281_size_sha256':True,'current_R_matching_count':sum(x['size']==x['basis_size'] and x['sha256']==x['basis_sha256'] for x in source_before),'inspection_before_after_equal':True,'R_differences_from_C2':[x for x in source_before if x['size']!=x['basis_size'] or x['sha256']!=x['basis_sha256']],'difference_scope':'BOOTSTRAP_RUNBOOK contains only one insertion: s36-plan510 prior operation instruction. Independently read unified diff; this was a root authored working change after the parent start check, not original Git mutation.','parent_reported_pre_edit_all_281_match':True,'parent_report_distinct_from_current_independent_check':True,'files':source_before},'conclusion':'13 additions are complete loose blobs, all byte-identical to registered fixed 0.50 C2 paths; 8 are the C2 record diff and 5 already match content C1. P510/basis-repo matches all 281 frozen C2 files. Current R matches 280; the only difference is the separately read s36-plan510 instruction insertion in RUNBOOK. Parent reported an all-281 match before that instruction was appended; that timing is not conflated with this independent current check. The prior 1305 files, HEAD/ref/index/config remain byte-identical and the entire 1318-file inventory is stable across this read-only inspection. No object was deleted or incorporated into a Git commit by this inspection.','limits':'The producer/process and reason for these additions are unknown. Content identity is not evidence that the original local repository was synchronized or that additions are reachable from HEAD. This finite interval does not guarantee later immutability. This receipt is a diagnosis, not authorization to silently rebaseline, reset, delete or synchronize the original .git; parent must explicitly preserve the original 1305 plus these exact 13 for any subsequent guard. Source equality is limited to registered 281, not arbitrary unregistered files or scientific correctness.'}
path=P/'git-extra-review510.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'path':str(path),'sha256':digest_file(path),'count':len(now),'added':len(added),'types':out['type_counts'],'head':head_before['commit'],'sources':len(rows),'stable':True},ensure_ascii=False))
