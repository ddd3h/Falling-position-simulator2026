from pathlib import Path
import hashlib,json,re
from decimal import Decimal,localcontext
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
b=json.loads((R/'references/jra3q_model_fixture/source_bundle.json').read_bytes())
# Direct original ASCII rows only; no repository module imported or query called.
def row(name,index):
    s=b['sources']['jra-'+name+'-cell']['body_utf8']; prefix=''.join('['+str(i)+']' for i in index)
    return [Decimal(x.strip()) for x in re.search('^'+re.escape(prefix)+r', ([^\n]+)',s,re.M)[1].split(',')]
node={name:str(row(short,(0,50,1))[0]) for name,short in [('H_gpm','h'),('temperature_k','t'),('eastward_wind_m_s','u'),('northward_wind_m_s','v'),('specific_humidity_kg_kg','q')]}
gaps=[];ground=[];bottom=[];top=[]
with localcontext() as c:
    c.prec=60
    radius=Decimal(6371000);g=Decimal('9.80665')
    for t in range(2):
      for j in range(2):
        for i in range(2):
          h0=row('h',(t,0,j))[i]; ht=row('h',(t,99,j))[i]; hg=row('gp',(0,j))[i]/g
          gaps.append(h0-hg);ground.append(hg);bottom.append(h0);top.append(ht)
    node['geometric_altitude_m']=str(radius*Decimal(node['H_gpm'])/(radius-Decimal(node['H_gpm'])))
    startH=max(bottom)+100
    scalar={'ground_gpm_min':str(min(ground)),'ground_gpm_max':str(max(ground)),'lowest_model_H_gpm_min':str(min(bottom)),'lowest_model_H_gpm_max':str(max(bottom)),'top_H_gpm_min':str(min(top)),'top_H_gpm_max':str(max(top)),'gap_gpm_min':str(min(gaps)),'gap_gpm_max':str(max(gaps)),'proposed_start_H_gpm':str(startH),'proposed_start_geometric_m':str(radius*startH/(radius-startH)),'H_at_geometric_30000m':str(radius*30000/(radius+30000)),'geometric_at_H30000gpm':str(radius*30000/(radius-30000))}
raw=[{'id':k,'bytes':len(v['body_utf8'].encode()),'sha256':hashlib.sha256(v['body_utf8'].encode()).hexdigest(),'matches_receipt':hashlib.sha256(v['body_utf8'].encode()).hexdigest()==v['response']['body_sha256'] and len(v['body_utf8'].encode())==v['response']['body_bytes']} for k,v in b['sources'].items()]
files=['tools/normalize_jra3q_model_fixture.py','tools/normalize_gfs_fixture.py','tests/test_jra3q_model_environment.py','balloon_sim/environment/storage.py','balloon_sim/environment/fields.py','balloon_sim/environment/bundle.py','balloon_sim/environment/gfs_contract.py','balloon_sim/flight/trajectory.py','balloon_sim/flight/config.py','balloon_sim/flight/models.py','balloon_sim/cli.py','balloon_sim/results/export.py','backend/application.py','backend/contracts.py','backend/worker.py','backend/weather/service.py','backend/ensemble/planning.py','backend/ensemble/service.py','frontend/src/domain.ts','frontend/src/weatherAcquisition.ts','references/jra3q_model_fixture/source_bundle.json','docs/IMPLEMENTATION_NOTES.md','docs/WEATHER_DATA_GUIDE.md','docs/ENVIRONMENT_CONTRACT.md']
manifest=[]
for rel in files:
 p=R/rel;data=p.read_bytes();base=P/'basis-repo'/rel
 manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_basis_copy':base.exists() and base.read_bytes()==data})
out={'schema':'jra-interface-review-material/1','basis_commit':'2cefd08dfd039645b85d184a7089a7aa002ab775','scope':'direct source reading / direct raw ASCII arithmetic; no source import, query, test, flight or network','raw_response_bytes':sum(x['bytes'] for x in raw),'raw_responses':raw,'native_node_00utc_level51_southwest':node,'independent_decimal_scalar_values':scalar,'source_manifest':manifest}
(P/'interface-material510.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_raw_receipts_match':all(x['matches_receipt'] for x in raw),'raw_bytes':out['raw_response_bytes'],'node':node,'scalar':scalar,'source_basis_mismatches':[x['path'] for x in manifest if not x['matches_basis_copy']]},ensure_ascii=False,indent=2))
