from pathlib import Path
import json,hashlib
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
c={'schema':'balloon.flight.config/1','label':'JRA保存解析場・支持内上空60秒の接続検査案','purpose':'Proposal only; starts above every contributing lowest model level, not an actual ground launch or complete historical flight.', 'launch':{'time_utc':'2024-01-01T02:17:13+00:00','latitude_deg':34.838688086410954,'longitude_deg':137.0625,'altitude_m':311.6637155690019768},'ascent':{'mode':'constant_speed','speed_m_s':5},'burst':{'mode':'altitude','altitude_m':30000},'descent':{'mode':'rated_speed','reference_speed_m_s':5,'density_model':'exponential','scale_height_m':8400},'integration':{'max_step_s':10,'max_duration_s':60,'event_tolerance_s':.001}}
(P/'jra-short-config510.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
m=json.loads((P/'interface-material510.json').read_bytes())
for rel in ['balloon_sim/weather.py','backend/app.py','tests/test_trajectory.py','tests/test_flight_cli.py']:
 b=(R/rel).read_bytes();base=P/'basis-repo'/rel
 m['source_manifest'].append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches_basis_copy':base.exists() and base.read_bytes()==b})
m['unchanged_after_read']={x['path']:hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in m['source_manifest']}
(P/'interface-material510.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result={'scope':'read-only interface review, not implementation or test execution','source_count':len(m['source_manifest']),'all_match_fixed_basis_copy':all(x['matches_basis_copy'] for x in m['source_manifest']),'all_read_sources_unchanged':all(m['unchanged_after_read'].values()),'outputs':[]}
for name in ['interface-review510.md','interface-material510.json','jra-short-config510.json','inspect-interface510.py','inspect-bounds510.py']:
 b=(P/name).read_bytes();result['outputs'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(P/'interface-review510-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
