"""Finite real-source trials; never modify inputs, network or existing outputs."""
from pathlib import Path
import copy, hashlib, json, subprocess, sys, time
from balloon_sim.environment.storage import load_weather
from balloon_sim.environment.fields import geometric_to_geopotential
from balloon_sim.flight.trajectory import simulate

P=Path(__file__).resolve().parent
W=P/'prepared-01/weather.json.gz'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)

out=P/'real-runs-01';out.mkdir(exist_ok=False)
before={str(p):sha(p) for p in Path('balloon_sim').rglob('*.py')}
weather_hash=sha(W)
start=time.perf_counter();field=load_weather(W);load_seconds=time.perf_counter()-start
base=json.loads((P/'jra-short-config510.json').read_text(encoding='utf-8'))
base['purpose']='Finite connection trial on saved real JRA; above-ground diagnostic, not a launch plan.'
cases={'short_constant':copy.deepcopy(base)}
physical=copy.deepcopy(base)
physical['ascent']={'mode':'isothermal_buoyancy','gas_mass_kg':0.5,'envelope_mass_kg':1.,'payload_mass_kg':1.,'drag_coefficient':.47}
physical['burst']={'mode':'altitude','altitude_m':1500.}
physical['descent']={'mode':'rated_speed','reference_speed_m_s':5.,'density_model':'weather','reference_density_kg_m3':1.225}
physical['integration']['max_duration_s']=3600
cases['physical_descent_gap']=physical
cases['ground_rejected']=copy.deepcopy(physical)
l=base['launch']
cases['ground_rejected']['launch']['altitude_m']=field.ground_altitude(l['time_utc'],l['latitude_deg'],l['longitude_deg'])
cases['time_boundary']=copy.deepcopy(base)
cases['time_boundary']['launch']['time_utc']='2024-01-01T05:59:30+00:00'
cases['horizontal_boundary']=copy.deepcopy(base)
cases['horizontal_boundary']['integration']['max_duration_s']=3600
rows=[]
for name,config in cases.items():
    config['label']=name
    config_path=out/(name+'.json');write(config_path,config)
    start=time.perf_counter();result=simulate(config,field);integration_seconds=time.perf_counter()-start
    start=time.perf_counter()
    proc=subprocess.run([sys.executable,'-X','utf8','-B','-m','balloon_sim.cli','simulate',str(config_path),'--weather',str(W),'--output',str(out/name)],capture_output=True,text=True,encoding='utf-8')
    cli_seconds=time.perf_counter()-start
    write(out/(name+'-command.json'),{'args':proc.args,'exit':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr,'wall_seconds':cli_seconds})
    if proc.returncode not in (0,2):raise RuntimeError(proc.stderr)
    stored=json.loads((out/name/'result.json').read_text(encoding='utf-8'))
    assert result==stored,name
    manifest=json.loads((out/name/'manifest.json').read_text())
    for filename,receipt in manifest['files'].items():
        p=out/name/filename
        assert p.stat().st_size==receipt['bytes'] and sha(p)==receipt['sha256']
    records=result['records']
    rows.append({'case':name,'status':result['status'],'stop_reason':result['stop_reason'],'complete':result['complete'],
                 'records':len(records),'events':result['events'],'last_record':records[-1] if records else None,
                 'integration_seconds':integration_seconds,'cli_process_seconds':cli_seconds,
                 'output_bytes':sum(p.stat().st_size for p in (out/name).iterdir()),'result_sha256':sha(out/name/'result.json'),
                 'cli_exit':proc.returncode,'direct_and_cli_results_equal':True,'all_manifest_files_verified':True})
queries=[]
for stamp in ('2024-01-01T00:00:00Z','2024-01-01T02:17:13Z','2024-01-01T06:00:00Z'):
    queries.append({'time_utc':stamp,'geometric_altitude_m':30000,'geopotential_height_gpm':geometric_to_geopotential(30000),
                    'sample':field.sample(stamp,l['latitude_deg'],l['longitude_deg'],30000)})
assert before=={str(p):sha(p) for p in Path('balloon_sim').rglob('*.py')}
assert weather_hash==sha(W)
receipt={'schema':'real-jra-flight510/1','load_seconds':load_seconds,'weather_sha256':weather_hash,'sources':before,
         'runs':rows,'queries_at_geometric_30km':queries,'network_requests':0,
         'limits':['2x2 January real field; not the Hokkaido half-month population','No ground layer added; stopped does not define a landing point',
                   'One-machine observations; integration and full CLI process are separate; no accuracy or Monte Carlo probability acceptance']}
write(out/'receipt.json',receipt)
print(json.dumps({'load_seconds':load_seconds,'runs':[{k:v for k,v in row.items() if k not in ('last_record','events')} for row in rows]},ensure_ascii=False,indent=2))
