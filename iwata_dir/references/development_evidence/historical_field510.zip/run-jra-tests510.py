from pathlib import Path
import subprocess,json,hashlib,time
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
O=P/'tests-jra510';O.mkdir(exist_ok=False)
paths=['tests/test_jra3q_flight_field.py','balloon_sim/environment/model_levels.py','balloon_sim/environment/jra3q.py','balloon_sim/environment/storage.py','tools/normalize_jra3q_model_fixture.py','tools/normalize_gfs_fixture.py','tests/test_jra3q_model_environment.py','references/jra3q_model_fixture/source_bundle.json','balloon_sim/flight/trajectory.py','balloon_sim/flight/models.py']
def hashes():return {x:hashlib.sha256((R/x).read_bytes()).hexdigest() for x in paths}
before=hashes();(O/'before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=[r'C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe','-B','-m','pytest','tests/test_jra3q_flight_field.py','-v','-p','no:cacheprovider','--junitxml='+str(O/'results.xml')]
(O/'command.json').write_text(json.dumps({'argv':cmd,'cwd':str(R)},indent=2)+'\n')
start=time.perf_counter()
with (O/'stdout.log').open('w',encoding='utf-8') as out,(O/'stderr.log').open('w',encoding='utf-8') as err:
 run=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
receipt={'returncode':run.returncode,'elapsed_s':time.perf_counter()-start,'before':before,'after':hashes(),'all_read_sources_unchanged':before==hashes()}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'returncode':run.returncode,'elapsed_s':receipt['elapsed_s'],'all_read_sources_unchanged':receipt['all_read_sources_unchanged']}))
print((O/'stdout.log').read_text(encoding='utf-8'))
print((O/'stderr.log').read_text(encoding='utf-8'))
