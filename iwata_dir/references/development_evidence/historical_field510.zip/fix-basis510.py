from pathlib import Path
import hashlib, json, shutil, subprocess, datetime, os

P=Path(__file__).resolve().parent
R=Path.cwd()
old=P.parent/'balloon-operational-500'
raw=(old/'record-freeze500.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='20b9afb5eb5880fd9781aa3d63f644f20d5c0da927a05e1e3845272ede700c12'
freeze=json.loads(raw)
rows=freeze['files']
assert len(rows)==281
for row in rows:
    data=(R/row['path']).read_bytes()
    assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
dest=P/'basis-repo'
dest.mkdir(exist_ok=False)
for row in rows:
    out=dest/row['path'];out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(R/row['path'],out)
    assert hashlib.sha256(out.read_bytes()).hexdigest()==row['sha256']
gd=R/'.git'
gitrows=[{'path':x.relative_to(gd).as_posix(),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(gd.rglob('*')) if x.is_file()]
fp=hashlib.sha256(json.dumps(gitrows,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(gitrows)==1305 and fp=='f01f6787954e458fee19d606fc73436e44b2041593e17541e522bd55104b65fb'
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
head=subprocess.check_output(['git','rev-parse','HEAD'],env=env,text=True).strip()
assert head=='ad3494d700068d873a22ed2fbbf6f0a760a41735'
result={'schema':'basis510/1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':'2cefd08dfd039645b85d184a7089a7aa002ab775','tree':'e06a65986898e0cf6c5e1000ffa396012a6417a2','main':'4e3e4db0d047af9479bcd68bfc2553eeb71efcc9','files':rows,'original_git':{'head':head,'fingerprint':fp,'files':gitrows}}
with (P/'basis510.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps({'checked_files':len(rows),'basis_commit':result['commit'],'original_git_files':len(gitrows),'sha256':hashlib.sha256((P/'basis510.json').read_bytes()).hexdigest()}))
