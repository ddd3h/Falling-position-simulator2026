import json,re,math
from pathlib import Path
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
b=json.loads((R/'references/jra3q_model_fixture/source_bundle.json').read_bytes())
w={}
for key in ['u','v']:
 rows=re.findall(r'^\[\d+\]\[\d+\]\[\d+\], ([^\n]+)',b['sources']['jra-'+key+'-cell']['body_utf8'],re.M)
 vals=[float(x) for row in rows for x in row.split(',')]
 w[key]={'count':len(vals),'min':min(vals),'max':max(vals),'maxabs':max(map(abs,vals))}
lat=(34.651383346207+35.0259928266149)/2;lon=(136.875+137.25)/2;rad=6371000;z=311.6637155690019768
lat_delta=math.degrees(w['v']['maxabs']*60/(rad+z))
lon_delta=math.degrees(w['u']['maxabs']*60/((rad+z)*math.cos(math.radians(35.0259928266149))))
m=json.loads((P/'interface-material510.json').read_bytes());m['convex_wind_bounds']={'source_global_extrema':w,'launch_latitude_deg':lat,'launch_longitude_deg':lon,'max60s_latitude_change_deg':lat_delta,'max60s_longitude_change_deg':lon_delta,'latitude_margin_deg':(35.0259928266149-34.651383346207)/2,'longitude_margin_deg':.1875,'expected60s_geometric_altitude_m':z+300,'argument':'conditional bound for existing spherical wind-following ODE and convex positive interpolation: finite 60s path cannot leave the fixture rectangle; not a physical accuracy test'}
(P/'interface-material510.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(m['convex_wind_bounds'],indent=2))
