# 0.58 年間48区分・気圧面探索：証拠束の外側staging

このフォルダーは主担当が最終ZIPを作るための選別案であり、repoのZIP・管理閉鎖・Git保存はまだ行っていない。基準は0.57 C2 b1b66dbff8b84bb6bb0332ec98043cc8990071b3（全363）。対象ZIPは references/development_evidence/climate_interaction_0580_evidence.zip。元票のbyteをそのまま records/ 以下へ複写した。MANIFEST.jsonは自分自身を除く全memberのSHA/bytesを持つ。

## 選別と主張の範囲

- backendのレビュー、既存数値/母集団の比較、年間48の独立原値比較、旧artifact互換、初回環境失敗と24件成功の担当実行票を保持する。24件はbackend-reviewのコマンド・runtime・exec session 66664を伴う記録で、この束に独立したpytest stdout/JUnitはない。成功を再実行した票として扱わない。
- FEはfull01の元JSON（381成功・2省略・失敗0）と先行有限試験、build01–04、独立source批評を保つ。後続ラベル/CSS変更の全回帰や実画面をfull01から推定しない。後段のtargeted04（24成功・2省略）とroot実UI票へ戻る。381と24は重複を含むため加算せず、backend24とも区別する。
- ERA2024全1188格子・37面・UTC00の比較は、旧数値/母集団fieldのfloat bit一致と48×37行の独立数値比較を区別する。source/provenance/query.source_id/new annual_quartersは旧量比較の除外項目。fixtureの暦/時刻/cache反例をこの実データ範囲へ混ぜない。
- 反復8回の面変更中央値は5.244→0.806秒、母集団cacheの初回は7.048→13.240秒。このPCのoffline adapter逐次観測であり、HTTP/図描画、厳密なOS disk-cold制御、全端末の速度保証ではない。初回費用増を隠さない。cProfile票は計測器の負荷も含む。
- 再提供tarのDB memberと現runtime DBが同じSHAであること、原有効日時のu/v表がないことを独立readonly票に残す。以前のtar自体とのbyte一致や新しい取得を主張しない。2024年rawの48と旧10年DBの24を混同しない。
- index01/02は入力hash・署名差分・有限構造照合とpublicationの時点を保持する。全sourceの意味/科学の再審査ではない。4資料の編集票もその手渡し時点であり、後段のpdf-doc-review580.jsonが最終TeX/PDF/操作資料のhashと変更頁の有限視認を記す。

## 大きな派生物と機密/状態の扱い

6個のbefore/after summary、full index JSON/AST、途中PDF画像はHASH_ONLY.jsonへbytes/SHAだけを残した。hashは同一性の照合であり、省略した値の復元や全数値の証明ではない。元P580には保持する。raw気象配列、元tar/DB、ユーザーstate、project/runs、runtime/environment、key、Git、dist全UIassetは含めない。compatibilityのsynthetic保存DB自体も含めず、作成helperと結果票を保つ。

## 再現helperと注意

records/compare-backend.py と check-compatibility.py は実行時に使用した原helperである。matching repository/dependenciesとrepo外のERA原標本が必要で、manifestには記録時のローカル絶対pathがある。自動実行する入口ではない。元票を上書きしない新しいscratchへhelperとbackend-before/を複写し、repo rootをcwdにする。原archive/manifestのhashと対応sourceを先に照合する。

before/afterの大きなsummaryを省略したため、再実行にはbefore入力の作成が必要となる。records/reproduce-baseline580.pyはこの作成だけを抜き出した新しい案で、--manifestと--outputを明示する。HTMLを編集する元plan-and-profile.pyを再現用に流用しない。この新helperはAST確認だけで未実行であり、実行成功や旧値一致を追加証明していない。元のcompare/check-compatibilityは同じscratch内のbefore summaryを参照する。新実行の時間・JSONは過去の票と区別して記録する。

indexの3helperは記録されたsyntax/hash更新を理解・再現するために含めた。実行先のsource-copy/入出力を読んで新しい隔離先へ向ける必要があり、repo indexを直接変更する推奨コマンドではない。文書・入口・restart・metadataのmutation helperは本束へ含めない。

## 主担当が最後に閉じる項目

UI/PDF/最終source対応の票を追加した。ui-review580.jsonは隔離8580でのCUAとDOM幾何、raw48/旧DB24、保存再訪を有限確認し、マウスdrag/FPS・Google再審査を主張しない。pdf-doc-review580.jsonはPROGRAM1/7/17頁とTHEORY1/21/22/25頁（最終再描画1/22）の有限視認で、全頁科学再審査ではない。dist04はDIST04_HASHES.jsonで固定し、compiled asset全体を重複収録しない。INDEX02の245sourceに対する主担当確認と、staging追加時のUI3source/ガイド6fileの現R hash一致を分ける。常設反映/保存保全はこれからなのでPENDINGに残し、ZIP確定後の結果はS36/C2の外側票へ置ける。旧失敗や中間buildを消さず、最終票との差を明記する。現stagingのmanifestへmemberを黙って追加せず、全memberのbytes/SHAを再生成してからZIP化し、全memberを読戻す。最終化時はpendingを実績で更新し、未確認を成功へ変更しない。管理検査とGit保存票はZIP確定後に外側で生成するので、この固定束へ未来のSHAを埋めない。

最終追補ではroot-entry580-publication.jsonも含め、入口7pathの採用/readbackと管理検査/Git保存を区別した。前段stagingのmanifest/pending/readme/selection/receiptは外側 evidence580-staging-revisions/01 に保持した。
