"""Display periods made from disjoint UTC half-month supports.

These IDs describe grouping, never synthetic timestamps or connected winters.
"""
from .statistics import utc_half_months


def periods(grain, hour_count=4, years=(2016, 2025)):
    halves = utc_half_months(*years)
    if grain == "half":
        return [{**r, "n_analyses_expected": r["n_days_total"] * hour_count,
                 "member_timebin_ids": [r["timebin_id"]],
                 "label": f'{r["month"]}月{"前半" if r["bin"] == 1 else "後半"}'} for r in halves]
    if grain == "month":
        groups = [(m - 1, f"{m}月", [m]) for m in range(1, 13)]
    elif grain == "season":
        groups = [(0, "冬（12–2月）", [12, 1, 2]), (1, "春（3–5月）", [3, 4, 5]),
                  (2, "夏（6–8月）", [6, 7, 8]), (3, "秋（9–11月）", [9, 10, 11])]
    else:
        raise ValueError("Unknown period grain")
    return [{"timebin_id": i, "label": label, "months": months,
             "member_timebin_ids": [r["timebin_id"] for r in halves if r["month"] in months],
             "n_days_total": sum(r["n_days_total"] for r in halves if r["month"] in months),
             "n_analyses_expected": sum(r["n_days_total"] for r in halves if r["month"] in months) * hour_count}
            for i, label, months in groups]
