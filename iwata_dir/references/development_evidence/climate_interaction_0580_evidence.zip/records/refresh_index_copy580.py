"""Refresh one string-only source in a fixed, already-reviewed index snapshot."""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess
P=Path(__file__).parent;R=Path.cwd();old=P/'index01';out=P/'index02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def put(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf8')
current=R/'docs/IMPLEMENTATION_INDEX.json'
assert sha(current)==sha(old/'candidate.json')=='250a2d156c90b4e012420e0f570e46b6bc7dbcc4cb9c191fbcbfb1e1d0451af1'
name='frontend/src/screens/WeatherScreen.tsx'
inputs=read(old/'inputs.json');before=copy.deepcopy(inputs)
changed=[n for n,h in inputs['files'].items() if sha(R/n)!=h];assert changed==[name],changed
out.mkdir(exist_ok=False);shutil.copytree(old/'source',out/'source')
(out/'before-index.json').write_bytes(current.read_bytes())
(out/'source-inventory.json').write_bytes((old/'source-inventory.json').read_bytes())
(out/'source'/name).write_bytes((R/name).read_bytes())
inputs['files'][name]=sha(R/name);put(out/'inputs.json',inputs)
front=read(old/'front-input.json')
for row in front['rows']:row['source_sha256']=inputs['files'][row['path']]
put(out/'front-input.json',front)
extractor=P.parent/'balloon-seasonal-550/detail-lease-repair550/index/pass02/extract_frontend550.cjs'
subprocess.run(['C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe',str(extractor),str(out/'source'),str(out/'front-input.json'),str(out/'front-syntax.json'),str(R/'frontend/node_modules/typescript')],check=True,capture_output=True)
syntax=read(out/'front-syntax.json');prior=read(old/'front-syntax.json')
assert len(syntax['files'])==len(prior['files'])
for a,b in zip(syntax['files'],prior['files']):
 assert a['path']==b['path']
 if a['path']==name:
  assert {k:v for k,v in a.items() if k not in ('source_sha256','bytes')}=={k:v for k,v in b.items() if k not in ('source_sha256','bytes')}
 else:assert a==b
j=read(current);m=j['structure']['manual_interpretation'];new=next(r for r in syntax['files'] if r['path']==name)
row=next(r for r in m['typescript_modules'] if r['path']==name);row.update(new)
def refresh_tree(node):
 if node.get('path')==name:node['source_sha256']=inputs['files'][name]
 for child in node.get('children',[]):refresh_tree(child)
refresh_tree(m['frontend_physical_tree'])
for row in m['screen_bindings']:
 if row.get('path')==name:row['source_sha256']=inputs['files'][name]
record=j['extraction']['climate_interaction']
record['input_manifest_sha256']=sha(out/'inputs.json');record['syntax_manifest_sha256']=sha(out/'front-syntax.json')
record['string_only_followup']={'previous_index_sha256':sha(current),'path':name,'source_sha256':inputs['files'][name],'helper_sha256':sha(Path(__file__)),'reason':'Clarify annual48 support in preparation guidance; only user-facing copy changed, extracted names/lines/imports unchanged.'}
put(out/'candidate.json',j)
subprocess.run(['C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe','-X','utf8','-B',str(P/'verify_index580.py'),'--candidate-dir',str(out),'--expected-candidate-sha256',sha(out/'candidate.json')],check=True)
assert current.read_bytes()==(out/'before-index.json').read_bytes()
current.write_bytes((out/'candidate.json').read_bytes())
put(out/'publication.json',{'before':sha(out/'before-index.json'),'after':sha(current),'changed_sources':changed,'syntax_unchanged_except_bytes_and_source_hash':True,'verification':'verification.json'})
