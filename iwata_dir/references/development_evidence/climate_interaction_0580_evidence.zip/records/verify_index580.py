"""Read-only, finite verification of a 0.58 index candidate; no repository writes."""
from pathlib import Path
import argparse, ast, hashlib, json

parser = argparse.ArgumentParser()
parser.add_argument('--candidate-dir', type=Path, required=True)
parser.add_argument('--expected-candidate-sha256', required=True)
args = parser.parse_args()
repo = Path.cwd()
folder = args.candidate_dir.resolve()
snapshot = folder / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
assert sha(folder / 'candidate.json') == args.expected_candidate_sha256
candidate = read(folder / 'candidate.json')
basis = read(folder / 'before-index.json')
inputs = read(folder / 'inputs.json')['files']
inventory = read(folder / 'source-inventory.json')
manual = candidate['structure']['manual_interpretation']
keys = ('typescript_modules', 'javascript_modules', 'frontend_assets')
rows = candidate['structure']['physical_modules'] + candidate['structure']['supporting_files'] + sum([manual[k] for k in keys], [])
assert len(inputs) == len(rows) == 245
assert {r['path'] for r in rows} == set(inputs)
for row in rows:
    name = row['path']
    assert row['source_sha256'] == inputs[name] == sha(snapshot / name) == sha(repo / name), name
assert set(inventory['current_paths']) - set(inventory['basis_paths']) == set(inventory['new_paths'])
assert len(inventory['new_paths']) == 1
assert set(inventory['new_paths']).issubset(inputs)
assert candidate['version'] == '0.58.0'
assert candidate['entries'] == basis['entries']
assert inventory['new_paths'] == ['backend/tests/test_climate_archive_interaction.py']
assert len(manual['data_flows']) == len(basis['structure']['manual_interpretation']['data_flows'])
assert len(manual['screen_bindings']) == len(basis['structure']['manual_interpretation']['screen_bindings'])
assert len(candidate['entries']) == 34
parsed = {name: ast.parse((snapshot / name).read_text(encoding='utf-8')) for name in inputs if name.endswith('.py')}
for entry in candidate['entries']:
    node = parsed[entry['path']]
    for name in entry['symbol'].split('.'):
        node = next(n for n in node.body if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    assert ast.unparse(node.args) == entry['signature'], entry['id']

verified_nodes = 0
def verify_tree(row):
    global verified_nodes
    if row['path'] not in parsed or 'tree' not in row:
        return
    nodes = list(ast.walk(parsed[row['path']]))
    def verify(parent):
        global verified_nodes
        for child in parent.get('children', []):
            matches = [n for n in nodes if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda))
                       and n.lineno == child['line'] and n.end_lineno == child['end_line']
                       and (child['kind'] == 'lambda' and isinstance(n, ast.Lambda) or getattr(n, 'name', None) == child['name'])]
            assert len(matches) == 1, (row['path'], child['name'], child['line'])
            if 'signature' in child:
                assert ast.unparse(matches[0].args) == child['signature']
            verified_nodes += 1
            verify(child)
    verify(row['tree'])
for row in rows:
    verify_tree(row)

syntax = read(folder / 'front-syntax.json')
assert not any(row.get('parse_diagnostics') for row in syntax['files'])
front_rows = {row['path']: row for key in keys for row in manual[key]}
assert set(front_rows) == {row['path'] for row in syntax['files']}
for row in syntax['files']:
    for key, value in row.items():
        assert front_rows[row['path']][key] == value, (row['path'], key)
factory = next(n for n in parsed['backend/app.py'].body if isinstance(n, ast.FunctionDef) and n.name == 'create_app')
for row in manual['http_routes']:
    handler = next(n for n in factory.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == row['handler'].split('.')[-1])
    assert handler.lineno == row['line']
support = {row['path']: row for row in candidate['structure']['supporting_files']}
new_test=support['backend/tests/test_climate_archive_interaction.py']
assert new_test['classification']=='active_regression_test' and new_test['test_method_definitions']==8
assert new_test['targets']==['backend/climate/archive.py','backend/climate/periods.py']
for provider in ('era5', 'jra3q'):
    name = f'tests/test_acquire_{provider}_climate_samples.py'
    assert support[name]['classification'] == 'active_regression_test'
    assert support[name]['targets'] == [f'tools/acquire_{provider}_climate_samples.py']
assert (repo / 'docs/IMPLEMENTATION_INDEX.json').read_bytes() == (folder / 'before-index.json').read_bytes()
result = {'basis_commit': 'b1b66dbff8b84bb6bb0332ec98043cc8990071b3', 'candidate_sha256': sha(folder / 'candidate.json'),
          'source_inputs': len(inputs), 'new_source_paths': inventory['new_paths'],
          'source_hashes_match_repository_and_fixed_copy': True, 'public_api_count': 34, 'public_entries_retained_exactly': True,
          'ast_nodes_verified': verified_nodes, 'frontend_syntax_diagnostics': 0, 'route_handler_locations_verified': True,
          'prior_acquisition_test_classifications_preserved': True, 'baseline_omissions_disclosed': inventory['baseline_paths_outside_index'],
          'applied': False, 'limits': ['Finite source index; not every repository file.', 'Syntax/location and explicit responsibility/contact review do not prove runtime completeness, annual download success, scientific validity, or API adoption.']}
out = folder / 'verification.json'
assert not out.exists()
out.write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(result, ensure_ascii=False, indent=2))
