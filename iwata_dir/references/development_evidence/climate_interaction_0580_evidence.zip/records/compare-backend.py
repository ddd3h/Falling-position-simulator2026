"""Finite offline before/after comparison; original archives are read-only."""
import cProfile
from copy import deepcopy
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import pstats
import statistics
import sys
import time

import numpy as np

R = Path.cwd()
P = Path(__file__).parent
sys.path.insert(0, str(R))
from backend.climate.archive import WindArchiveSource

spec = importlib.util.spec_from_file_location('backend.climate._before580', P/'backend-before/archive.py')
before_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(before_module)
manifest = Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/era5/manifest.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source_paths = ['backend/climate/archive.py', 'backend/climate/periods.py', 'backend/tests/test_climate_archive_interaction.py']
inputs = {p:sha(R/p) for p in source_paths}
inputs.update({'baseline_archive':sha(P/'backend-before/archive.py'), 'manifest':sha(manifest)})


def normalized(result):
    result = deepcopy(result)
    # These identify new code/version/annual extension, not changed old values.
    result.pop('source')
    result.pop('provenance')
    result.pop('annual_quarters', None)
    result['query'].pop('source_id')
    return result


def exact(a, b, path=''):
    """Includes float bit patterns, not merely numerical == (signed zero)."""
    if type(a) is not type(b):
        raise AssertionError((path, type(a).__name__, type(b).__name__))
    if isinstance(a, float):
        if a.hex() != b.hex():raise AssertionError((path, a.hex(), b.hex()))
    elif isinstance(a, dict):
        if a.keys() != b.keys():raise AssertionError((path, a.keys(), b.keys()))
        for k in a:exact(a[k],b[k],path+'/'+k)
    elif isinstance(a, list):
        if len(a) != len(b):raise AssertionError((path,len(a),len(b)))
        for i,(x,y) in enumerate(zip(a,b)):exact(x,y,path+'/'+str(i))
    elif a != b:raise AssertionError((path,a,b))


def q(source, pressure):
    return {'source_id':source.source_id,'level_id':next(l['level_id'] for l in source.descriptor()['levels'] if l['level_hpa']==pressure),
            'bounds':None,'grain':'half','hours_utc':[0]}


results = {}
timings = {'before':[], 'after':[]}
for name, cls in [('before',before_module.WindArchiveSource),('after',WindArchiveSource)]:
    start=time.perf_counter(); source=cls(manifest); activation=time.perf_counter()-start
    for run, pressure in enumerate([300,250,200,300,250,200,300,250,200]):
        start=time.perf_counter(); result=source.query(q(source,pressure)); elapsed=time.perf_counter()-start
        timings[name].append({'run':run,'pressure_hpa':pressure,'cold_population':run==0,'seconds':elapsed})
        print(name,run,pressure,round(elapsed,5),flush=True)
        if run < 3:
            saved=json.loads((P/f'before-{pressure}-summary.json').read_text(encoding='utf8'))
            exact(normalized(saved),normalized(result))
            if name=='after':
                (P/f'after-{pressure}-summary.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf8')
                results[pressure]=result
    timings[name+'_activation_seconds']=activation
    if name=='after':
        profiler=cProfile.Profile(); start=time.perf_counter(); profiler.enable()
        result=source.query(q(source,250))
        profiler.disable(); elapsed=time.perf_counter()-start
        stream=io.StringIO();pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(30)
        (P/'after-250-profile.txt').write_text(stream.getvalue(),encoding='utf8')
        timings['after_250_seconds_profiled']=elapsed

# Independent raw annual48 calculation: select original times; sum in native
# time-major arrays (not adapter per-level advanced-index layout), then fsum
# spatial means with source weights. All 48*37 rows, original 1 UTC / 1188 cells.
raw=json.loads(manifest.read_bytes())
weights=[float(g['weight']) for g in raw['grid']]
total_weight=math.fsum(weights)
lookup={(r['timebin_id'],r['level_id']):r for r in results[300]['annual_quarters']['annual']}
max_abs={key:0. for key in ('mean_u','mean_v','mean_speed','pooled_constancy','from_deg','max_cell_mean_speed','spatial_mean_speed_range')}
compared=0
for m in raw['months']:
    u=np.load(manifest.parent/m['u']['file'],mmap_mode='r',allow_pickle=False)
    v=np.load(manifest.parent/m['v']['file'],mmap_mode='r',allow_pickle=False)
    for quarter,(lo,hi) in enumerate(((1,7),(8,15),(16,22),(23,31))):
        take=[i for i,t in enumerate(m['times_utc']) if lo<=int(t[8:10])<=hi and t[11:13]=='00']
        a=np.asarray(u[take],dtype=np.float64);b=np.asarray(v[take],dtype=np.float64)
        means=[a.mean(axis=0),b.mean(axis=0),np.hypot(a,b).mean(axis=0)]
        for li,level in enumerate(raw['levels']):
            expected=[math.fsum(float(value)*weight for value,weight in zip(mean[li],weights))/total_weight for mean in means]
            row=lookup[((m['month']-1)*4+quarter,level['level_id'])]
            assert row['time_count']==row['valid_time_count']==len(take)
            assert row['cell_count']==len(weights) and row['missing_time_count']==0
            derived=dict(zip(('mean_u','mean_v','mean_speed'),expected))
            derived.update(pooled_constancy=min(1.,math.hypot(*expected[:2])/expected[2]),
                           from_deg=(math.degrees(math.atan2(*expected[:2]))+180.)%360.,
                           max_cell_mean_speed=float(max(means[2][li])),
                           spatial_mean_speed_range=float(max(means[2][li])-min(means[2][li])))
            for key,value in derived.items():
                difference=abs(row[key]-value);max_abs[key]=max(max_abs[key],difference)
                assert difference <= 1e-11, (key,difference,row,value)
            compared+=1
    del u,v

assert inputs == {**{p:sha(R/p) for p in source_paths},'baseline_archive':sha(P/'backend-before/archive.py'),'manifest':sha(manifest)}
for name in ('before','after'):
    timings[name+'_warm_median_seconds']=statistics.median(r['seconds'] for r in timings[name] if not r['cold_population'])
timings['warm_speedup_ratio']=timings['before_warm_median_seconds']/timings['after_warm_median_seconds']
report={'scope':'ERA5 2024 original samples, all1188 native cells/all37 levels/UTC00. Offline adapter wall-clock, not HTTP or UI. Same host sequential runs, no claim of controlled global filesystem-cache coldness.',
        'source_hashes':inputs,'timings':timings,
        'old_numeric_and_population_fields_exact_float_bits':True,
        'compared_legacy_pressure_hpa':[300,250,200],
        'excluded_from_legacy_comparison':['source descriptor','provenance identifiers/definitions','query.source_id','new annual_quarters'],
        'quarter_independent':{'rows':compared,'cell_count':len(weights),'hours_utc':[0],
            'original_values_read':366*37*1188*2,'method':'native time-major float64 means then scalar fsum weighted spatial reduction, no adapter calendar/group/cache helpers',
            'absolute_tolerance':1e-11,'max_abs_differences':max_abs},
        'limits':['No live state or original archive writes','Calendar/UTC multi-hour/cache mutation/source-change checks are separate small-fixture tests','Speedup applies to repeated pressures in the same bounded population cache; cold population still computes all annual fields and monthly quantiles']}
(P/'backend-comparison580.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'warm_before':timings['before_warm_median_seconds'],'warm_after':timings['after_warm_median_seconds'],
                  'ratio':timings['warm_speedup_ratio'],'quarter_max_abs':max_abs,'report':str(P/'backend-comparison580.json')}),flush=True)
