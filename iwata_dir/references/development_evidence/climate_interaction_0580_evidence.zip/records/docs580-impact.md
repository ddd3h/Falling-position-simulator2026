# 0.58の4資料・有限改訂

比較元 b1b66dbff8b84bb6bb0332ec98043cc8990071b3（固定0.57 C2）と編集前4実体のbyte一致を確認した。変更対象は COMMANDS-CORE、IMPLEMENTATION-NOTES、PROGRAM-CORE、THEORY-CORE。既存論理ID、TeXページID/式labelと資料の役割を維持し、新たな管理単位は設けていない。

- COMMANDS：原標本の年間「月内4区分・48区分」、UTCの4日付区間、旧DB/旧保存への補完禁止、飛行関心へ渡さない境界、選択中/表示中と状況の分離を利用者操作へ反映。
- IMPLEMENTATION_NOTES：annual_quartersの独立DTO、ClimateAnnualGrainのみquarter、原u/v直接集計、4母集団cacheの再利用範囲、選択面のspatialと一巡の風配counts、adapter /2、操作枠の責務を記録。
- PROGRAM：WEB-CLIMATE-FRONTEND/WEB-CLIMATE-RAWの既存箱と版入口だけを更新。年間48のadapter、年間値再利用/面再計算/風配読取の分担を実ファイルに戻す。ページ/リンクIDを保持。
- THEORY：th:climate-periodsにUTC 1–7/8–15/16–22/23–末の元時刻集合を定義し、旧式climate-timeをその集合へ適用。旧半月/月分位式は維持。1年細分化を10年代表性や独立標本数の増加と扱わない。

旧→新の目的比較：旧来の年間24半月だけでは依頼された48区分を読めず、面の計算と可変状況文が操作待ち/位置の不安定さへつながる。原標本がある資料だけに年間のより細かな比較を追加し、既存の半月・月/季節・中央値/幅・飛行関心・旧固定結果の意味を保つ。平均から分位への代用も、半月から48値への推定も追加していない。

frontend430は指定されたCOMMANDS/NOTESのbackend境界とPROGRAM raw箱を有限再読し重大不整合なしと返却した。UI成功の独立審査ではない。速度数値は4資料へ複写せず、主担当のS36へwarm/cold双方を含む有限観測を戻す。原始コードの読取hashと具体変更行はJSONを参照する。

確認印は0.57のまま、更新版だけ0.58とした。最終source/PDF生成/レイアウト視認/UIと管理閉鎖は主担当へ引き継ぐ。本文は未実施の速度改善幅や実UI合格を主張しない。MDは既存CRLF、TeXは既存LFを保持し、変更していない本文の一括改行正規化はしていない。TeXのpage/label保持とbrace差分だけを静的確認したが、コンパイル/描画成功の代わりではない。
