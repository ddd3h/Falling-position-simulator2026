"""Offline saved-artifact upgrade and unchanged metadata check."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

R=Path.cwd(); P=Path(__file__).parent
sys.path[:0]=[str(R),str(R/'backend/tests')]
from backend.climate.archive import WindArchiveSource
from backend.climate.service import ClimateService
from test_climate_archive import archive_fixture
spec=importlib.util.spec_from_file_location('backend.climate._before580',P/'backend-before/archive.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

source_checks=[]
for pressure in [300,250,200]:
    a=json.loads((P/f'before-{pressure}-summary.json').read_text(encoding='utf8'))
    b=json.loads((P/f'after-{pressure}-summary.json').read_text(encoding='utf8'))
    da,db=deepcopy(a['source']),deepcopy(b['source'])
    for d in (da,db):
        for key in ('source_id','adapter_version','statistics_version','source_code'):d.pop(key)
    db['capabilities'].pop('annual_grains')
    assert da==db
    for key in ('numpy_version','definitions'):assert a['provenance'][key]==b['provenance'][key]
    source_checks.append({'pressure_hpa':pressure,'other_descriptor_fields_unchanged':True,'provenance_definitions_unchanged':True})

root=P/'compatibility-artifacts'
assert not root.exists(), 'fresh isolated output required'
manifest=archive_fixture(root/'source')
store=root/'store'
with patch('backend.climate.service.WindArchiveSource',old.WindArchiveSource):
    first=ClimateService(store,archive_paths=[manifest])
    sourceid=first.sources()['sources'][0]['source_id']
    body={'client_request_id':'accepted-under-v1','query':{'source_id':sourceid,'level_id':0,'bounds':None,'grain':'half'}}
    artifact=first.create_analysis(body)
    assert 'annual_quarters' not in artifact['summary']
    old_json=json.dumps(artifact,sort_keys=True,ensure_ascii=False,separators=(',',':'))
updated=ClimateService(store,archive_paths=[manifest])
assert updated.sources()['sources'][0]['source_id']!=sourceid
assert updated.create_analysis(body)==artifact
assert updated.get_analysis(artifact['analysis_id'])==artifact
newbody={'client_request_id':'v2-request','query':{**body['query'],'source_id':updated.sources()['sources'][0]['source_id']}}
new=updated.create_analysis(newbody)
assert 'annual_quarters' in new['summary'] and new['analysis_id']!=artifact['analysis_id']
offline=ClimateService(store)
assert offline.get_analysis(artifact['analysis_id'])==artifact
assert json.dumps(offline.get_analysis(artifact['analysis_id']),sort_keys=True,ensure_ascii=False,separators=(',',':'))==old_json
receipt={'source_metadata':source_checks,
         'old_artifact_created_by':'preserved baseline archive.py / original-utc-wind/1 with current unchanged support modules',
         'old_saved_before_quarters':True,'accepted_retry_after_new_source':True,
         'old_offline_read_exact':True,'old_artifact_sha256':hashlib.sha256(old_json.encode()).hexdigest(),
         'new_distinct_artifact_has_quarters':True,'isolated_store':str(store),
         'source_hashes':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'backend/climate/archive.py',R/'backend/climate/periods.py')},
         'limits':'No live user store; finite upgrade compatibility test, not browser acceptance.'}
(P/'backend-compatibility580.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
