"""Prepare only the old summary inputs for the recorded 0.58 offline comparison.
No repository writes, network, service changes, user-store access or archive writes.
Run from a matching repository root. Output is a separate scratch directory.
"""
from pathlib import Path
import argparse,cProfile,hashlib,importlib.util,io,json,pstats,sys,time

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 repo=Path.cwd().resolve();out=args.output.resolve();manifest=args.manifest.resolve()
 assert not out.is_relative_to(repo),'Output must be outside repository'
 assert not out.is_relative_to(manifest.parent),'Output must be outside original archive'
 out.mkdir(parents=True,exist_ok=True)
 baseline=out/'backend-before/archive.py';assert baseline.is_file(),'Copy recorded backend-before/archive.py into scratch first'
 for pressure in [300,250,200]:
  assert not (out/f'before-{pressure}-summary.json').exists();assert not (out/f'before-{pressure}-profile.txt').exists()
 assert not (out/'before-timing.json').exists()
 sys.path.insert(0,str(repo));spec=importlib.util.spec_from_file_location('backend.climate._before580',baseline);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
 digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 originals={'manifest':digest(manifest),'baseline_archive':digest(baseline)}
 start=time.perf_counter();source=old.WindArchiveSource(manifest);activation=time.perf_counter()-start;d=source.descriptor();records=[]
 for pressure in [300,250,200]:
  q={'source_id':source.source_id,'level_id':next(l['level_id'] for l in d['levels'] if l['level_hpa']==pressure),'bounds':None,'grain':'half','hours_utc':[0]}
  profiler=cProfile.Profile();start=time.perf_counter();profiler.enable();result=source.query(q);profiler.disable();elapsed=time.perf_counter()-start
  stream=io.StringIO();pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(24)
  (out/f'before-{pressure}-profile.txt').write_text(stream.getvalue(),encoding='utf-8')
  data=json.dumps(result,ensure_ascii=False).encode('utf-8');(out/f'before-{pressure}-summary.json').write_bytes(data)
  records.append({'pressure':pressure,'seconds_profiled':elapsed,'payload_bytes':len(data),'summary_sha256':hashlib.sha256(data).hexdigest(),'profile':f'before-{pressure}-profile.txt'})
 assert originals=={'manifest':digest(manifest),'baseline_archive':digest(baseline)}
 (out/'before-timing.json').write_text(json.dumps({'scope':'Reproduced baseline inputs only; new execution is not the historical 0.58 evidence. No HTML write. Profiling overhead included.','activation':activation,'observations':records,'inputs':originals},ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
