"""Bounded 0.58 shadow index candidate. Publication is a separate verified step."""
from pathlib import Path
import argparse, ast, copy, hashlib, json, os, shutil, subprocess

REPO=Path.cwd(); P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();O=args.output.resolve();O.mkdir(parents=True,exist_ok=False);R=O/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def put(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
BASIS='b1b66dbff8b84bb6bb0332ec98043cc8990071b3'
B=P.parent/'balloon-climate-quantiles570/record-c2/candidate'
index=REPO/'docs/IMPLEMENTATION_INDEX.json'
assert sha(index)==sha(B/'docs/IMPLEMENTATION_INDEX.json')=='8261a7c8911b5ec9c378254a820c68b6ecd08c921e970c92152d28fda077a931'
base=read(index);j=copy.deepcopy(base);j['version']='0.58.0'
(O/'before-index.json').write_bytes(index.read_bytes())
keys=('typescript_modules','javascript_modules','frontend_assets')
manual=base['structure']['manual_interpretation']
old_front={r['path']:r for key in keys for r in manual[key]}
old_support={r['path']:r for r in base['structure']['supporting_files']}
old_modules_by_path={r['path']:r for r in base['structure']['physical_modules']}
new={'backend/tests/test_climate_archive_interaction.py'}
names=set(old_front)|set(old_support)|set(old_modules_by_path)|new
assert len(names)==245 and len(old_front)==134
allowed_changed={
 'backend/app.py','backend/climate/archive.py','backend/climate/periods.py',
 'frontend/src/App.tsx','frontend/src/climate-expansion.test.ts','frontend/src/climateDomain.ts',
 'frontend/src/screens/WeatherScreen.tsx','frontend/src/screens/weather/export.ts',
 'frontend/src/screens/weather/plots.ts','frontend/src/screens/weather/sources/climateSummary.ts',
 'frontend/src/screens/weather/climateController.js','frontend/src/screens/weather/screen.css',
 'frontend/package.json','frontend/package-lock.json',
}
baseline_rows={**old_front,**old_support,**old_modules_by_path}
actual_changed={n for n in baseline_rows if sha(REPO/n)!=baseline_rows[n]['source_sha256']}
assert actual_changed==allowed_changed,('unreviewed changed source',sorted(actual_changed^allowed_changed))
roots=('frontend','backend','balloon_sim','tests','tools')
ignored={'node_modules','dist','.venv','__pycache__','.pytest_cache'}
suffixes={'.py','.ts','.tsx','.js','.mjs','.css','.html','.json'}
def inventory(root):
    found=set()
    for top in roots:
        for directory,dirs,files in os.walk(root/top):
            dirs[:]=[d for d in dirs if d not in ignored]
            for name in files:
                path=Path(directory)/name
                if path.suffix in suffixes:found.add(path.relative_to(root).as_posix())
    return found
basis_inventory=inventory(B);current_inventory=inventory(REPO)
assert current_inventory-basis_inventory==new
assert not basis_inventory-current_inventory
put(O/'source-inventory.json',{'scope_roots':roots,'excluded_directory_names':sorted(ignored),
    'included_suffixes':sorted(suffixes),'basis_paths':sorted(basis_inventory),'current_paths':sorted(current_inventory),
    'new_paths':sorted(new),'baseline_paths_outside_index':sorted(basis_inventory-(names-new)),
    'limit':'Finite source roots/suffixes; old omissions remain disclosed, not silently promoted to whole-repository completeness.'})
inputs={n:sha(REPO/n) for n in sorted(names)}
for n in sorted(names):
    dest=R/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/n,dest)
    assert sha(dest)==inputs[n]
put(O/'inputs.json',{'basis':BASIS,'files':inputs})

# Preserve the reviewed finite Python AST/lexical extractor. Execute only its
# extraction fragment against the frozen source copy, not its old publication.
py_helper=P.parent/'balloon-operational-490/update_index490.py'
s=py_helper.read_text(encoding='utf8')
part=s[s.index('py_paths='):s.index('# Existing scientific APIs')].replace('0.49','0.58')
exec(compile(part,'reused-python-ast-extractor580','exec'))
assert not signature_changes and j['entries']==base['entries']
purposes={
 'backend/climate/archive.py':'原UTC風束の支持を保ち、範囲/UTC別の全高度年間値と月分位を再利用する。選択面の空間行と一点風配を分け、原日付からの年間48区分を別枝へ返す。',
 'backend/climate/periods.py':'固定年のUTC半月/月/季節の暦・件数を保持し、各半月内の1–7/8–15/16–22/23–末という年間専用48区分の暦を別に定義する。',
 'backend/tests/test_climate_archive_interaction.py':'原48区分の独立数値/UTC支持・暦の完全性と半月包含、面変更の年間再利用、cache返却値変異/母集団分離/失敗/資料変更の反例を検査する。',
 'frontend/src/climateDomain.ts':'固定資料・集計・月分位の型を保持し、年間専用ClimateAnnualGrain/annual_quartersを共通の3粒度およびhalf固定queryから分ける。',
 'frontend/src/screens/WeatherScreen.tsx':'実/人工の入口を保ち、固定artifactの半月/月/季節と任意の年間48区分を検査・投影し、草案/明示適用/保存/関心へ接続する。',
 'frontend/src/screens/weather/sources/climateSummary.ts':'資料別summaryをVMへ投影する。年間48区分は別VMで版・所属・行の一意性/件数を検査し、空間/風配の値へ混ぜない。',
 'frontend/src/screens/weather/climateController.js':'固定集計の図別表示とSVG出力を所有し、年間だけ48区分を選ぶ。面の選択値/表示値と待機・失敗を別枠へ描き、月分位/平均/一点風配の問いを分ける。',
 'frontend/src/screens/weather/plots.ts':'VMの年間高度構造と空間分布をSVGへ描く。原UTC年間48の区切りを半月/月/季節や人工JST区間から区別して表示する。',
 'frontend/src/screens/weather/screen.css':'気象画面の配置と応答幅を定義する。実気象の面slider、選択/表示値、待機/失敗の状況行を分け、文字長から操作枠を分離する。',
 'frontend/src/climate-expansion.test.ts':'図別粒度とUTC支持、旧保存・固定SVGの反例に加え、独立48行の年間投影・保存表示状態・旧半月と飛行関心の保持を検査する。',
}
for row in j['structure']['physical_modules']:
    old=old_modules_by_path.get(row['path']);syntax=copy.deepcopy(row)
    if old:row.clear();row.update(copy.deepcopy(old));row.update(syntax)
    if row['path'] in purposes:row['purpose']=purposes[row['path']]
new_test=next(iter(new));node=ast.parse((R/new_test).read_text(encoding='utf8'))
top=tree(node,module_of(new_test));top['end_line']=len((R/new_test).read_text(encoding='utf8').splitlines())
old_support[new_test]={'path':new_test,'source_sha256':inputs[new_test],
    'classification':'active_regression_test','interpretation':purposes[new_test],
    'targets':['backend/climate/archive.py','backend/climate/periods.py'],
    'lifecycle_in_contract':'active','structure_anchor':'WEB-CLIMATE-RAW','introduced_in':'0.58.0',
    'tree':top,'ast_imports':[ast.unparse(n) for n in ast.walk(node) if isinstance(n,(ast.Import,ast.ImportFrom))],
    'test_method_definitions':sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in ast.walk(node)),
    'extraction_note':'AST定義数は試験成功数ではない。実行/性能/統計比較は別の有限票へ戻る。'}
j['structure']['supporting_files']=sorted(old_support.values(),key=lambda r:r['path'])

extractor=P.parent/'balloon-seasonal-550/detail-lease-repair550/index/pass02/extract_frontend550.cjs'
put(O/'front-input.json',{'rows':[{'path':n,'source_sha256':inputs[n]} for n in sorted(old_front)]})
subprocess.run(['C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe',str(extractor),str(R),str(O/'front-input.json'),str(O/'front-syntax.json'),str(REPO/'frontend/node_modules/typescript')],check=True,capture_output=True)
syntax=read(O/'front-syntax.json');assert not any(r.get('parse_diagnostics') for r in syntax['files'])
m=j['structure']['manual_interpretation']
for key in keys:m[key]=[]
for extracted in syntax['files']:
    n=extracted['path'];key='typescript_modules' if n.endswith(('.ts','.tsx')) else 'javascript_modules' if n.endswith(('.js','.mjs')) else 'frontend_assets'
    row=copy.deepcopy(old_front[n]);row.update(extracted)
    if n in purposes:row['purpose']=purposes[n]
    m[key].append(row)
def refresh_tree(node):
    if node.get('kind')=='file':node['source_sha256']=inputs[node['path']]
    for child in node.get('children',[]):refresh_tree(child)
refresh_tree(m['frontend_physical_tree'])
for row in m['screen_bindings']:
    if row.get('path') in inputs:row['source_sha256']=inputs[row['path']]
factory=next(n for n in parsed['backend/app.py'].body if isinstance(n,ast.FunctionDef) and n.name=='create_app')
for row in m['http_routes']:
    handler=next(n for n in factory.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==row['handler'].split('.')[-1])
    row['line']=handler.lineno

# Update the existing original-sample connection in place. No repeated flow or
# service entries, no new scientific API, no adoption/reviewed_in advancement.
flows=[r for r in m['data_flows'] if r.get('source_version')=='0.57.0' and r.get('from')=='JRA/ERAの原UTC風とnative支持']
assert len(flows)==1
flows[0].update(source_version='0.58.0',through=['acquire tools → manifest/NumPy arrays',
    'MonthlySamples → WindArchiveSource population cache / selected-level spatial / native-point rose counts',
    'ClimateService → fixed climate-summary/1 (annual_quarters separate)',
    'climateSummary / annualQuarterViewModel / monthlyProfiles → climateController / export'],
    to='既存月分位・期間平均・一点風配と、原UTCから直接計算した年間48区分の固定図',
    boundary=flows[0]['boundary']+' 年間48は既存半月の内側を二分し、半月/月/季節の数値や月分位の計算順を置換しない。48の空間行や飛行関心を追加しない。')
bindings=[r for r in m['screen_bindings'] if r.get('kind')=='source-bound monthly quantiles and supported hours']
assert len(bindings)==1
bindings[0]['meaning']+=' 原標本のannual_quartersは年間図だけの別VMへ接続し、旧保存へ補完しない。面の選択/表示値と状況文は別枠で示す。'
assert len(m['data_flows'])==len(manual['data_flows']) and len(m['screen_bindings'])==len(manual['screen_bindings'])

def signatures(row):
    found={}
    def walk(node):
        if 'signature' in node:found[node['id']]=node['signature']
        for child in node.get('children',[]):walk(child)
    walk(row['tree']);return found
private_changes=[]
for row in j['structure']['physical_modules']:
    old=old_modules_by_path[row['path']]
    a,b=signatures(old),signatures(row)
    for symbol in sorted(a.keys()|b.keys()):
        if a.get(symbol)!=b.get(symbol):private_changes.append({'path':row['path'],'symbol':symbol,'before':a.get(symbol),'after':b.get(symbol),'public_entry':any(e.get('structure_symbol_id')==symbol for e in base['entries'])})
assert not any(r['public_entry'] for r in private_changes)
put(O/'private-signature-changes.json',{'changes':private_changes,'meaning':'Private helper changes/additions/removal are AST structure updates, not new public API or reviewed_in adoption.'})
j['extraction']['climate_interaction']={'basis_commit':BASIS,'basis_index_sha256':sha(index),
    'input_manifest_sha256':sha(O/'inputs.json'),'syntax_manifest_sha256':sha(O/'front-syntax.json'),
    'source_inventory_sha256':sha(O/'source-inventory.json'),'python_extractor_sha256':sha(py_helper),
    'frontend_extractor_sha256':sha(extractor),'helper_sha256':sha(Path(__file__)),
    'method':'Frozen 245-source fingerprints; Python AST/lexical extraction, TypeScript syntax and bounded annual48/pressure-layout responsibility review. Public entries/review stamps preserved.',
    'generated_by':'balloon-climate-interaction580/update_index580.py','self_hash_excluded':True}
assert j['entries']==base['entries'] and len(j['entries'])==34
rows=j['structure']['physical_modules']+j['structure']['supporting_files']+sum([m[key] for key in keys],[])
assert len(rows)==245 and {r['path'] for r in rows}==set(inputs)
for row in rows:assert row['source_sha256']==inputs[row['path']]
for entry in j['entries']:
    node=parsed[entry['path']]
    for name in entry['symbol'].split('.'):
        node=next(n for n in node.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    assert ast.unparse(node.args)==entry['signature']
assert inputs=={n:sha(REPO/n) for n in inputs},'source drift'
assert inventory(REPO)==current_inventory,'inventory drift'
assert sha(index)==sha(O/'before-index.json'),'index drift'
put(O/'candidate.json',j)
put(O/'receipt.json',{'basis_commit':BASIS,'sources':245,'frontend':134,'new':sorted(new),
    'changed_sources':sorted(actual_changed),'public_api_unchanged':True,'public_entries':34,
    'private_signature_changes':'private-signature-changes.json','http_routes':len(m['http_routes']),
    'new_flow_or_binding_rows':0,'candidate_sha256':sha(O/'candidate.json'),'applied':False,
    'limits':['Syntax/hash correspondence is not whole-repository completeness or runtime/scientific acceptance.',
              'Review scope is changed climate annual48/pressure UI and version literals. Unchanged source semantic reviews are inherited, not repeated.']})
print(json.dumps({'candidate':str(O/'candidate.json'),'sources':245,'frontend':134,'sha256':sha(O/'candidate.json')}))
