# 再提供JRA十年DBの有限読取

再提供tar内DBは現runtime DBと同一SHA `1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a`、309,866,496 bytes。tarは195,352,205 bytes、SHA `7a1a64b495a22f1b75703709ff21ce7132ef1642bebd366f08b96572e208dfbc`、97 member（85 file＋12 directory）。新規展開せず、tar memberのstream hash一致後に既存DBをread_only=Trueで確認した。

実表18・view10。dim_timebin24行、fact_wind519,840行（24×38×570）、diurnal1,094,400行（24×20×570×4）、rose87,552行（24×38×16×6）。原有効日時/u/vの表はなく、TIMESTAMPはmeta_provenanceの処理開始/終了だけ。全tableのcolumnと実countは同名JSONへ保存した。fitsや分位・共分散から半月内の日付所属は復元できず、この束だけで十年48区分は作れない。

README38–42行は元6時間解析値とwindclimの未収録、fitjob3–7行は外部raw cache読込を記している。meta_dataset.periodには14,610とあるが、実period支持・fact_windの1格子/面のn合計は14,612。元日時を再取得する場合の支持は2016–2025/4UTC/38面/570格子、Float32 u/v本体2,531,967,360 bytes。この容量は支持からの算術であり、今回新規取得や公開元到達確認をした値ではない。元DB・コード・資料・ユーザーstateは変更していない。
