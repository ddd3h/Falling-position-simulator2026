# 0.58 frontend 有限独立レビュー

記録 UTC: 2026-10-02T11:42:59.383235+00:00

## 結論と担当範囲

この候補差分に新しい実装阻害点は見つからなかった。旧原標本保存結果への「再集計」案内は、旧 source_id が現 catalog に無い場合を含めて現在利用できる資料の明示選択が必要とする文へ訂正され、読戻しを確認した。年間 intro も半月・月・季節だけを列挙しない文へ訂正済み。

即時基準は 0.57 C2 b1b66dbff8b84bb6bb0332ec98043cc8990071b3、比較元は P570/record-c2/candidate。指定 7 source の差分と現接点を読解した。補助読解は useClimateWorkspace、ClimateFlightHandoff、export、climateDistributions、backend annual_quarters 生成/版識別の該当部分。repo・UI・API・Git は変更/操作せず、この票だけを外側へ保存した。今回は試験を実行していない。科学的採用や全画面の受入をこの票から主張しない。

## 確認した責務

1. **48 は原時刻から集計した年間図だけ。** climateDomain.ts:1–4,22 の optional annual_quarters と annual_grain の拡張に閉じ、query grain / spatial / monthly / interest の契約は half/month/season を保つ。sources/climateSummary.ts:7–21 は schema・UTC・暦版・48期間・期間/面キー・標本数を検査し、渡された48区分の実数値を描く。半月値の複製・補間ではなく、quarter VM の spatial / windRose を除く。plots.ts:12 は48列を「UTC月内4区分」と明示する。1–7 / 8–15 / 16–22 / 23–月末を ISO 週や人工JST暦と同一視しない説明を確認した。
2. **旧保存と飛行関心を保持。** WeatherScreen.tsx:20 は quarter が存在するときだけ projection を追加し、既存3grainの風配検査にquarterを通さない。climateController.js:77–80 は未対応48を選択不可にし、既存halfへ表示fallbackする。旧保存を自動再集計/現在sourceへ自動付替えしない。ClimateFlightHandoff.tsx:3–10 / climateGrains は年間48を関心候補へ混入せず、controller.fields と hook.show の merge は既存 interest を保持する。summary provenance/query は元固定artifactを保ち、図別48選択は保存された表示状態として区別される。
3. **表示中と選択中を分け、統計を変えず操作幅を安定化。** controller:70–76,133–136 は slider の希望面と artifact の表示面を別欄にし、ISAも表示面から出す。待機文を専用行へ分け、CSS:64–73 は toolbar を flex-wrap、sliderとapply行を全幅とする。これは待機時間を隠すために旧図を新面と表示する変更ではない。既存queue/cacheが返却した固定artifact以外は図・SVGへ採用しない接続を保持している。
4. **固定SVGの意味は維持。** controller:121–129 / export.ts:14–28 は選択された annual VM を同期snapshotしてから準備し、48 membership・UTC暦・source/query/result・表示条件を保持する。保存リンクの既存URL寿命/失敗時保持を変更しない。半月/年/対象の元artifactと48表示の membership は別fieldとして辿れる。速度改善を目的としたUI側標本間引き/値変更は差分にない。

## 指摘と処置

- 修正済み: 旧raw artifactで「この対象で再集計」だけを促す説明は、raw adapter版更新によるsource_id移行時に再集計buttonが無効のため実操作と矛盾していた。controller:92 の現在資料を選び対象確認後に再集計する説明へ訂正を確認した。自動移行や旧固定GETの書換えは必要ない。
- 受入阻害ではない表示上の残り: WeatherScreen.tsx:33 の詳細欄は「月・半月・季節の表示選択は図ごと」と旧列挙を残す。48不可と断言しておらず操作/数値には影響しないが、次回この欄を触る場合は「利用できる時間区切りは図ごと」等にすると年間48も含む説明になる。
- 狭幅の未視認範囲: CSS:67–73 の二列readoutは両spanを nowrap にする。520px以下でも 14ch + 第二列で、rose minimap の横に残る狭い幅では文字がはみ出す余地がある。この票は再現を確認しておらず、デスクトップ候補の阻害とはしない。狭幅対応を受入範囲に含めるなら別途実画面で確認する。

## 証拠の限界

追加試験 climate-expansion.test.ts:25以降は48値の独立projection、並び/欠落/重複/標本数/UTC境界、旧half不変、interest分離、旧artifact読取を対象とする。controllerのmount/DOM/CSS往復を直接保証する試験ではない。calendar_definition.version を照合する一方、FE単体が原日時配列から全暦/集計を再計算する設計ではない。実標本の暦・統計比較は別のbackend票に依存する。

主担当報告として、初稿toolbar gridが凡例SVGを横全幅へ拡張した後にflex-wrapへ訂正し、新tab28では凡例が通常の約300pxへ復帰したとの連絡を受領した。私はその画面を視認していない。圧力変更の体感、旧保存からの再訪、48/24/12/4往復、SVG実受領の最終UI受入は主担当票へ戻す。backend-comparison580.json の温cache短縮を、初回母集団・ネットワーク・全UI操作の一律高速化と解釈しない。

## 読解候補の固定指紋

| 対象 | 現候補 SHA256 | 即時基準 SHA256 |
|---|---|---|
| frontend/src/climateDomain.ts | 124b52656e34a48f94cea632c7ac90d6567e33343c359de938047a4bddf4e60e | 0ac541b11c7ff5661dc7973e3cfae99fbc3f74df6e4991b545d11f00f76f453a |
| frontend/src/screens/WeatherScreen.tsx | cdb2350fd66b08957a2faa094af983f00dc79ce5d391bf1de5ee7a0688f198f2 | 2ed36c9ea73dcf29dfea0e034a2505db578d7c01b6779486f64caf9d96005d71 |
| frontend/src/screens/weather/climateController.js | e7e6f9b92ca4403f05d0b8c0d69a9f465e728c919ac1d481cc4f95cd0bca954d | 2bf9de2a3645b33b9f42716cddbd3414434994e26483659ee62fd2a8d0ba643c |
| frontend/src/screens/weather/sources/climateSummary.ts | 115213ba37b82a7edf81871da1a067fb86c788bae79661f56f24decaec2e85f8 | 1f2ad630c51872500844a61ee9447c14e5bd5264ad5d0cfed62a9e6b1090986c |
| frontend/src/screens/weather/plots.ts | e662cea82d52e997b1e587b1223e4acdc8e619b820eb664405ea1811b8278c65 | 08c2d355e96ac3204b1c5ba250f4befbe26b7fdc07c70fd8e1181619f81723f8 |
| frontend/src/screens/weather/screen.css | 2c538b45af1998291d84652342f720c20b5a8658047573621be8ca502c95c90b | 9bf74b40930770db912ba8bdde1da24bb22a59ff5a3879b85ed3735781a23681 |
| frontend/src/climate-expansion.test.ts | 08dbbe129baf5551913e0cdc56e05ab4999e7b84f5ab78c2dbec63b4487519c5 | 8b462fe23a9ef34f9caa403b32165b8d3e47c77d384047278d26ba5a68f347f9 |
