# 0.58 原UTC標本adapterの限定実装票

基準は 0.57 C2 `b1b66dbff8b84bb6bb0332ec98043cc8990071b3`。編集は `backend/climate/archive.py`、`backend/climate/periods.py` と新規 `backend/tests/test_climate_archive_interaction.py` のみ。元標本・ユーザー保存state・稼働アプリ・Git・他担当資料はこの実装担当では変更しない。

## 判断と最終初稿

- 面を変えるたびに全高度の年間集計を作り直す処理を分離した。4母集団（範囲＋採用UTC）の既存LRUへ、半月momentと月分位に加え半月/月/季節の年間値と新48区分の年間値を保持する。面依存のspatial/尺度は要求ごとに作る。cacheはsource instance内であり、資料/コードの変更検知は従来どおり要求前後に行う。返却値はdeepcopyし、cacheや暦定義を利用者側の変更から分ける。
- 選択面・選択点の原標本を一巡して風配の24半月count/静穏数を作り、同じcountを3粒度へまとめる。Nには静穏を含む。boundsに対する点の内外は要求ごとに計算する。
- 原UTC sourceだけに `annual_quarters` を追加した。`schema:climate-annual-quarters/1`、`date_convention:UTC`、`calendar_definition.version:utc-half-nested-quarters/1`。UTC 1–7 / 8–15 / 16–22 / 23–末日を直接集計し、年ごとの月末/閏年と選択時刻を反映する。48区分はISO週ではない。
- `timebins`は独立ID 0..47、`month/quarter/parent_timebin_id/start_day/end_day_min/end_day_max/n_days_total/n_analyses_expected/label`を持つ。半月からquarterを合成できないので`member_timebin_ids`は付けない。全高度の`annual`と`display_scales`だけを追加し、48区分のspatial行は作らない。
- 旧query grain、旧半月/月/季節、旧月中央値/10–90%帯、気象関心は変更しない。旧半月をquarterから再結合せず、元の計算順を保持する。新raw adapterは `original-utc-wind/2` とし新source IDに結ぶ。旧保存値は再計算・上書きしない。

## 数値・反例

`backend/tests/test_climate_archive.py`、`test_climate_archive_interaction.py`、`test_climate_periods.py` の24試験は成功（33.59秒）。新規8試験は、48区分の全日重複なし/半月への包含、閏年2000と非閏年2100、quarterをqueryへ入れない境界、元値からの独立空間加重計算（全48×2面、全4UTC/UTC00/UTC06+18）、面変更で年間再集計しないこと、風配1回読取、返却値の深い変更、地域/時刻/LRU eviction、source/adapter変更、途中失敗cache非採用を対象とした。

`backend-comparison580.json` はERA5 2024全1,188格子・37面・UTC00の実標本を使う。保存した旧300/250/200 hPa結果と、旧実装の保存コピーによる再計算と、新実装の再計算を比較した。既存annual/spatial、half/month/season、風配、月分位、尺度、母集団の数値はfloatの16進表現まで同一。識別/実装版/新48の枝は一致対象から分けた。

新48×37=1,776行は別コードで原UTC 32,175,792成分を読み、time-major配列の時間平均→scalar fsumの空間加重へ独立に計算した。平均u/v/速さ、R、来向、格子平均速さの最大/範囲、件数を比較し、この対象の最大絶対差は0だった（比較上限1e-11）。これは取得値の再集計確認であり、気象製品の科学精度の検証ではない。

`backend-compatibility580.json`では旧/新のsource descriptorの識別・版・code・annual_grains以外、および既存provenance定義が同じことも確認した。隔離Temp storeで保存した旧実装結果（48なし）を、新source有り/原資料無しの双方で同一に読み、受付済み再送も旧結果へ戻った。新要求の新source結果だけ48を持つ。稼働ユーザーstateの操作ではない。

## 性能と費用

同一PC・同一原資料・同一選択のadapter通常時計（HTTP/SQLite保存/browser描画を除く）。各実装を逐次実行し、各8回の既存母集団への面変更を比べた。OS全体のfilesystem cacheを消す実験ではない。

| 対象 | 旧 | 新 |
|---|---:|---:|
| 既存母集団への面変更8回・中央値 | 5.24394秒 | 0.806074秒 |
| 同上の速度比 | 1 | 6.5055 |
| 新規母集団の初回・各1回 | 7.04788秒 | 13.23964秒 |

profile込みの旧warm17.16秒と通常時計を混同しない。新warmのprofileは`after-250-profile.txt`（約2.21秒）。年間再集計がなくなり、deepcopy/JSON化と選択面spatialが残る。実アプリの同じ面への再訪は永続artifactやFEの6面cacheから返る場合があるため、この8回のadapter反復をユーザーの全操作の速度比へ広げない。

初回は新48の費用で増えた。`_moments`や原標本走査を2回へ増やしたのではなく、同じu/v/sをquarter maskで平均し、1,776地域行×1,188セル=2,109,888セル行をPython辞書/検証/空間加重へ追加した。月分位の別読取は以前からある。quarter専用の配列reducerは将来の候補だが、丸め順・検証境界の再審査が必要であり今回未実装。全操作/全端末の速度保証やドラッグ各frameの追随を主張しない。

## 初回試験環境の失敗を分離

初回Miniforge3にはduckdbがなくcollection失敗。cacheproviderが2つの一時dir名を作った後にsandboxの権限警告を出した。次に既存専用runtimeでsandboxのTemp fixture作成が拒否され22 failed / 2 passed。これらは実装成功票ではない。同じ専用runtimeの承認済みコマンドをsandbox外で実行し、cacheprovider無効/隔離basetempで24 passedとなった。新依存は導入していない。2dirの原警告・生成時刻と親の隔離対象は`backend-test-initial-attempts.json`へ戻る。他の既存pytest一時dirをこの担当では削除しない。

独立critic map_refresh_review は3pathを読み、cacheの所有/出口deepcopy、source guard、旧半月の加算順、quarter直接mask、風配Nの保持に阻害点なしと報告した。coldの意味とアプリの別cacheを速度比へ混ぜない指摘を上へ反映した。親の実UI受入は別票。現在のsource/根拠hashは`backend-review580.json`に束縛する。
