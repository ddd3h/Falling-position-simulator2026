"""Offline final-continuation guard and combined provenance, not real decoding."""
from pathlib import Path
import datetime as dt
import importlib.util
import json
import tempfile
import types
import unittest
from unittest.mock import patch
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
s=importlib.util.spec_from_file_location('resume520final',P/'fetch_jra_window520_resume02.py')
f=importlib.util.module_from_spec(s);s.loader.exec_module(f)


class Final(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=P/'acquisition',prefix='final-test-')
        self.addCleanup(self.temp.cleanup);self.a=Path(self.temp.name);self.run=self.a/'run'

    def clock(self,hour,minute,second):
        class Clock(dt.datetime):
            @classmethod
            def now(cls,tz=None):return dt.datetime(2026,9,29,hour,minute,second,tzinfo=dt.timezone.utc)
        return types.SimpleNamespace(datetime=Clock,timezone=dt.timezone)

    def test_before_not_before_rejects_without_attempt_or_directory(self):
        with patch.object(f,'RUN',self.run),patch.object(f,'A',self.a),patch.object(f,'dt',self.clock(22,47,32)),patch.object(f,'supervise') as call:
            with self.assertRaisesRegex(ValueError,'Not before'):f.execute()
            self.assertEqual(call.call_count,0);self.assertFalse(self.run.exists())

    def test_final_failure_stops_after_one_charges_prior_budget(self):
        with patch.object(f,'RUN',self.run),patch.object(f,'A',self.a),patch.object(f,'dt',self.clock(22,48,0)),patch.object(f,'supervise',return_value=(2,b'',b'',False,False)) as call:
            self.assertEqual(f.execute(),2);self.assertEqual(call.call_count,1)
            r=json.loads((self.run/'receipt.json').read_bytes())
            self.assertEqual(r['responses'][0]['ordinal'],6)
            self.assertEqual(r['cost']['cumulative_budget_charge_bytes'],2437064+2097152)
            self.assertEqual(r['cost']['cumulative_preserved_body_bytes'],209030)
            self.assertFalse((self.a/'combined-receipt520.json').exists())

    def test_six_mock_successes_flat_manifests_outside_current_run(self):
        p=f.load_plan();self.assertEqual([r['ordinal'] for r in p['fields']],list(range(6,12)))
        def fake_transport(command,timeout):
            ordinal=int(command[-2]);r=p['fields'][ordinal-6];out=self.run/f'{ordinal:02d}-{r["variable"]}'
            (out/'response.partial').write_bytes(b'CDF\x01mock')
            f.write_new(out/'worker-result.json',{'status':200,'transport_complete':True,'body_bytes_read':8,'error':None})
            return 0,b'',b'',False,False
        class MockValidator:
            @staticmethod
            def validate_response(*args):return {'status':'passed','note':'mock decoder, not science'}
        with patch.object(f,'RUN',self.run),patch.object(f,'A',self.a),patch.object(f,'dt',self.clock(22,48,0)),patch.object(f,'supervise',side_effect=fake_transport) as call,patch.object(f,'validator',return_value=MockValidator),patch.object(f.time,'sleep') as wait:
            self.assertEqual(f.execute(),0);self.assertEqual(call.call_count,6)
            self.assertEqual([c.args for c in wait.call_args_list],[(10,)]*5)
            c=json.loads((self.a/'combined-receipt520.json').read_bytes())
            self.assertEqual(len(c['successful_fields']),11)
            self.assertEqual(len(c['source_receipts']),3);self.assertEqual(len(c['source_manifests']),3)
            for r in c['source_receipts']+c['source_manifests']:
                data=Path(r['path']).read_bytes();self.assertEqual((len(data),f.sha(data)),(r['bytes'],r['sha256']))
            manifest=json.loads((self.run/'manifest.json').read_bytes())
            self.assertNotIn('combined-receipt520.json',[r['path'] for r in manifest['files']])
            self.assertEqual(c['cost']['cumulative_preserved_body_bytes'],209030+48)
            self.assertEqual(c['cost']['cumulative_budget_charge_bytes'],2437064+48)


if __name__=='__main__':
    with patch('socket.create_connection',side_effect=AssertionError('no network')):
        unittest.main(verbosity=2)
