"""Offline continuation orchestration only. Transport/decoder mocked, no HTTP."""
from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
s=importlib.util.spec_from_file_location('resume520',P/'fetch_jra_window520_resume01.py')
f=importlib.util.module_from_spec(s);s.loader.exec_module(f)


class Resume(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=P/'acquisition',prefix='resume-test-')
        self.addCleanup(self.temp.cleanup);self.run=Path(self.temp.name)/'run'

    def test_plan_only_remaining_eight_and_old_inputs_unchanged(self):
        p=f.load_plan();f.verify_inputs(p)
        self.assertEqual([r['ordinal'] for r in p['fields']],list(range(4,12)))
        self.assertEqual((p['prior_body_bytes'],p['prior_preserved_body_bytes']),(268764,137882))
        self.assertTrue(all('run520-resume01/' in r['raw_relative_path'] for r in p['fields']))

    def test_failure_first_continuation_stops_with_prior_conservative_charge(self):
        with patch.object(f,'RUN',self.run),patch.object(f,'supervise',return_value=(2,b'',b'',False,False)) as call:
            self.assertEqual(f.execute(),2);self.assertEqual(call.call_count,1)
            r=json.loads((self.run/'receipt.json').read_bytes())
            self.assertEqual(r['responses'][0]['ordinal'],4)
            self.assertEqual(r['cost']['cumulative_preserved_body_bytes'],137882)
            self.assertEqual(r['cost']['cumulative_budget_charge_bytes'],268764+131072)
            self.assertEqual(len(r['not_attempted']),7)
            self.assertFalse((self.run/'combined-receipt.json').exists())

    def test_eight_mock_successes_combine_with_exact_original_three(self):
        p=f.load_plan()
        def fake_transport(command,timeout):
            ordinal=int(command[-2]);row=p['fields'][ordinal-4];out=self.run/f'{ordinal:02d}-{row["variable"]}'
            (out/'response.partial').write_bytes(b'CDF\x01mock')
            f.write_new(out/'worker-result.json',{'status':200,'transport_complete':True,'body_bytes_read':8,'error':None})
            return 0,b'',b'',False,False
        class MockValidator:
            @staticmethod
            def validate_response(*args):return {'status':'passed','note':'orchestrator test only; not actual decoding'}
        with patch.object(f,'RUN',self.run),patch.object(f,'supervise',side_effect=fake_transport) as call,patch.object(f,'validator',return_value=MockValidator),patch.object(f.time,'sleep'):
            self.assertEqual(f.execute(),0);self.assertEqual(call.call_count,8)
            c=json.loads((self.run/'combined-receipt.json').read_bytes());self.assertEqual(len(c['field_to_raw']),11)
            for old in p['resume']['reused_successes']:self.assertEqual(c['field_to_raw'][old['variable']],old['raw_path'])
            self.assertEqual(c['cost']['cumulative_preserved_body_bytes'],137882+8*8)
            self.assertEqual(c['cost']['cumulative_budget_charge_bytes'],268764+8*8)


if __name__=='__main__':
    with patch('socket.create_connection',side_effect=AssertionError('no network')):
        unittest.main(verbosity=2)
