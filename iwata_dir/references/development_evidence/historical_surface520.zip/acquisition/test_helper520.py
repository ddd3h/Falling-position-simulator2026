"""Bounded offline adversarial checks. Does not execute fetch, worker, or network."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from scipy.io import netcdf_file

P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
fetch=load('fetch520',P/'fetch_jra_window520.py')
validate=load('validate520',P/'validate_jra_window520.py')
PLAN=fetch.load_plan()


class Offline(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=P/'acquisition',prefix='offline-')
        self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'response.nc'
        self.field=copy.deepcopy(PLAN['fields'][1]) # 2m specific humidity

    def fixture(self,mutation=None):
        f=self.field
        with netcdf_file(self.path,'w') as d:
            for name,n in zip(('time','lat','lon'),f['expected_shape']):
                d.createDimension(name,n);v=d.createVariable(name,'d',(name,));v[:]=PLAN['axes'][name][:n]
                v.units={'time':'hours since 1900-01-01 00:00:00','lat':'degrees_north','lon':'degrees_east'}[name]
                if name=='time':v.calendar='gregorian'
            v=d.createVariable(f['variable'],'f',('time','lat','lon'));v[:]=.003
            v.units=f['unit'];v.data_type='analysis';v.time_step='6-hour';v.group='anl_surf'
            v.level_code=103;v.level_value=2;v.level_units='m'
            v._FillValue=np.float32(9.999e20);v.missing_value=np.float32(9.999e20)
            if mutation:mutation(d,v)

    def check_response(self): return validate.validate_response(self.path,self.field,PLAN,compare_prior=False)

    def test_plan_pins_and_all_caps(self):
        fetch.verify_inputs(PLAN)
        self.assertEqual(PLAN['prior_body_bytes'],30844)
        self.assertEqual(sum(f['max_body_bytes'] for f in PLAN['fields'])+30844,11303036)

    def test_existing_small_T_validates_full_prior_precision(self):
        p=copy.deepcopy(PLAN);f=copy.deepcopy(PLAN['fields'][5]);f['expected_shape']=[3,100,2,2]
        p['axes']['lat']=[35.0259928266149,34.651383346207];p['axes']['lon']=[136.875,137.25]
        result=validate.validate_response(validate.OLD/'model-t-ncss510/response.nc',f,p)
        self.assertEqual([r['compared_values'] for r in result['comparisons']],[800,1200])

    def test_valid_surface(self):
        self.fixture();self.assertEqual(self.check_response()['shape'],[3,20,46])

    def test_negative_or_one_humidity(self):
        for bad in (-.001,1.0):
            with self.subTest(bad=bad):
                self.fixture(lambda d,v:v.__setitem__((0,0,0),bad))
                with self.assertRaisesRegex(ValueError,'Specific humidity'):self.check_response()

    def test_missing_nan_rejected(self):
        for bad in (np.float32(9.999e20),np.nan):
            with self.subTest(bad=str(bad)):
                self.fixture(lambda d,v:v.__setitem__((0,0,0),bad))
                with self.assertRaises(ValueError):self.check_response()

    def test_coordinate_time_units_height_mutations(self):
        mutations=[lambda d,v:d.variables['lat'].__setitem__(0,38.),
            lambda d,v:d.variables['time'].__setitem__(2,1086978.),
            lambda d,v:setattr(v,'units','percent'),lambda d,v:setattr(v,'level_value',10),
            lambda d,v:setattr(v,'scale_factor',2.)]
        for mutate in mutations:
            self.fixture(mutate)
            with self.assertRaises(ValueError):self.check_response()

    def test_static_epoch_is_not_2024(self):
        self.field=copy.deepcopy(PLAN['fields'][-1])
        def constant(d,v):
            v.data_type='constant';v.time_step='none';v.group='tl479_surf';v.level_code=1
        self.fixture(constant)
        with self.assertRaisesRegex(ValueError,'coordinate mismatch: time'):self.check_response()
        self.fixture(lambda d,v:(constant(d,v),d.variables['time'].__setitem__(0,417816.)))
        self.assertEqual(self.check_response()['time_utc'],['1947-09-01T00:00:00Z'])

    def test_cap_does_not_overread_and_exactcap_not_complete(self):
        for body,cap,complete in [(b'ab',3,True),(b'abc',3,False),(b'abcde',3,False)]:
            source=io.BytesIO(body);target=io.BytesIO()
            count,done=fetch.read_bounded(source,target,cap)
            self.assertEqual(target.getvalue(),body[:cap]);self.assertLessEqual(source.tell(),cap)
            self.assertEqual(done,complete)

    def test_redirect_not_followed(self):
        self.assertIsNone(fetch.NoRedirect().redirect_request(None,None,302,'x',{},'https://example.com/'))

    def test_first_response_failure_stops_and_existing_run_refused(self):
        run=Path(self.temp.name)/'run'
        def failed(command,timeout):return 2,b'',b'',False,False
        with patch.object(fetch,'RUN',run),patch.object(fetch,'supervise',side_effect=failed) as runner:
            self.assertEqual(fetch.execute(),2);self.assertEqual(runner.call_count,1)
            result=json.loads((run/'receipt.json').read_bytes())
            self.assertEqual(len(result['not_attempted']),10)
            self.assertEqual(result['cost']['cumulative_preserved_body_bytes'],30844)
            self.assertEqual(result['cost']['cumulative_budget_charge_bytes'],30844+131072)
            with self.assertRaises(FileExistsError):fetch.execute()


if __name__=='__main__':
    # All socket entrypoints are blocked even if an accidental call escapes a stub.
    with patch('socket.create_connection',side_effect=AssertionError('No network in offline checks')):
        unittest.main(verbosity=2)
