# 0.52 実過去一窓の取得候補（未実行）

目的は、同じJRA-3Q製品・格子・時刻の表層と全モデル面を揃え、地上接続の比較と費用評価へ入力することです。取得成功を地上完飛行や科学的精度の受入にはしません。

`fetch_jra_window520.py` は通常起動・`--plan`で外部通信を行いません。実行はrootの全文確認後の `--execute` のみです。出力は `acquisition/run520` 固定で、既存フォルダがあれば拒否します。失敗後の自動再試行・URL代替・範囲拡大・認証・redirect・proxyはありません。

各モデル面2MiB、表層と定数各128KiB。11応答の全上限と既取得30,844bytesの和は11,303,036bytesで累積16MiB以内です。各要求は別Python processを60秒監視し、期限で停止します。HTTP55秒socket timeoutも設定します。1秒の直列間隔は小さな礼儀的待機であり、データ時間刻みや配布側の公式制限ではありません。応答保存量・経過時間・復号検査時間は分けます。失敗時に読取量を確定できなければ、その応答cap全額を予算引当てし、保全できたraw量を別に残します。wire/TLS/header/server処理量は未測定です。

応答ごとにCDF1/CDF2、3UTC、100面、20×46、次元順、厳密なnative座標、単位/analysis種別/6時間刻み、2m/10m診断高、有限値・欠測、T/p正値、q∈[0,1)を検査し、失敗なら後続を止めます。静的GPは1947-09-01 00 UTCの1時刻とm²/s²のまま保存します。JRAの古い2×2原値（モデル5量/SP/GP）、小q12値、小NCSS T1200値を返却Float32へ戻して照合します。新しい多数の格子値の真値や精度はそれでは証明できません。

検証票にfield→rawpath、全返却座標とその順序、観測属性・missing sentinel、比較母数を残します。係数は今回要求しません。後続rootの正規化で、既存固定A/Bの出典と今回応答にA/Bが同梱されないことを明記する必要があります。保存bundle/面再構成/飛行は本helperに含めません。

無通信10反例（実小T再読/人工surface/不正q・欠測・時刻・座標・単位・診断高・packing/cap/redirect/初回失敗停止/既存run拒否）成功。最初の同試験はTemp権限で失敗し、同内容を許可された環境で再試行しました。原失敗ログを保持。新配布応答は未取得です。

## 固定要求

- 01 `tmp2m-hgt-an-gauss` / surface / K / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_surf/202401/jra3q.anl_surf.0_0_0.tmp2m-hgt-an-gauss.2024010100_2024013118.nc?var=tmp2m-hgt-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 02 `spfh2m-hgt-an-gauss` / surface / kg kg-1 / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_surf/202401/jra3q.anl_surf.0_1_0.spfh2m-hgt-an-gauss.2024010100_2024013118.nc?var=spfh2m-hgt-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 03 `ugrd10m-hgt-an-gauss` / surface / m s-1 / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_surf/202401/jra3q.anl_surf.0_2_2.ugrd10m-hgt-an-gauss.2024010100_2024013118.nc?var=ugrd10m-hgt-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 04 `vgrd10m-hgt-an-gauss` / surface / m s-1 / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_surf/202401/jra3q.anl_surf.0_2_3.vgrd10m-hgt-an-gauss.2024010100_2024013118.nc?var=vgrd10m-hgt-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 05 `pres-sfc-an-gauss` / surface / Pa / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_surf/202401/jra3q.anl_surf.0_3_0.pres-sfc-an-gauss.2024010100_2024013118.nc?var=pres-sfc-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 06 `tmp-hyb-an-gauss` / model / K / cap 2,097,152 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_mdl/202401/jra3q.anl_mdl.0_0_0.tmp-hyb-an-gauss.2024010100_2024010518.nc?var=tmp-hyb-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 07 `spfh-hyb-an-gauss` / model / kg kg-1 / cap 2,097,152 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_mdl/202401/jra3q.anl_mdl.0_1_0.spfh-hyb-an-gauss.2024010100_2024010518.nc?var=spfh-hyb-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 08 `ugrd-hyb-an-gauss` / model / m s-1 / cap 2,097,152 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_mdl/202401/jra3q.anl_mdl.0_2_2.ugrd-hyb-an-gauss.2024010100_2024010518.nc?var=ugrd-hyb-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 09 `vgrd-hyb-an-gauss` / model / m s-1 / cap 2,097,152 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_mdl/202401/jra3q.anl_mdl.0_2_3.vgrd-hyb-an-gauss.2024010100_2024010518.nc?var=vgrd-hyb-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 10 `hgt-hyb-an-gauss` / model / gpm / cap 2,097,152 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/anl_mdl/202401/jra3q.anl_mdl.0_3_5.hgt-hyb-an-gauss.2024010100_2024010518.nc?var=hgt-hyb-an-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=2024-01-01T00%3A00%3A00Z&time_end=2024-01-01T12%3A00%3A00Z&accept=netCDF&addLatLon=true
- 11 `gp-sfc-cn-gauss` / constant / m2 s-2 / cap 131,072 bytes
  - https://tds.gdex.ucar.edu/thredds/ncss/grid/files/g/d640000/tl479_surf/194709/jra3q.tl479_surf.0_3_4.gp-sfc-cn-gauss.1947090100_1947090100.nc?var=gp-sfc-cn-gauss&north=38.3974780173953&south=31.2798979077148&west=128.625&east=145.5&horizStride=1&time_start=1947-09-01T00%3A00%3A00Z&time_end=1947-09-01T00%3A00%3A00Z&accept=netCDF&addLatLon=true

## 実行予定（root確認前は実行しない）

```powershell
& "C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe" -X utf8 -B "C:/Users/genia/AppData/Local/Temp/balloon-surface-520/fetch_jra_window520.py" --execute
```
