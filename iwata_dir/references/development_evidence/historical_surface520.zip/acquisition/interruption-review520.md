# 取得停止の有限診断（追加通信なし）

| run/変数 | HTTP | worker秒 | 監視込み秒 | body bytes |
|---|---:|---:|---:|---:|
| run520/tmp2m-hgt-an-gauss | 200 | 4.235 | 4.407 | 35608 |
| run520/spfh2m-hgt-an-gauss | 200 | 4.313 | 4.453 | 35616 |
| run520/ugrd10m-hgt-an-gauss | 200 | 6.375 | 6.516 | 35624 |
| run520/vgrd10m-hgt-an-gauss | 503 | 0.531 | 0.703 | 190 |
| run520-resume01/vgrd10m-hgt-an-gauss | 200 | 2.203 | 2.375 | 35624 |
| run520-resume01/pres-sfc-an-gauss | 200 | 9.125 | 9.313 | 35524 |
| run520-resume01/tmp-hyb-an-gauss | 未受領 | 21.359 | 21.547 | 0 |

- 成功は表層5量だけ。モデル面の広域応答はまだ1件も成功していない。
- 503はnginxの190bytes完全HTML。原因やrate limitは不明。Retry-Afterは保存対象外だったため未観測。
- model TのWinError10060はopener.open内で発生し、HTTPヘッダ/本文未受領。DNS/TCP/TLS段階は未計測で特定できない。60秒監視によるkillではない。
- 直列間隔は約1.18〜1.21秒、503から明示続行まで222.809秒。間隔が失敗原因とは判定できない。
- 実保全209,030bytesと予算引当2,437,064bytesを区別する。前者はwire全量ではない。後者には既知の190bytes503にも128KiBを引き当てた保守性がある。
- 原receipt/raw/manifestを変更していない。新しいbatchや次要求は作成・実行せずroot判断待ち。
- 全11が後に揃う場合、combinedをrun外へ置き、全attemptのreceipt/manifestをflat参照すればhash循環を避けられる。
