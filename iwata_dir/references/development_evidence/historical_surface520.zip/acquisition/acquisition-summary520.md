# 実過去一窓の取得結果（0.52入力）

全11量を固定rawとして保全した。正規化・地上再構成・飛行は本票の受入範囲ではない。

|量|shape|raw bytes|単位|
|---|---|---:|---|
|tmp2m-hgt-an-gauss|3×20×46|35,608|K|
|spfh2m-hgt-an-gauss|3×20×46|35,616|kg kg-1|
|ugrd10m-hgt-an-gauss|3×20×46|35,624|m s-1|
|vgrd10m-hgt-an-gauss|3×20×46|35,624|m s-1|
|pres-sfc-an-gauss|3×20×46|35,524|Pa|
|tmp-hyb-an-gauss|3×100×20×46|1,129,748|K|
|spfh-hyb-an-gauss|3×100×20×46|1,129,768|kg kg-1|
|ugrd-hyb-an-gauss|3×100×20×46|1,129,768|m s-1|
|vgrd-hyb-an-gauss|3×100×20×46|1,129,768|m s-1|
|hgt-hyb-an-gauss|3×100×20×46|1,129,748|gpm|
|gp-sfc-cn-gauss|1×20×46|27,040|m2 s-2|

成功11本文 5,853,836 bytes。失敗503 190bytesと先行q/T 30,844bytesも含め保全 5,884,870 bytes。保守的予算引当 8,112,904 /16,777,216bytes。引当額は通信実測ではない。

3attemptのactive wall合計 133.266秒（規定待機55秒や検査/保存も含む）。初回から最終完了まで 710.146秒には人間相当のレビュー・300秒以上待機も含み、通常取得性能へ一般化できない。

初回は3表層成功後503。明示続行01は残表層2量成功後、modelTのHTTP前10060。原票を保ち成功5を再利用し、最終続行02は6量すべて成功した。13回のopener呼出しであり、自動retryは0。

各量の返却座標・属性・fill・旧subset比較はcombinedのfield_to_validationから辿れる。GPは1947-09-01静的1時刻のまま、モデル/診断表層は2024-01-01 00/06/12 UTC。モデル100面とnative20×46は全量一致。係数は今回追加取得していない。

全11raw/validationと全3receipt/manifestを最終再読照合。既存R/Git/サービスへの変更は行わず、combinedを正規化担当へ引き渡した。
