"""Independent known linear columns and failure cases for external A/B experiment."""
import copy
import unittest
from balloon_sim.environment.fields import WeatherError, FIELD_NAMES, geopotential_to_geometric as to_z
from balloon_sim.environment.model_levels import ModelLevelField
from surface_prototype import SurfaceBridgeField

TIMES = ["2024-01-01T00:00:00+00:00", "2024-01-01T06:00:00+00:00"]
MID = "2024-01-01T03:00:00+00:00"
JOIN = {name: 2 if "wind" in name else 1 for name in FIELD_NAMES}


def fixture():
    ground = [[[0.0, 200.0]], [[0.0, 200.0]]]
    h = [[[[g+dz for g in [0.0, 200.0]]] for dz in [8., 28., 1000.]] for t in range(2)]
    p = [[[[100000.-10*z for z in row] for row in level] for level in time] for time in h]
    field = {}
    for name, f in {
        "temperature_k": lambda z,t: 280.-.006*z,
        "specific_humidity_kg_kg": lambda z,t: .004,
        "eastward_wind_m_s": lambda z,t: 2+.01*z+t,
        "northward_wind_m_s": lambda z,t: -1+.005*z,
    }.items():
        field[name] = [[[[f(z,t) for z in row] for row in level] for level in h[t]] for t in range(2)]
    source = ModelLevelField(times=TIMES, latitudes=[0.0], longitudes=[0.0, 1.0], levels=[1,2,3],
        heights=h, pressures=p, fields=field, surface_pressure=[[[100000.,98000.]]]*2,
        surface_height=ground, metadata={})
    surface = {"temperature_2m_k": [[[279.988,278.788]]]*2,
               "specific_humidity_2m_kg_kg": [[[.004,.004]]]*2,
               "eastward_wind_10m_m_s": [[[2.1,4.1]],[[3.1,5.1]]],
               "northward_wind_10m_m_s": [[[-.95,.05]]]*2}
    return source, surface


class SurfaceComparison(unittest.TestCase):
    def setUp(self): self.source,self.surface=fixture()
    def wrap(self,mode):return SurfaceBridgeField(self.source,self.surface,JOIN,mode)
    def code(self,code,fn):
        with self.assertRaises(WeatherError) as c:fn()
        self.assertEqual(c.exception.code,code)

    def test_ab_strict_agree_for_linear_upper_field(self):
        expected={"pressure_pa":95000.,"temperature_k":277.,"specific_humidity_kg_kg":.004,
                  "eastward_wind_m_s":7.5,"northward_wind_m_s":1.5}
        for f in [self.source,self.wrap("column_surface_extension"),self.wrap("native_horizontal_first")]:
            actual=f.sample(MID,0.,.5,to_z(500.))
            for name,value in expected.items():self.assertAlmostEqual(actual[name],value,places=9)

    def test_native_point_kept_above_fixed_joins(self):
        for mode in ("column_surface_extension","native_horizontal_first"):
            actual=self.wrap(mode).sample(TIMES[0],0.,0.,to_z(28.))
            self.assertAlmostEqual(actual['eastward_wind_m_s'],2.28)
            self.assertAlmostEqual(actual['pressure_pa'],99720.)

    def test_ground_bridge_uses_surface_and_reports_extension(self):
        a=self.wrap("column_surface_extension").sample(TIMES[0],0.,.5,to_z(100.))
        b=self.wrap("native_horizontal_first").sample(TIMES[0],0.,.5,to_z(100.))
        self.assertAlmostEqual(b['eastward_wind_m_s'],3.1)
        self.assertAlmostEqual(b['pressure_pa'],99000.)
        self.assertAlmostEqual(a['eastward_wind_m_s'],3.55)
        self.assertGreater(a['terrain_stencil_clamp_depth_m'],100.)
        self.assertEqual(b['terrain_stencil_clamp_depth_m'],0)
        self.assertIn('10m_analysis_held_below_anchor',b['quality'])

    def test_stops_below_surface_and_outside(self):
        for mode in ("column_surface_extension","native_horizontal_first"):
            f=self.wrap(mode)
            self.code('BELOW_MODEL_SURFACE',lambda:f.sample(MID,0.,.5,to_z(99.)))
            self.code('TIME_OUT_OF_RANGE',lambda:f.sample('2024-01-02T00:00:00Z',0.,.5,to_z(500.)))
            self.code('LONGITUDE_OUT_OF_RANGE',lambda:f.sample(MID,0.,1.1,to_z(500.)))
            self.code('HEIGHT_OUT_OF_RANGE',lambda:f.sample(MID,0.,.5,to_z(1300.)))

    def test_surface_missing_never_renormalized(self):
        self.surface['eastward_wind_10m_m_s'][0][0][1]=None
        for mode in ("column_surface_extension","native_horizontal_first"):
            f=self.wrap(mode)
            self.code('MISSING_DATA',lambda:f.sample(TIMES[0],0.,.5,to_z(100.)))
            # Missing diagnostic is not consumed above the fixed bridge.
            self.assertAlmostEqual(f.sample(TIMES[0],0.,.5,to_z(500.))['eastward_wind_m_s'],7.)

    def test_bad_fixed_join_is_rejected(self):
        joins=dict(JOIN,eastward_wind_m_s=1)
        self.code('SURFACE_JOIN_UNSUPPORTED',lambda:SurfaceBridgeField(
            self.source,self.surface,joins,'native_horizontal_first'))

    def test_both_sides_of_diagnostic_anchor_and_fixed_join(self):
        f=self.wrap('native_horizontal_first')
        # At an original zero-terrain node the 10m anchor has unambiguous units.
        for center in (10.,to_z(28.)):
            left=f.sample(TIMES[0],0.,0.,center-1e-6)['eastward_wind_m_s']
            right=f.sample(TIMES[0],0.,0.,center+1e-6)['eastward_wind_m_s']
            self.assertLess(abs(right-left),3e-8)
        # The lowest native wind is deliberately not reconstructed at its node.
        v=f.sample(TIMES[0],0.,0.,to_z(8.))['eastward_wind_m_s']
        self.assertAlmostEqual(v,2.1)
        self.assertNotEqual(v,self.source.fields['eastward_wind_m_s'][0][0][0][0])

    def test_unrequested_surface_humidity_not_needed(self):
        self.surface['specific_humidity_2m_kg_kg'][0][0][1]=None
        f=self.wrap('native_horizontal_first')
        v=f.sample(TIMES[0],0.,.5,to_z(100.),fields=['eastward_wind_m_s'])
        self.assertAlmostEqual(v['eastward_wind_m_s'],3.1)
        self.code('MISSING_DATA',lambda:f.sample(TIMES[0],0.,.5,to_z(100.)))

    def test_flags_and_source_immutability(self):
        before=copy.deepcopy(self.source.__dict__)
        f=self.wrap('native_horizontal_first');f.sample(MID,0.,.5,to_z(100.))
        self.assertEqual(self.source.__dict__,before)
        self.assertEqual(f.statistics['calls'],1)
        self.assertEqual(f.statistics['bridge_calls'],1)

    def test_invalid_positive_diagnostic_is_not_hidden_by_mean(self):
        self.surface['specific_humidity_2m_kg_kg'][0][0]=[-.1,.108]
        for mode,lon,height in (('column_surface_extension',0.,0.),
                                ('native_horizontal_first',.5,100.)):
            f=self.wrap(mode)
            self.code('INVALID_FIELD_VALUE',lambda:f.sample(TIMES[0],0.,lon,to_z(height)))
            # Unrequested q and unused surface q above the bridge are separate.
            f.sample(TIMES[0],0.,lon,to_z(height),fields=['eastward_wind_m_s'])
            f.sample(TIMES[0],0.,.5,to_z(500.))

    def test_fixed_join_is_checked_at_unused_time_and_location_before_query(self):
        data=copy.deepcopy(self.source.__dict__)
        heights=[[list(map(list,level)) for level in time] for time in self.source.heights]
        heights[1][1][0][1]=209.  # This original column's 10m anchor is above join2.
        self.source.heights=tuple(tuple(tuple(tuple(row) for row in level) for level in time) for time in heights)
        try:
            self.code('SURFACE_JOIN_UNSUPPORTED',lambda:self.wrap('native_horizontal_first'))
        finally:
            self.source.__dict__.clear();self.source.__dict__.update(data)

    def test_missing_join_geometry_is_not_inferred_from_other_columns(self):
        data=copy.deepcopy(self.source.__dict__)
        heights=[[list(map(list,level)) for level in time] for time in self.source.heights]
        heights[1][1][0][1]=None
        self.source.heights=tuple(tuple(tuple(tuple(row) for row in level) for level in time) for time in heights)
        try:
            self.code('MISSING_HEIGHT_SUPPORT',lambda:self.wrap('native_horizontal_first'))
        finally:
            self.source.__dict__.clear();self.source.__dict__.update(data)

    def test_attempted_and_successful_queries_are_separate(self):
        f=self.wrap('native_horizontal_first')
        self.code('TIME_OUT_OF_RANGE',lambda:f.sample('2024-01-02T00:00:00Z',0.,.5,to_z(500.)))
        self.code('BELOW_MODEL_SURFACE',lambda:f.sample(MID,0.,.5,to_z(99.)))
        f.sample(MID,0.,.5,to_z(500.))
        self.assertEqual(f.statistics['attempted_calls'],3)
        self.assertEqual(f.statistics['successful_calls'],1)
        self.assertEqual(f.statistics['calls'],1)
        self.assertEqual(f.statistics['failed_calls'],2)


if __name__=='__main__':unittest.main(verbosity=2)
