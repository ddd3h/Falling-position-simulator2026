# 0.52 一つの実過去窓と地上接続の証拠

この束は、JRA-3Qの一窓を取得・保存し、旧strict、比較用A/B、現役の明示Bを比較した有限記録です。元応答・入力・結果・失敗を原bytesで保持します。科学的精度、保存則、実地形への着地精度、任意地域の成功、多年の季節MCや過去場取得画面の完成を示すものではありません。

## 読む順序

1. `design-intent520.md`、`surface-research/`、`analysis-review/decision-review520.md` で用途、一次根拠、設計近似、未証明の範囲を読む。地上解析の2mT/q・10m風を直接観測や最下モデル面と取り違えない。
2. `acquisition/combined-receipt520.json` から3試行のreceipt/manifestと、全11量のraw・validationをたどる。最初の10mv HTTP503本文190 bytes、次のmodel T接続失敗は各試行に残る。成功11量のみに書き換えず、保存量・予算・通信状態の不確かさを取得要約とともに読む。`request.json` は原URLを保持する。再取得はこのZIPの再閲覧に必要ない。
3. `normalization/run520/receipt.json` はraw指紋、緯度整列、Float32保持、GP/g0変換、係数原本、時間とWindowsメモリの測定範囲を記す。strictとsurface診断の2 gzipを収録し、原地上GPの1947識別時刻を解析有効UTCと混ぜない。元のmetadataを維持している。
4. `model-prototype/` と `surface_prototype.py`、試験原ログ、`flights/{strict-step10,A-step10,B-step10,B-step5}` を読む。旧prototype失敗と修復前ソースは比較記録で、現役policyへ自動適用するものではない。各飛行はconfig/result/receiptを収録する。時間、プロセス高水位メモリ、問い合わせ計数の測定区間は各票へ戻る。
5. `runtime-implementation520.json`、新旧試験XML・原ログ、`runtime-fixture520/receipt.json` と `runtime-replay520.json`、2つの `runtime-*-flight520` を読む。現役CLIの入力/結果/来歴/HTML/CSV/GeoJSON/manifestを全て保全する。現役Bとprototype Bの数値一致は、品質名称とconfig説明の差を除いた比較であり、全JSON同値ではない。06 UTCを跨ぐ別入力も、元のUTCと時刻境界の意味を保つ有限な行程である。
6. `review/index.html` はこの比較の図をまとめる保存ページ。隣の `plotly.min.js` と `PLOTLY_LICENSE.txt` を同じ配置にする。Plotlyは図を読むための同梱配布物で、Python/Node実行環境一式ではない。ページの軽微な修正前の観察hashは `runtime-replay520.json` に残し、梱包時点のhashはmanifestで別に固定する。両者が異なれば、そのページを古い観察と同一視しない。

## 現役の再実行入口

private repoの、この束の `source-references.json` と同じsourceを使います。`references/flight_fixture/jra3q-weather.json.gz` と `examples/jra3q-ground-flight.json` はrepoに登録した実体を参照し、同じ大きな結合bundleはZIPへ重複収録しません。両指紋を `runtime-fixture520/receipt.json` と照合します。原物の代替がhashだけになる構成ではなく、原11応答と正規化pairはこの束にあり、結合bundleと現役sourceは同じ版のrepoで保存します。

repoのCOMMANDS C-11に従い、新しい出力先を作って `python -B -m balloon_sim inspect references/flight_fixture/jra3q-weather.json.gz`、続いて `python -B -m balloon_sim simulate examples/jra3q-ground-flight.json --weather references/flight_fixture/jra3q-weather.json.gz --output <新規パス>` を使います。記録済み出力は上書きしません。必要なPython/数値依存はその版のBUILD/COMMANDSへ戻り、このZIPだけで環境が揃うとは説明しません。保存場からの計算には再取得・認証・NetCDF復号は不要です。

## 比較実験を再実行する境界

外側helperは元機械の絶対repoパス、P520配置、WindowsメモリAPI、固定した旧C2のsource/原資料を参照するものがあります。`model-prototype/` の早期試験と後の実窓比較は同一段階ではなく、各receiptのsource指紋・元入力を優先します。`compare_flights520.py` 等は原出力ディレクトリで再実行せず、別の作業コピーへ必要な配置を揃え、移植したパスとソース差を新しい記録に残してください。元票やhelperを再現の都合で書き換えません。

基準は0.51 C2 `f94027cec2ff56b732af7bd11b2df26bdd9513a5`。原係数を含む `references/jra3q_model_fixture/source_bundle.json` と旧固定decoderはrepoの既存実体で、正規化票がそのSHAを示します。以前のP510小取得や一次資料の保存場所も原票内の参照として保持します。これらを含む全過去環境・basis-repo全体をこのZIPへ重複複製しないため、portableな独立一式ではありません。

## 収録の固定と限界

`package-plan.json` が明示allowlist、梱包直前のbytes/hash、用途群、参照するrepo実体を固定し、別のroot読解票がそのplan/helper SHAへ結び付きます。`package-manifest.json` は自身以外の全memberを記録し、ZIP外のreceiptがmanifest自身も含む全memberを全byte読戻し・CRC照合します。原gzipを解凍再圧縮して置換しません。秘密値の検査は既知パターンによる有限走査で、全種類の秘密の不存在を証明するものではありません。稼働DB・キー・ブラウザ状態・Python/Node依存全体は収録対象外です。

この束の構造索引は外側候補としての時点票です。後続の最終ガイド出版、管理確認印、Git C1/C2/PR保存票はS36や別の正本記録に置き、未来の成功を先に記したり、このZIP自身の保存結果を循環収録したりしません。
