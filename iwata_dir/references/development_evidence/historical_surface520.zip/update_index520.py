"""External 0.52 structural candidate. Does not write repository or review stamps."""
from pathlib import Path
import ast, copy, datetime as dt, difflib, hashlib, json

P = Path(__file__).resolve().parent
R = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
B = P / 'basis-repo'
BASE = 'f94027cec2ff56b732af7bd11b2df26bdd9513a5'
MAIN = '4e3e4db0d047af9479bcd68bfc2553eeb71efcc9'
rd = lambda p: json.loads(p.read_text('utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
name = 'docs/IMPLEMENTATION_INDEX.json'
before = sha(R / name)
basis = rd(P / 'basis520.json')
assert basis['head'] == BASE and basis['main'] == MAIN
assert before == sha(B / name) == basis['files'][name], 'index differs from fixed C2'
base = rd(B / name)
j = copy.deepcopy(base)

# Reuse only the reviewed AST/lexical extraction block, not any 0.49 publication,
# frontend, metadata or acceptance logic. The same block was used by 0.51.
old_helper = P.parent / 'balloon-operational-490/update_index490.py'
old = old_helper.read_text('utf-8')
part = old[old.index('py_paths='):old.index('# Existing scientific APIs')]
part = part.replace("extraction_note='0.49 Python", "extraction_note='0.52 Python").replace("changed_in='0.49.0'", "changed_in='0.52.0'")
exec(compile(part, 'bounded-python-ast-extraction520', 'exec'))
expected = {'balloon_sim/environment/model_surface.py',
            'balloon_sim/environment/jra3q.py', 'balloon_sim/environment/storage.py'}
assert changed == expected, ('unexpected runtime change', sorted(changed))
assert signature_changes == [], 'existing API signature changed'
assert set(parsed) - set(old_modules) == {'balloon_sim/environment/model_surface.py'}

roles = {
    'balloon_sim/environment/model_surface.py': (
        '検証済みモデル面場を保持し、明示policyの原UTC別仮想列・地上接続と高度照会を行う製品非依存の再構成',
        'active_opt_in_surface_reconstruction', 'WEATHER-SURFACE'),
    'balloon_sim/environment/jra3q.py': (
        '保存JRAの製品・原UTC・鉛直座標を検証し、旧strictまたは明示した地上接続の場へ束縛する',
        'active_saved_product_binding', 'WEATHER-MODEL'),
}
for row in j['structure']['physical_modules']:
    if row['path'] in roles:
        purpose, role, anchor = roles[row['path']]
        row.update(purpose=purpose, current_role=role, structure_anchor=anchor)
        for node in parsed[row['path']].body:
            if isinstance(node, ast.ClassDef):
                sub = next(n for n in row['tree'].get('children', []) if n['name'] == node.name)
                sub['bases'] = [ast.unparse(b) for b in node.bases]
                if node.name in {'Jra3qSurfaceField', 'ModelSurfaceField'}:
                    sub['structure_anchor'] = 'WEATHER-SURFACE'

load = next(e for e in j['entries'] if e['id'] == 'API-WEATHER-load_weather')
load.update(purpose='保存JSON/gzipを厳密読込し、schemaに応じて気圧面場・JRA strict・明示的なJRA地上接続場を構築する',
            changed_in='0.52.0')
load['additional_test_paths'] = list(dict.fromkeys(load.get('additional_test_paths', []) + ['tests/test_jra3q_surface_field.py']))

def definition(path, symbol):
    node = parsed.get(path)
    if node is None:
        node = ast.parse((R / path).read_text('utf-8'))
    for item in symbol.split('.'):
        node = next(n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.name == item)
    return node

new_api = [
    ('API-WEATHER-ModelSurfaceField-sample', 'balloon_sim/environment/model_surface.py', 'ModelSurfaceField.sample',
     '固定joinを使う原UTC別の仮想列から、要求量・品質・補間地形を返す明示的な地上再構成の照会'),
    ('API-WEATHER-ModelSurfaceField-ground_altitude', 'balloon_sim/environment/model_surface.py', 'ModelSurfaceField.ground_altitude',
     '保持したstrict場の地形APIへ委譲して同じモデル地形を返す'),
    ('API-WEATHER-Jra3qSurfaceField-init', 'balloon_sim/environment/jra3q.py', 'Jra3qSurfaceField.__init__',
     '新schemaと明示policy・地上解析配列を検証し、元JRA strict場を構築してModelSurfaceFieldへ渡す'),
]
for identity, path, symbol, purpose in new_api:
    j['entries'].append(dict(
        id=identity, path=path, symbol=symbol, signature=ast.unparse(definition(path, symbol).args), purpose=purpose,
        theory_or_structure_anchor='WEATHER-SURFACE', test_path='tests/test_jra3q_surface_field.py',
        introduced_in='0.52.0', changed_in='0.52.0', reviewed_in=None, lifecycle='active',
        next_review='保存schema・policy・固定join・要求量・支持・順序・元場への委譲を変更するときに独立期待値と旧strict経路を点検',
        structure_symbol_id=module_of(path) + '.' + symbol, structure_anchor='WEATHER-SURFACE'))

test_path = 'tests/test_jra3q_surface_field.py'
assert not any(r['path'] == test_path for r in j['structure']['supporting_files'])
node = ast.parse((R / test_path).read_text('utf-8'))
top = tree(node, module_of(test_path))
top['end_line'] = len((R / test_path).read_text('utf-8').splitlines())
j['structure']['supporting_files'].append(dict(
    path=test_path, classification='active_regression_test',
    interpretation='仮想列の独立期待値・原UTC順序・固定join・原値欠測/不正・上端と新保存dispatchを照合し、旧strictを保つ有限試験',
    targets=['balloon_sim/environment/model_surface.py', 'balloon_sim/environment/jra3q.py', 'balloon_sim/environment/storage.py'],
    source_sha256=sha(R / test_path), tree=top,
    test_method_definitions=sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in ast.walk(node)),
    ast_imports=[ast.unparse(n) for n in ast.walk(node) if isinstance(n, (ast.Import, ast.ImportFrom))],
    lifecycle_in_contract='active', retire_or_reconsider_when='地上再構成または保存bindingを変更するときに独立の数値・拒否・旧経路反例を再評価',
    structure_anchor='WEATHER-SURFACE',
    extraction_note='0.52 ASTの所在・定義・import。試験成功数や科学精度の認定ではない。旧fixture decoderは試験入力準備だけに使いruntimeへ入れない。'))

manual = j['structure']['manual_interpretation']
older = base['structure']['manual_interpretation']
weather = next(x for x in manual['duck_types_and_callbacks'] if x['id'] == 'weather-object')
weather['providers'].append('balloon_sim.environment.jra3q.Jra3qSurfaceField')
manual['duck_types_and_callbacks'].append(dict(
    id='jra-surface-field-inheritance', caller='balloon_sim.environment.jra3q.Jra3qSurfaceField.__init__',
    provider='balloon_sim.environment.model_surface.ModelSurfaceField', kind='manual_review_inheritance_binding',
    methods=['Jra3qModelField(strict bundle view)', 'super().__init__(validated source, diagnostics, fixed joins)',
             'inherited sample(...)', 'inherited ground_altitude(...)'],
    limits='製品bindingが旧strict場を構築してから再構成基底へ渡す。旧Jra3qModelFieldを継承する関係ではない。新schemaを明示した入力だけがこの枝へ入る。'))
manual['duck_types_and_callbacks'].append(dict(
    id='model-surface-source-composition', caller='balloon_sim.environment.model_surface.ModelSurfaceField',
    provider='balloon_sim.environment.model_levels.ModelLevelField', kind='manual_review_composition_binding',
    methods=['source._support(...) / source._ground(...) / source._check_value(...)',
             'source.ground_altitude(...)', 'source times / native arrays / surface / metadata'],
    limits='sourceは保持する検証済み元列場。sampleのB数値をsource.sampleへ委譲しない。__getattr__の動的委譲やsuper()は字句call graphで全解決したとはしない。'))
manual['data_flows'].append(dict(
    source_version='0.52.0',
    **{'from': '明示policyを持つ保存JRAモデル面・地上解析bundle',
       'through': ['balloon_sim.environment.storage.load_weather schema dispatch',
                   'balloon_sim.environment.jra3q.Jra3qSurfaceField',
                   'Jra3qModelField validation and native field retention',
                   'ModelSurfaceField reconstruction / source ground_altitude',
                   'balloon_sim.flight.trajectory.simulate'],
       'to': '既存の飛行記録と共通結果出力・気象metadata保存',
       'boundary': '旧strictとGFSのdispatchを保持。外側の取得/正規化/比較helperはruntime依存へ入れない。地上接続だけでなく上空の水平・鉛直順序も異なる明示policyで、科学精度・保存性・汎用JRA取得UI・多年MCの完成を意味しない。'}))

j['version'] = '0.52.0'
j['structure']['extraction_limits'].append(
    '0.52はmodel_surface新module、jra3q/storageの変更ASTと新試験だけを反映。旧strictと旧公開APIのreviewed_in/public reexport、未変更backend/frontend/3Dと旧支持票を保持。包含されたsourceへの動的委譲・継承は手動解釈に分ける。数式/実験値はTHEORY/S36へ戻し、この索引を実行・科学精度・過去場UIの受入にしない。')
j['extraction']['surface_model_field'] = dict(
    basis_commit=BASE, basis_index_sha256=before,
    method='Changed Python AST/lexical calls; new test AST; separately labeled inheritance/composition and loader/flight binding',
    generated_by='P520/update_index520.py', self_hash_excluded=True,
    reused_ast_extractor_source_sha256=sha(old_helper),
    reused_ast_block_sha256=hashlib.sha256(part.encode()).hexdigest(),
    status='candidate-structural-correspondence-not-acceptance')

# Finite preservation checks, not broad code or scientific acceptance.
assert len({e['id'] for e in j['entries']}) == len(j['entries'])
for entry in j['entries']:
    assert ast.unparse(definition(entry['path'], entry['symbol']).args) == entry['signature'], entry['id']
    assert (R / entry['test_path']).is_file(), entry['id']
for entry, old_entry in zip(j['entries'], base['entries']):
    for key in ('reviewed_in', 'public_path', 'public_symbol', 'introduced_in'):
        assert entry.get(key) == old_entry.get(key), (entry['id'], key)
    if entry['id'] != 'API-WEATHER-load_weather':
        assert entry == old_entry, entry['id']
assert j['structure']['supporting_files'][:-1] == base['structure']['supporting_files']
assert manual['data_flows'][:-1] == older['data_flows']
for key in older:
    if key not in {'data_flows', 'duck_types_and_callbacks'}:
        assert manual[key] == older[key], key
assert manual['duck_types_and_callbacks'][1:-2] == older['duck_types_and_callbacks'][1:]
assert all(j[k] == base[k] for k in ('schema', 'legacy_tools', 'structure_basis', 'test_contract'))
for path, syntax in parsed.items():
    for n in ast.walk(syntax):
        if isinstance(n, ast.Import):
            assert not any(a.name == 'tools' or a.name.startswith('tools.') for a in n.names), path
        elif isinstance(n, ast.ImportFrom):
            assert not ((n.module or '') == 'tools' or (n.module or '').startswith('tools.')), path
fingerprints = {r['path']: r['source_sha256'] for r in modules}
fingerprints[test_path] = sha(R / test_path)
for path, digest in fingerprints.items():
    assert sha(R / path) == digest, ('source changed during extraction', path)
assert sha(R / name) == before
assert len(j['structure']['physical_modules']) == len(base['structure']['physical_modules']) + 1
guide = (R / 'docs/PROGRAM_GUIDE.tex').read_text('utf-8')
assert '{WEATHER-SURFACE}' in guide and '{WEATHER-MODEL}' in guide

candidate = P / 'index-candidate520.json'
candidate.write_text(json.dumps(j, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
patch = P / 'index-candidate520.patch'
patch.write_text(''.join(difflib.unified_diff((B / name).read_text('utf-8').splitlines(True),
    candidate.read_text('utf-8').splitlines(True), fromfile='0.51-C2/docs/IMPLEMENTATION_INDEX.json',
    tofile='candidate-0.52/docs/IMPLEMENTATION_INDEX.json')), encoding='utf-8', newline='\n')
report = dict(
    schema='bounded-index-review520/1', created_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    basis_commit=BASE, basis_tree=basis['tree'], main=MAIN, basis_receipt_sha256=sha(P / 'basis520.json'),
    index_before_sha256=before, candidate_path=str(candidate), candidate_sha256=sha(candidate),
    helper_sha256=sha(Path(__file__)), patch_sha256=sha(patch), source_fingerprints=fingerprints,
    changed_runtime_modules=sorted(changed), new_runtime_modules=['balloon_sim/environment/model_surface.py'],
    new_supporting_files=[test_path], existing_api_signature_changes=signature_changes,
    counts=dict(runtime_modules=len(modules), public_entries=len(j['entries']),
                supporting_files=len(j['structure']['supporting_files']),
                preserved_lexical_edges=len(retained_edges), new_lexical_edges=len(new_edges)),
    old_api_review_history_and_reexports_preserved=True, new_api_reviewed_in=None,
    frontend_scene3d_and_backend_manual_index_exactly_preserved=True,
    old_supporting_rows_preserved=True, repository_index_unchanged=True,
    guide_anchor=dict(path='docs/PROGRAM_GUIDE.tex', sha256=sha(R / 'docs/PROGRAM_GUIDE.tex'),
                      anchor='WEATHER-SURFACE', status='current source anchor present; final publication owned by root'),
    review=[dict(subject=path, method='Read current source; AST hierarchy/import/signature; finite lexical call resolution',
                 result=roles[path][0] if path in roles else 'explicit surface schema branch preserves strict and GFS branches',
                 limits='Structure and responsibility only; numerical and operational acceptance are separate') for path in sorted(changed)],
    limits=['Candidate only; repository index/source/metadata/review stamps not changed.',
            'New reviewed_in remains null pending root semantic adoption.',
            'ModelSurfaceField source composition and super() are manual interpretations, not resolved static-call guarantees.',
            'Existing API histories, strict branch, frontend/3D, backend routes and old supporting rows retained exactly.',
            'No numeric examples/experiment values/whole-product or UI acceptance added to the structural index.'])
(P / 'index-evidence520.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: report[key] for key in ('candidate_sha256', 'changed_runtime_modules', 'counts', 'repository_index_unchanged')}, ensure_ascii=False))
