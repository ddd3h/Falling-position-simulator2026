"""Finite offline result/reconstruction comparison. No flight, HTTP or source writes."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys
from unittest.mock import patch

import numpy as np
from geographiclib.geodesic import Geodesic

R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
sys.path[:0]=[str(R),str(P)]
from balloon_sim.environment.storage import load_weather,read_json
from balloon_sim.environment.fields import WeatherError,FIELD_NAMES
from surface_prototype import SurfaceBridgeField


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def distance(a,b):return Geodesic.WGS84.Inverse(a['latitude_deg'],a['longitude_deg'],b['latitude_deg'],b['longitude_deg'])['s12']
def weights(axis,value):
    axis=np.asarray(axis);hit=np.flatnonzero(axis==value)
    if len(hit):return [(int(hit[0]),1.)]
    k=int(np.searchsorted(axis,value));assert 0<k<len(axis)
    f=float((value-axis[k-1])/(axis[k]-axis[k-1]));return [(k-1,1-f),(k,f)]


def main():
    out=P/'analysis-review';receipts={};results={};files={}
    for name in ('strict-step10','A-step10','B-step10','B-step5'):
        base=P/'flights'/name;receipt=json.loads((base/'receipt.json').read_bytes());result=json.loads((base/'result.json').read_bytes())
        assert sha(base/'result.json')==receipt['result_sha256'] and sha(base/'config.json')==receipt['config_sha256']
        receipts[name]=receipt;results[name]=result
        for f in base.iterdir():
            if f.is_file():files[str(f)]=sha(f)
    b=receipts['B-step10']
    # Only use the exact code/input bytes employed for the completed measurement.
    for path,digest in b['source_hashes'].items():assert sha(path)==digest,(path,'source changed; do not evaluate different implementation')
    files.update(b['source_hashes'])
    weather=P/'normalization/run520/strict-weather.json.gz';surface=P/'normalization/run520/surface-diagnostics.json.gz'
    source=load_weather(weather);diag=read_json(surface)['fields'];joins=b['weather_metadata']['join_model_levels']
    af=SurfaceBridgeField(source,diag,joins,'column_surface_extension');bf=SurfaceBridgeField(source,diag,joins,'native_horizontal_first')
    configs=[json.loads((P/'flights'/n/'config.json').read_bytes()) for n in ('A-step10','B-step10','B-step5')]
    for c in configs:
        c.pop('label');c.pop('purpose');c['integration'].pop('max_step_s')
    assert configs[0]==configs[1]==configs[2]
    comparisons=[]
    for a,bname in [('A-step10','B-step10'),('B-step10','B-step5')]:
        ar,br=results[a],results[bname];ae,be=ar['summary']['landing'],br['summary']['landing']
        perphase=[]
        for phase in ('ascent','descent'):
            aa=[r for r in ar['records'] if r['phase']==phase];bb=[r for r in br['records'] if r['phase']==phase]
            at=np.asarray([r['elapsed_s'] for r in aa]);bt=np.asarray([r['elapsed_s'] for r in bb])
            ts=np.linspace(max(at[0],bt[0]),min(at[-1],bt[-1]),201)
            va={n:np.interp(ts,at,[r[n] for r in aa]) for n in ('latitude_deg','longitude_deg','altitude_m')}
            vb={n:np.interp(ts,bt,[r[n] for r in bb]) for n in va}
            horizontal=[distance({n:va[n][k] for n in va},{n:vb[n][k] for n in vb}) for k in range(len(ts))]
            perphase.append({'phase':phase,'grid_points':201,'max_horizontal_m':max(horizontal),'max_altitude_m':float(np.max(np.abs(va['altitude_m']-vb['altitude_m'])))})
        comparisons.append({'a':a,'b':bname,'landing_distance_m':distance(ae,be),'duration_delta_s_b_minus_a':be['elapsed_s']-ae['elapsed_s'],
            'burst_distance_m':distance(ar['events'][0],br['events'][0]),'burst_time_delta_s':br['events'][0]['elapsed_s']-ar['events'][0]['elapsed_s'],
            'same_elapsed_piecewise_linear_history_comparison':perphase,'limitation':'Interpolated history diagnostic only; not an independent ODE solution or measured trajectory.'})
    launch=results['B-step10']['config']['launch'];z0=launch['altitude_m'];points=[]
    for agl in (0,2,5,8,10,20,30,50,100,300,1000,5000,10000,20000,30000):
        point=dict(time_utc=launch['time_utc'],latitude_deg=launch['latitude_deg'],longitude_deg=launch['longitude_deg'],altitude_m=z0+agl)
        row={'where':'same launch position/time','agl_m':agl,'point':point,'methods':{}}
        for name,f in [('strict',source),('A',af),('B',bf)]:
            try:
                r=f.sample(**point);row['methods'][name]={'values':{n:r[n] for n in FIELD_NAMES},'quality':r['quality'],'bridge_height_m':r.get('surface_bridge_height_m',0),'extension_depth_m':r.get('terrain_stencil_clamp_depth_m',0)}
            except WeatherError as e:row['methods'][name]={'error':e.code}
        row['B_minus_A']={n:row['methods']['B']['values'][n]-row['methods']['A']['values'][n] for n in FIELD_NAMES}
        points.append(row)
    # Independent vector arithmetic for B above every bridge: native horizontal
    # weighted mean at each original UTC, np.interp(H), then time weights.
    heights=np.asarray(source.heights);arrays={n:np.asarray(source.fields[n]) for n in FIELD_NAMES}
    ground=np.asarray(source.surface_height);independent=[]
    epoch=source.times[0];times=[(t-epoch).total_seconds() for t in source.times]
    for utc in [source.times[0],dt.datetime.fromisoformat(launch['time_utc']),source.times[1]]:
        tw=weights(times,(utc-epoch).total_seconds());yw=weights(source.latitudes,launch['latitude_deg']);xw=weights(source.longitudes,launch['longitude_deg'])
        for altitude in (1000.,5000.,10000.,20000.,30000.):
            h=6371000.*altitude/(6371000.+altitude);expect={n:0. for n in FIELD_NAMES}
            for t,wt in tw:
                hm=sum(wy*wx*heights[t,:,j,i] for j,wy in yw for i,wx in xw)
                assert hm[1]<h<hm[-1]
                for n,array in arrays.items():
                    fm=sum(wy*wx*array[t,:,j,i] for j,wy in yw for i,wx in xw)
                    expect[n]+=wt*float(np.interp(h,hm,fm))
            actual=bf.sample(utc,launch['latitude_deg'],launch['longitude_deg'],altitude)
            error={n:actual[n]-expect[n] for n in FIELD_NAMES}
            assert all(abs(error[n])<1e-8 for n in FIELD_NAMES)
            independent.append({'time_utc':utc.isoformat(),'altitude_m':altitude,'actual_minus_independent':error})
    toz=lambda h:6371000.*h/(6371000.-h)
    level_agl=toz(heights[:,:2])-toz(ground[:,None,:,:])
    join_stats=[{'model_level':k+1,'native_geometric_AGL_range_m':[float(level_agl[:,k].min()),float(level_agl[:,k].max())]} for k in range(2)]
    # Original-UTC virtual top need not equal the smallest supporting-column top.
    top=[]
    for t,wt in weights(times,(dt.datetime.fromisoformat(launch['time_utc'])-epoch).total_seconds()):
        terms=[(j,i,wy*wx) for j,wy in weights(source.latitudes,launch['latitude_deg']) for i,wx in weights(source.longitudes,launch['longitude_deg'])]
        rawtop=[heights[t,-1,j,i] for j,i,w in terms];virtual=sum(w*heights[t,-1,j,i] for j,i,w in terms)
        top.append({'source_time_utc':source.times[t].isoformat(),'strict_positive_column_min_top_gpm':float(min(rawtop)),'virtual_top_gpm':float(virtual),'virtual_minus_strict_top_gpm':float(virtual-min(rawtop))})
    assert all(sha(p)==h for p,h in files.items()),'Source/input changed during independent comparisons'
    report={'schema':'jra-surface-independent-values/1','inputs_sha256':files,'source_unchanged':True,'methods':'Read four immutable results; WGS84 geodesic and phase-wise linear history comparison;15same physical queries;15independent B-upper NumPy checks. No new integration/HTTP.',
        'comparisons':comparisons,'same_physical_point_queries':points,'independent_B_upper_checks':independent,'native_join_AGL_ranges':join_stats,'launch_upper_support':top,
        'limits':['This is one winter analysis window, one launch/physical config, one grid.','A10/B10 timings are one observation each; B5 changes workload; no cost benchmark repeat.','Numerical step agreement is conditional on the chosen reconstruction and is not meteorological accuracy.','No empirical descent/ground truth, probability calibration, fine terrain, or UI test.']}
    output=out/'independent-values520.json'
    with output.open('x',encoding='utf8',newline='\n') as stream:json.dump(report,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'output':str(output),'sha256':sha(output),'comparisons':comparisons,'native_join_AGL_ranges':join_stats,'launch_upper_support':top},ensure_ascii=False))


if __name__=='__main__':
    with patch('socket.create_connection',side_effect=AssertionError('offline comparison only')):main()
