"""External A/B ground-connection experiment; not the accepted runtime policy.

Uses a validated ModelLevelField and same-grid surface analyses. Join level IDs
are fixed for the whole window, so a layer crossing a diagnostic height cannot
silently switch the interpolation segment. Original arrays remain unchanged.
"""
from copy import deepcopy
import math

from balloon_sim.environment.fields import (
    FIELD_NAMES, WeatherError, _array, _bracket,
    geometric_to_geopotential as to_h, geopotential_to_geometric as to_z,
)

SURFACE = {
    "temperature_k": ("temperature_2m_k", 2),
    "specific_humidity_kg_kg": ("specific_humidity_2m_kg_kg", 2),
    "eastward_wind_m_s": ("eastward_wind_10m_m_s", 10),
    "northward_wind_m_s": ("northward_wind_10m_m_s", 10),
}


class SurfaceBridgeField:
    def __init__(self, source, surface, join_levels, mode):
        if mode not in ("column_surface_extension", "native_horizontal_first"):
            raise ValueError("unknown experimental reconstruction")
        if set(join_levels) != set(FIELD_NAMES) or any(
            type(v) is not int or not 1 <= v <= len(source.levels)
            for v in join_levels.values()
        ):
            raise ValueError("fixed one-based join levels required for every field")
        self.source, self.mode = source, mode
        self.join_levels = dict(join_levels)
        shape = (len(source.times), len(source.latitudes), len(source.longitudes))
        self.surface = {n: _array(surface[n], shape, n) for n, _ in SURFACE.values()}
        self._validate_fixed_joins()
        self.metadata = deepcopy(source.metadata)
        self.metadata.update(
            experimental_reconstruction=mode,
            surface_policy="fixed native joins; 2m T/q and 10m u/v held below anchors",
            join_model_levels=self.join_levels,
            pressure_interpolation="native full pressure, linear in geopotential height",
            time_order="independent reconstruction at each original UTC, then linear time",
            scope="finite design experiment, not a scientifically validated default",
            fixed_join_validation="all UTCs/columns and configured field joins; geometry must be present",
            diagnostic_value_validation="each consumed positive-weight value before averaging; unused diagnostics not required",
            query_counter_meaning="attempted_calls counts sample entries; successful_calls/calls and bridge counters count returns only",
        )
        self.statistics = dict(attempted_calls=0, successful_calls=0, failed_calls=0,
                               calls=0, bridge_calls=0, extension_calls=0,
                               max_bridge_height_m=0.0, max_extension_depth_m=0.0)

    def _validate_fixed_joins(self):
        """Window-wide geometry is a precondition, not a per-query join choice.

        Unlike consumed field values, the configured joins must be valid in
        every original column/time. Missing terrain or a join height refuses
        construction. Missing diagnostic/native scalar values remain local to
        the requested quantity and positive support consumed by a later query.
        """
        s = self.source
        for t in range(len(s.times)):
            for j in range(len(s.latitudes)):
                for i in range(len(s.longitudes)):
                    ground = s.surface_height[t][j][i]
                    if ground is None:
                        raise WeatherError("MISSING_SURFACE_SUPPORT", f"join geometry {t},{j},{i}")
                    for name, level in self.join_levels.items():
                        height = s.heights[t][level-1][j][i]
                        if height is None:
                            raise WeatherError("MISSING_HEIGHT_SUPPORT", f"join geometry {t},{level},{j},{i}")
                        offset = 0 if name == "pressure_pa" else SURFACE[name][1]
                        anchor = to_h(to_z(ground) + offset)
                        if height <= anchor:
                            raise WeatherError("SURFACE_JOIN_UNSUPPORTED", f"{name} level {level} column {t},{j},{i}")

    def __getattr__(self, name):
        return getattr(self.source, name)

    def ground_altitude(self, time_utc, latitude_deg, longitude_deg):
        return self.source.ground_altitude(time_utc, latitude_deg, longitude_deg)

    def _mix(self, array, members, name):
        values = [(array[t][j][i], weight) for t, j, i, weight in members]
        if any(value is None for value, _ in values):
            raise WeatherError("MISSING_DATA", name)
        physical_name = next((n for n, (diagnostic, _) in SURFACE.items() if diagnostic == name), name)
        if physical_name == "surface pressure":
            physical_name = "pressure_pa"
        if physical_name in FIELD_NAMES:
            for value, _ in values:
                self.source._check_value(physical_name, value)
        result = sum(value * weight for value, weight in values)
        if not math.isfinite(result):
            raise WeatherError("INVALID_FIELD_VALUE", name)
        return result

    def _column(self, members, height, requested):
        s = self.source
        ground = self._mix(s.surface_height, members, "surface H")
        sp = self._mix(s.surface_pressure, members, "surface pressure")
        if sp <= 0:
            raise WeatherError("INVALID_PRESSURE", "surface pressure")
        local_h = height
        extension = 0.0
        if height < ground - 1e-7:
            if self.mode != "column_surface_extension":
                raise WeatherError("BELOW_MODEL_SURFACE", "virtual column")
            local_h = ground
            extension = to_z(ground) - to_z(height)
        local_h = max(local_h, ground)  # inverse-height roundoff only for B
        heights = []
        for k in range(len(s.levels)):
            heights.append(self._mix([planes[k] for planes in s.heights], members, "native H"))
        if any(b <= a for a, b in zip(heights, heights[1:])):
            raise WeatherError("INVALID_COLUMN", "mixed heights not ascending")

        def native(name, k):
            # All selected source nodes must be atmospheric, not only their mean.
            for t, j, i, _ in members:
                pressure = s.pressures[t][k][j][i]
                if pressure is None:
                    raise WeatherError("MISSING_DATA", "native pressure")
                if (s.heights[t][k][j][i] < s.surface_height[t][j][i]
                        or pressure > s.surface_pressure[t][j][i]):
                    raise WeatherError("BELOW_MODEL_SURFACE", "selected native node")
            value = self._mix([planes[k] for planes in s.fields[name]], members, name)
            return s._check_value(name, value)

        result, quality, bridge_height = {}, set(), 0.0
        for name in requested:
            join = self.join_levels[name] - 1
            offset = 0 if name == "pressure_pa" else SURFACE[name][1]
            anchor = to_h(to_z(ground) + offset)
            if heights[join] <= anchor:
                raise WeatherError("SURFACE_JOIN_UNSUPPORTED", f"{name} level {join+1}")
            if local_h < heights[join]:
                bridge_height = max(bridge_height, to_z(heights[join]) - to_z(ground))
                quality.add("surface_layer_bridge")
                low = sp if name == "pressure_pa" else self._mix(
                    self.surface[SURFACE[name][0]], members, SURFACE[name][0])
                s._check_value(name, low)
                # Validate the upper anchor even when its interpolation weight is zero.
                high = native(name, join)
                fraction = max(0.0, (local_h - anchor) / (heights[join] - anchor))
                result[name] = low * (1 - fraction) + high * fraction
                if offset and local_h <= anchor:
                    quality.add(f"{offset}m_analysis_held_below_anchor")
            else:
                vertical = _bracket(heights[join:], local_h, "HEIGHT_OUT_OF_RANGE")
                result[name] = sum(weight * native(name, join+k) for k, weight in vertical)
            s._check_value(name, result[name])
        if extension:
            quality.add("terrain_stencil_surface_extension")
        return result, quality, bridge_height, extension

    def sample(self, time_utc, latitude_deg, longitude_deg, altitude_m, fields=None):
        self.statistics["attempted_calls"] += 1
        try:
            result = self._sample(time_utc, latitude_deg, longitude_deg, altitude_m, fields)
        except BaseException:
            self.statistics["failed_calls"] += 1
            raise
        self.statistics["successful_calls"] += 1
        self.statistics["calls"] += 1  # compatibility alias, explicitly success-only
        return result

    def _sample(self, time_utc, latitude_deg, longitude_deg, altitude_m, fields=None):
        requested = FIELD_NAMES if fields is None else fields
        if (not isinstance(requested, (list, tuple)) or not requested
                or any(not isinstance(n, str) for n in requested)
                or len(set(requested)) != len(requested)):
            raise WeatherError("INVALID_REQUIRED_FIELDS", "distinct fields required")
        if set(requested) - self.source.fields.keys():
            raise WeatherError("MISSING_CAPABILITY", sorted(set(requested)-self.source.fields.keys()))
        support = self.source._support(time_utc, latitude_deg, longitude_deg)
        height = to_h(altitude_m)
        ground = self.source._ground(support)
        if height < ground - 1e-7:
            raise WeatherError("BELOW_MODEL_SURFACE", "query below interpolated terrain")
        height = max(height, ground)
        if self.mode == "column_surface_extension":
            columns = [(((t, j, i, 1.0),), weight) for t, j, i, weight in support]
        else:
            groups = {}
            for t, j, i, weight in support:
                groups.setdefault(t, []).append((t, j, i, weight))
            columns = []
            for members in groups.values():
                temporal_weight = sum(m[3] for m in members)
                columns.append((tuple((t, j, i, weight/temporal_weight)
                                     for t, j, i, weight in members), temporal_weight))
        values = {name: 0.0 for name in requested}
        quality = {"experimental_surface_reconstruction", self.mode,
                   "spherical_geopotential_height_approximation", "height_linear_pressure",
                   "model_orography_not_fine_dem", "fixed_native_join_levels"}
        max_bridge = max_extension = 0.0
        for members, weight in columns:
            value, flags, bridge, extension = self._column(members, height, requested)
            for name in requested:
                values[name] += weight * value[name]
            quality.update(flags)
            max_bridge, max_extension = max(max_bridge, bridge), max(max_extension, extension)
        for name, value in values.items():
            self.source._check_value(name, value)
        self.statistics["bridge_calls"] += bool(max_bridge)
        self.statistics["extension_calls"] += bool(max_extension)
        self.statistics["max_bridge_height_m"] = max(self.statistics["max_bridge_height_m"], max_bridge)
        self.statistics["max_extension_depth_m"] = max(self.statistics["max_extension_depth_m"], max_extension)
        return {**values, "ground_altitude_m": to_z(ground), "quality": sorted(quality),
                "surface_bridge_height_m": max_bridge,
                "terrain_stencil_clamp_depth_m": max_extension}
