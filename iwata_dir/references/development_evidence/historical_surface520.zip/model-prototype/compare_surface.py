"""Independent inputs for root's external surface candidate; no source edits."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from surface_prototype import SurfaceBridgeField
from native_horizontal_first import NativeHorizontalFirstField
from test_native_horizontal_first import make_data, query, START, U, V, P, T, Q, geometric
from balloon_sim.environment.fields import FIELD_NAMES, WeatherError
from balloon_sim.environment.model_levels import ModelLevelField

JOINS = {name: 2 if "wind" in name else 1 for name in FIELD_NAMES}


def surface_data():
    return {"temperature_2m_k": [[[280., 281.]], [[282., 283.]]],
            "specific_humidity_2m_kg_kg": [[[.004, .004]], [[.004, .004]]],
            "eastward_wind_10m_m_s": [[[2., 3.]], [[4., 5.]]],
            "northward_wind_10m_m_s": [[[-1., -2.]], [[-3., -4.]]]}


class IndependentSurfaceComparison(unittest.TestCase):
    def setUp(self):
        for name in ("socket.socket", "socket.create_connection"):
            block = patch(name, side_effect=AssertionError("network forbidden"))
            block.start()
            self.addCleanup(block.stop)

    def wrap(self, source, surface=None):
        return SurfaceBridgeField(source, surface or surface_data(), JOINS, "native_horizontal_first")

    def reject(self, code, fn):
        with self.assertRaises(WeatherError) as caught:
            fn()
        self.assertEqual(caught.exception.code, code)

    def test_upper_support_matches_independent_B_at_two_terrains_and_times(self):
        for terrain in ((0., 0.), (0., 200.)):
            source = ModelLevelField(**make_data(terrain=terrain))
            a, b = NativeHorizontalFirstField(source), self.wrap(source)
            for hour in (0., 1.7, 3., 6.):
                for lon in (136., 136.2, 137., 137.8, 138.):
                    for h in (550., 800., 950.):
                        for name in FIELD_NAMES:
                            self.assertAlmostEqual(query(a, h, hour, lon)[name],
                                                   query(b, h, hour, lon)[name], places=9)

    def test_moving_shear_above_fixed_join_has_same_height_then_time_order(self):
        h = [[[8., 28., 200., 400.]]*2, [[8., 28., 300., 400.]]*2]
        winds = [[[0., 0., 20., 20.]]*2]*2
        source = ModelLevelField(**make_data(time_heights=h, time_winds=winds))
        root = self.wrap(source)
        independent = NativeHorizontalFirstField(source)
        expected = (20 + 20*(200-28)/(300-28))/2
        time_first = 20*(200-28)/(250-28)
        self.assertAlmostEqual(query(root, h=200.)[U], expected, places=10)
        self.assertAlmostEqual(query(independent, h=200.)[U], expected, places=10)
        self.assertGreater(abs(query(root, h=200.)[U]-time_first), .5)

    def test_10m_boundary_is_value_continuous_with_constant_lower_segment(self):
        h = [[[8., 28., 1000.]]*2]*2
        source = ModelLevelField(**make_data(time_heights=h))
        root = self.wrap(source)
        values = [root.sample(START, 35., 136., z, fields=(U,))[U] for z in (9.999999, 10., 10.000001)]
        self.assertEqual(values[:2], [2., 2.])
        self.assertLess(abs(values[2]-2.), 1e-6)

    def test_selected_native_missing_pressure_and_q_stop_as_in_independent_B(self):
        for which in (P, Q):
            data = make_data()
            if which == P:
                data["pressures"][1][1][0][1] = None
            else:
                data["fields"][Q][1][1][0][1] = None
            source = ModelLevelField(**data)
            for field in (self.wrap(source), NativeHorizontalFirstField(source)):
                self.reject("MISSING_DATA", lambda: query(field))

    def test_bridge_and_upper_queries_leave_original_field_and_surface_unchanged(self):
        source = ModelLevelField(**make_data())
        before = deepcopy(source.__dict__)
        surface = surface_data()
        surface_before = deepcopy(surface)
        root = self.wrap(source, surface)
        query(root, h=0., hour=0.)
        query(root, h=500.)
        self.assertEqual(source.__dict__, before)
        self.assertEqual(surface, surface_before)

    def test_invalid_source_diagnostic_must_not_be_hidden_by_average(self):
        source = ModelLevelField(**make_data())
        surface = surface_data()
        surface["specific_humidity_2m_kg_kg"][0][0] = [-.1, .108]
        # Every positive support must be valid, even though mean .004 is valid.
        self.reject("INVALID_FIELD_VALUE", lambda: query(self.wrap(source, surface), h=0., hour=0.))

    def test_join_below_10m_in_one_column_must_not_be_hidden_by_average(self):
        h = [[[8., 28., 1000.], [8., 9., 1000.]]]*2
        source = ModelLevelField(**make_data(time_heights=h))
        # Native level 2 in the right column is below its 10m anchor, while the
        # mixed level 18.5gpm is above 10m. Whole-window fixed join is not valid.
        self.reject("SURFACE_JOIN_UNSUPPORTED", lambda: query(self.wrap(source), h=0., hour=0.))


if __name__ == "__main__":
    unittest.main(verbosity=2)
