"""External, unadopted B experiment. No surface bridge or field mutation.

For each original UTC independently: horizontally average common native levels,
query their virtual height column, then linearly interpolate the sampled values
in time. Pressure averages original full-level pressures (B1); it is not rebuilt
from mixed surface pressure. This is not a hydrostatic-consistency assertion.
"""
from copy import deepcopy
import math

from balloon_sim.environment.fields import (
    FIELD_NAMES, WeatherError, _bracket, _utc,
    geometric_to_geopotential, geopotential_to_geometric,
)
from balloon_sim.environment.model_levels import ModelLevelField

METHOD = "experimental-native-horizontal-height-then-time/1"


class NativeHorizontalFirstField:
    """Read-only adapter over a validated ModelLevelField; no copy of arrays.

    The caller must not mutate the wrapped field. This external prototype does
    not change loader dispatch or claim that its metadata describe strict JRA.
    """

    def __init__(self, field):
        if not isinstance(field, ModelLevelField):
            raise TypeError("a validated ModelLevelField is required")
        self.field = field
        self.times = field.times
        self.metadata = deepcopy(field.metadata)
        self.metadata.update(
            experiment_method=METHOD,
            vertical_interpolation="horizontal native-level mean, height-linear, then time-linear",
            vertical_pressure_method="horizontal mean of original full pressures (B1)",
            surface_policy="no bridge; each original-UTC virtual column must support query",
            scientific_adoption=False,
        )

    def ground_altitude(self, time_utc, latitude_deg, longitude_deg):
        # Exactly the existing mixed-H terrain convention, including time.
        return self.field.ground_altitude(time_utc, latitude_deg, longitude_deg)

    def _at_original_time(self, t, latitude_deg, longitude_deg, height, requested):
        field = self.field
        # Calling support at an exact native UTC prevents time weights entering
        # the virtual column. Positive horizontal weights and longitude rules
        # remain the existing field's rules.
        support = field._support(field.times[t], latitude_deg, longitude_deg)
        surface = []
        for ti, j, i, weight in support:
            assert ti == t
            sp, ground = field.surface_pressure[t][j][i], field.surface_height[t][j][i]
            if sp is None or ground is None:
                raise WeatherError("MISSING_SURFACE_SUPPORT", f"column {t},{j},{i}")
            surface.append((j, i, weight, sp, ground))
        ground = math.fsum(weight * local_ground for _, _, weight, _, local_ground in surface)
        if height < ground:
            raise WeatherError("BELOW_MODEL_SURFACE", f"original UTC {t} virtual terrain")
        heights = []
        for k in range(len(field.levels)):
            terms = []
            for j, i, weight, _, _ in surface:
                value = field.heights[t][k][j][i]
                if value is None:
                    raise WeatherError("MISSING_HEIGHT_SUPPORT", f"column {t},{j},{i}, level {k}")
                terms.append(weight * value)
            heights.append(math.fsum(terms))
        if (any(not math.isfinite(h) for h in heights)
                or any(b <= a for a, b in zip(heights, heights[1:]))):
            raise WeatherError("NUMERIC_UNSUPPORTED", "virtual height order not representable")
        vertical = _bracket(heights, height, "HEIGHT_OUT_OF_RANGE")
        level_values = {name: [] for name in requested}
        for k, wz in vertical:
            means = {name: [] for name in requested}
            for j, i, weight, sp, local_ground in surface:
                pressure = field.pressures[t][k][j][i]
                if pressure is None:
                    raise WeatherError("MISSING_DATA", "full pressure coordinate missing")
                if pressure > sp or field.heights[t][k][j][i] < local_ground:
                    raise WeatherError("BELOW_MODEL_SURFACE", f"cell {t},{k},{j},{i}")
                for name in requested:
                    value = field.fields[name][t][k][j][i]
                    if value is None:
                        raise WeatherError("MISSING_DATA", f"{name} at {t},{k},{j},{i}")
                    means[name].append(weight * value)
            for name in requested:
                level_values[name].append(wz * math.fsum(means[name]))
        return {name: math.fsum(values) for name, values in level_values.items()}

    def sample(self, time_utc, latitude_deg, longitude_deg, altitude_m, fields=None):
        requested = FIELD_NAMES if fields is None else fields
        if (not isinstance(requested, (list, tuple)) or not requested
                or any(not isinstance(name, str) for name in requested)
                or len(set(requested)) != len(requested)):
            raise WeatherError("INVALID_REQUIRED_FIELDS", "nonempty distinct field names required")
        absent = set(requested) - self.field.fields.keys()
        if absent:
            raise WeatherError("MISSING_CAPABILITY", ",".join(sorted(absent)))
        height = geometric_to_geopotential(altitude_m)
        times = _bracket(self.times, _utc(time_utc), "TIME_OUT_OF_RANGE")
        terms = {name: [] for name in requested}
        for t, wt in times:
            values = self._at_original_time(t, latitude_deg, longitude_deg, height, requested)
            for name in requested:
                terms[name].append(wt * values[name])
        values = {name: math.fsum(parts) for name, parts in terms.items()}
        for name, value in values.items():
            self.field._check_value(name, value)
        return {**values,
                "ground_altitude_m": self.ground_altitude(time_utc, latitude_deg, longitude_deg),
                "quality": ["spherical_geopotential_height_approximation",
                            "experimental_native_horizontal_first",
                            "original_utc_height_query_before_time_interpolation",
                            "original_full_pressure_mean_B1", "height_linear_pressure",
                            "no_surface_bridge", "model_orography_not_fine_dem"]}
