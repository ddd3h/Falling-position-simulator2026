"""Synthetic counterexamples; no observed data, HTTP, flight or adoption."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import math
import unittest
from unittest.mock import patch

from balloon_sim.environment.fields import WeatherError
from balloon_sim.environment.model_levels import ModelLevelField
from native_horizontal_first import NativeHorizontalFirstField, METHOD

START = datetime(2024, 1, 1, tzinfo=timezone.utc)
U, V, T, Q, P = ("eastward_wind_m_s", "northward_wind_m_s", "temperature_k",
                 "specific_humidity_kg_kg", "pressure_pa")
ALL = (U, V, P, T, Q)


def geometric(h):
    return 6371000.0 * h / (6371000.0 - h)


def make_data(terrain=(0., 0.), time_heights=None, time_winds=None):
    # time_heights[t][horizontal column][native level]. All remaining fields
    # follow independent affine functions of absolute H and time/position.
    if time_heights is None:
        time_heights = [[[g + h for h in (8., 300., 1000.)] for g in terrain] for _ in range(2)]
    arrays = {name: [] for name in ("h", P, T, U, V, Q)}
    for t, columns in enumerate(time_heights):
        for data in arrays.values():
            data.append([])
        for k in range(len(columns[0])):
            values = {name: [] for name in arrays}
            for i, column in enumerate(columns):
                h = column[k]
                row = {"h": h, P: 100000 - 20*h + 4*t + 8*i,
                       T: 270 + .005*h + 2*t + 4*i,
                       U: .01*h + t + 2*i, V: -.02*h,
                       Q: .001 + .000001*h}
                if time_winds is not None:
                    row[U] = time_winds[t][i][k]
                for name, value in row.items():
                    values[name].append(value)
            for name in arrays:
                arrays[name][t].append([values[name]])
    return dict(times=[START + timedelta(hours=6*t) for t in range(len(time_heights))],
                latitudes=[35.], longitudes=[136., 138.],
                levels=list(range(1, len(time_heights[0][0]) + 1)),
                heights=arrays.pop("h"), pressures=arrays.pop(P), fields=arrays,
                surface_pressure=[[[101000., 101000.]] for _ in time_heights],
                surface_height=[[list(terrain)] for _ in time_heights],
                metadata={"fixture": "synthetic; not observed JRA"})


def query(field, h=500., hour=3., lon=137., lat=35., fields=ALL):
    return field.sample(START + timedelta(hours=hour), lat, lon, geometric(h), fields=fields)


class SyntheticBTests(unittest.TestCase):
    def setUp(self):
        for name in ("socket.socket", "socket.create_connection"):
            blocker = patch(name, side_effect=AssertionError("network forbidden"))
            blocker.start()
            self.addCleanup(blocker.stop)

    def reject(self, code, fn):
        with self.assertRaises(WeatherError) as caught:
            fn()
        self.assertEqual(caught.exception.code, code)

    def test_flat_affine_field_matches_independent_formula_and_strict(self):
        base = ModelLevelField(**make_data())
        result = query(NativeHorizontalFirstField(base))
        expected = {U: 6.5, V: -10., P: 90006., T: 275.5, Q: .0015}
        for name, value in expected.items():
            self.assertAlmostEqual(result[name], value, places=10)
            self.assertAlmostEqual(result[name], query(base)[name], places=10)

    def test_native_horizontal_points_match_strict_at_native_and_intermediate_time(self):
        base = ModelLevelField(**make_data(terrain=(0., 200.)))
        candidate = NativeHorizontalFirstField(base)
        for hour in (0., 3., 6.):
            for lon in (136., 138.):
                for h in (250., 500., 900.):
                    with self.subTest(hour=hour, lon=lon, h=h):
                        for name in ALL:
                            self.assertAlmostEqual(query(candidate, h, hour, lon)[name],
                                                   query(base, h, hour, lon)[name], places=10)

    def test_mixed_terrain_query_uses_virtual_levels_without_column_clamp(self):
        base = ModelLevelField(**make_data(terrain=(0., 200.)))
        candidate = NativeHorizontalFirstField(base)
        self.reject("BELOW_MODEL_SURFACE", lambda: query(base, h=150., hour=0.))
        result = query(candidate, h=150., hour=0.)
        self.assertAlmostEqual(result[U], 2.5, places=12)
        self.assertAlmostEqual(result[P], 97004., places=10)
        self.assertAlmostEqual(result["ground_altitude_m"], geometric(100.))
        self.assertIn("no_surface_bridge", result["quality"])

    def test_virtual_surface_gap_and_below_surface_are_not_filled(self):
        candidate = NativeHorizontalFirstField(ModelLevelField(**make_data(terrain=(0., 200.))))
        for h in (100., 104., 107.):
            self.reject("HEIGHT_OUT_OF_RANGE", lambda: query(candidate, h=h))
        self.reject("BELOW_MODEL_SURFACE", lambda: query(candidate, h=99.))

    def test_upper_support_is_virtual_and_is_not_extrapolated(self):
        base = ModelLevelField(**make_data(terrain=(0., 200.)))
        candidate = NativeHorizontalFirstField(base)
        self.reject("HEIGHT_OUT_OF_RANGE", lambda: query(base, h=1050.))
        self.assertAlmostEqual(query(candidate, h=1050.)[U], 12., places=10)
        self.reject("HEIGHT_OUT_OF_RANGE", lambda: query(candidate, h=1101.))

    def test_horizontal_native_first_differs_from_column_first_for_shear(self):
        h = [[[100., 200., 400.], [100., 300., 400.]]] * 2
        u = [[[0., 20., 20.], [0., 20., 20.]]] * 2
        base = ModelLevelField(**make_data(time_heights=h, time_winds=u))
        self.assertAlmostEqual(query(base, h=200.)[U], 15., places=12)
        self.assertAlmostEqual(query(NativeHorizontalFirstField(base), h=200.)[U], 40/3, places=12)

    def test_moving_shear_is_height_queried_before_time_interpolation(self):
        h = [[[100., 200., 400.]] * 2, [[100., 300., 400.]] * 2]
        u = [[[0., 20., 20.]] * 2] * 2
        candidate = NativeHorizontalFirstField(ModelLevelField(**make_data(time_heights=h, time_winds=u)))
        self.assertAlmostEqual(query(candidate, h=200., hour=0.)[U], 20., places=12)
        self.assertAlmostEqual(query(candidate, h=200., hour=6.)[U], 10., places=12)
        self.assertAlmostEqual(query(candidate, h=200., hour=3.)[U], 15., places=12)
        wrong_time_mixed_height_answer = 20 * (200-100) / (250-100)
        self.assertGreater(abs(query(candidate, h=200.)[U] - wrong_time_mixed_height_answer), 1.)

    def test_each_original_utc_must_support_query_not_only_time_mean_column(self):
        h = [[[8., 300., 1000.]] * 2, [[108., 400., 1100.]] * 2]
        candidate = NativeHorizontalFirstField(ModelLevelField(**make_data(time_heights=h)))
        # Time-mean minimum is 58; H=80 is still unsupported at UTC 06.
        self.reject("HEIGHT_OUT_OF_RANGE", lambda: query(candidate, h=80.))
        query(candidate, h=80., hour=0.)

    def test_missing_surface_height_and_pressure_are_not_reweighted(self):
        for name in ("surface_height", "surface_pressure"):
            data = make_data()
            data[name][1][0][1] = None
            candidate = NativeHorizontalFirstField(ModelLevelField(**data))
            self.reject("MISSING_SURFACE_SUPPORT", lambda: query(candidate))
            query(candidate, hour=0.)
            query(candidate, lon=136.)

    def test_missing_height_even_at_unselected_level_rejects_positive_column(self):
        data = make_data()
        data["heights"][1][2][0][1] = None
        candidate = NativeHorizontalFirstField(ModelLevelField(**data))
        self.reject("MISSING_HEIGHT_SUPPORT", lambda: query(candidate, h=100.))
        query(candidate, h=100., hour=0.)

    def test_missing_pressure_rejects_even_wind_only(self):
        data = make_data()
        data["pressures"][1][1][0][1] = None
        candidate = NativeHorizontalFirstField(ModelLevelField(**data))
        self.reject("MISSING_DATA", lambda: query(candidate, fields=(U,)))

    def test_missing_requested_field_and_zero_weight_support(self):
        data = make_data()
        data["fields"][Q][1][1][0][1] = None
        candidate = NativeHorizontalFirstField(ModelLevelField(**data))
        self.reject("MISSING_DATA", lambda: query(candidate))
        query(candidate, fields=(U, V))
        query(candidate, lon=136.)
        query(candidate, hour=0.)

    def test_time_spatial_capability_and_height_failures_remain(self):
        data = make_data()
        del data["fields"][Q]
        candidate = NativeHorizontalFirstField(ModelLevelField(**data))
        for code, options in (("TIME_OUT_OF_RANGE", {"hour": 7.}),
                              ("LATITUDE_OUT_OF_RANGE", {"lat": 34.}),
                              ("LONGITUDE_OUT_OF_RANGE", {"lon": 139.})):
            self.reject(code, lambda: query(candidate, fields=(U,), **options))
        self.reject("MISSING_CAPABILITY", lambda: query(candidate))
        self.reject("INVALID_REQUIRED_FIELDS", lambda: query(candidate, fields=(U, U)))

    def test_original_nodes_below_ground_not_hidden_by_virtual_average(self):
        data = make_data()
        data["surface_height"][0][0][1] = 400.
        candidate = NativeHorizontalFirstField(ModelLevelField(**data))
        self.reject("BELOW_MODEL_SURFACE", lambda: query(candidate, h=500., hour=0.))

    def test_adapter_does_not_mutate_original_metadata_or_arrays(self):
        data = make_data()
        preserved = deepcopy(data)
        base = ModelLevelField(**data)
        candidate = NativeHorizontalFirstField(base)
        query(candidate)
        self.assertEqual(data, preserved)
        self.assertEqual(base.metadata, preserved["metadata"])
        self.assertEqual(candidate.metadata["experiment_method"], METHOD)
        self.assertFalse(candidate.metadata["scientific_adoption"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
