"""External-only reproducible synthetic run; refuses output overwrite."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    basis_path = here.parent / "basis520.json"
    basis = json.loads(basis_path.read_text(encoding="utf-8"))
    if basis["head"] != "f94027cec2ff56b732af7bd11b2df26bdd9513a5":
        raise RuntimeError("unexpected fixed comparison commit")
    tracked_before = {p: sha(args.repo / p) for p in basis["files"]}
    source_paths = [p for p in basis["files"] if p.startswith("balloon_sim/") and p.endswith(".py")]
    if any(tracked_before[p] != basis["files"][p] for p in source_paths):
        raise RuntimeError("runtime source differs from fixed basis")
    args.out.mkdir(parents=True, exist_ok=False)
    prototype_before = {p.name: sha(p) for p in here.glob("*.py")}
    command = [sys.executable, "-B", "-X", "utf8", "-m", "unittest", "discover",
               "-s", str(here), "-p", "test_native_horizontal_first.py", "-v"]
    environment = dict(os.environ, PYTHONPATH=str(args.repo)+os.pathsep+str(here),
                       PYTHONDONTWRITEBYTECODE="1")
    started = datetime.now(timezone.utc).isoformat()
    began = time.perf_counter()
    test = subprocess.run(command, cwd=args.repo, env=environment, capture_output=True,
                          text=True, encoding="utf-8", timeout=60)
    test_wall = time.perf_counter()-began
    (args.out / "tests.stdout").write_text(test.stdout, encoding="utf-8")
    (args.out / "tests.stderr").write_text(test.stderr, encoding="utf-8")
    observations = None
    timing = None
    if test.returncode == 0:
        sys.path[:0] = [str(here), str(args.repo)]
        from test_native_horizontal_first import make_data, query, U
        from native_horizontal_first import NativeHorizontalFirstField
        from balloon_sim.environment.model_levels import ModelLevelField
        h = [[[100., 200., 400.]] * 2, [[100., 300., 400.]] * 2]
        u = [[[0., 20., 20.]] * 2] * 2
        moving = NativeHorizontalFirstField(ModelLevelField(**make_data(time_heights=h, time_winds=u)))
        horizontal_h = [[[100., 200., 400.], [100., 300., 400.]]] * 2
        horizontal_u = [[[0., 20., 20.], [0., 20., 20.]]] * 2
        horizontal = ModelLevelField(**make_data(time_heights=horizontal_h, time_winds=horizontal_u))
        observations = {
            "synthetic_only": True,
            "moving_shear": {"B_time_00_u_m_s": query(moving, h=200., hour=0.)[U],
                             "B_time_03_u_m_s": query(moving, h=200., hour=3.)[U],
                             "B_time_06_u_m_s": query(moving, h=200., hour=6.)[U],
                             "time_mixed_height_first_oracle_u_m_s": 20*100/150},
            "horizontal_shear": {"strict_u_m_s": query(horizontal, h=200.)[U],
                                 "B_u_m_s": query(NativeHorizontalFirstField(horizontal), h=200.)[U]},
        }
        # Timing is a tiny warmed 3-level/2-column/2-UTC query microbenchmark,
        # separate from correctness, initialization, HTTP and any flight.
        base = ModelLevelField(**make_data())
        candidate = NativeHorizontalFirstField(base)
        timing = {"kind": "warmed synthetic query microbenchmark", "levels": 3,
                  "horizontal_columns": 2, "time_support": 2,
                  "queries_per_repeat": 1000, "repeats": 3, "initialization_included": False,
                  "strict_wall_s": [], "B_wall_s": [],
                  "limits": "No observed field, 100-level cost, flight, CPU or RSS assertion."}
        for field in (base, candidate):
            query(field)
        for repeat in range(3):
            ordered = (("strict", base), ("B", candidate)) if repeat % 2 == 0 else (("B", candidate), ("strict", base))
            for label, field in ordered:
                tick = time.perf_counter()
                for _ in range(1000):
                    query(field)
                timing[label+"_wall_s"].append(time.perf_counter()-tick)
        timing["strict_median_wall_s"] = statistics.median(timing["strict_wall_s"])
        timing["B_median_wall_s"] = statistics.median(timing["B_wall_s"])
    tracked_after = {p: sha(args.repo / p) for p in basis["files"]}
    prototype_after = {p.name: sha(p) for p in here.glob("*.py")}
    changes = [p for p in tracked_before if tracked_after[p] != tracked_before[p]]
    if prototype_before != prototype_after:
        raise RuntimeError("prototype source changed during run")
    receipt = {"schema": "external.model-B.synthetic-receipt/1", "started_at_utc": started,
               "completed_at_utc": datetime.now(timezone.utc).isoformat(),
               "basis_commit": basis["head"], "basis_tree": basis["tree"],
               "basis_sha256": sha(basis_path), "command": command, "cwd": str(args.repo),
               "python": sys.version, "platform": platform.platform(), "exit_code": test.returncode,
               "tests_wall_s": test_wall, "tracked_files_count": len(tracked_before),
               "basis_differences_before": [p for p in tracked_before if tracked_before[p] != basis["files"][p]],
               "tracked_source_changes": changes, "runtime_source_sha256": {p: tracked_before[p] for p in source_paths},
               "prototype_sha256": prototype_before, "observations": observations, "timing": timing,
               "limits": ["No surface bridge, scientific adoption, real field or flight test.",
                          "No server, Git, repository writes or external request.",
                          "Unit tests block socket construction; query microbenchmark performs no I/O.",
                          "Existing geometric conversions, validation and support helpers are shared dependencies."]}
    (args.out / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"exit": test.returncode, "receipt": str(args.out / "receipt.json"),
                      "tracked_changes": changes, "test_wall_s": test_wall, "timing": timing}, ensure_ascii=False))
    if changes:
        raise RuntimeError("registered files changed during run; inspect ownership before claiming preserved")
    return test.returncode


if __name__ == "__main__":
    raise SystemExit(main())
