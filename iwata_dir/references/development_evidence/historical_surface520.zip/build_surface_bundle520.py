"""Join hash-bound real inputs into the explicitly selected runtime schema.

Offline, creates new outputs only. Original arrays are compared after gzip read.
Historical acquisition paths stay provenance, never runtime file dependencies.
"""
import copy, hashlib, json, pathlib, sys

P = pathlib.Path(__file__).resolve().parent
R = pathlib.Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
sys.path.insert(0, str(R))
from balloon_sim.environment.storage import read_json, write_bundle, load_weather
from balloon_sim.environment.jra3q import SURFACE_SCHEMA, SURFACE_PRODUCT
from balloon_sim.environment.model_surface import POLICY, JOIN_LEVELS

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p): return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

paths = [P/'normalization/run520'/name for name in ('strict-weather.json.gz', 'surface-diagnostics.json.gz', 'receipt.json')]
expected = ['2ef71b7b46ba08526da5568b82ad9dcd1f8116ca083dc5165257cbbf42780131', '31b58b12e0e22354eca4541cd1e8a9720d5ae24cb9917f7da92028b16b4c48d4', 'a11ac835de826dc9862b594b5b12de3c48589a524a64079e28911b843acd238a']
assert [sha(p) for p in paths] == expected
strict, diagnostics, normalization = map(read_json, paths)
assert diagnostics['schema'] == 'balloon.experiment.jra3q_surface_diagnostics/1'
assert diagnostics['product'] == 'jra3q.ncar.regular_gaussian.surface_analysis'
assert all(strict['axes'][k] == diagnostics['axes'][k] for k in diagnostics['axes'])
assert strict['metadata']['acquisition_receipt_sha256'] == diagnostics['metadata']['acquisition_receipt_sha256']
bundle = copy.deepcopy(strict)
bundle.update(schema=SURFACE_SCHEMA, product=SURFACE_PRODUCT,
              reconstruction=dict(policy=POLICY, join_model_levels=JOIN_LEVELS))
bundle['surface'].update(diagnostics['fields'])
bundle['metadata'].update(
    scope='Fixed real 3-UTC historical window with explicit provisional surface reconstruction; not a validated launch forecast',
    input_bindings={p.name:record(p) for p in paths},
    surface_analysis_diagnostic_heights_agl_m=diagnostics['diagnostic_height_agl_m'],
    evidence_archive='references/development_evidence/historical_surface520.zip',
    provenance_path_semantics='Absolute paths identify the acquisition experiment only. Runtime uses contained arrays; archived evidence provides the preserved inputs.',
    builder_sha256=sha(pathlib.Path(__file__)),
)
out = P/'runtime-fixture520'
out.mkdir(exist_ok=False)
target = out/'jra3q-weather.json.gz'
write_bundle(target, bundle)
saved = read_json(target)
assert saved == bundle
assert saved['fields'] == strict['fields'] and saved['axes'] == strict['axes'] and saved['hybrid'] == strict['hybrid']
assert all(saved['surface'][n] == v for n,v in strict['surface'].items())
assert all(saved['surface'][n] == v for n,v in diagnostics['fields'].items())
field = load_weather(target)
assert field.metadata['product'] == SURFACE_PRODUCT and field.metadata['reconstruction_policy'] == POLICY
config = read_json(P/'flights/B-step10/config.json')
config['label'] = '実JRA保存場・地上から30 kmを経て着地する診断例'
config['purpose'] = 'Real historical analysis and explicitly selected surface reconstruction. Artificial 30 km burst and illustrative balloon masses; not an operational launch plan or accuracy validation.'
ground = field.ground_altitude(config['launch']['time_utc'], config['launch']['latitude_deg'], config['launch']['longitude_deg'])
assert abs(ground-config['launch']['altitude_m']) < 1e-12
example = out/'jra3q-ground-flight.json'
example.write_text(json.dumps(config, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
assert [sha(p) for p in paths] == expected
receipt=dict(schema='surface-fixture520/1', inputs=[record(p) for p in paths], outputs=[record(target),record(example)], array_roundtrip_exact=True, field_class=type(field).__name__, ground_altitude_m=ground, source_arrays_unchanged=True)
(out/'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
