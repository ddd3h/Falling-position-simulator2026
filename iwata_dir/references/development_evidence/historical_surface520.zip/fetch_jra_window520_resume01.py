"""Explicit single continuation of fields4..11 after the preserved503 failure. Default is offline plan display; --execute is explicit.

No automatic retries/additional resume, redirects, credentials, proxy or repository/service writes.
Root must review and authorize execution separately from preparing this helper.
"""
from pathlib import Path
import datetime as dt
import hashlib
import importlib.util
import json
import os
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

P = Path(r'C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
A = P/'acquisition'; RUN = A/'run520-resume01'; PLAN = A/'request-plan520-resume01.json'
PLAN_SHA = '485aecb60ab089c2c115a583a4d76e92448d775efadbdd5615f4701c0af8df34'
VALIDATOR = P/'validate_jra_window520.py'


def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def encode(value): return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf8')
def write_new(path,value):
    with Path(path).open('xb') as stream: stream.write(encode(value))


def load_plan():
    raw = PLAN.read_bytes()
    if sha(raw) != PLAN_SHA: raise ValueError('Fixed request plan changed')
    plan = json.loads(raw)
    if len(plan['fields']) != 8: raise ValueError('Expected8 fixed continuation requests')
    if plan['prior_body_bytes']+sum(f['max_body_bytes'] for f in plan['fields']) > plan['total_body_cap_bytes']:
        raise ValueError('Even all response caps must fit the remaining cumulative budget')
    for i,f in enumerate(plan['fields'],4):
        u=urllib.parse.urlsplit(f['url'])
        if (f['ordinal']!=i or u.scheme!='https' or u.netloc!='tds.gdex.ucar.edu'
            or not u.path.startswith('/thredds/ncss/grid/files/g/d640000/') or u.fragment):
            raise ValueError('Request order/official endpoint differs')
        expected=2097152 if f['kind']=='model' else 131072
        if f['max_body_bytes']!=expected: raise ValueError('Fixed per-variable cap differs')
    return plan


def verify_inputs(plan):
    for row in plan['inputs']:
        data=Path(row['path']).read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
            raise ValueError('Pinned previous input differs: '+row['path'])


def validator():
    spec=importlib.util.spec_from_file_location('validate_jra_window520',VALIDATOR)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl): return None


def read_bounded(response,stream,cap):
    """Read no more than cap. At exact cap, do not read an extra byte or claim EOF."""
    count=0
    while count<cap:
        block=response.read1(min(65536,cap-count))
        if not block: return count,True
        count+=len(block)
        stream.write(block);stream.flush()
    return count,False


def worker(ordinal,request_hash):
    plan=load_plan(); field=plan['fields'][ordinal-4]
    out=RUN/f'{ordinal:02d}-{field["variable"]}'
    request_raw=(out/'request.json').read_bytes();request=json.loads(request_raw)
    if sha(request_raw)!=request_hash or request['field']!=field: raise ValueError('Worker request changed')
    if request['helper_sha256']!=sha(Path(__file__).read_bytes()): raise ValueError('Worker helper changed')
    begin=time.monotonic(); result={'started_at_utc':now(),'status':None,'transport_complete':False,
        'body_bytes_read':0,'error':None,'retry_count':0,'redirect_follow_count':0,'requests_attempted':0}
    try:
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);context.load_default_certs()
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect(),urllib.request.HTTPSHandler(context=context))
        req=urllib.request.Request(field['url'],method='GET',headers={'Accept':'application/x-netcdf','Accept-Encoding':'identity'})
        result['requests_attempted']=1
        try: response=opener.open(req,timeout=plan['socket_timeout_seconds'])
        except urllib.error.HTTPError as exc: response=exc
        with response:
            result['status']=response.code
            write_new(out/'response-headers.json',{'status':response.code,'url':response.geturl(),
                'headers':{k:response.headers.get(k) for k in ('Content-Type','Content-Length','Content-Encoding','Date','Last-Modified','ETag')}})
            if response.geturl()!=field['url']: raise ValueError('Final URL changed')
            if response.headers.get('Content-Encoding','identity') not in ('identity',''): raise ValueError('Encoded body refused')
            length=response.headers.get('Content-Length')
            if length is not None and (int(length)<0 or int(length)>field['max_body_bytes']):
                raise ValueError('Advertised body exceeds cap; body not read')
            with (out/'response.partial').open('xb') as stream:
                count,complete=read_bounded(response,stream,field['max_body_bytes'])
                os.fsync(stream.fileno())
            result.update(body_bytes_read=count,transport_complete=complete)
            if not complete: raise ValueError('Body cap reached; no EOF confirmed, no extra read')
            if length is not None and int(length)!=count: raise ValueError('Content-Length differs from complete stored body')
            if response.code!=200: raise ValueError('HTTP status '+str(response.code)+'; stop all later requests')
    except Exception as exc: result['error']=type(exc).__name__+': '+str(exc)
    result.update(finished_at_utc=now(),elapsed_seconds=time.monotonic()-begin,ssl_version=ssl.OPENSSL_VERSION)
    # Read count may be unavailable after abrupt termination/write failure; parent retains raw bytes and stops.
    write_new(out/'worker-result.json',result)
    return 0 if result['error'] is None and result['transport_complete'] and result['status']==200 else 2


def supervise(command,timeout):
    child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timedout=False;interrupted=False
    try: stdout,stderr=child.communicate(timeout=timeout)
    except (subprocess.TimeoutExpired,KeyboardInterrupt) as exc:
        timedout=isinstance(exc,subprocess.TimeoutExpired);interrupted=not timedout
        child.kill();stdout,stderr=child.communicate()
    return child.returncode,stdout,stderr,timedout,interrupted


def execute():
    plan=load_plan();verify_inputs(plan)
    previous_end=dt.datetime.fromisoformat(plan['resume']['previous_finished_at_utc'])
    if (dt.datetime.now(dt.timezone.utc)-previous_end).total_seconds()<60: raise ValueError('Wait at least60seconds after previous run; do not communicate yet')
    module=validator() # Existing SciPy only; fail before any network if unavailable.
    scripts={str(f):sha(f.read_bytes()) for f in (Path(__file__),VALIDATOR)}
    RUN.mkdir(exist_ok=False) # One fixed run. A partial/failed run cannot reset budget or retry automatically.
    start=now();begin=time.monotonic();rows=[];failure=None;prior=plan['prior_body_bytes'];used=prior
    write_new(RUN/'plan.json',plan)
    write_new(RUN/'execution-inputs.json',{'plan_sha256':PLAN_SHA,'scripts':scripts,'started_at_utc':start,'python':sys.executable})
    try:
        for field in plan['fields']:
            verify_inputs(plan)
            if load_plan()!=plan or any(sha(Path(p).read_bytes())!=h for p,h in scripts.items()):
                raise ValueError('Plan/helper/validator changed during run')
            if used+field['max_body_bytes']>plan['total_body_cap_bytes']: raise ValueError('Cumulative budget cannot reserve next response cap')
            ordinal=field['ordinal'];out=RUN/f'{ordinal:02d}-{field["variable"]}';out.mkdir()
            request={'schema':'jra-window-request/1','field':field,'plan_sha256':PLAN_SHA,
                'helper_sha256':scripts[str(Path(__file__))],'validator_sha256':scripts[str(VALIDATOR)],
                'cumulative_prior_body_bytes':used,'per_request_supervised_seconds':plan['deadline_seconds'],'started_at_utc':now()}
            write_new(out/'request.json',request)
            print(json.dumps({'event':'request_start','ordinal':ordinal,'variable':field['variable'],'cumulative_budget_charge_bytes':used}),flush=True)
            t=time.monotonic()
            code,stdout,stderr,timedout,interrupted=supervise([sys.executable,'-I','-B',str(Path(__file__)),
                '--worker',str(ordinal),sha((out/'request.json').read_bytes())],plan['deadline_seconds'])
            (out/'worker-stdout.txt').write_bytes(stdout);(out/'worker-stderr.txt').write_bytes(stderr)
            rawpath=out/'response.partial';raw=rawpath.read_bytes() if rawpath.exists() else b''
            wr=out/'worker-result.json';result=json.loads(wr.read_bytes()) if wr.exists() else {}
            # If timeout/write/read failure prevents exact accounting, charge the entire
            # reserved cap. Persisted partial bytes remain an observation, not wire usage.
            uncertain=timedout or interrupted or not result or result.get('body_bytes_read')!=len(raw) or bool(result.get('error'))
            charge=field['max_body_bytes'] if uncertain else len(raw)
            used+=charge
            row={'ordinal':ordinal,'variable':field['variable'],'url':field['url'],'raw_path':str(rawpath),
                'body_bytes':len(raw),'body_sha256':sha(raw),'supervised_wall_seconds':time.monotonic()-t,
                'worker':result,'returncode':code,'deadline_killed':timedout,'interrupted':interrupted,
                'budget_charge_bytes':charge,'body_accounting_uncertain':uncertain,
                'cumulative_budget_charge_bytes':used,'status':'failed'}
            rows.append(row)
            if code!=0 or timedout or interrupted or result.get('error') or not result.get('transport_complete') or result.get('status')!=200:
                write_new(out/'receipt.json',row)
                raise ValueError('Response failed; all later requests stopped: '+field['variable'])
            if len(raw)>field['max_body_bytes'] or result.get('body_bytes_read')!=len(raw): raise ValueError('Transport/raw byte accounting differs')
            verify_inputs(plan)
            try: validation=module.validate_response(rawpath,field,plan)
            except Exception as exc:
                validation={'schema':'jra-window-response-validation/1','status':'failed','error':type(exc).__name__+': '+str(exc),
                    'raw_path':str(rawpath),'raw_bytes':len(raw),'raw_sha256':sha(raw)}
            if validation['status']=='passed':
                if rawpath.read_bytes()!=raw: raise ValueError('Raw changed before acceptance')
                rawpath.rename(out/'response.nc')
                validation['validated_input_path']=str(rawpath)
                validation['raw_path']=str(out/'response.nc')
            write_new(out/'validation.json',validation)
            if validation['status']!='passed':
                row['validation_error']=validation['error'];write_new(out/'receipt.json',row)
                raise ValueError('Offline validation failed; all later requests stopped: '+field['variable'])
            # Validation records the input name and the accepted preserved name separately.
            row.update(status='passed',raw_path=str(out/'response.nc'),validation_sha256=sha((out/'validation.json').read_bytes()))
            write_new(out/'receipt.json',row)
            print(json.dumps({'event':'request_validated','ordinal':ordinal,'variable':field['variable'],'body_bytes':len(raw),'cumulative_budget_charge_bytes':used}),flush=True)
            if ordinal<11: time.sleep(plan['minimum_gap_seconds'])
    except BaseException as exc:
        failure=type(exc).__name__+': '+str(exc)
    unchanged=True
    try:
        verify_inputs(plan)
        unchanged=load_plan()==plan and all(sha(Path(p).read_bytes())==h for p,h in scripts.items())
    except Exception: unchanged=False
    status='passed' if failure is None and unchanged and len(rows)==8 and all(r['status']=='passed' for r in rows) else 'failed'
    receipt={'schema':'jra-window-acquisition-receipt/1','status':status,'started_at_utc':start,'finished_at_utc':now(),
        'total_supervised_wall_seconds':time.monotonic()-begin,'error':failure,'inputs_unchanged':unchanged,'plan_sha256':PLAN_SHA,
        'scripts':scripts,'responses':rows,'cost':{'prior_q_body_bytes':792,'prior_small_T_body_bytes':30052,
            'prior_failed_run_budget_charge_bytes':prior,'prior_preserved_body_bytes':plan['prior_preserved_body_bytes'],
                'new_preserved_body_bytes':sum(r['body_bytes'] for r in rows),
                'cumulative_preserved_body_bytes':plan['prior_preserved_body_bytes']+sum(r['body_bytes'] for r in rows),
                'cumulative_budget_charge_bytes':used,'cap_bytes':plan['total_body_cap_bytes'],
            'remaining_budget_bytes':plan['total_body_cap_bytes']-used,
            'meaning':'Preserved body bytes include failures/partials, separate from TLS/wire/headers/server I/O. Unknown consumption after timeout/read/write error charges the whole per-request cap; no later request or automatic reset.'},
        'not_attempted':[f['variable'] for f in plan['fields'][len(rows):]],
        'limits':['One historical-window input only; no ground closure, flight or meteorological accuracy claim.',
            'No coefficients fetched or inferred. GP static epoch preserved.',
            'No R/Git/service changes, retry, redirect, auth, or proxy.'],
        'field_to_raw':{r['variable']:r['raw_path'] for r in rows if r['status']=='passed'}}
    write_new(RUN/'receipt.json',receipt)
    if status=='passed':
        verify_inputs(plan)
        old=plan['resume']['reused_successes']
        combined={'schema':'jra-window-combined-receipt/1','status':'passed','scope':'Input acquisition only; not surface reconstruction or flight acceptance',
            'first_receipt_path':plan['resume']['previous_receipt'],'first_receipt_sha256':plan['resume']['previous_receipt_sha256'],
            'continuation_receipt_path':str(RUN/'receipt.json'),'continuation_receipt_sha256':sha((RUN/'receipt.json').read_bytes()),
            'field_to_raw':{**{r['variable']:r['raw_path'] for r in old},**receipt['field_to_raw']},
            'field_to_validation':{**{r['variable']:r['validation_path'] for r in old},**{r['variable']:str(Path(r['raw_path']).parent/'validation.json') for r in rows}},
            'reused_original_successes':old,'new_responses':rows,'cost':receipt['cost'],
            'prior_failure':'Original field4 HTTP503 complete190byte body; preserved unchanged. Only one expressly authorized continuation. No auto retry.',
            'limits':receipt['limits']}
        if len(combined['field_to_raw'])!=11:raise ValueError('Combined11 fields incomplete')
        write_new(RUN/'combined-receipt.json',combined)
    files=[f for f in RUN.rglob('*') if f.is_file()]
    write_new(RUN/'manifest.json',{'schema':'jra-window-raw-manifest/1','files':[{'path':f.relative_to(RUN).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(files)]})
    print(json.dumps({'status':status,'responses':len(rows),'cumulative_budget_charge_bytes':used,'error':failure}),flush=True)
    return 0 if status=='passed' else 2


if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--worker': sys.exit(worker(int(sys.argv[2]),sys.argv[3]))
    if sys.argv[1:]==['--execute']: sys.exit(execute())
    if sys.argv[1:] not in ([],['--plan']): raise SystemExit('Use --plan (offline) or --execute (explicitly authorized only)')
    p=load_plan();verify_inputs(p)
    print(json.dumps({'status':'offline_plan_only','requests':p['fields'],'prior_body_bytes':p['prior_body_bytes'],
        'maximum_cumulative_body_bytes':p['prior_body_bytes']+sum(f['max_body_bytes'] for f in p['fields']),
        'total_cap_bytes':p['total_body_cap_bytes'],'per_request_deadline_seconds':p['deadline_seconds']},ensure_ascii=False,indent=2))
