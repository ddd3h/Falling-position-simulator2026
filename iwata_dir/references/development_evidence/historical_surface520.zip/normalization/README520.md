# 0.52 比較用入力のオフライン正規化候補

初稿作成時は取得が全11変数に達しておらず、成功した5つの表層応答だけでは開始しなかった。その後の全11成功・主担当了承を受けた実行結果を末尾へ追記した。rawの取得・再試行・R/Git・稼働サービスの変更は本helperに含まない。

## 受け入れる統合票

統合票は `acquisition/combined-receipt520.json` とする。attemptの外に置き、全attempt manifestを含めても循環参照しない。必要字段は次の通り。

```json
{
  "schema": "jra-window-combined-receipt/1",
  "status": "passed",
  "source_receipts": [{"path": "各attempt/receipt.json", "bytes": 0, "sha256": "..."}],
  "source_manifests": [{"path": "各attempt/manifest.json", "bytes": 0, "sha256": "..."}],
  "successful_fields": [{
    "variable": "tmp2m-hgt-an-gauss",
    "raw": {"path": "各attempt/01-tmp2m-hgt-an-gauss/response.nc", "bytes": 0, "sha256": "..."},
    "validation": {"path": "同じ親/validation.json", "bytes": 0, "sha256": "..."}
  }]
}
```

数値0や`...`は形式説明であり実行入力ではない。`successful_fields` は全11を一意に含み、各元receiptのpassed行と対応させる。503/通信失敗の原receipt・partialもmanifest経由で固定するが、科学配列には使用しない。各run全ファイル集合とbytes/hashを処理前後で照合する。統合票のSHA256は主担当から明示的に渡す。

## 変換と出力

- 全3原UTC、100モデル面、20緯度×46経度を維持し、緯度だけ昇順へ並べ替える。未取得値の補間、欠測補完、qのclampはしない。
- 原Float32はPython数値への無損失変換でJSON化する。保存再読後の全Float32 bit列を、緯度並替え後の原NetCDF値と照合する（符号付きzeroも区別）。値の物理変換は地表GP/g0のみ。
- 係数は旧 `load_fixture(R)` が検証する固定原本のprovenanceから取得し、現在の `COEFFICIENT_SHA256` へ照合。現役libraryから旧toolをimportする変更は行わない。
- `normalization/run520/strict-weather.json.gz` は現役 `balloon.weather.jra3q_model/1`。静的GPの1947出典・元単位をmetadataに保持したまま、GP/g0の同一地表を3UTCへ反復する。新しい下層橋は含まない。
- `surface-diagnostics.json.gz` は別の実験文書で、schema `balloon.experiment.jra3q_surface_diagnostics/1`、product `jra3q.ncar.regular_gaussian.surface_analysis`。`fields` はprototypeへ渡す4配列。元静的GPも独立した1947/単位付き配列として残す。
- `join-diagnostics.json` はlevel1/2の幾何AGLの全2760原列での最小・最大と所在、p/T/q=level1・u/v=level2の指定anchorより上かを示す。未支持ならその数を記録し、別のjoinへ自動変更しない。有効な厳密bundleの作成と、橋の採用可能性は別判定。
- `receipt.json` の `paired_outputs.strict_weather / surface_diagnostics` はpath/bytes/sha256/schema/productを持つ。`common_axes` はtime/lat/lon、`common_axes_equal` は保存再読後の完全一致。時刻は `+00:00` 形式。両出力は同じ `acquisition_receipt_sha256` を持つ。モデル解析と表層解析のproduct文字列を同一へ偽装しない。

write/read/field構築とloadの計時を分ける。Windows peak working setは**この正規化プロセス開始から各段階までの高水準**であり、差分メモリ・飛行RSS・通信量ではない。JSON原値／再読値／二つのfieldを同時保持する検査の費用も含む。

## 実行条件

全11成功の統合票と主担当のコード確認後、P470の既存Pythonで `--execute --receipt <統合票> --receipt-sha256 <実SHA>` を明示する。出力runが既存なら拒否する。途中失敗時に出力を削除して成功に見せる処理はない。

初稿提出時点の実施はAST構文解析だけだった。以下はその後の別時点の実績である。

## 実行結果（2026-09-29 22:51:05–22:51:13 UTC）

主担当が了承したhelper `c915aa412de658c0316f8951dd9ccbd6e71a08a0631fb5ec176519c799bb0c36` と、全11成功の統合票 `fd54e06d61a75beec67b494bb234c0bf9b1264dc0ca0a80a524286b17124cc93` を明示して一度実行し、終了コード0となった。命令出力は `normalize520-01.log`、実績は `run520/receipt.json`（SHA256 `a11ac835de826dc9862b594b5b12de3c48589a524a64079e28911b843acd238a`）へ保存した。

| 検査・費用 | 実測／結果 |
|---|---|
| 原Float32の保存再読 | 1,394,720値すべてbit一致。座標・GP/g0・runtime field再読も一致 |
| 原本保持 | 成功と失敗を含む全attempt manifestの集合・bytes/hash、原要求票、R入力とhelperが処理前後で不変 |
| 第1面の幾何AGL | 7.4309234347–8.2930936793m（3UTC×20×46=2,760列） |
| 第2面の幾何AGL | 26.0113836931–28.3602622306m（同母数） |
| 固定join | p/T/q=1、u/v=2で全列anchorより上。native風level1は全2,760列が10m以下 |
| 総経過時間 | 7.8104秒（取得を含まず、原票検査から保存再読・前後照合まで） |
| gzip二文書の書込 | 3.2599秒 |
| `load_weather` | 1.7957秒（gzip展開/JSON読込/strict field構築を含む） |
| Windows peak working set | load/readback終了時点までの高水準245,985,280bytes、約234.6MiB。プロセス終了瞬間や飛行処理の値ではない |

`strict-weather.json.gz` は6,814,307bytes、`surface-diagnostics.json.gz` は79,462bytes。完全SHAとpaired axes/productはreceiptに記録。固定joinが成立したことを仮想列の全補間点・下層精度・保存性・地上完飛行の受入へ広げない。比較用入力として主担当のrunnerへ渡した。
