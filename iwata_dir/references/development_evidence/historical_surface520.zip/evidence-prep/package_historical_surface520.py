"""Explicit external evidence packaging. Inspect does not create an archive.

Pack requires a separately authored root binding to the exact fresh plan/helper.
No repository, Git, database, provider, calculation or test mutation occurs here.
"""
from pathlib import Path, PurePosixPath
import argparse, datetime as dt, gzip, hashlib, io, json, os, re, zipfile

HERE = Path(__file__).resolve().parent
P = HERE.parent
R = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
BASE = 'f94027cec2ff56b732af7bd11b2df26bdd9513a5'
MAX_FILE = 32 * 1024 * 1024
MAX_GZIP = 128 * 1024 * 1024
MAX_TOTAL = 96 * 1024 * 1024
GROUPS = {
    'acquisition_design_and_failures': [
        'fetch_jra_window520.py', 'fetch_jra_window520_resume01.py', 'fetch_jra_window520_resume02.py',
        'validate_jra_window520.py', 'acquisition/request-plan520.json', 'acquisition/request-plan520-resume01.json',
        'acquisition/request-plan520-resume02.json', 'acquisition/combined-receipt520.json',
        'acquisition/acquisition-summary520.json', 'acquisition/acquisition-summary520.md',
        'acquisition/README520.md', 'acquisition/helper-review520-before-progress-label.json',
        'acquisition/helper-review520.json', 'acquisition/interruption-review520.json',
        'acquisition/interruption-review520.md', 'acquisition/resume01-helper.diff',
        'acquisition/resume01-review.json', 'acquisition/resume02-helper.diff',
        'acquisition/test_helper520.py', 'acquisition/test_resume520.py', 'acquisition/test_final_resume520.py',
        'acquisition/offline-test520-01.log', 'acquisition/offline-test520-02.log', 'acquisition/offline-test520-03.log',
        'acquisition/offline-resume520-01.log', 'acquisition/offline-final-resume520-01.log',
    ],
    'normalized_pair': ['normalize_window520.py', 'normalization/README520.md', 'normalization/normalize520-01.log',
        'normalization/run520/receipt.json', 'normalization/run520/join-diagnostics.json',
        'normalization/run520/strict-weather.json.gz', 'normalization/run520/surface-diagnostics.json.gz'],
    'prototype_and_counterexamples': ['surface_prototype.py', 'test_surface_prototype.py', 'compare_flights520.py',
        'model-prototype/compare_surface.py', 'model-prototype/manifest.json', 'model-prototype/native_horizontal_first.py',
        'model-prototype/README.md', 'model-prototype/run_prototype.py', 'model-prototype/surface-before-02.txt',
        'model-prototype/surface-tests-before-02.txt', 'model-prototype/surface-repair02-receipt.json',
        'model-prototype/surface-repair02.patch', 'model-prototype/test_native_horizontal_first.py',
        'model-prototype/surface-compare-01.stderr', 'model-prototype/surface-compare-01.stdout',
        'model-prototype/surface-compare-02.stderr', 'model-prototype/surface-compare-02.stdout',
        'model-prototype/surface-root-02.stderr', 'model-prototype/surface-root-02.stdout',
        'model-prototype/run-01/receipt.json', 'model-prototype/run-01/tests.stderr', 'model-prototype/run-01/tests.stdout',
        'root-prototype-tests01/receipt.json', 'root-prototype-tests01/stderr.txt', 'root-prototype-tests01/stdout.txt'],
    'interpretation_and_independent_checks': ['design-intent520.md',
        'surface-research/record_sources520.py', 'surface-research/source-evidence520.json',
        'surface-research/surface-primary-review520.md', 'analysis-review/decision-review520.json',
        'analysis-review/decision-review520.md', 'analysis-review/independent_values520.py',
        'analysis-review/independent-values520.json', 'analysis-review/theory-addition-review520.json',
        'analysis-review/docs-review520.json', 'analysis-review/docs-final-reread520.json'],
    'runtime_and_tests': ['build_surface_bundle520.py', 'runtime-fixture520/receipt.json',
        'runtime-fixture520/jra3q-ground-flight.json', 'runtime-cross06-config.json', 'runtime-implementation520.json',
        'runtime-replay520.json', 'runtime-test520-01.log', 'runtime-test520-02.log',
        'runtime-tests/test01.xml', 'runtime-tests/test02.xml', 'pytest-root.xml', 'pytest-root-normal.xml',
        'pytest-root-failed-nodes.txt'],
    'saved_comparison_page': ['review_results520.py', 'review/index.html', 'review/plotly.min.js', 'review/PLOTLY_LICENSE.txt'],
    'structural_candidate': ['update_index520.py', 'index-candidate520.json', 'index-candidate520.patch', 'index-evidence520.json'],
    'packaging_definition': ['evidence-prep/package_historical_surface520.py', 'evidence-prep/README520.md'],
}
# These are finite explicit attempts/cases, not recursive wildcard enrollment.
ATTEMPTS = {
    'acquisition/run520': [('01-tmp2m-hgt-an-gauss', 'passed'), ('02-spfh2m-hgt-an-gauss', 'passed'),
        ('03-ugrd10m-hgt-an-gauss', 'passed'), ('04-vgrd10m-hgt-an-gauss', 'http503')],
    'acquisition/run520-resume01': [('04-vgrd10m-hgt-an-gauss', 'passed'), ('05-pres-sfc-an-gauss', 'passed'),
        ('06-tmp-hyb-an-gauss', 'connect_failure')],
    'acquisition/run520-resume02': [('06-tmp-hyb-an-gauss', 'passed'), ('07-spfh-hyb-an-gauss', 'passed'),
        ('08-ugrd-hyb-an-gauss', 'passed'), ('09-vgrd-hyb-an-gauss', 'passed'),
        ('10-hgt-hyb-an-gauss', 'passed'), ('11-gp-sfc-cn-gauss', 'passed')],
}
GROUPS['raw_attempts'] = []
for folder, fields in ATTEMPTS.items():
    GROUPS['raw_attempts'] += [folder + '/' + n for n in ('execution-inputs.json', 'manifest.json', 'plan.json', 'receipt.json')]
    for field, status in fields:
        names = ['request.json', 'receipt.json', 'worker-result.json', 'worker-stdout.txt', 'worker-stderr.txt']
        if status == 'passed':
            names += ['response-headers.json', 'response.nc', 'validation.json']
        elif status == 'http503':
            names += ['response-headers.json', 'response.partial']
        GROUPS['raw_attempts'] += [folder + '/' + field + '/' + n for n in names]
GROUPS['prototype_flights'] = [f'flights/{case}/{name}' for case in ('strict-step10', 'A-step10', 'B-step10', 'B-step5')
                                for name in ('config.json', 'receipt.json', 'result.json')]
GROUPS['runtime_flights'] = [folder + '/' + name for folder in ('runtime-flight520', 'runtime-cross06-flight520')
    for name in ('input.json', 'manifest.json', 'provenance.json', 'report.html', 'result.json', 'trajectory.csv', 'trajectory.geojson')]
REFERENCES = [
    'references/flight_fixture/jra3q-weather.json.gz', 'examples/jra3q-ground-flight.json',
    'references/jra3q_model_fixture/source_bundle.json', 'tools/normalize_jra3q_model_fixture.py',
    'tools/normalize_gfs_fixture.py', 'balloon_sim/environment/fields.py', 'balloon_sim/environment/model_levels.py',
    'balloon_sim/environment/model_surface.py', 'balloon_sim/environment/jra3q.py', 'balloon_sim/environment/storage.py',
    'balloon_sim/flight/config.py', 'balloon_sim/flight/models.py', 'balloon_sim/flight/events.py',
    'balloon_sim/flight/numerics.py', 'balloon_sim/flight/trajectory.py', 'balloon_sim/results/export.py',
    'balloon_sim/results/report.py', 'tests/test_jra3q_surface_field.py', 'tests/test_jra3q_flight_field.py',
]
PATTERNS = {
    'google_key': rb'AIza[0-9A-Za-z_-]{35}',
    'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    'github_token': rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
    'aws_access_key': rb'(?:AKIA|ASIA)[A-Z0-9]{16}',
    'authorization_bearer': rb'(?i)Authorization\s*[:=]\s*["\x27]?Bearer\s+[A-Za-z0-9._~-]{16,}',
    'credential_json': rb'(?i)["\x27](?:api_key|access_token|refresh_token|client_secret|password)["\x27]\s*:\s*["\x27][A-Za-z0-9_./+=~-]{12,}["\x27]',
    'url_credential': rb'https?://[^\s/"\x27]+:[^\s/@"\x27]+@',
}

def sha(data): return hashlib.sha256(data).hexdigest()
def enc(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def load(data): return json.loads(data.decode('utf-8-sig'))
def fingerprint(data): return {'bytes': len(data), 'sha256': sha(data)}

def safe(root, name):
    name = str(name).replace('\\', '/')
    rel = PurePosixPath(name)
    if rel.is_absolute() or ':' in name or '..' in rel.parts or not rel.parts:
        raise ValueError('invalid relative path')
    path = root.joinpath(*rel.parts)
    if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
        raise ValueError('path escaped declared root')
    return path

def read(path):
    if not path.is_file() or path.stat().st_size > MAX_FILE:
        raise ValueError('missing/oversized input: ' + str(path))
    data = path.read_bytes()
    if len(data) > MAX_FILE: raise ValueError('input grew beyond cap')
    return data

def unzip_gzip(data):
    with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
        result = stream.read(MAX_GZIP + 1)
    if len(result) > MAX_GZIP: raise ValueError('gzip payload exceeds declared scan cap')
    return result

def scan(payloads):
    for name, data in payloads.items():
        scanned = unzip_gzip(data) if name.endswith('.gz') else data
        for rule, pattern in PATTERNS.items():
            if re.search(pattern, scanned):
                raise ValueError('credential-like content requires root review: ' + name + ' / ' + rule)
    return {'rules': list(PATTERNS), 'matches': [], 'files_scanned': len(payloads),
            'limits': 'Finite byte patterns including gzip payloads; not a proof of absence of all secrets. No key stores or browser state read.'}

def names():
    result = [name for group in GROUPS.values() for name in group]
    if len(result) != len(set(result)): raise ValueError('duplicate member enrollment')
    return sorted(result)

def collect():
    result = {n: read(safe(P, n)) for n in names()}
    if sum(map(len, result.values())) > MAX_TOTAL: raise ValueError('package input exceeds cap')
    return result

def resolve_included(path, data):
    absolute = Path(path).resolve()
    if not absolute.is_relative_to(P.resolve()): raise ValueError('receipt refers outside P520')
    name = absolute.relative_to(P.resolve()).as_posix()
    if name not in data: raise ValueError('receipt member omitted from explicit plan: ' + name)
    return name

def verify_row(row, data):
    name = resolve_included(row['path'], data)
    if fingerprint(data[name]) != {k: row[k] for k in ('bytes', 'sha256')}:
        raise ValueError('receipt payload mismatch: ' + name)
    return name

def validate(data, refs):
    combined = load(data['acquisition/combined-receipt520.json'])
    if combined['schema'] != 'jra-window-combined-receipt/1' or combined['status'] != 'passed':
        raise ValueError('combined acquisition is not passed')
    fields = combined['successful_fields']
    if len(fields) != 11 or len({x['variable'] for x in fields}) != 11: raise ValueError('expected eleven distinct raw fields')
    for row in combined['source_receipts'] + combined['source_manifests']:
        verify_row(row, data)
    for item in fields:
        verify_row(item['raw'], data); verify_row(item['validation'], data)
    for folder in ATTEMPTS:
        m = load(data[folder + '/manifest.json'])
        for row in m['files']:
            n = folder + '/' + row['path']
            if n not in data or fingerprint(data[n]) != {k: row[k] for k in ('bytes', 'sha256')}:
                raise ValueError('raw manifest mismatch or omission: ' + n)
    normalized = load(data['normalization/run520/receipt.json'])
    if normalized['status'] != 'passed': raise ValueError('normalization not passed')
    verify_row(normalized['source_receipt'], data)
    for row in normalized['outputs']: verify_row(row, data)
    pair = normalized['paired_outputs']
    strict = load(unzip_gzip(data[verify_row(pair['strict_weather'], data)]))
    surface = load(unzip_gzip(data[verify_row(pair['surface_diagnostics'], data)]))
    for document, row in ((strict, pair['strict_weather']), (surface, pair['surface_diagnostics'])):
        if any(document[k] != row[k] for k in ('schema', 'product')): raise ValueError('normalized schema/product mismatch')
    if any(strict['axes'][k] != surface['axes'][k] for k in ('time_utc', 'latitude_deg', 'longitude_deg')):
        raise ValueError('paired axes mismatch')
    fixture = load(data['runtime-fixture520/receipt.json'])
    for row in fixture['inputs']: verify_row(row, data)
    # Joint bundle is deliberately referenced once in the repository, not copied.
    for row, target in zip(fixture['outputs'], ('references/flight_fixture/jra3q-weather.json.gz', 'examples/jra3q-ground-flight.json')):
        if refs[target] != {k: row[k] for k in ('bytes', 'sha256')}: raise ValueError('runtime fixture reference mismatch')
    manifests = []
    for folder in ('runtime-flight520', 'runtime-cross06-flight520'):
        m = load(data[folder + '/manifest.json'])
        if m['schema'] != 'balloon.flight.output_manifest/1': raise ValueError('unknown output manifest')
        for name, row in m['files'].items():
            full = folder + '/' + name
            if full not in data or fingerprint(data[full]) != row: raise ValueError('flight output mismatch: ' + full)
        if set(m['files']) != {'input.json','provenance.json','report.html','result.json','trajectory.csv','trajectory.geojson'}:
            raise ValueError('unexpected output manifest set')
        result = load(data[folder + '/result.json'])
        if m['complete'] != result['complete'] or m['status'] != result['status']: raise ValueError('flight marker/result disagree')
        manifests.append({'folder': folder, 'status': result['status'], 'records': len(result['records']), 'six_outputs_verified': True})
    replay = load(data['runtime-replay520.json'])
    for row in replay['inputs']: verify_row(row, data)
    if fingerprint(data['review/plotly.min.js']) != {k: replay['plotly'][k] for k in ('bytes','sha256')}:
        raise ValueError('Plotly replay identity differs')
    # Review markup may receive later editorial correction; its current bytes are
    # bound by this fresh plan and its earlier observation remains unmodified.
    prior_report = {k: replay['report'][k] for k in ('bytes','sha256')}
    implementation = load(data['runtime-implementation520.json'])
    for row in implementation['current_sources']:
        path = Path(row['path']).resolve()
        if not path.is_relative_to(R.resolve()): raise ValueError('implementation source outside repository')
        name = path.relative_to(R.resolve()).as_posix()
        if refs.get(name) != {k:row[k] for k in ('bytes','sha256')}: raise ValueError('implementation receipt source differs: '+name)
    for run in implementation['test_runs']:
        verify_row(run['junit'], data); verify_row(run['log'], data)
    prototype_outputs=[]
    for case in ('strict-step10','A-step10','B-step10','B-step5'):
        folder='flights/'+case; record=load(data[folder+'/receipt.json']); result=load(data[folder+'/result.json'])
        if (sha(data[folder+'/config.json'])!=record['config_sha256']
            or sha(data[folder+'/result.json'])!=record['result_sha256']
            or result['summary']!=record['result_summary'] or result['status']!=record['status']):
            raise ValueError('prototype input/result receipt mismatch: '+case)
        prototype_outputs.append({'case':case,'status':result['status'],'records':len(result['records'])})
    return {'raw_fields': 11, 'attempt_manifests': 3, 'normalized_pair_verified': True,
            'runtime_fixture_matches_repository': True, 'runtime_output_manifests': manifests,
            'prototype_outputs':prototype_outputs,'implementation_source_and_test_log_hashes_verified':True,
            'historical_page_observation': prior_report, 'page_current': fingerprint(data['review/index.html']),
            'page_equals_historical_observation': prior_report == fingerprint(data['review/index.html']),
            'implementation_receipt_schema': implementation['schema'],
            'limits': 'Packaging verifies preserved bytes and declared joins; does not rerun scientific queries, flights, tests or browser observation.'}

def references(): return {n: fingerprint(read(safe(R, n))) for n in REFERENCES}

def inspect(output):
    if output.exists(): raise FileExistsError('keep prior plan; use a new external plan name')
    data = collect(); refs = references()
    validation = validate(data, refs)
    secrets = scan(data)
    rows = {n: {'group': next(g for g, values in GROUPS.items() if n in values), **fingerprint(b)} for n, b in data.items()}
    if any(fingerprint(read(safe(P, n))) != fingerprint(b) for n, b in data.items()) or refs != references():
        raise ValueError('inputs changed while planning')
    plan = {'schema':'historical-surface520-plan/1','status':'candidate_not_pack_authorized','created_at_utc':now(),
            'basis_commit':BASE,'helper_sha256':sha(read(Path(__file__))), 'input_count':len(rows),
            'input_bytes':sum(len(x) for x in data.values()), 'rows':rows,'repository_references':refs,
            'validation':validation,'secret_scan':secrets,
            'exclusions':['Repository source/bundle are references, not duplicated; only new scientific observations are preserved here.',
                          'No basis-repo tree, Python/Node environment, live databases, credentials, browser state, guide build or future metadata/Git receipts.',
                          'Earlier coefficient/P510 source records remain references in preserved metadata; this is not a portable environment.']}
    with output.open('xb') as stream: stream.write(enc(plan))
    print(json.dumps({'path':str(output),'sha256':sha(read(output)),'inputs':len(rows),'bytes':plan['input_bytes'],
                      'validation':validation,'archive_created':False},ensure_ascii=False))

def pack(plan_path, plan_sha, binding_path, binding_sha):
    # Read each control once, preserve those verified bytes, then compare again
    # before final publication. Root meaning/approval is never generated here.
    plan_raw, binding_raw = read(plan_path), read(binding_path)
    if sha(plan_raw) != plan_sha or sha(binding_raw) != binding_sha: raise ValueError('control hash mismatch')
    plan, binding = load(plan_raw), load(binding_raw)
    helper_sha = sha(read(Path(__file__)))
    if (plan['schema'] != 'historical-surface520-plan/1' or plan['basis_commit'] != BASE
        or plan['helper_sha256'] != helper_sha or set(plan['rows']) != set(names())): raise ValueError('plan changed from explicit helper')
    if (binding.get('approved') is not True or binding.get('scope') != 'create-external-historical-surface520-archive'
        or binding.get('plan_sha256') != plan_sha or binding.get('helper_sha256') != helper_sha
        or not isinstance(binding.get('review'), str) or not binding['review'].strip()): raise ValueError('explicit root binding required')
    output, receipt_path = HERE/'historical_surface520.zip', HERE/'archive-receipt520.json'
    partial = output.with_suffix('.zip.partial')
    if any(p.exists() for p in (output, partial, receipt_path)): raise FileExistsError('preserve prior archive/partial/receipt')
    start = now(); data = collect(); refs = references()
    for name, value in data.items():
        if fingerprint(value) != {k:plan['rows'][name][k] for k in ('bytes','sha256')}: raise ValueError('input changed since root plan: '+name)
    if refs != plan['repository_references']: raise ValueError('repository reference changed')
    validation = validate(data, refs); secrets = scan(data)
    generated = {
        'README.md':data['evidence-prep/README520.md'],
        'package-plan.json':plan_raw,'package-root-binding.json':binding_raw,
        'source-references.json':enc({'schema':'historical-surface520-references/1','basis_commit':BASE,
            'current_repository_files':refs,'limits':'These actual bytes remain in the private repository. No future candidate commit or whole-environment portability is asserted.'}),
        'package-validation.json':enc({'validation':validation,'secret_scan':secrets}),
    }
    payloads = data | generated
    manifest = {'schema':'historical-surface520-manifest/1','started_at_utc':start,
        'members':{n:{**fingerprint(b),'kind':'original_preserved' if n in data else 'packaging_record'} for n,b in sorted(payloads.items())},
        'self_excluded':'Manifest has no self hash. External receipt includes all members including this manifest.'}
    payloads['package-manifest.json'] = enc(manifest)
    scan(payloads)
    with zipfile.ZipFile(partial,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for n,b in sorted(payloads.items()):
            info=zipfile.ZipInfo(n,date_time=(2026,9,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,b)
    members={}
    with zipfile.ZipFile(partial) as archive:
        stored=archive.namelist()
        if len(stored)!=len(set(stored)) or set(stored)!=set(payloads) or archive.testzip() is not None:
            raise ValueError('ZIP member set/CRC failure; partial retained')
        for n in stored:
            b=archive.read(n)
            if b!=payloads[n]: raise ValueError('ZIP member bytes differ: '+n)
            members[n]=fingerprint(b)
    if (any(fingerprint(read(safe(P,n)))!=fingerprint(b) for n,b in data.items()) or refs!=references()
        or read(plan_path)!=plan_raw or read(binding_path)!=binding_raw or sha(read(Path(__file__)))!=helper_sha):
        raise ValueError('input/control changed during pack; partial retained')
    if output.exists(): raise FileExistsError('final archive concurrently created')
    os.rename(partial,output)
    receipt={'schema':'historical-surface520-archive-receipt/1','status':'verified_external_candidate',
        'started_at_utc':start,'finished_at_utc':now(),'path':str(output),'bytes':output.stat().st_size,
        'sha256':sha(output.read_bytes()),'plan_sha256':plan_sha,'root_binding_sha256':binding_sha,
        'helper_sha256':helper_sha,'member_count':len(members),'members':members,'crc':'passed',
        'all_original_bytes_and_references_unchanged':True,'validation':validation,'secret_scan':secrets,
        'limits':['No repository write, scientific computation, test execution, HTTP, DB access, browser or Git operation.',
                  'Final guide/publication, metadata and C1/C2 receipts follow outside this archive; no circular collection.']}
    with receipt_path.open('xb') as stream: stream.write(enc(receipt))
    print(json.dumps({k:receipt[k] for k in ('status','path','bytes','sha256','member_count')},ensure_ascii=False))

def main():
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='action',required=True)
    a=sub.add_parser('inspect');a.add_argument('--output',type=Path,required=True)
    a=sub.add_parser('pack');a.add_argument('--plan',type=Path,required=True);a.add_argument('--plan-sha256',required=True)
    a.add_argument('--root-binding',type=Path,required=True);a.add_argument('--root-binding-sha256',required=True)
    args=parser.parse_args()
    for name in ('output','plan','root_binding'):
        p=getattr(args,name,None)
        if p is not None and not p.resolve().is_relative_to(HERE.resolve()): raise ValueError('controls/output must stay in evidence-prep')
    if args.action=='inspect':inspect(args.output)
    else:pack(args.plan,args.plan_sha256,args.root_binding,args.root_binding_sha256)

if __name__=='__main__':main()
