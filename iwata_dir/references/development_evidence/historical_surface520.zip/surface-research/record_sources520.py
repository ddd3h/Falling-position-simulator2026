"""Read-only source receipts; writes only this surface-research directory."""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
P520 = OUT.parent
P510 = Path('C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
R = Path('C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
OLD = Path('C:/Users/genia/.codex/visualizations/2026/09/21/01a0c475-9ac7-7852-85a1-e3a4f3188dfa/p1-model-weather-0.17.0/model-level-research')

def fingerprint(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

basis = json.loads((P520 / 'basis520.json').read_text(encoding='utf-8-sig'))
sources = []
for relative, scope in [
    ('docs/WEATHER_DATA_GUIDE.md', 'Current JRA and surface-support sections only'),
    ('balloon_sim/environment/jra3q.py', 'Full-pressure reconstruction and binding; complete module'),
    ('balloon_sim/environment/model_levels.py', 'Strict column support and ground/height conventions; complete module'),
    ('references/jra3q_model_fixture/source_bundle.json', 'Provenance and stored source identities, not a fresh numeric verification'),
]:
    row = fingerprint(R / relative)
    row.update(relative_path=relative, read_scope=scope, basis_sha256=basis['files'][relative])
    row['matches_basis'] = row['sha256'] == row['basis_sha256']
    sources.append(row)

originals = [fingerprint(P510 / 'surface-connection-independent-review510.md'),
             fingerprint(P510 / 'next-window-plan/surface-connection-options510.md'),
             fingerprint(P510 / 'next-window-plan/metadata-receipt.json')]
metadata = json.loads((P510 / 'next-window-plan/metadata-receipt.json').read_text(encoding='utf-8-sig'))
for variable in ['tmp2m-hgt-an-gauss', 'spfh2m-hgt-an-gauss', 'ugrd10m-hgt-an-gauss',
                 'vgrd10m-hgt-an-gauss', 'hgt-hyb-an-gauss', 'pres-sfc-an-gauss', 'gp-sfc-cn-gauss']:
    row = fingerprint(P510 / 'next-window-plan' / (variable + '.das'))
    saved = next(item for item in metadata['rows'] if item['variable'] == variable and item['url'].endswith('.das'))
    assert row['bytes'] == saved['bytes'] and row['sha256'] == saved['sha256'], variable
    row.update(url=saved['url'], original_observed_at=metadata['observed_at'], receipt_matches=True)
    originals.append(row)
body = fingerprint(OLD / 'inherited-sources/jma-model-format.body')
http_path = OLD / 'inherited-sources/jma-model-format.http.json'
http = json.loads(http_path.read_text(encoding='utf-8-sig'))
assert body['sha256'] == http['body_sha256'] and body['bytes'] == http['body_bytes']
body.update(url=http['url'], original_start_utc=http['start_utc'], original_end_utc=http['end_utc'], receipt_matches=True)
originals.extend([body, fingerprint(http_path)])

report = {
    'schema': 'balloon.surface-primary-source-review/1',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'research_date_jst': '2026-09-30',
    'basis_head': basis['head'], 'basis_tree': basis['tree'],
    'basis_receipt': fingerprint(P520 / 'basis520.json'),
    'status': 'bounded research and unadopted design advice; no scientific adoption',
    'repo_sources': sources,
    'saved_originals': originals,
    'web_reads': [
        {'url': http['url'], 'sections': ['4.1 printed p11', '4.5 printed p13', '5.1 printed p21', '8.1 printed pp25-27'],
         'read_date_jst': '2026-09-30', 'raw_original_retained': body['path'],
         'claim': 'Parameter/height/pressure definition only; does not prescribe the proposed bridge'},
        {'url': 'https://gdex.ucar.edu/datasets/d640000/', 'sections': ['Dataset identity and regular Gaussian grid'],
         'read_date_jst': '2026-09-30', 'raw_original_retained': None,
         'claim': 'NCAR product identity; remapping details are bound to the saved DAS originals above'},
        {'url': 'https://www.jma.go.jp/jma/kishou/books/kisetutext/34_2/all.pdf',
         'sections': ['Table 3.1-2 printed p17 / PDF page index3'], 'read_date_jst': '2026-09-30',
         'raw_original_retained': None,
         'claim': 'GSM surface-layer physics context, not a reconstruction algorithm for anl_surf'},
        {'url': 'https://www.jma.go.jp/jma/jma-eng/jma-center/nwp/outline2019-nwp/pdf/outline2019_03.pdf',
         'sections': ['3.2.6 GSM surface fluxes'], 'read_date_jst': '2026-09-30',
         'raw_original_retained': None, 'used_in_note': False,
         'limit': 'MSM screen-temperature 1.5m passage is a different model and is not evidence for JRA 2m'},
    ],
    'classification': {
        'established': ['anl_surf: T/q at2m and u/v at10m above ground; analysis data',
                        'model HGT gpm; SP at surface; invariant GP',
                        'original-column hybrid full pressure uses the JMA formula',
                        'NCAR regular Gaussian values are remapped products'],
        'design_approximations': ['originalUTC horizontal virtual columns then common absoluteH queries then time interpolation',
                                  'B1 pressure: original-column fullpressure first, horizontal mean second',
                                  'virtual-ground geometricAGL anchors under the existing spherical height convention',
                                  'constant below2m/10m and H-linear bridge to field-specific fixed native joins',
                                  'exclude only the native wind nodes covered by the wind reconstruction'],
        'unproven': ['hydrostatic or conservative reconstruction', 'JMA-recommended interpolation',
                    'accuracy superiority or optimal join levels', 'exact surface-analysis diagnostic reproduction',
                    'general continuity outside the fixed-join supported window', 'ground flight or real obstacle accuracy'],
    },
    'root_design_update_incorporated': 'Fixed field-specific native join ID across all UTCs and columns; reject unsupported anchor order; expected levels1/2 are not yet verified on new arrays',
    'no_actions': ['no repo/Git writes', 'no new weather-array acquisition', 'no experiments',
                   'no credentials', 'no review stamp changes'],
    'note': fingerprint(OUT / 'surface-primary-review520.md'),
    'helper': fingerprint(Path(__file__)),
}
(OUT / 'source-evidence520.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': fingerprint(OUT / 'source-evidence520.json'), 'note': report['note'],
                  'basis_matches': all(row['matches_basis'] for row in sources),
                  'saved_originals_verified': len(originals), 'note_characters': len((OUT / 'surface-primary-review520.md').read_text(encoding='utf-8'))}, ensure_ascii=False))
