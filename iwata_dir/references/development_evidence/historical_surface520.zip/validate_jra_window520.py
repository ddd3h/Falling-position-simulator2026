"""Offline NCSS response validation only; no normalization, fetch, or field adoption."""
from pathlib import Path
import datetime as dt
import hashlib
import io
import json
import re
import time

import numpy as np
import scipy
from scipy.io import netcdf_file

OLD = Path(r'C:/Users/genia/AppData/Local/Temp/balloon-historical-510')
SOURCE = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp/references/jra3q_model_fixture/source_bundle.json')
ASCII_KEYS = {'tmp-hyb-an-gauss':'jra-t-cell','hgt-hyb-an-gauss':'jra-h-cell',
    'ugrd-hyb-an-gauss':'jra-u-cell','vgrd-hyb-an-gauss':'jra-v-cell',
    'spfh-hyb-an-gauss':'jra-q-cell','pres-sfc-an-gauss':'jra-sp-cell',
    'gp-sfc-cn-gauss':'jra-gp-cell'}
ATTRS = ('units','calendar','long_name','short_name','standard_name','vertical_orientation',
    '_FillValue','missing_value','scale_factor','add_offset','data_type','time_step',
    'group','level_code','level_value','level_units','rda_data_output_grid')


def sha(data): return hashlib.sha256(data).hexdigest()


def require(condition, reason):
    if not condition: raise ValueError(reason)


def plain(value):
    if isinstance(value, bytes): return value.decode('utf8')
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.generic): return value.item()
    return value


def ascii_reference(text, variable):
    """Parse the fixed bounded DAP2 raw: indexed rows and named coordinate axes."""
    header = re.search(r'^'+re.escape(variable+'.'+variable)+r'((?:\[\d+\])+)\r?$', text, re.M)
    require(header is not None, 'Old ASCII grid header missing')
    shape = tuple(map(int, re.findall(r'\d+', header[1])))
    values = np.empty(shape, dtype=np.float64)
    rows = re.findall(r'^((?:\[\d+\])+), ([^\r\n]+)$', text, re.M)
    require(len(rows) == int(np.prod(shape[:-1])), 'Old ASCII row count')
    for (index, row), expected in zip(rows, np.ndindex(shape[:-1])):
        actual = tuple(map(int, re.findall(r'\d+', index)))
        require(actual == expected, 'Old ASCII row order')
        row_values = [float(v) for v in row.split(',')]
        require(len(row_values) == shape[-1], 'Old ASCII longitude count')
        values[actual] = row_values
    axes = {}
    names = ('time','hybrid_level','lat','lon') if len(shape) == 4 else ('time','lat','lon')
    for name, n in zip(names, shape):
        match = re.search(r'^'+re.escape(variable+'.'+name)+r'\['+str(n)+r'\]\r?\n([^\r\n]+)', text, re.M)
        require(match is not None, 'Old ASCII axis missing: '+name)
        axes[name] = np.asarray([float(v) for v in match[1].split(',')])
        require(axes[name].size == n, 'Old ASCII axis count: '+name)
    return values, axes, names


def compare_reference(values, axes, names, reference, reference_axes, label):
    indices = []
    for name in names:
        at = []
        for value in reference_axes[name]:
            match = np.flatnonzero(axes[name] == value)
            require(len(match) == 1, 'Prior axis value absent/duplicated: '+name)
            at.append(int(match[0]))
        indices.append(at)
    subset = values[np.ix_(*indices)]
    binary = reference.astype(np.float32)
    require(np.array_equal(subset, binary), 'Prior Float32 values differ: '+label)
    return {'reference':label,'compared_values':int(binary.size),
        'unequal_float32_values':0,'max_abs_float32_difference':0.0,
        'max_abs_vs_printed_decimal':float(np.max(np.abs(subset.astype(np.float64)-reference))),
        'meaning':'Equality at Float32 precision only; no meteorological accuracy validation.'}


def validate_response(path, field, plan, compare_prior=True):
    begin = time.perf_counter(); raw = Path(path).read_bytes()
    require(0 < len(raw) <= field['max_body_bytes'], 'Response body size outside fixed cap')
    require(raw[:4] in (b'CDF\x01',b'CDF\x02'), 'Expected NetCDF3 CDF1/CDF2; no fallback/install')
    kind, name = field['kind'], field['variable']
    names = ('time','hybrid_level','lat','lon') if kind == 'model' else ('time','lat','lon')
    shape = tuple(field['expected_shape'])
    expected_axes = {n:np.asarray(plan['axes'][n]) for n in names}
    if kind == 'constant': expected_axes['time'] = np.asarray(plan['static_gp_time_hours_since1900'])
    # Decode exactly the bytes hashed above, not a second filesystem read.
    with netcdf_file(io.BytesIO(raw), mmap=False) as dataset:
        require(dict(dataset.dimensions) == dict(zip(names,shape)), 'Dimensions differ from exact request')
        require(name in dataset.variables, 'Requested variable absent')
        v = dataset.variables[name]
        require(v.dimensions == names and v.shape == shape, 'Variable order/shape differs')
        require(v.data.dtype.kind == 'f' and v.data.dtype.itemsize == 4, 'Expected original Float32 field')
        require(not hasattr(v,'scale_factor') and not hasattr(v,'add_offset'), 'Packed data require a new reviewed decoder')
        require(plain(getattr(v,'units',None)) == field['unit'], 'Field units differ')
        require(plain(getattr(v,'data_type',None)) == ('constant' if kind == 'constant' else 'analysis'), 'Product type differs')
        require(plain(getattr(v,'time_step',None)) == ('none' if kind == 'constant' else '6-hour'), 'Source time_step differs')
        expected_group = {'model':'anl_mdl','surface':'anl_surf','constant':'tl479_surf'}[kind]
        require(plain(getattr(v,'group',None)) == expected_group, 'Source group differs')
        if '2m-' in name or '10m-' in name:
            require(int(v.level_code) == 103 and int(v.level_value) == (2 if '2m-' in name else 10)
                and plain(v.level_units) == 'm', 'Diagnostic height meaning differs')
        elif kind != 'model': require(int(v.level_code) == 1, 'Expected ground/water surface definition')
        values = np.array(v[:], dtype=np.float32, copy=True)
        require(np.isfinite(values).all(), 'Nonfinite field values')
        fill = {a:plain(getattr(v,a)) for a in ('_FillValue','missing_value') if hasattr(v,a)}
        require(len(fill) == 2, 'Expected both fill/missing attributes')
        require(all(not np.equal(values, value).any() for value in fill.values()), 'Missing sentinel present')
        if field['unit'] in ('K','Pa'): require((values>0).all(), 'Nonpositive absolute temperature/pressure')
        if field['unit'] == 'kg kg-1': require(((values>=0)&(values<1)).all(), 'Specific humidity outside [0,1); no clamp')
        axes = {}
        for n in names:
            av = dataset.variables[n]
            require(av.dimensions == (n,), 'Coordinate dimensions: '+n)
            axes[n] = np.array(av[:],copy=True)
            require(np.array_equal(axes[n], expected_axes[n]), 'Exact native coordinate mismatch: '+n)
        require(plain(dataset.variables['time'].units) == 'hours since 1900-01-01 00:00:00'
            and plain(dataset.variables['time'].calendar) == 'gregorian', 'UTC epoch/calendar differs')
        require(plain(dataset.variables['lat'].units)=='degrees_north' and plain(dataset.variables['lon'].units)=='degrees_east','Coordinate units differ')
        if kind == 'model':
            require(plain(dataset.variables['hybrid_level'].vertical_orientation)=='from near-surface upward','Model-level orientation differs')
        inventory = {k:{'dimensions':list(var.dimensions),'shape':list(var.shape),'dtype':str(var.data.dtype),
            'attributes':{a:plain(getattr(var,a)) for a in ATTRS if hasattr(var,a)}} for k,var in dataset.variables.items()}
    if name == 'hgt-hyb-an-gauss': require((np.diff(values,axis=1)>0).all(), 'H must rise strictly from native level1 to100')
    comparisons = []
    if compare_prior and name in ASCII_KEYS:
        text = json.loads(SOURCE.read_bytes())['sources'][ASCII_KEYS[name]]['body_utf8']
        old, old_axes, old_names = ascii_reference(text,name)
        require(old_names == names,'Prior dimension order')
        comparisons.append(compare_reference(values,axes,names,old,old_axes,'fixed original '+ASCII_KEYS[name]))
    if compare_prior and name == 'spfh2m-hgt-an-gauss':
        old, old_axes, old_names = ascii_reference((OLD/'surface-q-openssl510/response.ascii').read_text(encoding='utf8'),name)
        comparisons.append(compare_reference(values,axes,names,old,old_axes,'small q probe: all3UTC/12 values'))
    if compare_prior and name == 'tmp-hyb-an-gauss':
        with netcdf_file(OLD/'model-t-ncss510/response.nc',mmap=False) as old:
            reference=np.array(old.variables[name][:],copy=True)
            refaxes={n:np.array(old.variables[n][:],copy=True) for n in names}
        comparisons.append(compare_reference(values,axes,names,reference,refaxes,'small NCSS T: all3UTC/1200 values'))
    require(Path(path).read_bytes() == raw, 'Raw changed during offline validation')
    return {'schema':'jra-window-response-validation/1','status':'passed','variable':name,'kind':kind,
        'raw_path':str(Path(path).resolve()),'raw_bytes':len(raw),'raw_sha256':sha(raw),'magic_hex':raw[:4].hex(),
        'dimensions':list(names),'shape':list(values.shape),'value_count':int(values.size),
        'axes':{n:axes[n].tolist() for n in names},'time_utc':[(dt.datetime(1900,1,1,tzinfo=dt.timezone.utc)+dt.timedelta(hours=float(t))).isoformat().replace('+00:00','Z') for t in axes['time']],
        'units':field['unit'],'fill_attributes':fill,'missing_count':0,'value_range':[float(values.min()),float(values.max())],
        'observed_inventory':inventory,'comparisons':comparisons,'decode_validation_seconds':time.perf_counter()-begin,
        'decoder':{'name':'scipy.io.netcdf_file','scipy':scipy.__version__,'numpy':np.__version__},
        'limits':['No pressure/height conversion or normalized field construction.',
            'Static GP retains1947 epoch, not reassigned to analysis2024.',
            'Prior checks cover only the existing tiny subset; other returned values have no independent value reference.',
            'Coordinate/product consistency and finite physical range do not establish meteorological accuracy or ground flight support.']}
