"""One fresh-process real-window flight. No HTTP, source edits or model adoption."""
from pathlib import Path
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import sys
import time

R = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P = Path(__file__).resolve().parent
sys.path.insert(0, str(R))
from balloon_sim.environment.storage import load_weather, read_json
from balloon_sim.flight.trajectory import simulate
from surface_prototype import SurfaceBridgeField


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    with Path(path).open('x', encoding='utf8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def memory():
    class Counters(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (n, ctypes.c_size_t) for n in ('PeakWorkingSetSize', 'WorkingSetSize',
            'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
            'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    counters = Counters(); counters.cb = ctypes.sizeof(counters)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {n: getattr(counters,n) for n in ('WorkingSetSize', 'PeakWorkingSetSize', 'PagefileUsage', 'PeakPagefileUsage')}


class TimedField:
    """Includes failed sample calls; diagnostics distinguish sampler from full flight."""
    def __init__(self, field):
        self.field = field
        self.sample_attempts = self.sample_successes = self.sample_failures = 0
        self.sample_seconds = 0.0
        self.ground_attempts = self.ground_failures = 0
        self.ground_seconds = 0.0

    def sample(self, *args, **kwargs):
        self.sample_attempts += 1; begin = time.perf_counter()
        try:
            value = self.field.sample(*args, **kwargs)
            self.sample_successes += 1
            return value
        except BaseException:
            self.sample_failures += 1
            raise
        finally: self.sample_seconds += time.perf_counter() - begin

    def ground_altitude(self, *args, **kwargs):
        self.ground_attempts += 1; begin = time.perf_counter()
        try: return self.field.ground_altitude(*args, **kwargs)
        except BaseException:
            self.ground_failures += 1
            raise
        finally: self.ground_seconds += time.perf_counter() - begin

    def metrics(self): return {k:v for k,v in vars(self).items() if k != 'field'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--weather', type=Path, required=True)
    parser.add_argument('--surface', type=Path, required=True)
    parser.add_argument('--normalization-receipt', type=Path, required=True)
    parser.add_argument('--mode', choices=['strict', 'column_surface_extension', 'native_horizontal_first'], required=True)
    parser.add_argument('--step', type=float, default=10)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False, parents=True)
    pairing = read_json(args.normalization_receipt)['paired_outputs']
    for path, key in [(args.weather, 'strict_weather'), (args.surface, 'surface_diagnostics')]:
        expected = pairing[key]
        if path.stat().st_size != expected['bytes'] or sha(path) != expected['sha256']:
            raise ValueError('Paired normalized output changed: '+key)
    diagnostic_read_start = time.perf_counter()
    surface_document = read_json(args.surface)
    diagnostic_read_seconds = time.perf_counter() - diagnostic_read_start
    if (surface_document['schema'] != 'balloon.experiment.jra3q_surface_diagnostics/1'
            or surface_document['product'] != 'jra3q.ncar.regular_gaussian.surface_analysis'
            or surface_document['axes'] != pairing['common_axes']
            or pairing['common_axes_equal'] is not True):
        raise ValueError('Surface product/axes differ from paired normalization')
    paths = [args.weather, args.surface, args.normalization_receipt, Path(__file__), P/'surface_prototype.py',
             R/'examples/wakayama-isothermal.json'] + sorted((R/'balloon_sim').rglob('*.py'))
    hashes = {str(p):sha(p) for p in paths}
    started = time.perf_counter(); cpu = time.process_time(); initial_memory = memory()
    source = load_weather(args.weather)
    if ({'time_utc':[t.isoformat() for t in source.times], 'latitude_deg':list(source.latitudes),
         'longitude_deg':list(source.longitudes)} != pairing['common_axes']
            or source.metadata['product'] != 'jra3q.ncar.regular_gaussian.model_analysis'):
        raise ValueError('Strict field product/axes differ from paired normalization')
    loaded = time.perf_counter()
    surface = surface_document['fields']
    joins = {n:2 if 'wind' in n else 1 for n in source.fields}
    field = source if args.mode == 'strict' else SurfaceBridgeField(source, surface, joins, args.mode)
    constructed = time.perf_counter()
    config = json.loads((R/'examples/wakayama-isothermal.json').read_bytes())
    config.update(label='jra3q-real-window-520-'+args.mode,
        purpose='Ground to 30 km reconstruction/cost comparison on one historical analysis window; not a launch plan')
    config['launch'].update(time_utc='2024-01-01T02:17:13+00:00', latitude_deg=34.8, longitude_deg=137.0)
    config['launch']['altitude_m'] = source.ground_altitude(config['launch']['time_utc'], 34.8, 137.0)
    config['integration']['max_step_s'] = args.step
    write(args.output/'config.json', config)
    timed = TimedField(field)
    before_flight_memory = memory(); before_flight = time.perf_counter(); flight_cpu = time.process_time()
    result = simulate(config, timed)
    finished = time.perf_counter(); finished_cpu = time.process_time()
    final_memory = memory()
    # These two rows share a phase-change time. They do not constitute two durations.
    rows = result['records']
    intervals = {'touches_surface_bridge_s':0., 'touches_terrain_extension_s':0.}
    for left,right in zip(rows,rows[1:]):
        delta = right['elapsed_s'] - left['elapsed_s']
        for key, name in [('surface_bridge_height_m','touches_surface_bridge_s'),
                          ('terrain_stencil_clamp_depth_m','touches_terrain_extension_s')]:
            if left.get(key,0)>0 or right.get(key,0)>0: intervals[name] += delta
    write(args.output/'result.json',result)
    if any(sha(p)!=h for p,h in hashes.items()): raise ValueError('Source or input changed during comparison')
    receipt = {'schema':'jra-real-window-flight-comparison/1', 'mode':args.mode,
        'source_hashes':hashes, 'source_unchanged':True, 'pid':os.getpid(),
        'weather_metadata':field.metadata, 'config_sha256':sha(args.output/'config.json'),
        'result_sha256':sha(args.output/'result.json'), 'result_summary':result['summary'],
        'status':result['status'], 'stop_reason':result['stop_reason'], 'events':result['events'],
        'seconds':{'surface_diagnostics_read':diagnostic_read_seconds,
            'load_weather':loaded-started, 'surface_wrapper_setup':constructed-loaded,
            'flight_wall':finished-before_flight,'flight_process_cpu':finished_cpu-flight_cpu,
            'load_through_flight_wall':finished-started, 'load_through_flight_cpu':finished_cpu-cpu},
        'calls':timed.metrics(), 'reconstruction_queries':getattr(field,'statistics',None),
        'memory_bytes':{'after_import':initial_memory,'before_flight':before_flight_memory,'after_flight':final_memory},
        'accepted_history':{'bridge_records':sum(r.get('surface_bridge_height_m',0)>0 for r in rows),
            'extension_records':sum(r.get('terrain_stencil_clamp_depth_m',0)>0 for r in rows),
            'max_bridge_height_m':max((r.get('surface_bridge_height_m',0) for r in rows),default=0),
            'max_extension_depth_m':max((r.get('terrain_stencil_clamp_depth_m',0) for r in rows),default=0),
            **intervals},
        'limits':['Finite historical input and reconstruction comparison, not meteorological or landing-probability calibration.',
            'Working set and its lifetime peak are process-level Windows observations, not array sizes or ensemble capacity.',
            'PagefileUsage counters represent process commit, not measured disk writes. None of the lifetime peaks isolates flight-only memory.',
            'Intervals touching bridge/extension use accepted endpoints: bracketing summaries, not exact physical occupancy.',
            'Terrain is interpolated model orography, not a fine DEM. No HTTP or Google request.']}
    write(args.output/'receipt.json',receipt)
    print(json.dumps({k:receipt[k] for k in ['mode','status','stop_reason','seconds','result_summary']},ensure_ascii=False))


if __name__=='__main__':main()
