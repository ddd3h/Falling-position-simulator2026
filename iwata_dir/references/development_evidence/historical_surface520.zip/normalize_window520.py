"""Offline, fixed-window normalization for a comparison experiment, not adoption.

Requires the completed combined acquisition and its explicit receipt hash.
Writes only a NEW normalization/run520 folder; never fetches or edits R.
"""
from pathlib import Path
import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timedelta, timezone
import hashlib
import io
import json
import os
import sys
import time

P = Path('C:/Users/genia/AppData/Local/Temp/balloon-surface-520')
R = Path('C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
OUT = P / 'normalization/run520'
PLAN_SHA = 'dbe799d3a056099fc33d99fe2958647225d529a783bb49bcde1716100c60a102'
BASIS = 'f94027cec2ff56b732af7bd11b2df26bdd9513a5'
G0 = 9.80665
RADIUS = 6371000.0
MODEL = {'tmp-hyb-an-gauss': 'temperature_k', 'spfh-hyb-an-gauss': 'specific_humidity_kg_kg',
         'ugrd-hyb-an-gauss': 'eastward_wind_m_s', 'vgrd-hyb-an-gauss': 'northward_wind_m_s',
         'hgt-hyb-an-gauss': 'geopotential_height_gpm'}
SURFACE = {'tmp2m-hgt-an-gauss': 'temperature_2m_k', 'spfh2m-hgt-an-gauss': 'specific_humidity_2m_kg_kg',
           'ugrd10m-hgt-an-gauss': 'eastward_wind_10m_m_s', 'vgrd10m-hgt-an-gauss': 'northward_wind_10m_m_s'}
SOURCES = ['balloon_sim/environment/jra3q.py', 'balloon_sim/environment/model_levels.py',
           'balloon_sim/environment/fields.py', 'balloon_sim/environment/storage.py',
           'tools/normalize_jra3q_model_fixture.py', 'tools/normalize_gfs_fixture.py',
           'references/jra3q_model_fixture/source_bundle.json']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def memory():
    """Windows working-set high water, cumulative since this process started."""
    if os.name != 'nt':
        return {'available': False, 'reason': 'Windows process counter only'}
    class Counters(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in ('PeakWorkingSetSize', 'WorkingSetSize',
                'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    counters = Counters(); counters.cb = ctypes.sizeof(counters)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        return {'available': False, 'winerror': ctypes.get_last_error()}
    return {'available': True, 'working_set_bytes': counters.WorkingSetSize,
            'peak_working_set_bytes_since_process_start': counters.PeakWorkingSetSize,
            'pagefile_usage_bytes': counters.PagefileUsage,
            'peak_pagefile_usage_bytes_since_process_start': counters.PeakPagefileUsage}


def frozen_input(receipt_path, receipt_sha):
    """Bind hashes first; accept only the completed, exact acquisition directory."""
    acquisition = (P / 'acquisition').resolve()
    receipt_path = Path(receipt_path).resolve()
    require(receipt_path == acquisition / 'combined-receipt520.json', 'Expected fixed combined receipt outside the attempt directories')
    receipt_raw = receipt_path.read_bytes()
    require(sha(receipt_raw) == receipt_sha, 'Explicit acquisition receipt hash differs')
    receipt = json.loads(receipt_raw)
    require(receipt['schema'] == 'jra-window-combined-receipt/1' and receipt['status'] == 'passed', 'Combined acquisition must pass')
    selected = {row['variable']: row for row in receipt['successful_fields']}
    require(len(receipt['successful_fields']) == len(selected) == 11, 'All eleven unique validated fields required')
    hashes = {str(receipt_path): fingerprint(receipt_path)}; source_receipts = []
    declared_manifests = {str(Path(row['path']).resolve()): row for row in receipt['source_manifests']}
    require(len(declared_manifests) == len(receipt['source_manifests']), 'Duplicate source manifest')
    for source in receipt['source_receipts']:
        path = Path(source['path']).resolve()
        require(path.is_relative_to(acquisition) and path.name == 'receipt.json', 'Source receipt outside acquisition')
        raw = path.read_bytes()
        require(len(raw) == source['bytes'] and sha(raw) == source['sha256'], 'Source receipt binding differs')
        data = json.loads(raw)
        require(data['schema'] == 'jra-window-acquisition-receipt/1' and data['inputs_unchanged'] is True, 'Source run inputs not fixed')
        source_receipts.append((path, data))
    require(len({str(path) for path, _ in source_receipts}) == len(source_receipts) > 0, 'Repeated/empty source receipts')
    require(set(declared_manifests) == {str(path.parent / 'manifest.json') for path, _ in source_receipts}, 'Each attempt needs exactly one raw manifest')
    for manifest_name, expected in declared_manifests.items():
        path = Path(manifest_name)
        raw = path.read_bytes()
        require(len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], 'Attempt manifest binding differs')
        manifest = json.loads(raw); run = path.parent
        require(manifest['schema'] == 'jra-window-raw-manifest/1', 'Raw manifest schema')
        rows = manifest['files']; names = [row['path'] for row in rows]
        require(len(names) == len(set(names)), 'Duplicate manifest path')
        require(set(names) == {p.relative_to(run).as_posix() for p in run.rglob('*') if p.is_file()} - {'manifest.json'},
                'Raw directory file set differs from manifest')
        hashes[str(path)] = fingerprint(path)
        for row in rows:
            source = (run / row['path']).resolve()
            require(source.is_relative_to(run), 'Manifest path escaped source run')
            fp = fingerprint(source)
            require(fp['bytes'] == row['bytes'] and fp['sha256'] == row['sha256'], 'Manifest input differs: ' + row['path'])
            hashes[str(source)] = fp
    successes = {}
    for path, data in source_receipts:
        saved_plan_raw = (path.parent / 'plan.json').read_bytes()
        # Each attempt has its own fixed plan: original failed attempts remain
        # evidence, while only passed response rows can provide weather values.
        saved_plan = json.loads(saved_plan_raw)
        # Acquisition records the original request-plan bytes, whereas its
        # in-run plan.json was serialized again (including newline differences).
        # Bind the original hash, then compare the saved representation by value.
        original_plans = [(candidate, candidate.read_bytes())
                          for candidate in acquisition.glob('request-plan520*.json')]
        matching_plans = [(candidate, raw) for candidate, raw in original_plans
                          if sha(raw) == data['plan_sha256']]
        require(len(matching_plans) == 1, 'Original attempt plan hash must resolve uniquely')
        original_path, original_raw = matching_plans[0]
        require(json.loads(original_raw) == saved_plan, 'Saved plan values differ from the hash-bound original')
        hashes[str(original_path)] = {'path': str(original_path), 'bytes': len(original_raw), 'sha256': sha(original_raw)}
        require(saved_plan['basis_commit'] == BASIS, 'Attempt basis differs')
        for script_path, expected in data['scripts'].items():
            require(fingerprint(script_path)['sha256'] == expected, 'Acquisition/validation helper changed')
            hashes[str(Path(script_path).resolve())] = fingerprint(script_path)
        for response in data['responses']:
            if response['status'] != 'passed':
                continue
            name = response['variable']
            require(name not in successes, 'A weather field has more than one selected successful original')
            raw_path = Path(response['raw_path']).resolve()
            require(raw_path.parent.parent == path.parent and raw_path.name == 'response.nc', 'Successful response left its attempt')
            row = selected[name]
            require(Path(row['raw']['path']).resolve() == raw_path
                    and Path(row['validation']['path']).resolve() == raw_path.parent / 'validation.json', 'Combined mapping differs')
            for member in ('raw', 'validation'):
                declared = row[member]; actual = hashes[str(Path(declared['path']).resolve())]
                require(actual['bytes'] == declared['bytes'] and actual['sha256'] == declared['sha256'], 'Combined member hash differs')
            successes[name] = response
    require(set(successes) == set(selected), 'Combined success set differs from original receipts')
    plan_raw = (P / 'acquisition/request-plan520.json').read_bytes()
    require(sha(plan_raw) == PLAN_SHA, 'Fixed original request plan differs')
    plan = json.loads(plan_raw)
    require(plan['basis_commit'] == BASIS and len(plan['fields']) == 11, 'Unexpected basis/request count')
    require(len({f['variable'] for f in plan['fields']}) == 11, 'Duplicate requested variable')
    for source in plan['inputs']:
        fp = fingerprint(source['path'])
        require(fp['bytes'] == source['bytes'] and fp['sha256'] == source['sha256'], 'Pinned original changed')
    hashes[str(P / 'acquisition/request-plan520.json')] = fingerprint(P / 'acquisition/request-plan520.json')
    return receipt, plan, hashes, successes


def normalize(receipt_path, receipt_sha):
    require(not OUT.exists(), 'Existing normalization is preserved; no overwrite/resume')
    begin = time.perf_counter(); start_utc = datetime.now(timezone.utc).isoformat()
    peaks = {'start': memory()}; timings = {}
    receipt, plan, before, successes = frozen_input(receipt_path, receipt_sha)
    basis = json.loads((P / 'basis520.json').read_bytes())
    require(basis['head'] == BASIS, 'Wrong baseline')
    runtime_before = {name: fingerprint(R / name) for name in SOURCES}
    require(all(row['sha256'] == basis['files'][name] for name, row in runtime_before.items()), 'Reviewed R input differs from basis')
    helper_hash = sha(Path(__file__).read_bytes())
    sys.path.insert(0, str(R))
    from tools.normalize_jra3q_model_fixture import load_fixture
    from balloon_sim.environment.jra3q import Jra3qModelField, SCHEMA, PRODUCT, COEFFICIENT_SHA256
    from balloon_sim.environment.storage import write_bundle, read_json, load_weather
    import numpy as np
    import scipy
    from scipy.io import netcdf_file
    timings['preflight_and_import_seconds'] = time.perf_counter() - begin
    t = time.perf_counter()
    old = load_fixture(R)
    coefficient_provenance = old.provenance
    a = list(map(float, coefficient_provenance['half_coefficients_pa']))
    b = list(map(float, coefficient_provenance['half_coefficients_dimensionless']))
    coefficient_hash = sha(json.dumps([a, b], separators=(',', ':'), allow_nan=False).encode())
    require(coefficient_hash == COEFFICIENT_SHA256, 'Unreviewed hybrid coefficients')
    del old
    timings['coefficient_original_validation_seconds'] = time.perf_counter() - t
    arrays, raw_bits, field_sources = {}, {}, {}
    expected_variables = set(MODEL) | set(SURFACE) | {'pres-sfc-an-gauss', 'gp-sfc-cn-gauss'}
    require({f['variable'] for f in plan['fields']} == expected_variables, 'Requested field set differs')
    lat = np.asarray(plan['axes']['lat'], dtype=np.float64)
    order = np.argsort(lat)
    require(len(lat) == 20 and np.all(np.diff(lat[order]) > 0), 'Latitude axis must uniquely sort ascending')
    lon = np.asarray(plan['axes']['lon'], dtype=np.float64)
    require(len(lon) == 46 and np.all(np.diff(lon) > 0), 'Longitude axis mismatch')
    times = [(datetime(1900, 1, 1, tzinfo=timezone.utc) + timedelta(hours=float(v))).isoformat()
             for v in plan['axes']['time']]
    require(times == ['2024-01-01T00:00:00+00:00', '2024-01-01T06:00:00+00:00', '2024-01-01T12:00:00+00:00'], 'Original UTCs differ')
    t = time.perf_counter()
    for field in plan['fields']:
        name = field['variable']; response = successes[name]
        directory = Path(response['raw_path']).resolve().parent
        require(response['variable'] == name and response['ordinal'] == field['ordinal'] and response['status'] == 'passed', 'Response order/status')
        validation_raw = (directory / 'validation.json').read_bytes()
        require(sha(validation_raw) == response['validation_sha256'], 'Validation hash differs')
        validation = json.loads(validation_raw)
        raw = (directory / 'response.nc').read_bytes()
        require(sha(raw) == response['body_sha256'] == validation['raw_sha256']
                and len(raw) == response['body_bytes'] == validation['raw_bytes'], 'NCSS raw binding differs')
        require(json.loads((directory / 'receipt.json').read_bytes()) == response, 'Response receipt differs')
        require(validation['status'] == 'passed' and validation['variable'] == name and validation['missing_count'] == 0, 'Validation did not pass')
        names = ('time', 'hybrid_level', 'lat', 'lon') if field['kind'] == 'model' else ('time', 'lat', 'lon')
        expected_shape = (3, 100, 20, 46) if field['kind'] == 'model' else ((1, 20, 46) if field['kind'] == 'constant' else (3, 20, 46))
        require(tuple(field['expected_shape']) == expected_shape == tuple(validation['shape']), 'Window shape differs')
        with netcdf_file(io.BytesIO(raw), mmap=False) as nc:
            v = nc.variables[name]
            require(v.dimensions == names and v.shape == expected_shape and v.data.dtype.kind == 'f' and v.data.dtype.itemsize == 4, 'Unexpected array type/order')
            require(not hasattr(v, 'scale_factor') and not hasattr(v, 'add_offset'), 'No packing allowed')
            require(v.units.decode() == field['unit'] == validation['units'], 'Units differ')
            for axis in names:
                expected = plan['static_gp_time_hours_since1900'] if field['kind'] == 'constant' and axis == 'time' else plan['axes'][axis]
                require(np.array_equal(nc.variables[axis][:], expected)
                        and np.array_equal(nc.variables[axis][:], validation['axes'][axis]), 'Raw/validated coordinate differs')
            raw_array = np.array(v[:], dtype=np.float32, copy=True)
            require(np.isfinite(raw_array).all() and all(not np.any(raw_array == value) for value in validation['fill_attributes'].values()), 'Invalid values')
            if field['unit'] in ('K', 'Pa'):
                require(np.all(raw_array > 0), 'Nonpositive temperature/pressure')
            if field['unit'] == 'kg kg-1':
                require(np.all((raw_array >= 0) & (raw_array < 1)), 'Invalid specific humidity; no clamp')
            arranged = np.take(raw_array, order, axis=-2)
            # Converting binary32 to Python binary64 is exact. Preserve every bit
            # (including signed zero) on JSON readback, not merely equal means.
            raw_bits[name] = arranged.astype('<f4', copy=False).tobytes(order='C')
            arrays[name] = arranged
        field_sources[name] = {'raw': before[str(directory / 'response.nc')],
            'validation': before[str(directory / 'validation.json')],
            'url': response['url'], 'source_unit': field['unit'], 'source_time_utc': validation['time_utc'],
            'shape': list(expected_shape), 'source_float32_sha256_after_latitude_sort': sha(raw_bits[name])}
    timings['read_decode_and_sort_seconds'] = time.perf_counter() - t
    peaks['decoded'] = memory()
    t = time.perf_counter()
    gp = arrays['gp-sfc-cn-gauss']
    require(field_sources['gp-sfc-cn-gauss']['source_time_utc'] == ['1947-09-01T00:00:00Z'], 'Static epoch differs')
    hs = np.repeat(gp.astype(np.float64) / G0, 3, axis=0)
    axes = {'time_utc': times, 'model_level': list(range(1, 101)), 'latitude_deg': lat[order].tolist(), 'longitude_deg': lon.tolist()}
    meta = {'scope': 'Fixed experimental 3-UTC 20x46 input; no surface bridge or scientific adoption',
            'source_dataset': 'jra3q.ncar.regular_gaussian',
            'acquisition_receipt_sha256': receipt_sha, 'acquisition_manifests': receipt['source_manifests'],
            'normalizer_sha256': helper_hash, 'field_sources': field_sources,
            'coefficient_source': coefficient_provenance,
            'normalization': ['latitude reordered ascending; time/level/longitude order unchanged',
                'all weather values preserve original Float32 exactly as JSON numbers',
                'only GP/g0 converts physical values; static field repeated unchanged across analysis times'],
            'static_surface': {'original_time_utc': ['1947-09-01T00:00:00Z'], 'kind': 'constant',
                'original_unit': 'm2 s-2', 'normalized_unit': 'gpm', 'divisor_m_s2': G0,
                'meaning': '1947 is the invariant product epoch, not an atmospheric support time'},
            'baseline': BASIS}
    bundle = {'schema': SCHEMA, 'product': PRODUCT, 'axes': axes,
              'fields': {target: arrays[name].tolist() for name, target in MODEL.items()},
              'surface': {'pressure_pa': arrays['pres-sfc-an-gauss'].tolist(), 'geopotential_height_gpm': hs.tolist()},
              'hybrid': {'a_half_pa': a, 'b_half': b}, 'metadata': meta}
    diagnostics = {'schema': 'balloon.experiment.jra3q_surface_diagnostics/1',
                   'product': 'jra3q.ncar.regular_gaussian.surface_analysis',
                   'axes': {key: value for key, value in axes.items() if key != 'model_level'},
                   'fields': {target: arrays[name].tolist() for name, target in SURFACE.items()},
                   'diagnostic_height_agl_m': {target: 2 if '2m' in target else 10 for target in SURFACE.values()},
                   'static_gp': {'time_utc': ['1947-09-01T00:00:00Z'], 'unit': 'm2 s-2', 'values': gp.tolist()},
                   'metadata': meta}
    timings['normalize_to_json_values_seconds'] = time.perf_counter() - t
    t = time.perf_counter(); field = Jra3qModelField(bundle)
    timings['strict_field_construct_validate_seconds'] = time.perf_counter() - t
    h = arrays['hgt-hyb-an-gauss'].astype(np.float64)
    ground_z = RADIUS * hs / (RADIUS - hs)
    z = RADIUS * h / (RADIUS - h)
    agl = z - ground_z[:, None, :, :]
    def describe(values):
        imin, imax = np.unravel_index(np.argmin(values), values.shape), np.unravel_index(np.argmax(values), values.shape)
        def where(index):
            t, j, i = map(int, index)
            return {'time_utc': times[t], 'latitude_deg': axes['latitude_deg'][j], 'longitude_deg': axes['longitude_deg'][i]}
        return {'minimum_m': float(values[imin]), 'maximum_m': float(values[imax]),
                'minimum_at': where(imin), 'maximum_at': where(imax), 'column_count': int(values.size)}
    join_specs = {'pressure_pa': (1, 0), 'temperature_k': (1, 2), 'specific_humidity_kg_kg': (1, 2),
                  'eastward_wind_m_s': (2, 10), 'northward_wind_m_s': (2, 10)}
    joins = {}
    for name, (level, anchor) in join_specs.items():
        margin = agl[:, level - 1] - anchor
        joins[name] = {'native_level_id': level, 'anchor_agl_m': anchor, 'strictly_above_anchor_in_all_original_columns': bool(np.all(margin > 0)),
                       'nonpositive_margin_count': int(np.count_nonzero(margin <= 0)), 'margin': describe(margin)}
    column_report = {'schema': 'balloon.experiment.surface_join_diagnostics/1',
                     'population': {'original_utc': 3, 'latitudes': 20, 'longitudes': 46, 'columns': 2760},
                     'height_convention': 'geometric ASL = R*H/(R-H), R6371000m; AGL subtracts static GP/g0 ground',
                     'native_level_1_agl': describe(agl[:, 0]), 'native_level_2_agl': describe(agl[:, 1]),
                     'fixed_joins': joins, 'all_selected_joins_supported': all(v['strictly_above_anchor_in_all_original_columns'] for v in joins.values()),
                     'native_wind_level1_at_or_below10m_count': int(np.count_nonzero(agl[:, 0] <= 10)),
                     'not_proved': 'No virtual-column interpolation continuity, accuracy, conservation or flight acceptance follows from original-column anchor order.'}
    peaks['validated_before_write'] = memory()
    OUT.mkdir(parents=True, exist_ok=False)
    t = time.perf_counter()
    strict_path = OUT / 'strict-weather.json.gz'; diagnostic_path = OUT / 'surface-diagnostics.json.gz'
    write_bundle(strict_path, bundle); write_bundle(diagnostic_path, diagnostics)
    timings['write_two_gzip_json_seconds'] = time.perf_counter() - t
    t = time.perf_counter()
    saved = read_json(strict_path); saved_diag = read_json(diagnostic_path)
    require(saved == bundle and saved_diag == diagnostics, 'JSON values changed on readback')
    common_axes = {key: value for key, value in saved['axes'].items() if key != 'model_level'}
    require(common_axes == saved_diag['axes'], 'Strict/surface time/latitude/longitude axes differ')
    require(saved['product'] == PRODUCT and saved_diag['product'] == 'jra3q.ncar.regular_gaussian.surface_analysis',
            'Unexpected product pair')
    timings['read_two_gzip_json_and_value_compare_seconds'] = time.perf_counter() - t
    bit_checks = []
    for name in expected_variables:
        value = (saved['fields'][MODEL[name]] if name in MODEL else saved_diag['fields'][SURFACE[name]] if name in SURFACE
                 else saved['surface']['pressure_pa'] if name == 'pres-sfc-an-gauss' else saved_diag['static_gp']['values'])
        bits = np.asarray(value, dtype='<f4').tobytes(order='C')
        require(bits == raw_bits[name], 'Float32 readback bits differ: ' + name)
        bit_checks.append({'variable': name, 'value_count': len(bits) // 4, 'float32_bits_match': True, 'sha256': sha(bits)})
    require(np.array_equal(np.asarray(saved['surface']['geopotential_height_gpm']), hs), 'GP/g0 readback differs')
    del saved, saved_diag
    t = time.perf_counter(); restored = load_weather(strict_path)
    timings['load_weather_gzip_parse_and_field_validate_seconds'] = time.perf_counter() - t
    require(restored.heights == field.heights and restored.fields == field.fields and restored.surface_height == field.surface_height
            and restored.surface_pressure == field.surface_pressure and restored.metadata == field.metadata, 'Runtime load differs')
    peaks['after_load_readback'] = memory()
    # Close the bound-input window: detect appended raw files as well as changes.
    after_receipt, after_plan, after, after_successes = frozen_input(receipt_path, receipt_sha)
    require(after == before and after_receipt == receipt and after_plan == plan and after_successes == successes, 'Acquisition changed during normalization')
    require({name: fingerprint(R / name) for name in SOURCES} == runtime_before and sha(Path(__file__).read_bytes()) == helper_hash,
            'Executing source changed during normalization')
    write_json(OUT / 'join-diagnostics.json', column_report)
    result = {'schema': 'balloon.experiment.jra3q_window_normalization/1', 'status': 'passed',
              'started_at_utc': start_utc, 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
              'source_receipt': fingerprint(receipt_path), 'source_manifests': receipt['source_manifests'],
              'source_files': runtime_before, 'helper_sha256': helper_hash, 'coefficient_sha256': coefficient_hash,
              'outputs': [fingerprint(path) for path in (strict_path, diagnostic_path, OUT / 'join-diagnostics.json')],
              'paired_outputs': {
                  'strict_weather': {**fingerprint(strict_path), 'schema': SCHEMA, 'product': PRODUCT},
                  'surface_diagnostics': {**fingerprint(diagnostic_path), 'schema': diagnostics['schema'], 'product': diagnostics['product']},
                  'common_axes': common_axes, 'common_axes_equal': True,
                  'source_dataset': 'jra3q.ncar.regular_gaussian', 'acquisition_receipt_sha256': receipt_sha,
                  'meaning': 'Known model-analysis/surface-analysis product pair, not identical product strings'},
              'all_float32_values': sum(row['value_count'] for row in bit_checks), 'float32_readback': sorted(bit_checks, key=lambda row: row['variable']),
              'all_selected_joins_supported': column_report['all_selected_joins_supported'],
              'timing_seconds': {**timings, 'total_through_readback_and_input_recheck': time.perf_counter() - begin},
              'windows_process_memory': peaks,
              'memory_meaning': 'Each peak is the Windows process lifetime high water through that phase; includes imports, originals, Python JSON lists and duplicate validation/load objects. Not acquisition cost, flight RSS, phase increment, or required steady runtime memory.',
              'runtime': {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__, 'pid': os.getpid()},
              'network_requests': 0, 'inputs_unchanged': True,
              'limits': ['Offline comparison input only; not accepted runtime source.', 'No model interpolation or surface bridge performed.',
                         'GP/g0 alone changes physical values; surface diagnostics retain original analysis values.',
                         'Original-column fixed-join support is a separate diagnostic; unsupported joins do not make valid strict input invalid.']}
    write_json(OUT / 'receipt.json', result)
    print(json.dumps({'status': result['status'], 'receipt': fingerprint(OUT / 'receipt.json'),
                      'outputs': result['outputs'], 'all_selected_joins_supported': result['all_selected_joins_supported']}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--receipt-sha256')
    args = parser.parse_args()
    if not args.execute:
        print('Candidate only. Requires explicit --execute and completed combined acquisition receipt SHA256.')
        return
    require(all(v is not None and len(v) == 64 and all(c in '0123456789abcdef' for c in v)
                for v in (args.receipt_sha256,)), 'Explicit valid SHA256 required')
    require(args.receipt is not None, 'Explicit combined receipt path required')
    normalize(args.receipt, args.receipt_sha256)


if __name__ == '__main__':
    main()
