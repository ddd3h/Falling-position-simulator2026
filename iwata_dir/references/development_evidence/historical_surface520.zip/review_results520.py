"""Read actual results into a portable Plotly comparison and replay receipt."""
from pathlib import Path
import json, hashlib, shutil, sys, math, datetime as dt
P=Path(__file__).resolve().parent
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
sys.path.insert(0,str(R))
from geographiclib.geodesic import Geodesic
from balloon_sim.environment.storage import load_weather
def rd(p):return json.loads(p.read_text('utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))

actual=rd(P/'runtime-flight520/result.json'); prototype=rd(P/'flights/B-step10/result.json')
assert actual['status']=='landed' and actual['complete']
assert actual['summary']==prototype['summary'] and actual['events']==prototype['events']
assert len(actual['records'])==len(prototype['records'])==848
for a,b in zip(actual['records'],prototype['records']):
 assert {k:v for k,v in a.items() if k!='weather_quality'}=={k:v for k,v in b.items() if k!='weather_quality'}
 assert 'native_horizontal_first_surface_v1' in a['weather_quality']
assert {k:v for k,v in actual['config'].items() if k not in ('label','purpose')}=={k:v for k,v in prototype['config'].items() if k not in ('label','purpose')}
cross=rd(P/'runtime-cross06-flight520/result.json')
assert cross['status']=='landed' and cross['complete'] and cross['summary']['record_count']==849
boundary=dt.datetime(2024,1,1,6,tzinfo=dt.timezone.utc)
times=[dt.datetime.fromisoformat(r['time_utc']) for r in cross['records']]
assert times[0]<boundary<times[-1] and all(b>=a for a,b in zip(times,times[1:]))
for a,b in zip(cross['records'],cross['records'][1:]):
 if a['time_utc']==b['time_utc']:
  assert a['phase']=='ascent' and b['phase']=='descent' and a['event']==b['event']=='burst'
f=load_weather(R/'references/flight_fixture/jra3q-weather.json.gz')
queries=[f.sample(boundary+dt.timedelta(seconds=s),34.8,137.,15000.) for s in (-1,0,1)]
provenance=rd(P/'runtime-flight520/provenance.json')
assert 'native_horizontal_first_surface_v1' in json.dumps(provenance)
out=P/'review';out.mkdir(exist_ok=False)
lib=R/'frontend/node_modules/plotly.js-dist-min/plotly.min.js'
shutil.copyfile(lib,out/'plotly.min.js')
lic=R/'frontend/node_modules/plotly.js-dist-min/LICENSE'
if lic.exists():shutil.copyfile(lic,out/'PLOTLY_LICENSE.txt')

cases=[('A-step10','A：列地表延長', '#b67420'),('B-step10','B：native水平先行', '#167d91'),('B-step5','B：刻み半減', '#875bba')]
charts=[]; rows=[]
base_landing=actual['summary']['landing']
for folder,label,color in cases:
 result=rd(P/'flights'/folder/'result.json')
 records=result['records'];land=result['summary']['landing']
 g=Geodesic.WGS84.Inverse(base_landing['latitude_deg'],base_landing['longitude_deg'],land['latitude_deg'],land['longitude_deg'])
 az=math.radians(g['azi1']); east=g['s12']*math.sin(az);north=g['s12']*math.cos(az)
 charts.append(dict(name=label,color=color,time=[r['elapsed_s']/60 for r in records],height=[r['altitude_m']/1000 for r in records],lon=[r['longitude_deg'] for r in records],lat=[r['latitude_deg'] for r in records],east=east,north=north))
 rows.append(dict(label=label,landing_distance_from_B10_m=g['s12'],duration_s=result['summary']['duration_s'],records=len(records)))
payload=json.dumps(charts,ensure_ascii=False).replace('</',r'<\/')
page='''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>実JRAの全飛行と再構成比較 · 0.52</title>
<style>body{font-family:system-ui,"Yu Gothic",sans-serif;margin:0;background:#edf2f3;color:#17333d}main{max-width:1220px;margin:auto;padding:28px}h1{font-size:27px}p{line-height:1.75}.lead{max-width:1020px}.cards,.plots{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card,.plot,section{background:white;border:1px solid #cad8dc;border-radius:10px;padding:16px;margin-bottom:16px}.cards strong{font-size:27px;color:#116576;display:block}.plot{min-width:0;padding:0}.chart{height:350px}small{color:#526870}table{border-collapse:collapse;width:100%}td,th{padding:10px;text-align:left;border-bottom:1px solid #d9e2e5}th{background:#f2f7f7}.note{border-left:5px solid #b67420;padding:8px 18px;background:#fff9ee}button{cursor:pointer;border:1px solid #8da8b1;background:white;border-radius:5px;padding:8px 12px;margin:3px}@media(max-width:750px){.plots,.cards{grid-template-columns:1fr}main{padding:15px}}footer{font-size:13px;color:#526870}</style>
<main><small>Balloon-JP / S36 · 0.52の有限な実データ検証</small><h1>実過去窓で、地上から30 kmを経て着地する</h1>
<p class="lead">2024年1月1日のJRA-3Q、00 / 06 / 12 UTC、100層、20 × 46格子と地上量を実取得。同じ機体条件で再構成方法を比較しました。図は一つの診断用飛行であり、落下分散や予測誤差の範囲ではありません。</p>
<div class="cards"><div class="card"><small>B方式・約140.28分の飛行</small><strong>3.84秒</strong>simulate単回壁時計。場読込み約1.90秒は別。取得や全出力の時間を含みません。</div><div class="card"><small>A / Bの着地点の距離</small><strong>32.35 m</strong>同じ実場でも再構成の仮定で変わることを示す比較。実際の着地誤差ではありません。</div></div>
<div class="plots"><div class="plot"><div id="track" class="chart"></div></div><div class="plot"><div id="landing" class="chart"></div></div></div><div class="plot"><div id="height" class="chart"></div></div>
<p>図右上のカメラからPNGを保存できます。<button onclick="save('track')">軌道のSVGを保存</button><button onclick="save('landing')">着地点のSVGを保存</button><button onclick="save('height')">高度履歴のSVGを保存</button></p>
<section><h2>何を比較し、何を採ったか</h2><table><thead><tr><th>再構成</th><th>地上開始</th><th>飛行時間の測定</th><th>判断に効いた点</th></tr></thead><tbody><tr><td>旧strict・各列を先に鉛直補間</td><td>0秒で支持不足</td><td>停止</td><td>厳密な列支持を調べる対照として保持</td></tr><tr><td>A・各列地上橋渡し＋地表値延長</td><td>着地</td><td>10.05秒</td><td>高い地形の列で最大約134 mの延長を使用</td></tr><tr><td>B・原UTCごとにnative水平→鉛直→時間</td><td>着地</td><td>3.84秒</td><td>地形列の延長を避ける明示選択肢。本体へ接続</td></tr><tr><td>B・最大刻み10秒→5秒</td><td>着地</td><td>8.29秒</td><td>B10との差約0.0057 m。この一条件の数値安定性</td></tr></tbody></table></section>
<p class="note">Bは低層だけの補修ではなく、全高度の内挿順と仮想上下端が変わります。2m温湿度→native1、10m風→native2、診断高度より下は定値。native1風は使いません。モデル地形への着地であり、実地形・建物との接触や科学的精度は未検証です。</p>
<section><h2>本体への接続と、次の審査</h2><p>保存bundleから本体CLIを実行し、848記録の数値がB試作と一致。さらに04:17:13 UTC開始の例は06 UTCをまたぎ、06:37:31 UTCに着地しました。通信なしで再実行できます。</p><p>次は原日時窓を既存GUIの保存比較へ渡し、季節・時間帯の対象集合と取得済み窓を分けて小集合の費用を測ります。半月統計の軽い傾向把握と、元日時の共同場による飛行を結びます。期間の周辺分布から瞬時場を作ったことや、季節モンテカルロが完成したことは意味しません。</p></section>
<footer>軌道図は経緯度の平面表示。着地点図はB10を原点とするWGS84測地距離と方位からの東・北成分。背景地図・外部通信なし。2026-09-30、同じPCで各条件1回の測定。入力/式/来歴と全原結果は証拠束、再実行はCOMMANDS C-11、判断はD-191/S36へ。</footer></main><script src="plotly.min.js"></script><script>
const data=PAYLOAD;const cfg={responsive:true,displaylogo:false,modeBarButtonsToRemove:["sendChartToCloud"],toImageButtonOptions:{format:'png',scale:2}};const base={font:{family:'Arial, Yu Gothic, sans-serif',color:'#17333d'},margin:{l:70,r:30,t:60,b:58},legend:{orientation:'h',y:-.25},hovermode:'closest'};
Plotly.newPlot('track',data.map(d=>({x:d.lon,y:d.lat,name:d.name,mode:'lines',line:{color:d.color,width:2}})),{...base,title:{text:'全軌道：AとBはこの縮尺ではほぼ重なる'},xaxis:{title:{text:'経度 / deg E'}},yaxis:{title:{text:'緯度 / deg N'}}},cfg);
Plotly.newPlot('landing',data.map(d=>({x:[d.east],y:[d.north],name:d.name,mode:'markers',marker:{color:d.color,size:12,symbol:d.name.includes('半減')?'cross':'circle'}})),{...base,title:{text:'着地点を拡大：B10を原点とした比較'},xaxis:{title:{text:'東方向 / m'},range:[-30,10]},yaxis:{title:{text:'北方向 / m'},range:[-6,34],scaleanchor:'x'}},cfg);
Plotly.newPlot('height',data.map(d=>({x:d.time,y:d.height,name:d.name,mode:'lines',line:{color:d.color,width:2}})),{...base,title:{text:'高度履歴：上昇 → 30 km破裂 → 下降'},xaxis:{title:{text:'放球からの経過時間 / min'}},yaxis:{title:{text:'幾何高度 ASL / km'}}},cfg);
function save(id){Plotly.downloadImage(document.getElementById(id),{format:'svg',filename:'jra520-'+id,width:1100,height:650})}
</script></html>'''.replace('PAYLOAD',payload)
(out/'index.html').write_text(page,encoding='utf-8')
receipt=dict(schema='runtime-replay520/1',same_numeric_summary_events_and_all_848_records=True,allowed_record_difference='weather_quality labels only; config label/purpose differ',cross06=dict(summary=cross['summary'],first_utc=times[0].isoformat(),last_utc=times[-1].isoformat(),queries_minus_at_plus_1s=queries),comparison=rows,inputs=[rec(P/path) for path in ['runtime-flight520/result.json','runtime-cross06-flight520/result.json','flights/B-step10/result.json']],plotly=rec(lib),report=rec(out/'index.html'))
(P/'runtime-replay520.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['schema','same_numeric_summary_events_and_all_848_records','comparison','report']},ensure_ascii=False))
