# 月分位SVGの有限視覚批評

current-monthly-static.pngを実見し、保存SVGと描画sourceを読んだ。12図・共通軸・前後半2線・灰帯・凡例・標本数・出典に、見切れや重なりによる修正必須はない。見た目だけの追加改修は提案しない。

## 必要な意味訂正

footerの「隣接面の中点で色帯を分け、端は元の面まで」は年間ヒートマップの高さ区画の規則である。月分位は各元面のp10/p90をpolygonで結んでおり、この規則を使わない。灰帯の構成を誤読させるため、最終出版前に局所訂正するのが適切。

最小案は `sources/climateSummary.ts:18` の共通 `heightDefinition` から末尾1文を除き、同 `annualDefinition` へ「年間ヒートマップでは、隣接面の中点で色帯を分け、端は元の面まで。」として移すこと。共通文にはISAが実高度/地表ではない説明を残す。`monthlyProfileView` は既に `annualDefinition` を月分位の方法へ置換し、exportはその値をmetadataと表示へ写すので、月だけの特殊処理やexport分岐を足す必要がない。平均/風配の共通footerも同じ誤説明を持たずに済む。

この変更は統計値・DTO・図のgeometryを変えない。採用後は月SVGのfooter/metadataから誤文が消え、年間SVGにヒートマップの説明が残る接点だけを再確認できる。データ再取得・再集計を必要とする所見ではない。source等の指紋は既存手順に従い主担当が再固定する。まだコードは編集していない。

## 担当範囲

独立に見たのは上記PNG一枚と保存SVG/sourceである。SVGには12帯polygon・24中央値polyline・12期間があり、UTC00のcaption/標本数と一致する。根拠hashはJSON票へ保存した。ブラウザでの実ファイル受領とfixed artifact全識別一致は主担当のcurrent-readback票であり、自身の実行として数えない。数値精度・原配列全検証・実UI/hover・他図の視覚受入に広げない。元SVG/PNGは保存したまま。
