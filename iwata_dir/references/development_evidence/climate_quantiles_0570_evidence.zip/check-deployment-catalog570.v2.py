"""Unexecuted V2 proposal: finite localhost catalog/static checks, no POST or acquisition."""
from pathlib import Path, PurePosixPath
import argparse
import calendar
import datetime
import hashlib
import json
import urllib.request

LEGACY_PROFILE = 'provided-hokkaido-2016-2025-half-v1'
LEGACY_DATASET = '1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a'
MAX_RESPONSE_BYTES = 64 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf8')


def source_identity(parts):
    return 'climate-' + sha(canonical(parts))


def get(port, path):
    require(path.startswith('/') and not path.startswith('//') and '#' not in path, 'Invalid localhost path')
    url = f'http://127.0.0.1:{port}' + path
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    with urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect()).open(url, timeout=30) as response:
        require(response.status == 200 and response.geturl() == url, 'Unexpected HTTP response')
        raw = response.read(MAX_RESPONSE_BYTES + 1)
        require(len(raw) <= MAX_RESPONSE_BYTES, 'Response exceeds finite helper limit')
        return raw


def safe_file(root, name):
    parts = PurePosixPath(name).parts
    require(parts and not PurePosixPath(name).is_absolute() and '\\' not in name and all(p not in ('.', '..') and ':' not in p for p in parts), 'Invalid relative static path')
    path = root.joinpath(*parts)
    require(path.resolve().is_relative_to(root.resolve()) and path.is_file() and not path.is_symlink(), 'Missing/escaped static file')
    return path


def raw_proof(source, manifest, digest, provider, level_count, cell_count):
    expected_id = source_identity(['original-utc-wind/1', digest])
    cap = source['capabilities']
    require(manifest['schema'] == 'balloon.wind-samples/1' and manifest['provider'] == provider, 'Manifest product mismatch')
    require(manifest['years'] == [2024, 2024] and manifest['hours_utc'] == [0, 6, 12, 18] and manifest['date_convention'] == 'UTC', 'Manifest UTC/year mismatch')
    months = manifest['months']
    require(sorted(row['month'] for row in months) == list(range(1, 13)), 'Manifest is not a complete year')
    # Metadata-only time support check; no NPY/raw acquisition bytes are loaded by this helper.
    for row in months:
        expected_times = [f'2024-{row["month"]:02d}-{day:02d}T{hour:02d}:00:00Z'
                          for day in range(1, calendar.monthrange(2024, row['month'])[1] + 1)
                          for hour in (0, 6, 12, 18)]
        require(row['times_utc'] == expected_times, 'Manifest has incomplete/noncanonical UTC times')
    require(source['source_id'] == expected_id and source['dataset_sha256'] == digest and source['provider'] == provider, 'Archive identity mismatch')
    require(source['profile'] == 'original-utc-wind' and source['adapter_version'] == source['statistics_version'] == 'original-utc-wind/1', 'Archive version/profile mismatch')
    require(source['label'] == manifest['label'] and source['weighting'] == manifest['weighting'], 'Label or weighting differs from manifest')
    expected_weighting = 'gaussian-area-equal-times' if provider == 'JRA-3Q' else 'spherical-area-equal-times'
    require(manifest['weighting'] == expected_weighting, 'Unexpected provider weighting')
    require(cap['years_fixed'] == manifest['years'] and cap['native_hours_utc'] == manifest['hours_utc'] and cap['date_convention'] == manifest['date_convention'], 'Descriptor temporal support mismatch')
    require(cap['display_grains'] == ['half', 'month', 'season'] and cap['grain'] == 'half', 'Period support mismatch')
    require(all(cap[k] is True for k in ['annual', 'spatial', 'raw_observations', 'hour_filter', 'wind_rose', 'wind_rose_hour_filter', 'wind_rose_point_select', 'empirical_monthly_profiles']), 'Missing supported capability')
    require(all(cap[k] is False for k in ['year_filter', 'quantile_reconstruction', 'flight_weather_field']), 'Unsupported capability advertised')
    require(cap['missing_policy'] == 'reject_incomplete_or_unequal_support' and cap['wind_rose_hours_utc'] == manifest['hours_utc'], 'Missing-value/rose support mismatch')
    grid = [{k: row[k] for k in ('cell_id', 'lat', 'lon', 'weight')} for row in source['native_grid']]
    levels = [{k: row[k] for k in ('level_id', 'level_hpa')} for row in source['levels']]
    require(grid == manifest['grid'] and len(grid) == source['native_grid_count'] == cell_count, 'Native grid projection mismatch')
    require(all(row['gauss_weight'] == row['weight'] for row in source['native_grid']), 'Native weight alias mismatch')
    require(levels == manifest['levels'] and len(levels) == level_count, 'Native pressure projection mismatch')
    require(cap['hour_level_ids'] == [row['level_id'] for row in manifest['levels']], 'UTC pressure support mismatch')
    bounds = {'west': min(row['lon'] for row in grid), 'east': max(row['lon'] for row in grid),
              'south': min(row['lat'] for row in grid), 'north': max(row['lat'] for row in grid)}
    require(source['bounds'] == bounds, 'Native bounds mismatch')
    centre = ((bounds['north'] + bounds['south']) / 2, (bounds['east'] + bounds['west']) / 2)
    point = min(grid, key=lambda row: (row['lat'] - centre[0]) ** 2 + (row['lon'] - centre[1]) ** 2)
    require(source['wind_rose_point'] == {k: point[k] for k in ('cell_id', 'lat', 'lon')}, 'Default native wind-rose point mismatch')
    require(source['units'] == {'wind': 'm/s', 'pressure': 'hPa', 'altitude': 'm', 'direction': 'degree'}, 'Display units mismatch')
    require(source['raw_samples']['schema'] == manifest['schema'] and source['raw_samples']['bundle_sha256'] == digest and source['raw_samples']['years_fixed'] == manifest['years'] and source['raw_samples']['complete_months'] == list(range(1, 13)), 'Raw support identity mismatch')
    metadata = source['attribution']['metadata']
    require(metadata['provider'] == provider and metadata['label'] == manifest['label'], 'Attribution product mismatch')
    compared = []
    for key in ('dataset_url', 'dataset_doi', 'license', 'citation', 'attribution', 'conversion', 'derived_subset'):
        if key in manifest['provenance']:
            require(metadata[key] == manifest['provenance'][key], 'Attribution mismatch: ' + key)
            compared.append(key)
    return {'source_id': expected_id, 'dataset_sha256': digest, 'levels': level_count, 'cells': cell_count,
            'native_grid_sha256': sha(canonical(grid)), 'native_levels_sha256': sha(canonical(levels)),
            'manifest_time_counts': {row['month']: len(row['times_utc']) for row in months},
            'checked_support_projection_matches_manifest': True,
            'checked_support_projection': ['native ID/coordinates/weights/order', 'native pressure ID/hPa/order', 'bounds/default point', 'year/UTC/month metadata', 'weighting/units', 'declared capabilities'],
            'compared_attribution_fields': compared,
            'limits': 'Manifest metadata/descriptor binding only. Full original-array byte integrity and legal/citation evaluation belong to the separate acquisition/archive receipts.'}


def legacy_proof(source):
    expected_id = source_identity([LEGACY_PROFILE, 'jra3q-halfmonth-summary/3', LEGACY_DATASET])
    require(source['source_id'] == expected_id and source['profile'] == LEGACY_PROFILE and source['dataset_sha256'] == LEGACY_DATASET, 'Legacy source identity mismatch')
    require(source['adapter_version'] == 'jra3q-halfmonth-summary/3' and source['statistics_version'] == 'gaussian-pooled-wind/3', 'Legacy versions mismatch')
    require(source['capabilities']['years_fixed'] == [2016, 2025] and source['raw_samples'] is None and source['capabilities']['empirical_monthly_profiles'] is False, 'Legacy support mismatch')
    require(source['wind_rose_point']['cell_id'] == 285, 'Legacy fixed wind-rose point mismatch')
    return {'source_id': expected_id, 'previous_adapter_v2_source_id': source_identity([LEGACY_PROFILE, 'jra3q-halfmonth-summary/2', LEGACY_DATASET]),
            'dataset_sha256': LEGACY_DATASET, 'adapter_version': source['adapter_version'], 'statistics_version': source['statistics_version'],
            'saved_artifact_readback': 'Not exercised by this helper; see restart-<mode>-readback01/receipt.json and its enumerated saved climate GET hashes.',
            'limits': 'Fixed DB digest and advertised profile/support. Original DB values and supplier legal attribution are not revalidated here.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['isolated', 'live'], required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    port = 8570 if args.mode == 'isolated' else 8551
    out = root / ('deployment-catalog-' + args.mode + '570.json')
    require(not out.exists(), 'Existing receipt is preserved; choose a new review run explicitly')
    prep_bytes = (root / 'live-static-preparation09.json').read_bytes()
    prep = json.loads(prep_bytes)
    baseline_bytes = (root / 'old-static-baseline570.json').read_bytes()
    baseline = json.loads(baseline_bytes)
    require(baseline['preparation_sha256'] == sha(prep_bytes), 'Static preparation changed after baseline observation')
    require(set(baseline['assets']) == set(prep['extra_prior_asset_paths']), 'Old asset inventory mismatch')
    # Refuse missing manifest inputs before contacting the local service.
    manifests = {}
    for name in ('jra3q', 'era5'):
        path = Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024') / name / 'manifest.json'
        raw = path.read_bytes()
        manifests[name] = (path, raw, json.loads(raw))
    raw_catalog = get(port, '/api/v1/climate-sources')
    catalog = json.loads(raw_catalog)
    require(not catalog['errors'] and len(catalog['sources']) == 3, 'Expected three error-free climate sources')
    sources = catalog['sources']
    require(len({row['source_id'] for row in sources}) == 3, 'Duplicate source identity')
    proof = {}
    for name, provider, levels, cells in [('jra3q', 'JRA-3Q', 38, 570), ('era5', 'ERA5', 37, 1188)]:
        path, raw, manifest = manifests[name]
        expected_id = source_identity(['original-utc-wind/1', sha(raw)])
        matches = [source for source in sources if source['source_id'] == expected_id]
        require(len(matches) == 1, 'Expected raw source missing')
        proof[name] = raw_proof(matches[0], manifest, sha(raw), provider, levels, cells)
    legacy = [source for source in sources if source['profile'] == LEGACY_PROFILE]
    require(len(legacy) == 1, 'Expected legacy profile missing')
    proof['legacy'] = legacy_proof(legacy[0])
    dist = root / ('dist09' if args.mode == 'isolated' else 'dist-live09')
    names = ['index.html'] + [name for name in prep['new_dist_files'] if name.startswith('assets/') and name.endswith(('.js', '.css'))]
    if args.mode == 'live':
        names += prep['extra_prior_asset_paths']
    assets = {}
    for name in sorted(set(names)):
        expected = safe_file(dist, name).read_bytes()
        if name in prep['new_dist_files']:
            expected_sha = prep['new_dist_files'][name]
            basis = 'preparation09.new_dist_files'
        else:
            expected_sha = baseline['assets'][name]['sha256']
            require(len(expected) == baseline['assets'][name]['bytes'], 'Old asset size mismatch')
            basis = 'old-static-baseline570 observation at ' + baseline['at']
        require(sha(expected) == expected_sha, 'Static input bytes no longer match fixed evidence: ' + name)
        actual = get(port, '/' if name == 'index.html' else '/' + name)
        require(actual == expected and sha(actual) == expected_sha, 'Delivered static asset mismatch: ' + name)
        assets[name] = {'bytes': len(actual), 'sha256': sha(actual), 'basis': basis}
    for path, raw, manifest in manifests.values():
        require(path.read_bytes() == raw, 'Manifest changed during catalog observation')
    require((root / 'live-static-preparation09.json').read_bytes() == prep_bytes and (root / 'old-static-baseline570.json').read_bytes() == baseline_bytes, 'Static evidence changed during observation')
    record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'mode': args.mode, 'port': port,
              'sources': proof, 'catalog_response_sha256': sha(raw_catalog), 'static_assets': assets,
              'helper_sha256': sha(Path(__file__).read_bytes()), 'preparation_sha256': sha(prep_bytes),
              'old_static_baseline_sha256': sha(baseline_bytes),
              'limits': 'Finite localhost catalog/current manifest and selected index/CSS/JS bytes only. Old asset baseline proves its stated observation-time bytes, not earlier browser delivery. Saved artifacts are validated by the separate post-restart helper. Not a full GUI/Google/scene3d asset test, scientific validation, legal review or new original-data verification.'}
    with out.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'mode': args.mode, 'sources': list(proof), 'checked_static_assets': len(assets)}))


if __name__ == '__main__':
    main()
