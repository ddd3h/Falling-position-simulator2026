# JRA 2024 原標本取得 最終票

2024全12月、00/06/12/18 UTCの全1,464時刻、38気圧面、北海道570格子、u/vを取得し、24 NPYとmanifestへ保存した。元2016–2025集計DBと異なる2024独立sourceである。全10年climatologyの完了とはしない。

- manifest: `jra3q-2024/manifest.json`
- SHA256: `3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60`
- original data responses: 144 / 253,857,936 response-body bytes
- NPY: 24 / 253,684,992 bytes（header込み）
- 原Float32 scalar values: 63,420,480 / 253,681,920 data bytes
- year/time support: 2024-01-01T00:00:00Z〜2024-12-31T18:00:00Z、全4 UTC、閏年2月を含む

取得器と新tests以外のrepo sourceはこの担当では編集しなかった。固定basis JSONも変更していない。source/test/basisはfreeze03と実取得終了時に同一byte hashを照合した。37 offline tests成功。source指紋、basis指紋、来歴はjra-final-acquisition-receipt.jsonへ戻る。

取得器をimportしない別のXDR parserで、全144原応答のSHA/bytes/軸と、対応するNPYへの全63,420,480値をbit比較して一致した。12月・1,464時刻・格子・気圧面・成分が全て揃うことを検査した。未取得月の0埋め、時刻の間引き、他年混入、推定分位による代替は行っていない。証拠はverify-jra-2024-bundle.pyとjra-final-original-bit-check.json/log。

実読取の有限確認ではMonthlySamples起動0.433秒、全38面4UTCの12月profile2.952秒、UTC00全38面0.616秒、300hPa1面0.120秒だった。全月available、UTC00は366時刻、2月前後半は60/56時刻。これはこの端末のcached filesystem上の読取実測であり、cold diskや全環境のSLAではない。1月300hPaの独立CDF sort比較は別のpartial票に保存済み。

run03のHTTP503は5月11〜15日u要求で即停止し、原成功4か月と失敗fragment/receiptを保全した。主担当がERA回復を確認後、JRAも同失敗応答1件のみを明示probeし完全HTTP200成功。続くrun04はJRA1＋ERA1の同host合計2で再開し、94新要求・164,729,713 response-body bytes、error=nullで完了した。途中の接続timeout1件は宣言済み最大3回内の限定retryで回復した。失敗を後続成功で消さず、stop/probe/run04票を分けてある。503の根因をrate-limitや過負荷と断定しない。

原応答・全域NPYはrepo外に保持する。Gitへの限定原標本・全域固定集計・再取得経路の保存、RawSource/GUI接続と画面受入は主担当の範囲。本担当はUI/API/Gitや実行中projectを操作していない。取得実行成功、原値保持、科学的精度、画面受入を区別する。取得プロセスと通信要求は終了済み。
