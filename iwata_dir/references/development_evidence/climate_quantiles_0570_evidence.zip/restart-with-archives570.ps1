param(
  [Parameter(Mandatory=$true)][ValidateSet('isolated','live')][string]$Mode,
  [Parameter(Mandatory=$true)][int]$ExpectedProcess,
  [Parameter(Mandatory=$true)][string]$ExpectedInstance,
  [ValidateSet('01','02')][string]$Attempt='01'
)
$ErrorActionPreference='Stop'
$taskRoot='C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570'
$taskPython='C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe'
$taskPort=if($Mode -eq 'live'){8550}else{8570}
$taskState=if($Mode -eq 'live'){'C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/state-review550'}else{Join-Path $taskRoot 'state-ui01'}
$taskReceipt=Join-Path $taskRoot ('restart-'+$Mode+'-archives'+$Attempt)
$taskDist=Join-Path $taskRoot $(if($Mode -eq 'live'){'dist-live09'}else{'dist09'})
$taskCapture=Join-Path $taskRoot ('restart-'+$Mode+'-preflight02')
$taskCaptured=Get-Content -LiteralPath (Join-Path $taskCapture 'receipt.json') -Raw | ConvertFrom-Json
if($taskCaptured.mode -ne $Mode -or $taskCaptured.port -ne $taskPort -or $taskCaptured.source_state.Replace('\','/') -ne $taskState.Replace('\','/') -or $taskCaptured.endpoints.health.instance_id -ne $ExpectedInstance){throw 'Backup receipt does not match this restart'}
if(([DateTimeOffset]::UtcNow-[DateTimeOffset]::Parse($taskCaptured.at)).TotalMinutes -gt 10){throw 'Backup receipt is stale'}
foreach($taskProperty in $taskCaptured.sqlite_backups.PSObject.Properties){
  $taskBackup=Join-Path (Join-Path $taskCapture 'sqlite') $taskProperty.Name
  if($taskProperty.Value.integrity -ne 'ok' -or (Get-FileHash -LiteralPath $taskBackup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value.sha256){throw 'Backup readback mismatch'}
}
$taskRuntimeReceipt=Get-Content -LiteralPath (Join-Path $taskRoot 'runtime-manifest04.json') -Raw | ConvertFrom-Json
foreach($taskProperty in $taskRuntimeReceipt.files.PSObject.Properties){
  if((Get-FileHash -LiteralPath (Join-Path $taskRuntimeReceipt.runtime $taskProperty.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value){throw 'Runtime changed'}
}
$taskDistReceipt=Get-Content -LiteralPath (Join-Path $taskRoot 'live-static-preparation09.json') -Raw | ConvertFrom-Json
foreach($taskProperty in $taskDistReceipt.new_dist_files.PSObject.Properties){
  if((Get-FileHash -LiteralPath (Join-Path $taskDist $taskProperty.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value){throw 'Frontend changed'}
}
if(!(Test-Path -LiteralPath $taskPython)){throw 'Python executable missing'}
if(Test-Path -LiteralPath $taskReceipt){throw 'Receipt path already exists; preserve it'}
if(!(Test-Path -LiteralPath (Join-Path $taskDist 'index.html'))){throw 'Prepared frontend is missing'}
$taskArchives=@('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q/manifest.json','C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/era5/manifest.json')
foreach($taskManifest in $taskArchives){
  $taskData=Get-Content -LiteralPath $taskManifest -Raw | ConvertFrom-Json
  if($taskData.months.Count -ne 12 -or $taskData.years[0] -ne 2024 -or $taskData.years[1] -ne 2024){throw 'Incomplete archive'}
}
if(!(Test-Path -LiteralPath (Join-Path $taskState 'registry.sqlite3'))){throw 'Existing state missing'}
$taskOwner=@(Get-NetTCPConnection -LocalPort $taskPort -State Listen)
if($taskOwner.Count -ne 1 -or $taskOwner[0].OwningProcess -ne $ExpectedProcess){throw 'Observed service owner changed'}
$taskCommand=Get-CimInstance Win32_Process -Filter ('ProcessId = '+$ExpectedProcess)
if($taskCommand.CommandLine -notmatch 'uvicorn' -or $taskCommand.CommandLine -notmatch 'backend.app:create_app' -or $taskCommand.CommandLine -notmatch ('--port '+$taskPort+'(?:\s|$)')){throw 'Unexpected service command'}
$taskHealth=Invoke-RestMethod ('http://127.0.0.1:'+$taskPort+'/api/v1/health')
if($taskHealth.instance_id -ne $ExpectedInstance -or !$taskHealth.flight_execution.available -or $taskHealth.flight_execution.restart_required){throw 'Unexpected service instance/state'}
foreach($taskPair in @(@('runs','runs'),@('ensembles','ensembles'),@('weather-acquisitions','acquisitions'))){
  $taskRows=Invoke-RestMethod ('http://127.0.0.1:'+$taskPort+'/api/v1/'+$taskPair[0])
  foreach($taskRow in $taskRows.($taskPair[1])){if($taskRow.state -in @('queued','running','cancelling','acquiring')){throw 'Active work; restart refused'}}
}
foreach($taskEndpoint in @('project','runs','ensembles','weather-acquisitions')){
  $taskRaw=(Invoke-WebRequest ('http://127.0.0.1:'+$taskPort+'/api/v1/'+$taskEndpoint)).Content
  $taskDigest=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($taskRaw))).ToLowerInvariant()
  if($taskDigest -ne $taskCaptured.endpoints.$taskEndpoint.sha256){throw 'User state changed after capture'}
}
New-Item -ItemType Directory -Path $taskReceipt | Out-Null
@{mode=$Mode;port=$taskPort;owner=$ExpectedProcess;instance=$ExpectedInstance;state=$taskState;stop_is_process_stop_not_graceful_shutdown_proof=$true} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskReceipt 'before.json') -Encoding utf8
# Caller separately captures GET state and a consistent read-only SQLite backup before invocation.
Stop-Process -Id $ExpectedProcess
Wait-Process -Id $ExpectedProcess -Timeout 10 -ErrorAction SilentlyContinue
if(Get-Process -Id $ExpectedProcess -ErrorAction SilentlyContinue){throw 'Old process has not exited'}
$taskReleaseDeadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
do {
  $taskRemaining=@(Get-NetTCPConnection -LocalPort $taskPort -State Listen -ErrorAction SilentlyContinue)
  if(!$taskRemaining.Count){break}
  if(@($taskRemaining | Where-Object {$_.OwningProcess -ne $ExpectedProcess}).Count){throw 'A different process acquired the port'}
  Start-Sleep -Milliseconds 250
} while([DateTimeOffset]::UtcNow -lt $taskReleaseDeadline)
if($taskRemaining.Count){throw 'Port was not released in the finite wait'}
$env:BALLOON_DATA_DIR=$taskState
$env:BALLOON_FRONTEND_DIST=$taskDist
$env:BALLOON_CLIMATE_DB='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb'
$env:BALLOON_CLIMATE_SHA256='1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a'
$env:BALLOON_CLIMATE_ARCHIVES=ConvertTo-Json -Compress -InputObject $taskArchives
if($Mode -eq 'live'){$env:BALLOON_HISTORICAL_CATALOG='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/historical-catalog550-02.json'}
else{Remove-Item Env:BALLOON_HISTORICAL_CATALOG -ErrorAction SilentlyContinue}
$taskLaunched=Start-Process -FilePath $taskPython -ArgumentList @('-X','utf8','-B','-m','uvicorn','backend.app:create_app','--factory','--host','127.0.0.1','--port',$taskPort.ToString()) -WorkingDirectory (Join-Path $taskRoot 'runtime04') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskReceipt 'stdout.log') -RedirectStandardError (Join-Path $taskReceipt 'stderr.log')
@{wrapper_pid=$taskLaunched.Id;runtime=(Join-Path $taskRoot 'runtime04');dist=$taskDist;port=$taskPort;state=$taskState;archives=$taskArchives} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskReceipt 'launched.json') -Encoding utf8
$taskLaunched.Id
# Startup completion is independently read back by the caller before UI use.
# This script does not retry a failed launch or restore/overwrite user state.
