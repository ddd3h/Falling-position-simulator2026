from pathlib import Path
import calendar,hashlib,json,numpy as np
p=Path('C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570')
source_root=Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q')
demo_root=p/'demo-build/jra3q'
source_path=source_root/'manifest.json'; demo_path=demo_root/'manifest.json'
source=json.loads(source_path.read_bytes());demo=json.loads(demo_path.read_bytes())
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
assert digest(source_path)=='3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60'
assert source['years']==demo['years']==[2024,2024]
assert source['hours_utc']==demo['hours_utc']==[0,6,12,18]
assert source['levels']==demo['levels'] and len(demo['levels'])==38
assert demo['weighting']==source['weighting']=='gaussian-area-equal-times'
latitude,longitude=43.2,141.4
ys=sorted(set(c['lat'] for c in source['grid']));xs=sorted(set(c['lon'] for c in source['grid']))
expected_y={max(y for y in ys if y<=latitude),min(y for y in ys if y>latitude)}
expected_x={max(x for x in xs if x<=longitude),min(x for x in xs if x>longitude)}
expected_grid=[c for c in source['grid'] if c['lat'] in expected_y and c['lon'] in expected_x]
assert len(expected_grid)==4 and demo['grid']==expected_grid
indices=[next(i for i,c in enumerate(source['grid']) if c['cell_id']==selected['cell_id']) for selected in demo['grid']]
assert demo['provenance']['derived_subset']['source_manifest_sha256']==digest(source_path)
assert demo['provenance']['derived_subset']['original_cell_ids']==[c['cell_id'] for c in demo['grid']]
assert demo['provenance']['derived_subset']['selection_point']=={'latitude':43.2,'longitude':141.4}
assert [m['month'] for m in demo['months']]==list(range(1,13))
checks=[]; total_values=0; file_records=[]
for original,small in zip(source['months'],demo['months']):
 month=small['month'];expected_times=[f'2024-{month:02d}-{day:02d}T{hour:02d}:00:00Z' for day in range(1,calendar.monthrange(2024,month)[1]+1) for hour in (0,6,12,18)]
 assert original['month']==month and original['times_utc']==small['times_utc']==expected_times
 for component in ('u','v'):
  src=source_root/original[component]['file'];dst=demo_root/small[component]['file']
  assert src.stat().st_size==original[component]['bytes'] and digest(src)==original[component]['sha256']
  assert dst.stat().st_size==small[component]['bytes'] and digest(dst)==small[component]['sha256']
  a=np.load(src,mmap_mode='r',allow_pickle=False);b=np.load(dst,mmap_mode='r',allow_pickle=False)
  assert b.dtype==a.dtype==np.float32 and b.shape==(len(expected_times),38,4)
  selected=a[:,:,indices]
  assert np.array_equal(selected.view(np.uint32),b.view(np.uint32)),(month,component)
  total_values+=b.size
  checks.append({'month':month,'component':component,'shape':list(b.shape),'all_bits_equal':True})
for path in sorted(demo_root.rglob('*')):
 if path.is_file():file_records.append({'path':path.relative_to(demo_root).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)})
result={'scope':'independent source-cell selection, exact UTC/level retention and Float32 bit comparison; no prepare tool/module imported','source_manifest':str(source_path),'source_manifest_sha256':digest(source_path),'demo_manifest':str(demo_path),'demo_manifest_sha256':digest(demo_path),'selection_point':{'latitude':latitude,'longitude':longitude},'grid':demo['grid'],'months':12,'times':1464,'levels':38,'cells':4,'scalar_values':total_values,'checks':checks,'files':file_records,'limits':['four-cell functional demo; not a replacement for the full region','no interpolation or value synthesis','no UI or scientific accuracy validation']}
(p/'jra-demo-independent-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','files']},ensure_ascii=False,indent=2))
