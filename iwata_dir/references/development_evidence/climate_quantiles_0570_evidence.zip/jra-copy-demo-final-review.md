# JRA常設archive・4セルdemo 完了票

完成済みTemp archiveを指定常設先 `C:\Users\genia\AppData\Local\SpaceBalloonSimulator\climate-archives-2024\jra3q` へ全355 files / 512,365,196 bytesコピーした。既存を上書きせず、元Tempを保持し、copy後にsourceとdestinationの全SHA256を再照合して一致。各src/path/bytes/hashはjra-persistent-copy-inventory.json。完全manifest SHAは `3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60` のままである。

現tools/prepare_climate_demo.pyを読解し、43.2N/141.4Eを挟む2×2元格子を全12月・全38面・全4UTCのまま P570/demo-build/jra3q へ作成した。tool SHAは `d4f5eced9302c55b4f135d4a89e4cd3b7816ee3e44b052ee8e7640963bb0efbf`。source code編集なし、ネット要求なし、Git操作なし。

独立検査はprepare toolをimportせず、原manifestから位置の上下格子を再選定し、cell_ids [249,250,279,280]、緯度42.892791748046875/43.267398834228516、経度141.375/141.75と面積重みの保持を確認した。24配列・445,056 Float32値が元570セル配列の該当部分とbit一致。1,464時刻・38面・閏年を含む全12月、各hash/bytesも再照合した。jra-demo-independent-check.jsonとverify-jra-demo-subset.pyが再現根拠。

4セルdemo manifest SHA: `3ff632c02bdbe7fcf3eeddd35d2519fd2f30a970b895a9e38bbf9946372da9dc`。これは機能確認用の小原標本であり、全570セル地域分布の代わりではない。全域archiveは別の常設先に保持する。repo資料/ZIPへの収録、他providerとの整合、GUI受入は主担当の範囲。自分はこの作業でUIを操作/視認していない。
