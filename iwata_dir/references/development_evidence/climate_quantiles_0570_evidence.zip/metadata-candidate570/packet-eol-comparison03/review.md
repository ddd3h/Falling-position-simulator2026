# 派生研究本文の改行比較：有限修正03

主担当の方針を採用可能と判断し、外側close helperの「Q410-02以外は本文不変」の比較だけを修正した。close本体は実行していない。

## 原因と確認

旧比較は新生成byteをdecodeしてCRLFを保持する一方、比較元だけPath.read_textのuniversal newlineでLFへ変えていた。hh.normalizeは版印等を除く関数で、改行は正規化しない。生成器はsourceをread_bytes/decodeし、原抜粋をLFの見出しとjoinするため、原抜粋のCRLFが混在する。

registration02/shadowから既存生成器で再生成し、required02の全7成果物とbyte一致を確認した。Q410-03にはCRLFが6、Q410-05には28あり、比較元は双方LFのみ。両側CRLF→LFだけで全byteが一致する。Q410-02は改行を揃えても本文差が残り、主担当が読解した意図差として扱う。

## 局所修正と反例

両側をread_bytes/decodeした文字列として取得し、この比較の前にCRLF→LFだけを適用した。その後の既存hh.normalizeとQ410-02の例外は維持する。全生成物のbyte保存・SHA、最後の生成byte再現検査、入力hash、allowed paths、guard、PROJECT_PLAN固定比較は変更していない。改行を揃えたファイルを保存する処理もない。比較以外の実行ASTが完全同一であることを照合した。

実helperから比較for文だけをAST抽出して9反例を実行し、全成功。LF/CRLF/実混在は通り、本文追加・空白追加・単独CRは拒否した。版印を無視する既存規則とQ410-02だけの例外は保持。旧比較は実Q03/Q05を拒否し、新比較は全実成果物を受け入れた。

## 境界

これはテキストの同一性判定を対称にする修正であり、hh.normalizeやcheck_contract/guardを緩めない。hash/healthではQ03/Q05は引き続きbyte差として現れるため、最終生成後のprepareでそれぞれ「EOLだけ」の根拠を割り当てる。本文差を科学的に受入れた印でも、未完ZIPの完成、全scope確認、close実行や承認でもない。Rの研究出力・registry・guard・生成器は不変を確認した。

修正helper SHA: a2706ab36c2ed12f37215f19f2a66e0f23ba7a98f430ea9632e972a361f47ddf。before/diff/receiptと再実行可能probeは同フォルダー。初回probeの非ASCII bytes literalによる構文誤りは実行前停止で、修正前probeも保全した。
