# 2024年・native4セルのデモZIP helper：有限レビュー

未実行のbuild_demo_archive570.pyと既存tools/prepare_climate_demo.pyを読んだ。格子/母集団の誤変換は見つからず、二つの独立原標本sourceから4元格子をそのまま切り出す方針は整合する。実行前に両常設入力を揃え、以下の小さな事前条件・同一性検査を明示することを推奨する。コードは変更していない。

## DEMO-PREFLIGHT

場所: build_demo_archive570.py:9-17

Output is created before both sources are checked. At review time ERA permanent manifest is absent; premature run would leave JRA-only partial output and a new-directory rerun would be refused. Input provider/support is only indirectly presumed from absolute path.

提案: Before out.mkdir, validate both fixed source objects and pin their manifest hashes. Require provider JRA-3Q/ERA5, raw schema, [2024,2024], all 12 months and expected 570/38 vs1188/37 native support. Keep partial outputs on later failure and choose a new output explicitly; do not delete/overwrite or silently reuse them.

境界: No output/data error has occurred; helper has not been run. Root can instead enforce these preconditions externally with a receipt.

## DEMO-INDEPENDENT-SELECTION

場所: build_demo_archive570.py:19-30; tools/prepare_climate_demo.py:26-49

Independent value comparison uses IDs selected by subset itself. It verifies raw values at those IDs, but would also pass a wrong four-cell choice. Current subset code does choose the correct bracketing corners.

提案: Independently derive the two native coordinates bracketing 43.2/141.4, compare the four ID/lat/lon/weight records to demo.grid, and require demo.levels == source.levels, years/hours/weighting/provenance retained except declared subset changes. Preserve original array axis order.

境界: Do not require equal JRA/ERA coordinates: each product has a different native grid and retains its own support.

## DEMO-FIXED-INPUT

場所: build_demo_archive570.py:15-30,47

The outer MonthlySamples instance precedes the separate subset loader. Its manifest hash is written to results without a post-comparison source.assert_current. An ordinary change between the two loaders could detach that outer hash from the later values.

提案: After each full value comparison call source.assert_current (or verify_full) and demo.assert_current; record build helper SHA plus Python/NumPy versions in verification. The subset itself already validates its own original input and output.

境界: Expected inputs are finished permanent copies; no mutation was observed. This does not require a repo source change.

## DEMO-CONVERSION-NOTE

場所: references/climate_demo_057/README.md:48

Conversion description currently says only DAP2 Float32. ERA completed input may contain explicitly acquired NCSS NetCDF3 values and preserved DODS responses.

提案: At final publication describe DAP2 or NCSS NetCDF3 original Float32 -> NPY float32 plus native subset, with per-request transport provenance retained; do not claim U/all-year transport equality merely from the earlier V probes.

境界: README is still explicitly work-in-progress. No edit made during this review.

## 保持される意味と安全性

元IDはarray indexに読み替えず、選択元の順番を保つ。year/UTC/level/weight/帰属をdeepcopyし、全24配列をfloat32のまま切り出す。外側の全値tobytes比較はsigned zeroを含むbit一致を要求する。2×(24配列＋manifest)=50member、元UTCは366日×4=1464時刻、予定比較はJRA445056値・ERA433344値となる。

JRAの元manifestから独立に囲みを求めると、ID249/250/279/280、緯度42.892791748046875/43.267398834228516、経度141.375/141.75。ERAには別のnative格子を使い、二資料を同一座標へ補間しない。

出力は新規dir/ZIP排他的作成で既存を上書きしない。抽出器はinventory/member/SHA・path包含・5MiB/memberを確認し、NPY/manifestを再検証する。予定の原応答本体はZIP外で、URL/hash等の来歴と4セル原配列を同梱する。全北海道・十年分・飛行用気象場の再現とは呼ばない。圧縮環境を跨ぐZIP自体の完全同一性と、全member内容の同一性も区別する。

## 読解した入力と限界

JRA常設manifestのmetadataは存在し2024/12月/570格子/38面。ERA常設manifestとdemo-final570は確認時に未作成。原配列はロードせず、helper/subset/extractを実行せず、通信・source編集・試験も行っていない。実完成/全値比較/ZIP readbackの成功は今後の実行票で判定する。SHAと具体提案は同名JSON票。


## 改訂版の再読と採否（revision02）

改訂helper SHA `ecb8ab9bb5f4578193faa91d37844e7d05a065c7e4e1d110977f09f29712dccb`（5120 bytes）を直接再読した。既存subset / MonthlySamplesのSHAは初回と同一。helperはAST構文解析だけを行い、import・実行していない。

- **DEMO-PREFLIGHT：解消。** 両資料を出力dir作成前に読み、2024単年・全12月・provider・570×38 / 1188×37の支持を検証する。MonthlySamplesの既存検証と合わせ、raw schema、全UTC、有限Float32、file hashを確認する。
- **DEMO-INDEPENDENT-SELECTION：解消。** demoの選択IDから期待位置を作らず、元全格子座標から固定点の南北・東西を独立導出し4隅を照合する。元ID/座標/weightを含むgridレコード・面・weighting・UTC・各月時刻の一致も明示した。JRAとERAの格子を同一化しない。
- **DEMO-FIXED-INPUT：解消。** 全値byte比較の後に元sourceとdemoのassert_currentを実施し、両manifest指紋、helper指紋、NumPy版を記録する。Python版の追加は再圧縮環境の追跡には有用だが、今回の全member SHA readbackの必須条件ではない。

**残る資料処置：** READMEの「DAP2だけ」という変換説明は、DAP2／明示NCSS NetCDF3の実来歴に合わせ主担当が最終資料で訂正する。Vの限定比較をUや全通年transport一致へ広げない。この処置はhelperの新しい実行阻害ではない。

**指紋記録の訂正：** 初稿を閲覧した時のhelper SHAは `1745dd5437b4b568b54d2c7af362f126c1246de2a10584b3c3270f2b6c6ef16b`。初回JSON票を書き出す間に主担当が修正したため、同票inputsには改訂後SHAが記録され、初稿指摘の対象版とずれた。元票bytesを `demo-helper-review-revision02/before-review.*` に保全し、今回JSONで初稿閲覧版と改訂再読版を分離した。初稿helper自体の物理copyは保存しておらず、事前保全したとは記さない。

**有限結論：** 改訂helperに新しい阻害点は見つからない。固定の2024年・各4元格子デモを、完成した両入力から実行する設計として妥当。原配列/ZIP生成/抽出readbackはこのレビューでは実行しておらず、実成功は主担当の実行票へ戻す。ERAの現取得状態も再確認していない。帰属保持はdeepcopy経路の読解であり外部licenseの再確認ではない。4セル1年を地域全量・十年・飛行場の代替とはしない。
