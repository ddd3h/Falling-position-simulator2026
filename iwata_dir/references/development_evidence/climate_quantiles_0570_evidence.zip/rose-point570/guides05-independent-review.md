# native地点追補：変更3頁の独立確認

対象は guides570-05 の PROGRAM PDF物理7/17頁と THEORY PDF物理23頁（印字22頁）。PNG 3枚を実際に視認し、該当TeX、backendの分位/風配、FEの点要求/風配検査、4文書同期票を有限に照合した。画像・PDF・source・入力のSHAと実行結果は同名JSONに保存した。TeX/PDFはbuild.jsonの指紋と一致した。

PROGRAM 7頁は気圧面/風配点を同じ要求列で扱うhook、点候補のDOMを持つcontroller、元格子図/count検査を持つclimateDistributions、固定図/条件を捕捉するexportを分けている。artifactと草案の分離、保存済3粒度の切替に追加POST不要という記述は現sourceと整合する。固定summaryの矢印ラベルも判読でき、箱と文字の重なりはない。

PROGRAM 17頁は取得器→外生原標本束→archive→samples/共通計算の責務が明確。archiveが全12か月を要すること、地域分位/平均と選択1地点の風配を分けること、原格子を他製品へ補間しないことは実装と整合する。_roseの実効pointは局所引数であり、資料の既定pointや地域poolを変更しない。2×2例を全域の代表標本としない注意も残っている。カードの本文・矢印・下段注記に見切れや重なりはない。

THEORYは格子×選択UTCの面積加重経験CDF、前半/後半の別中央値、月全体p10–p90を明示しており、samples.pyの面ごとのnp.quantile(inverted_cdf)と一致する。一点風配のNに格子数を掛けず、旧DBの固定285点/全4UTCと、rawの既定点または明示native選択を分けている。rawの静穏は方向を作らず分母に保持、旧DBの区分を書き換えない式もcount実装と整合する。「代表地点」は地域全体の代表性の保証には読まないよう本文で区別されている。本文はPROGRAMより密だが、式・区分説明・図を含め100dpi原寸画像で読め、下端も収まっている。

4文書同期票との間に、新しい矛盾や必須適用漏れは見つからなかった。旧DBのadapter/statistics /3、optional rose_cell_idの省略互換、rawの現在catalogによる旧保存からの明示点切替、未適用草案保持、点変更中の面探索停止、生成済みSVGの地点固定は各文書の役割に応じて接続されている。指南書に操作・入力契約を全面複写する必要はない。

既存のFE実DTO検査を、同じBALLOON_CLIMATE_SAMPLE_DIR=real-dto570/legacy-dbで1回だけ再実行した。climate-expansion.test.ts は25/25成功・失敗0・skip0。外部2件は全時刻38面/固定285点と時刻subset20面/風配非対応をそれぞれ読み、半月/月/季節のprojectionが成功した。新ログは legacy-frontend-regression05.json / .log。実DTOは変形していない。

今回の判定は変更3頁の可読性と該当source/既存実DTOの整合性に限る。実UIの操作、全資料の科学的受入、原配列の再数値照合を実施したとはしない。ERA取得CLIは親担当からNCSS追加中と共有されており、その確定後にCOMMANDS/WEATHERの取得節へ別途同期が必要。今回の4文書票にあるJRA通年/ERA3か月＋部分停止という記録を、両製品通年完成へ拡張しない。
