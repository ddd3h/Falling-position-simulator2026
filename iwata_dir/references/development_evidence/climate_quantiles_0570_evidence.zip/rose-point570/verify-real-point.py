from pathlib import Path
import hashlib,json,time,math,sys
from collections import Counter
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from backend.climate.archive import WindArchiveSource
from backend.climate.contracts import ClimateQuery,Bounds
from backend.climate.service import ClimateService
P=Path('C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570/rose-point570')
before=json.loads((P/'before.json').read_text(encoding='utf8'))
old_checks=[]
for case in before['old_cases']:
 svc=ClimateService(P/'old-stores'/case['kind'])
 assert svc.get_analysis(case['artifact']['analysis_id'])==case['artifact']
 assert svc.create_analysis(case['body'])==case['artifact']
 null={'client_request_id':case['body']['client_request_id'],'query':{**case['body']['query'],'rose_cell_id':None}}
 assert svc.create_analysis(null)==case['artifact']
 assert svc._body(null)[2]==case['canonical_request']
 assert svc._identity(case['artifact']['summary']['source'],ClimateQuery.from_mapping(null['query']))==case['identity']
 old_checks.append({'kind':case['kind'],'analysis_id':case['artifact']['analysis_id'],'saved_get_retry_null_legacy_identity_equal':True})
path=Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q/manifest.json')
manifest_sha=hashlib.sha256(path.read_bytes()).hexdigest(); m=json.loads(path.read_bytes())
source=WindArchiveSource(path); level=next(l['level_id'] for l in m['levels'] if l['level_hpa']==300)
base={'source_id':source.source_id,'level_id':level,'bounds':Bounds(141.375,141.75,42.892791748046875,43.267398834228516),'hours_utc':[0]}
t0=time.perf_counter(); old=source.query(ClimateQuery(**base)); seconds0=time.perf_counter()-t0
with patch.object(source,'_moments',side_effect=AssertionError('regional moments reloaded')),patch.object(source._samples,'profiles',side_effect=AssertionError('profile reloaded')):
 t0=time.perf_counter(); inside=source.query(ClimateQuery(**base,rose_cell_id=249));seconds1=time.perf_counter()-t0
 outside=source.query(ClimateQuery(**base,rose_cell_id=0))
 again=source.query(ClimateQuery(**base))
assert old==again
assert inside['wind_rose']['point_in_selected_region'] is True
assert outside['wind_rose']['point_in_selected_region'] is False
assert old['wind_rose']['point']['cell_id']==284
for selected in (inside,outside):
 for key in ('population','levels','annual','spatial','display_scales','monthly_profiles','source'):
  assert selected[key]==old[key],key
 for grain in ('month','season'):
  for key in ('timebins','annual','spatial_rows','display_scales'):assert selected['summaries_by_grain'][grain][key]==old['summaries_by_grain'][grain][key]
 assert selected['wind_rose']['rows']!=old['wind_rose']['rows']
# Independent scalar, original-array counting for the chosen native point, all 12 months at UTC00.
ci=next(i for i,c in enumerate(m['grid']) if c['cell_id']==249);li=next(i for i,l in enumerate(m['levels']) if l['level_id']==level)
checks=[]
for month in m['months']:
 u=np.load(path.parent/month['u']['file'],mmap_mode='r');v=np.load(path.parent/month['v']['file'],mmap_mode='r')
 counts=Counter();calm=0;n=0
 for i,t in enumerate(month['times_utc']):
  if int(t[11:13])!=0:continue
  n+=1;a=float(u[i,li,ci]);b=float(v[i,li,ci]);s=math.hypot(a,b)
  if s==0:calm+=1;continue
  angle=math.degrees(math.atan2(-a,-b))%360
  sector=int((angle+11.25)//22.5)%16
  speed_class=sum(s>=x for x in (5,10,20,30,50))
  counts[sector,speed_class]+=1
 rose=inside['summaries_by_grain']['month']['wind_rose']
 for row in (r for r in rose['rows'] if r['timebin_id']==month['month']-1):
  assert row['count']==counts[row['sector'],row['speed_class']]
  assert row['time_count']==n and row['frequency']==row['count']/n
 c=next(r for r in rose['calm_counts'] if r['timebin_id']==month['month']-1)
 assert c['count']==calm and sum(counts.values())+calm==n
 checks.append({'month':month['month'],'time_count':n,'calm':calm,'all_96_bins_equal':True})
assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest_sha
receipt={'old_before_edit_artifacts':old_checks,'raw_manifest':str(path),'raw_manifest_sha256':manifest_sha,
 'source_id':source.source_id,'regional_native_ids':old['population']['selected_cell_ids'],'default_point':old['wind_rose']['point'],'selected_inside_point':inside['wind_rose']['point'],'selected_outside_point':outside['wind_rose']['point'],
 'regional_profiles_moments_invariant':True,'cache_reuse_guard':True,'default_source_point_unchanged':True,'independent_month_bins':checks,'seconds':{'first_region_query':seconds0,'point_only_query':seconds1},
 'limits':'Local source/service only; no browser, production API, existing user state or scientific accuracy validation.'}
(P/'real-point-and-legacy-proof.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False))
