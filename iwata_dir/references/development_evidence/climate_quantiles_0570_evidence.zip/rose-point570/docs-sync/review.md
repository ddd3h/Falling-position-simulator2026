# 地点選択の4文書同期

編集は COMMANDS、IMPLEMENTATION_NOTES、WEATHER_DATA_GUIDE、backend/README の既存4文書に限定。before/after実体とSHAはbefore.json/receipt.json、意味差分はimplementation.diff。読んだ節は両票のread_sectionsに列挙した。PROGRAM/THEORY/PDF/INDEXと正本進捗は主担当へ戻す。

COMMANDSはC-09の操作へ地点候補→明示切替、地域外1点、草案保持、切替中の面スライダー停止、再試行、生成済みSVGの地点確認を追加した。全体の旧確認印は上げず、当該節のsource読解範囲に0.57確認を付した。デモ2資料登録例は両通年束の提供を前提とする旨を補い、途中ERAを年間source扱いしない。

IMPLEMENTATION_NOTESはoptional rose_cell_idの入力/拒否/省略互換、共有既定点と局所実効点、地域cache不変、地点用適用種別と共通1active/latestpending queue、点を含むFE cache、旧raw現在catalog、保存GET/SVGの固定を契約本文へ戻した。現在形に残っていた旧DB adapter/statisticsの/2を、現contracts.pyと一致する/3へ訂正した。旧artifactのschema/数値の書換えを指示せず、raw original-utc-wind/1は保持した。

WEATHERは母集団と支持の違いを中心に、地域×UTCの中央値/月幅と選択1点の経験風配、その分母N、既定/地域外点、旧DB固定285の意味を明記した。限定確認印の0.57はこの統計/原標本節のsource照合に限定し、旧0.24全文や製品URLの再調査としない。JRA全12月とERA3か月＋部分取得停止を、両方の通年完了へ拡大しない。

backend/READMEは運用入口として同じquery/capability/保存・UI境界を接続し、詳細は各正本へ戻した。追補の確認対象がclimate節だけであると明記した。

前FE批評2点の修正も該当sourceで再読した。controllerは旧raw保存のcapability欠落だけでは操作を閉じず、同sourceの現在pointAvailableと選択中sourceを使う。windDownloadConditionsは生成metadata.wind_rose.pointからID/座標を作る。これはsourceの限定再確認であり、主担当の実UI確認に代わる証拠ではない。

文書対応の有限チェック10項目は成功。文書修正のためコード回帰を再実行していない。sourceの意味を再採用したり、未読の全backend/全資料/全UIを確認済みにしていない。新たな矛盾はこの読取範囲では見つからなかった。
