# 原標本の風配地点指定：実装・有限検証

操作前計画は BOOTSTRAP_RUNBOOK.html#s36-climate-point-plan570。今回の意図は、原標本の全元格子にあるu/vを使い、地域の分布を保ったまま任意一点の季節差を読めるようにすること。基準は親担当の現0.57候補（比較元98b6C2、main M550）。元.git、既存application state、ブラウザ、外部API、取得器には触れていない。

## 実装

編集は backend/climate/contracts.py、archive.py、source.py と既存 tests/test_climate.py、test_climate_archive.py、test_climate_service.py の6ファイルだけ。

- ClimateQuery末尾に optional rose_cell_id を追加。bool、負数、float（1.0も含む）、文字列、非数などを拒否。省略/Noneはas_dictへ出さず、旧canonical要求byteとidentityを維持する。
- 原標本sourceだけwind_rose_point_select=trueを公開。指定native IDをgrid要素へ解決し、配列indexと同一視しない。不存在はCLIMATE_SUPPORT。
- _roseへ局所pointを引数で渡す。self._pointとdescriptorの既定点は変えない。未指定queryへ既定IDを補わず、実効点は結果wind_rose.pointに保存する。
- 選択地域外の元格子も許容し、point_in_selected_regionをその点と実際のboundsで返す。地域cache keyへ地点を混ぜず、momentsとmonthly_profilesを再利用する。
- 旧集計DBの明示指定はCLIMATE_UNSUPPORTED/HTTP相当422。Noneは旧指定と同じ。既存attribution metadata修正とその回帰を保持した。

## 試験と実資料照合

1. 対象3suiteは34 passed / 1 opt-in skipped（tests02.log）。追加で残るclimate API/samples/periodsと旧DB opt-inを実行し12 passed（tests03.log）。合計46件が成功し、先のskipは後段で実行した。後段はStarlette依存のDeprecationWarning 1件のみ。両実行とも python -B、pytest -p no:cacheprovider。初回tests01.logの一時fixture権限エラーは保存し、同じ許可済み検査を実行権限付きで再試行した。
2. 連番でなく並びも異なるnative IDs [40,7,901,25] の人工原配列で、選択ID25の全半月/月/季節の風配を独立scalarカウントと照合。地域点40と一点25を混同せず、地域平均・各grainの地域値・profile不変、cache再利用、未指定への復帰完全一致を確認した。
3. 常設JRA 2024 manifest 3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60 を読取専用で使用。300hPa/UTC00/4セル地域を保ち、既定284から249（地域内）と0（地域外）へ変更。地域値/profile不変かつ風配変更、全12月×96binの度数・分母・頻度が原NPYを読む別scalarコードと一致した。2月29時刻、通年366時刻。既定pointを含むsource descriptorは不変。
4. 編集直前に隔離stateへ保存した旧契約raw/旧DBの2artifactを、修正後serviceでGET/同request retry/None追加retryし完全一致。旧canonical要求byteと旧descriptorでのidentityも完全一致。新選択点は別artifactとして固定され、同要求IDへの別地点はCLIMATE_IDEMPOTENCY。新要求IDの同地点は保存cacheを再利用し、sourceなしでも保存GET/retry可能。

実資料probeは verify-real-point.py と real-point-and-legacy-proof.json。最初の地域集計0.435秒、地点のみ0.173秒はこの端末・cache状態の有限計測であり、UI性能保証ではない。

## 元の意図への評価・残る境界

原標本に存在する一点の変更が地域母集団を変えないため、地域の月分布と一点風配を併せて読む用途に適合する。既定点はsource descriptor、利用者が実際に選んだ点は各結果wind_rose.pointに分かれるため、FEは受領した結果の点を表示・保存・出力に使う必要がある。選択草案を表示済み結果の点と混同しないこと、最新要求/圧力cache/保存復帰のUI接続は親担当の範囲で、この票で確認済みとはしない。

今回の追加は地点風配の契約/数値/保存の有限検査であり、両provider全地点の全数検査、ブラウザ操作、運用runtime反映、科学精度、remote保存/main統合の証拠ではない。残るbackend阻害はこの検査範囲では見つからなかった。

before.json / before/ が編集前、after-files.json / after/ が完成指紋とsource。implementation.diffは元.gitを使わず編集前byte保存との比較から生成した。変更前後の6pathと入力・実行票はreceipt.jsonで辿れる。
