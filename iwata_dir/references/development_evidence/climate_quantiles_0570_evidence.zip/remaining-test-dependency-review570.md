# 残る8 test scope：依存変更の有限互換性レビュー

基準は98b6dad115e4ac30c03f06ff3366fc6468022b8a。P560/record-c2のsave-receiptとcandidateを読み、対象8ファイルは基準票・required02・現在のbytes/SHAがすべて一致した。本文の新規変更はない。依存先6ファイルもrequired02の指紋と一致する。

| scope | 静的展開件数 | 今回確認した接点 |
|---|---:|---|
| BACKEND-TEST-SERVICE | 23 | 共通service/appの任意設定追加とproject/run/API境界。版文字列以外のapp契約は不変。 |
| BACKEND-TEST-WEATHER | 18 | 既存weather_options/オフライン取得fixtureと、気象統計archive設定の分離。 |
| BACKEND-TEST-ENSEMBLE | 20 | 共通worker/集合plan-submit・保存snapshotの既存契約。仮の感度分布を科学採用へ広げない。 |
| BACKEND-TEST-CLIMATE-API | 2 | 旧DB専用options、fixture不変、受付済retryの先行解決、保存GETと集計lockの分離。 |
| BACKEND-TEST-WEATHER-GROUND | 11 | 旧weather_groundのASL/model/hash境界。風配のnative点選択とは別API。 |
| BACKEND-TEST-HISTORICAL-ENSEMBLE | 9 | 元UTC窓・欠けた日時・元場hashと既存paused/settle helper。 |
| BACKEND-TEST-RECOVERY550 | 19 | 再開/受付照合/instance guardとhealthの既存field。気象追加fieldを旧保存に要求しない。 |
| BACKEND-TEST-CLIMATE-PERIODS | 5 | rose_cell_id省略と位置引数の互換、samplesなしの旧moment/count経路、UTC/N/保存GET。 |

既存backend-final-full10.logは **166 PASS / 1 SKIP / 1 warning、580.73秒**。静的ASTでbackend/tests全体の既知parametrizeを展開すると167件、今回8scopeは107件となり整合する。8scopeにskip指定はなく、別test_climate.pyの提供DB opt-in 1件がskip数と対応する。quiet logにはnode名・実行コマンド・入力hashがないため、個別107件の実行票を再構成したとはしない。warningはStarlette/AnyIOの非推奨aliasで、失敗ではない。

**追加の阻害点なし。** 全試験は再実行していない。大きい旧testは全行の新規通読とはせず、本文不変をbyte比較で確かめ、変更依存の引数・既定・呼出し・assert接点を有限読解した。旧DB共通create_fixtureはASTも同一。具体の読解範囲・hash・依存照合・静的件数は同名JSONへ保存した。

この票は互換性と既存実行記録の対応に限る。実データの科学的受入、取得完了、UI動作、新しい確認印/close承認を意味しない。source・test・管理実体は未変更。
