# 0.57 原標本 archive の独立批評

2026-10-02。比較基準は `98b6dad115e4ac30c03f06ff3366fc6468022b8a`、全347実体の `climate-expansion550/record-c2/candidate`。読取対象は `backend/climate/archive.py`、`samples.py`、`source.py`、`service.py`、`periods.py`、`statistics.py`、`contracts.py`、`backend/application.py`、`test_climate_archive.py`、`test_climate_samples.py`。repoへの編集、Git操作、原資料変更、ネット取得、実UI操作は行っていない。原標本取得UIだけを後続にし、中央値・月幅・時間帯等の分析機能と実UI確認は今回対象とする訂正済み方針を前提にした。

**結論：この読取範囲では、平均図へのすり替えはなく、原標本から半月中央値2本と月全体p10–p90帯を作る経路は元の分析目的に適合する。独立に見つけた資料選択・エラー隠蔽の2件と、別担当が指摘した数値依存版のcache同一性は主担当が修正し、修正後の独立反例で閉じた。現在残る阻害指摘はない。ただし実2資料の全年取得・全条件数値照合・FE型契約・実UI・性能までを受け入れた結論ではない。**

## 数値と母集団

`samples._profiles` は、選択された原UTC時刻×原格子ごとの `hypot(u,v)` を気圧面ごとに集める。各UTC時刻の重みは等しく、格子はmanifestの面積重みである。月のp10/p90は月の原標本全体、2本のmedianはUTCの1–15日/16–末日をそれぞれ集計する。半月分位を平均して月帯を作らず、地域平均風の時系列分布にも置き換えていない。逆経験CDFは `inf{x : Σ(weight·I[speed≤x]) / Σweight ≥ q}`。人工画面の全9格子等重みと同じ「空間×時間の風速分布」という問いを保ち、実原格子に面積重みを適用する違いは資料・画面で明示すべきである。単一代表地点の風配はこの地域分位とは別の分析である。

独立fixtureは、製品側の `expected_times` を使わずdatetimeを6時間刻みで進めた2024年全12か月、非連続IDの3格子、重み1:3:2、2気圧面。分位のoracleは整数重みを反復展開した独立sortで、NumPy quantileを呼ばない。全4UTC・06/18・00の3条件、異なる格子選択について、12月×2面の月p10/p90・半月medianを比較し最大差0。u/v/風速の月平均も原標本の直接重み付き和と一致した。2月は全4UTC116、単一UTC29、前後半60/56または15/14。季節は実時刻数でpoolし、2024年DJFは91日になる。これは選択した暦年内の12/1/2月の集合であり、連続した2023–24冬の軌跡ではない。時刻をJST日付へ移し替えてはいない。

風配の独立fixtureは固定代表格子の静穏、FROMのN/E/S/Wおよび斜め風、5/10/20/30/50 m/s境界を含む。全4UTCと06/18について12月×96区分×2条件＝2,304区分を照合。非静穏区分＋静穏数が全時刻数、頻度和が1になる。静穏は方向に振り分けず分母に残る。選択地域外の代表点を地域全体の風配と偽らず `point_in_selected_region=false` になる。風配点はarchive全域中心近傍の固定native点で、矩形変更ごとに代表点を変更する実装ではない。

## 修正を確認した点

1. **未知資料IDの明示検証が旧DBへ流れる不具合。** 初回は `_selected_source` が未一致のIDでもlegacyを返し、`verify_source('climate-nonexistent')` がその旧DBの成功を返した。`create_analysis` は後段のID比較で拒否しており、直ちに誤った分析を保存する反例ではなかった。現版はlegacyもID一致を必須とし、未知IDのverify/createを共に `CLIMATE_SOURCE_CHANGED` で拒否する。verify_sourceは現在HTTPに公開されていない内部経路という優先度の境界を保持する。
2. **明示設定した不良legacy DBのエラー隠蔽。** 初回は有効raw sourceが1つあれば、欠損した設定DBの `_source_error` がsources応答から消えた。現版は未設定を意味する `CLIMATE_UNCONFIGURED` と明示設定失敗を分け、有効rawを使えるまま不良legacyのエラーを列挙する。独立fixtureで実欠損path＋有効rawを確認した。
3. **NumPy版と保存cacheの同一性。** 新rawとoptional companionのdescriptorに `numerical_dependencies` が入り、service identityが存在時だけそれを含める。rawのquery_hashにもNumPy版が含まれる。別runtimeを仮定した新要求が別artifactとなり、直接queryと保存結果のquery_hashが一致することを独立に確認した。受理済み同一client_request_idは固定結果を返す既存の再送契約であり、再計算へ変更すべきではない。このaccepted-retry反例は主担当追加testの本文を読んだが、当担当の独立実行数には加算していない。

## 分離と破損時の挙動

manifest bytesのhashが配列digest群、provider、年、native座標、native圧力、重み、UTC軸と結びつき、raw source IDを作る。JRA-3Q/ERA5/2016–25旧DBを同じsourceや同じ年として合成しない。独立fixtureでは2 providerの別source/別保存ID、sourceを設定しないserviceからの同一保存artifact読戻しを確認した。旧DB単体では月分位を捏造せず、optional companionは旧DB hash・2016–25年・座標/面の完全一致を要求する。

12か月揃わないraw archiveは `CLIMATE_COUNTS`、重複UTC・不一致digest・重複level IDは `CLIMATE_SAMPLES`、cache構築後に配列が変われば `CLIMATE_SOURCE_CHANGED` で拒否する。query中のnp.loadのOSErrorも部分結果を返さずClimateErrorになる。pressure変更は同地域/UTCの全気圧面profileを再利用し、返却objectを改変してもcacheは汚れない。明示verify_fullは全hash再照合、通常queryはstatガードであり、metadataを復元した敵対的改変の検出保証ではない。これは実装コメントの限界と一致する。

なおschemaのラベルやhash検証だけで、配列が本当にproviderのm/s原商品であると証明できるわけではない。元URL・変数・単位・時刻・座標対応・欠損値・抽出履歴は取得側の責務として照合が必要である。有限な巨大欠損sentinelをadapter単体のisfinite検査だけで気象値から区別する実装ではなく、取得側の宣言missing値/範囲検査の証拠を残す必要がある。2024原標本の平均を2016–25の旧DB climatologyと一致するはずだと要求してはならない。

## 実JRA 1月の有限照合と残る範囲

`jra3q-2024-preview/manifest.json` のSHA256 `8d778eed8697f9b2f22129ce94a6fe9366f8ac93624b18fba8cbddf3ece42c82` をread-onlyで取得。登録済み1月は原570格子/38面、2024年。3格子（cell_id 0/285/569）×3面（3/350/1000 hPa）×UTC06/18に限り、原u/vのmath.hypotと独立累積重みCDFで月p10/p90・半月medianを照合し差0。時刻62、前後半30/32。残り2–12月はavailable=falseで、これを年間WindArchiveSourceへ登録すると明示拒否した。原1月データの完全性全検算、ERA5実数値、全570格子分位の独立照合、両資料の全年受入を主張しない。

取得完了後に必要なのは、完成束の全12か月支持と取得票照合、および実際の最大地域/UTC変更から保存再訪までの実UI・実時間確認である。気圧面cacheは分位の再sortを防ぐ一方、風配は各grainに対して原選択点を読む実装なので、全操作がraw読取ゼロとは記載しない。API型と描画は別担当の受入へ戻す。ISAは表示用の標準大気高度であって取得した実高度・地表被覆・飛行場ではない。これら未確認を理由に既に一致した分位の接続自体を取り消す必要はなく、完成範囲の主張を分ければよい。

## 証拠と検査の区別

最終 `independent-archive-probe-result.json` は**独立7検査群PASS / FAIL 0**。これは既存unit test件数ではない。対象10実体の開始/終了hash一致を記録し、`independent-archive-review-receipt.json` が固定基準・現hash・証拠hashを結ぶ。`independent-january-profile-result.json` は別の実物限定数値票。`independent-archive-review.diff` は固定0.56との差分である。

初回票/脚本は `independent-archive-probe-attempt01.*` に保持した。初回の風配oracleで (u,v)=(3,4) のFROM約216.87度をsector9と誤記したのは当担当の検査側誤りで、正しくはsector10。訂正して2,304区分が一致した。attempt02は修正後の未知ID拒否を旧観測脚本が未捕捉でFAILとして記録した票であり、新製品故障ではない。また同一要求IDを前回storeへ再投入したため新queryとの比較が混じる余地があり、最終脚本では実行毎に独立storeを作って再確認した。初回票を成功へ書き換えていない。

既存repo test本文は有限に読んだが今回当担当がその全suiteを再実行したとは記載しない。管理検査・全source登録・PDF・Git保存の受入も本票の対象外である。
