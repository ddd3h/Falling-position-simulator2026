# required02 実行consumer・BUILD/告知の有限読解

指定した依存差のみの13scopeについて、新しい阻害点は見つからなかった。本文は直前98b6dadの固定候補と全13件byte一致。変更された上流の型/import/版との接点を読み、再確認の根拠を以下へ限定する。80scope全体や旧科学核の通読・受入ではない。

## BACKEND-WORKER

範囲: backend/worker.py:17-31,34-50

backend/climateをrglobでsource指紋へ含めるため新archive/samplesも対象。execute_runは既存保存場を読み、ClimateQueryや気象統計を飛行場へ変換しない。

接点: backend/application.py:24,65,116-118,210; backend/climate/service.py:67-71,100-115,272-299

## FRONTEND-MAIN

範囲: frontend/src/main.tsx:1-15

Appのimport/exportとCSS load/error後の単一起動を維持。Appの0.57表示・実/人工WeatherScreenの切替は既存入口と整合。

接点: frontend/src/App.tsx:66-78

## SCREEN-WEATHER-CONTROLLER

範囲: frontend/src/screens/weather/controller.js:1-16,90-98,110-119

climate modeを先にmountClimateへ委譲し人工fixtureを実統計へ混ぜない。人工の共通annual/spatial export呼出は追加任意引数を必要とせず有効。既存人工saveの全挙動再受入ではない。

接点: frontend/src/screens/weather/climateController.js:15-24,120-135; frontend/src/screens/weather/export.ts:4-30

## SCREEN-WEATHER-RUNTIME

範囲: frontend/src/screens/weather/runtime.ts:1-18

climateではdirectionのみをinstallしfixture/impactを導入しない。mountの返却をspreadするため新point操作を担うclimate syncとdisposeを保つ。hand-offは人工操作だけを読む。

接点: frontend/src/screens/WeatherScreen.tsx:10-29; frontend/src/screens/weather/climateController.js:129-135

## FRONTEND-CLIMATE-API

範囲: frontend/src/climateApi.ts:1-3

ClimateQuery全体をJSON化するため任意rose_cell_idは失われず、省略なら従来bytesの形を保つ。create/getは同じ包絡検査を通し固定query/result hashとsummaryの対応を確かめる。API自身は新規取得や再集計の時刻制御を持たない。

接点: frontend/src/climateDomain.ts:5,24,36,45

## SCREEN-WEATHER-FIXTURE-SUMMARY

範囲: frontend/src/screens/weather/sources/fixtureSummary.ts:1-5

WindViewModelの新monthlyProfilesは任意であり人工adapterへの必須要求ではない。人工9格子/JST/等重みを維持し、実sourceのnative点やUTC支持と混ぜない。

接点: frontend/src/screens/weather/viewModel.ts:1-9

## SCREEN-WEATHER-PLOTS

範囲: frontend/src/screens/weather/plots.ts:1-21

平均/R/地域幅の共通VMを読み、追加された分位/風配を無条件検査しない。levelsとperiodsの配列順で描画し疎nativeIDを添字として扱わず、24/12/4期間と元面を保つ。風配点選択が地域図の母集団になる経路はない。

接点: frontend/src/screens/weather/viewModel.ts:1-9; frontend/src/screens/weather/sources/climateSummary.ts:1-18

## FRONTEND-CLIMATE-FLIGHT-HANDOFF

範囲: frontend/src/ClimateFlightHandoff.tsx:1-14

artifact/query/result/dataset識別と期間構成・地域・選択UTC・実年を関心として渡す。source固有年は固定2016–25へ戻さず、圧力/風配点を飛行場や放球条件へ自動採用しない。旧半月・新月/季節を受ける読取先と整合。

接点: frontend/src/climateDomain.ts; frontend/src/screens/weather/sources/climateSummary.ts; frontend/src/historicalWorkspace.ts:4-23

## BACKEND-CLIMATE-AGGREGATION

範囲: backend/climate/aggregation.py:1-74

SQL経路は旧DBに限定してperiodsの既定2016–2025支持を使用。時間はn重み、地域はGaussian重み。原標本sourceはSQL annual/spatialを呼ばず、scalesの共通出力だけを利用するため新年引数や点要求の混入がない。

接点: backend/climate/source.py:279-312; backend/climate/archive.py:98-135; backend/climate/periods.py:8-27

## BACKEND-CLIMATE-EXTENSIONS

範囲: backend/climate/extensions.py:1-103

旧DB拡張は同じ16FROM×6速度階級、一点の全4UTC件数を扱う。hours subsetは明示unavailable。source.pyが明示点を先に拒否するため新point selectorを無言で固定285へ落とさない。raw roseはarchive別経路。

接点: backend/climate/source.py:256,279-312; backend/climate/archive.py:155-191

## BACKEND-CLIMATE-STATISTICS

範囲: backend/climate/statistics.py:1-69

finite_number/ClimateErrorの契約は保持。combine_cellsは正の提供weightと同一time_countを使うためraw Gaussian/spherical両方の面積重みをそのまま合成できる。R/fromの式を変えず、utc_half_monthsの既定は旧DB、rawは明示年で呼ぶ。既存Gaussianというdocstring/エラー語は計算の重みをGaussianへ置換する処理ではない。

接点: backend/climate/contracts.py; backend/climate/periods.py:8-27; backend/climate/archive.py:116-125

## BUILD

範囲: docs/BUILD.md:1-41; package/lockの宣言比較

今回frontend package/lockの差はrootアプリ版0.56→0.57のみで、依存集合・Node下限・build/test scriptは不変。npm ci→tsc/Vite、Python固定lock、runtime3root、資料専用生成の説明は新実装と衝突しない。旧版別節のDB起動例や実績を今回通年raw取得の完了へ転用しない。

接点: frontend/package.json; frontend/package-lock.json; backend/pyproject.toml; backend/requirements.lock

## SCENE3D-THIRD-PARTY-NOTICES

範囲: frontend/scene3d/THIRD_PARTY_NOTICES.txt:1-5,1076,1100,1129,1153（見出しと責務）

Cesium1.145.0/Plotly4.1.1/Leaflet1.9.4/React・ReactDOM19.2.8の告知版は固定lockと一致。全node_modules package entryは直前と同一、告知本文も同byteなので新依存告知の欠落は検出しない。0.46表題は告知生成由来として保持。外部ライセンスの法的再評価は行わない。

接点: frontend/package.json; frontend/package-lock.json

## 証拠と未確認

JSON票に各source SHA、request02一致、scopeと変化依存を記録。全third-party package entryは基準と同じで、package/lockの差はアプリversionのみ。テストは重複実行しておらず、親のbackend試験や過去UI票を自身の実施として数えない。取得・接続・UI・画像・Git操作なし。BUILDの旧版実績、第三者告知全文の法的審査、旧HTML・旧証拠ZIP・研究由来scopeは今回の対象外。確認印・metadata・sourceは変更していない。
