"""Finite mocked descriptor checks only. No helper main, HTTP, processes or raw arrays."""
from pathlib import Path
import copy
import hashlib
import json
import runpy
import ast

P = Path(__file__).resolve().parent
HELPER = P / 'check-deployment-catalog570.v2.py'
ast.parse(HELPER.read_text(encoding='utf8'))
N = runpy.run_path(str(HELPER), run_name='offline_definitions_only')
M = Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q/manifest.json')
raw = M.read_bytes()
m = json.loads(raw)
h = hashlib.sha256(raw).hexdigest()
grid = [{**r, 'gauss_weight': r['weight']} for r in m['grid']]
levels = [{**r, 'isa_alt_m': 0, 'alt_geom_mean_m': None, 'alt_geom_min_m': None, 'alt_geom_max_m': None} for r in m['levels']]
b = {'west': min(r['lon'] for r in grid), 'east': max(r['lon'] for r in grid), 'south': min(r['lat'] for r in grid), 'north': max(r['lat'] for r in grid)}
centre = ((b['north'] + b['south']) / 2, (b['east'] + b['west']) / 2)
point = min(grid, key=lambda r: (r['lat'] - centre[0])**2 + (r['lon'] - centre[1])**2)
cap = {k: True for k in ['annual', 'spatial', 'raw_observations', 'hour_filter', 'wind_rose', 'wind_rose_hour_filter', 'wind_rose_point_select', 'empirical_monthly_profiles']}
cap.update({k: False for k in ['year_filter', 'quantile_reconstruction', 'flight_weather_field']})
cap.update(years_fixed=m['years'], native_hours_utc=m['hours_utc'], date_convention='UTC', display_grains=['half', 'month', 'season'], grain='half', missing_policy='reject_incomplete_or_unequal_support', wind_rose_hours_utc=m['hours_utc'], hour_level_ids=[r['level_id'] for r in levels])
s = {'source_id': N['source_identity'](['original-utc-wind/1', h]), 'dataset_sha256': h, 'provider': 'JRA-3Q', 'profile': 'original-utc-wind', 'adapter_version': 'original-utc-wind/1', 'statistics_version': 'original-utc-wind/1', 'label': m['label'], 'weighting': m['weighting'], 'capabilities': cap, 'native_grid': grid, 'native_grid_count': 570, 'levels': levels, 'bounds': b, 'wind_rose_point': {k: point[k] for k in ('cell_id', 'lat', 'lon')}, 'units': {'wind': 'm/s', 'pressure': 'hPa', 'altitude': 'm', 'direction': 'degree'}, 'raw_samples': {'schema': m['schema'], 'bundle_sha256': h, 'years_fixed': m['years'], 'complete_months': list(range(1, 13))}, 'attribution': {'metadata': {'provider': 'JRA-3Q', 'label': m['label'], **{k: m['provenance'][k] for k in ('dataset_url', 'dataset_doi', 'license', 'citation', 'attribution', 'conversion', 'derived_subset') if k in m['provenance']}}}}
results = []


def check(name, mutate=None, manifest_mutate=None, expected_failure=False):
    source, manifest = copy.deepcopy(s), copy.deepcopy(m)
    if mutate: mutate(source)
    if manifest_mutate: manifest_mutate(manifest)
    try:
        N['raw_proof'](source, manifest, h, 'JRA-3Q', 38, 570)
    except (RuntimeError, KeyError, ValueError) as exc:
        if not expected_failure: raise
        results.append({'name': name, 'passed': True, 'rejected': str(exc)})
    else:
        assert not expected_failure, name
        results.append({'name': name, 'passed': True})


check('matching projection accepted')
check('same cell count wrong coordinate rejected', lambda x: x['native_grid'][0].update(lat=40), expected_failure=True)
check('same cell count wrong native ID rejected', lambda x: x['native_grid'][0].update(cell_id=10000), expected_failure=True)
check('same level count wrong pressure rejected', lambda x: x['levels'][0].update(level_hpa=4), expected_failure=True)
check('native order differs rejected', lambda x: x['native_grid'].reverse(), expected_failure=True)
check('weight alias differs rejected', lambda x: x['native_grid'][0].update(gauss_weight=1), expected_failure=True)
check('weighting differs rejected', lambda x: x.update(weighting='spherical-area-equal-times'), expected_failure=True)
check('UTC convention differs rejected', lambda x: x['capabilities'].update(date_convention='JST'), expected_failure=True)
check('missing original UTC time rejected', manifest_mutate=lambda x: x['months'][0]['times_utc'].pop(), expected_failure=True)
check('attribution license differs rejected', lambda x: x['attribution']['metadata'].update(license='unverified substitute'), expected_failure=True)
check('bounds differs rejected', lambda x: x['bounds'].update(east=180), expected_failure=True)
check('default native point differs rejected', lambda x: x['wind_rose_point'].update(cell_id=9999), expected_failure=True)
check('wrong source identity rejected', lambda x: x.update(source_id='climate-wrong'), expected_failure=True)
legacy = {'source_id': N['source_identity']([N['LEGACY_PROFILE'], 'jra3q-halfmonth-summary/3', N['LEGACY_DATASET']]), 'profile': N['LEGACY_PROFILE'], 'dataset_sha256': N['LEGACY_DATASET'], 'adapter_version': 'jra3q-halfmonth-summary/3', 'statistics_version': 'gaussian-pooled-wind/3', 'capabilities': {'years_fixed': [2016, 2025], 'empirical_monthly_profiles': False}, 'raw_samples': None, 'wind_rose_point': {'cell_id': 285}}
proof = N['legacy_proof'](legacy)
assert proof['source_id'] != proof['previous_adapter_v2_source_id']
assert 'Not exercised' in proof['saved_artifact_readback']
results.append({'name': 'legacy v3 identity and honest separate saved-GET scope', 'passed': True})
legacy['source_id'] = proof['previous_adapter_v2_source_id']
try:
    N['legacy_proof'](legacy)
except RuntimeError:
    results.append({'name': 'legacy old v2 identity rejected for current descriptor', 'passed': True})
else:
    raise AssertionError('old v2 identity accepted')
receipt = {'scope': 'Offline synthetic descriptor checks using local JRA manifest metadata; no API/helper main/process/raw-array read.', 'tests': len(results), 'failures': 0, 'helper_sha256': hashlib.sha256(HELPER.read_bytes()).hexdigest(), 'fixture_manifest_sha256': h, 'test_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'results': results}
with (P / 'deployment-catalog-v2-offline570.json').open('x', encoding='utf8', newline='\n') as f:
    json.dump(receipt, f, ensure_ascii=False, indent=2); f.write('\n')
print(json.dumps(receipt, ensure_ascii=False))
