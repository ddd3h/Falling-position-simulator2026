"""Independent final receipt: no acquisition module is imported and no network."""
from pathlib import Path
import calendar,datetime,hashlib,json,re,struct,sys,urllib.parse
import numpy as np

root=Path(sys.argv[1]).resolve()
manifest_path=root/'manifest.json'
manifest=json.loads(manifest_path.read_bytes())
assert manifest['schema']=='balloon.wind-samples/1' and manifest['provider']=='JRA-3Q'
assert manifest['years']==[2024,2024] and manifest['hours_utc']==[0,6,12,18]
allow_partial='--allow-partial' in sys.argv[2:]
month_ids=[m['month'] for m in manifest['months']]
assert month_ids==sorted(set(month_ids)) and all(1<=m<=12 for m in month_ids)
assert len(month_ids)>0 and (allow_partial or month_ids==list(range(1,13)))
assert len(manifest['levels'])==38 and len(manifest['grid'])==570
assert manifest['weighting']=='gaussian-area-equal-times'

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
 return h.hexdigest()

arrays={}; positions={}; observed={}; checks=[]
for m in manifest['months']:
 month=m['month']
 expect=[f'2024-{month:02d}-{d:02d}T{h:02d}:00:00Z' for d in range(1,calendar.monthrange(2024,month)[1]+1) for h in (0,6,12,18)]
 assert m['times_utc']==expect
 positions[month]={stamp:i for i,stamp in enumerate(expect)}
 for component in ('u','v'):
  record=m[component]; path=(root/record['file']).resolve()
  assert path.is_relative_to(root) and path.is_file() and not path.is_symlink()
  assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256']
  arr=np.load(path,mmap_mode='r',allow_pickle=False)
  assert arr.shape==(len(expect),38,570) and arr.dtype==np.float32
  assert np.isfinite(arr).all() and np.max(np.abs(arr))<1000
  arrays[month,component]=arr; observed[month,component]=set()

requests=manifest['provenance']['requests']
assert len(requests)==len(month_ids)*12 and len({r['url'] for r in requests})==len(requests)
for receipt in requests:
 url=receipt['url']; body=root/'download-cache'/(hashlib.sha256(url.encode()).hexdigest()+'.body')
 assert body.stat().st_size==receipt['bytes'] and sha(body)==receipt['sha256']
 raw=body.read_bytes(); header,payload=raw.split(b'\nData:\n',1)
 header=header.decode('ascii')
 match=re.search(r'Float32 (ugrd|vgrd)-pres-an-gauss\[time = (\d+)\]\[pressure_level = (\d+)\]\[lat = (\d+)\]\[lon = (\d+)\];',header)
 assert match
 component='u' if match[1]=='ugrd' else 'v'
 shape=tuple(map(int,match.groups()[1:])); assert shape[1:]==(38,19,30)
 count=int(np.prod(shape)); offset=0
 def read(n,dtype):
  global offset
  assert struct.unpack_from('>II',payload,offset)==(n,n)
  offset+=8; result=np.frombuffer(payload,dtype=dtype,count=n,offset=offset)
  offset+=n*np.dtype(dtype).itemsize
  return result
 wind=read(count,'>f4').reshape(shape)
 time=read(shape[0],'>i4'); level=read(38,'>f8'); lat=read(19,'>f8'); lon=read(30,'>f8')
 assert offset==len(payload)
 stamps=[(datetime.datetime(1900,1,1,tzinfo=datetime.timezone.utc)+datetime.timedelta(hours=int(t))).strftime('%Y-%m-%dT%H:%M:%SZ') for t in time]
 month=int(stamps[0][5:7]); assert all(s.startswith(f'2024-{month:02d}-') for s in stamps)
 assert not observed[month,component].intersection(stamps)
 observed[month,component].update(stamps)
 level_index=[list(level).index(row['level_hpa']) for row in manifest['levels']]
 lat32=list(lat.astype(np.float32)); lon32=list(lon.astype(np.float32))
 grid_lat=[lat32.index(np.float32(row['lat'])) for row in manifest['grid']]
 grid_lon=[lon32.index(np.float32(row['lon'])) for row in manifest['grid']]
 original=wind[:,level_index,:,:][:,:,grid_lat,grid_lon].astype(np.float32)
 saved=np.asarray(arrays[month,component][[positions[month][s] for s in stamps]])
 assert np.array_equal(original.view(np.uint32),saved.view(np.uint32)),(month,component,url)
 checks.append({'month':month,'component':component,'times':len(stamps),'bytes':receipt['bytes']})
for key,stamps in observed.items(): assert stamps==set(positions[key[0]])
result={'schema':'balloon.jra-original-bit-check/1','manifest_sha256':sha(manifest_path),'scope':'independent XDR to published NPY bit equality, all manifest-listed responses; no acquisition module/network/DB','months':len(month_ids),'month_ids':month_ids,'annual_complete':len(month_ids)==12,'utc_times':sum(len(t) for t in positions.values()),'levels':38,'cells':570,'components':2,'scalar_values':sum(a.size for a in arrays.values()),'original_responses':len(checks),'checks':checks,'limitations':['not a ten-year climatology comparison','not a scientific accuracy claim','no UI validation']}
out=root.parent/('jra-partial-original-bit-check.json' if allow_partial else 'jra-final-original-bit-check.json')
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
