# 再起動 capture / post-readback v2 改訂案

元 helper は変更せず、`capture-before-restart570.v2.py` と `check-after-restart570.v2.py` を別名で作った。両方の main は未実行。変更前 bytes と v1→v2 diff は `post-restart-v2-proposal570/`、最終 SHA・検査対象・限界は同名 JSON に保存した。作成用 fragment/tail は中間入力であり、v2 は単独で動く stdlib script である。

全 SQLite の backup と live readonly connection を、schema、column、user_version/application_id、型付き全行の multiset で比較する。行順は無視し、重複行は落とさず、text/blob/integer/real/null を区別する。物理 DB bytes は WAL/checkpoint で変わるので live SHA 一致は要求しない。比較元 backup と固定 file/GET inventory は capture receipt の SHA に束縛する。

保存 GET は backup の全 `runs JOIN jobs` を起点にする。既定 run 一覧で除外される ensemble trial も含む全 run detail と completed result、plan/snapshot/analysis、全 climate artifact を取得し、snapshot の result_available trial は専用 result GET でも参照 hash を検査する。raw 応答は local に置き、比較/結果票には hash/count を使う。保存 JSON は意味一致を必須とし、生 bytes 一致は別途記録する。

capture/post の終端に DB・固定 file・主要 API を再照合する。跨 DB atomicity と検査後の新規ユーザー書込み排除は保証しない。元 PS1 と同じ `preflight02/readback01` 名・従来 receipt 欄を保ち、既存出力は上書きせず停止する。GET は localhost 固定・proxy/redirect 無効、4,096 GET・64 MiB/応答・250,000 行/table の有限上限を超えれば失敗し、coverage を切り詰めて成功とはしない。

主担当の指摘を反映し、旧 source_id が新 catalog に残ることを要求する初稿の subset assert は撤回した。adapter /2→/3 による source identity 変更は採用済みの transition であり、旧保存図は固定 GET のまま保つ。v2 最終案は追加/削除 ID を記録し、新しい 3 資料の manifest/profile/adapter/支持の一致は主担当の別票へ戻す。この補正前の v2 bytes と局所 diff も保全した。

オフライン **16/16 成功**（最終 `post-restart-v2-offline-tests57003.log/json`）。構文、row order、型/重複、参照 hash だけの破損、climate integrity column だけの破損、schema、DB version、readonly INSERT 拒否、単便+ensemble_trial 列挙、completed result 欠落、snapshot result 経路、保存 GET 内容変化、JSON key order のみの変化、path traversal、proxy/redirect 無効を、合成 SQLite と mock GET で確認した。実 API・既存 state・process は使っていない。

未確認: 実環境の所要時間/保全結果、UI 成功、旧 lazy asset 全 URL、科学的妥当性。weather DB 全論理内容は比較するが、weather 文書の全 GET は検査対象に含めていない。8551 全 path proxy は主担当の別確認として受け取り、自分が確認したとはしない。新計算・取得・Google 接続・自動回復/上書きは行わない。
