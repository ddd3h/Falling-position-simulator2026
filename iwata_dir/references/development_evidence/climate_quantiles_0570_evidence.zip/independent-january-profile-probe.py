"""Read-only empirical check of received JRA January; not annual acceptance."""
from pathlib import Path
import hashlib,json,sys,math,bisect,time
import numpy as np
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570')
sys.path.insert(0,str(R))
from backend.climate.samples import MonthlySamples
from backend.climate.archive import WindArchiveSource
from backend.climate.contracts import ClimateError
path=P/'jra3q-2024-preview/manifest.json'
before=hashlib.sha256(path.read_bytes()).hexdigest();t0=time.monotonic()
s=MonthlySamples(path)
grid=[s.grid[i] for i in [0,len(s.grid)//2,len(s.grid)-1]]
levels=[s.levels[i] for i in [0,len(s.levels)//2,len(s.levels)-1]]
profiles=s.profiles(grid,levels,[6,18]);jan=profiles['months'][0]
times=s.months[1]['times'];chosen=[i for i,t in enumerate(times) if t[11:13] in ['06','18']]
u=np.load(s.months[1]['files']['u'],mmap_mode='r',allow_pickle=False)
v=np.load(s.months[1]['files']['v'],mmap_mode='r',allow_pickle=False)
weights=[c['gauss_weight'] for c in grid]
def direct(vi,probability):
    pairs=sorted(vi)
    total=math.fsum(w for _,w in pairs);threshold=total*probability
    # math.fsum independent cumulative oracle, small finite subset only.
    cumulative=[];w=[]
    for _,weight in pairs:
        w.append(weight);cumulative.append(math.fsum(w))
    return pairs[bisect.bisect_left(cumulative,threshold)][0]
rows=[]
for l,row in zip(levels,jan['rows']):
    li=next(i for i,ll in enumerate(s.levels) if ll['level_id']==l['level_id'])
    cells=[next(i for i,cc in enumerate(s.grid) if cc['cell_id']==c['cell_id']) for c in grid]
    pairs=[(math.hypot(float(u[i,li,ci]),float(v[i,li,ci])),weight) for i in chosen for ci,weight in zip(cells,weights)]
    expected={'p10':direct(pairs,.1),'p90':direct(pairs,.9),'half_medians':[
        direct([(math.hypot(float(u[i,li,ci]),float(v[i,li,ci])),weight) for i in chosen if (int(times[i][8:10])<=15)==first for ci,weight in zip(cells,weights)],.5)
        for first in [True,False]]}
    diffs=[abs(row['p10']-expected['p10']),abs(row['p90']-expected['p90']),*[abs(a-b) for a,b in zip(row['half_medians'],expected['half_medians'])]]
    if max(diffs)>1e-12:raise AssertionError((row,expected))
    rows.append({'level_id':l['level_id'],'pressure_hpa':l['level_hpa'],'adapter':row,'independent':expected,'maximum_difference':max(diffs)})
try:WindArchiveSource(path)
except ClimateError as e:annual={'status':'rejected_incomplete','code':e.code}
else:raise AssertionError('January preview accepted as annual source')
after=hashlib.sha256(path.read_bytes()).hexdigest()
result={'schema':'independent-january-profile/1','manifest_sha256':before,'manifest_unchanged':before==after,
    'source_schema':s.schema,'years':s.years,'complete_months':sorted(s.months),'native_grid_count':len(s.grid),'native_levels':len(s.levels),
    'selected_cell_ids':[c['cell_id'] for c in grid],'hours_utc':[6,18],
    'january_time_count':jan['time_count'],'half_time_counts':jan['half_time_counts'],'comparison_rows':rows,
    'missing_months':[m['month'] for m in profiles['months'] if not m['available']], 'annual_adapter':annual,
    'elapsed_seconds':time.monotonic()-t0,'limits':'Three native cells and three native levels of received January only. Not full-year acquisition, provider authenticity, physical accuracy, UI, or all-grid independent numerical acceptance.'}
(P/'independent-january-profile-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
