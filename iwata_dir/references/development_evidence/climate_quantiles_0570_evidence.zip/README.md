# 0.57 実原標本の月分布接続 — 開発証拠束 README

この証拠束は0.56記録C2 `98b6dad115e4ac30c03f06ff3366fc6468022b8a`以降の有限な根拠を案内します。**JRA/ERAの指定2024支持の取得・原値保持、両4セルデモ、隔離とliveの保存保全、主担当による最終GUI操作、説明本文の編集票が揃いました。** 主担当は根拠の版・用途・観測者・未確認の区別を読んで収録を採用しました。ZIP生成と全member読戻し、最終metadata/Git閉鎖の票はこの束の外側に置きます。

分析の問いは、地域の元格子×UTC時刻の風速分布を **月の前半/後半中央値2線と月全体p10–p90幅** で比較すること。地域平均風の時系列の幅や予測区間ではなく、平均図は補助量です。月/季節・UTC・気圧面自動更新・一点風配・固定SVG・保存再訪は今回の分析対象、再取得はCLI、取得/登録UIは後続です。

旧2016–2025集計DB（UTC subset下層20面）と別sourceの2024原標本を混ぜません。新JRAは570格子×38面、ERAは1188格子×37面、4UTC/日。面積重み×等時間重みの逆経験CDFを使い、UTC暦の1–15日/16–月末を分けます。ISAは参考高度。ERAは公開元の0.25度lat/lon面で、元モデルmeshや全24時間/日の取得とは違います。一年・地域全域・各4セルデモを十年気候や瞬時飛行場に置き換えません。

## まず読む六つの入口

| 問い | 読む順序と限界 |
|---|---|
| 中央値/月幅の意味・計算 | [原標本adapter批評](independent-archive-review.md) → [独立反例](independent-archive-probe-result.json) → [通常service/実DTO](real-dto570/service-dto-final-review.md)。初期票の固定一点風配は後続地点票で拡張。 |
| 何を取得し、失敗も保持したか | [JRA最終確認](jra-final-acquisition-review.md) / [ERA全年まとめ](era5/full-year-acquisition-summary.md) → [ERA全原値照合](era5/full-year-independent-readback.json) → [実final23台帳](era5/attempt-ledger-final23.json)。支持/bit保持の検証であり科学精度とは別。 |
| filter・面・地点・往復は動いたか | [最終live操作](ui-final570.json) → [ERA隔離操作/保存再訪](ui-era-final570.json)。地点と往復の根拠は[地点切替](ui-native-point570.json) → [12遷移](ui-monthly-roundtrip570.json) / [独立地点数値](rose-point570/real-point-and-legacy-proof.json)。観察者は主担当。 |
| SVGの受領・意味・可読性 | [最終静的批評](final-static-reader-review570.md) → [訂正SVG](svg-receipt570/corrected-monthly.svg) / [PNG](svg-receipt570/corrected-monthly-static.png) → [実保存読戻し](svg-receipt570/footer-correction-readback.json)。保存要求表示とファイル受領を区別。 |
| 資料/既存機能との接点 | [変更3頁](rose-point570/guides05-independent-review.md) → [INDEX04](index-final04/verification.json) → [13 consumer](required02/dependency-consumer-review.md) / [59履歴等](historical-dependency-review570.json) / [8 test scope](remaining-test-dependency-review570.md)。これは以前の有限点検で、最終metadata検査はZIP外。 |
| デモと保存保全 | [両4セルデモ](demo-final570/verification.json) → [通常consumer](demo-consumer570/receipt.json)。配置は[live保存GET/DB読戻し](restart-live-readback01/receipt.json) / [8551資料・static照合](deployment-catalog-live570.json)、経緯は[失敗01/訂正批評](deployment-config-review570.md)。 |

## 完成した取得/デモ票の範囲

ERAは366日×4UTC、732日別U/V成分、128,703,168 Float32値を、独立DAP2 parserまたはNetCDF3 readerから全24月成分NPYへ新たに読戻しました。[初回checker JSON](era5/full-year-independent-readback-raw.json)のSHAを[最終照合票](era5/full-year-independent-readback.json)が束縛します。ファイル名のrawはchecker出力の意味で、配列本文は含みません。採用応答はDODS250/NCSS482です。

[final23台帳](era5/attempt-ledger-final23.json)は実入力で `final_verified`。primaryの799観測には732成功成分、32成功metadata、35失敗が含まれ、side移管の成功/失敗も原票hashへ戻れます。[集計JSON](era5/full-year-acquisition-summary.json)は全走査の結論です。途中のtailだけで「失敗なし」と読んだ旧観測を最終結論にしません。35失敗を消した取得成功とも書きません。

[Sep18停止](era5/main15-sep18-stop.json) → [正確なURL/slot03承認](sep18-root-plan22/receipt.json) → [回復22](era5/sep18u-slot03-result22.json) → [別承認のprimary23開始](era5/primary23-start-receipt.json) → 全年実票、の順序を保持します。回復22当時の「月NPY未照合」はその時点の事実で、全年読戻しが後続しました。[final22差分](era5/close-attempt-ledger570-final22.diff)はApr28V/Sep18Uの固定receiptだけを例外にし、一般の再試行予算を増やしません。[offline10群](era5/attempt-ledger-final22-offline.json)と実final23は別の証拠です。

[ERA常設copy](era5-persistent-copy-inventory.json)は2,436ファイル/1,050,459,586 Bを全hash照合し、Temp原物と失敗票を保持しました。[性能/CDF票](era5-final-performance.json)はこの機械のcache済file上の1観測（全37面8.67秒、UTC00全37面1.47秒、300hPa単面0.31秒）と1月300hPaの独立CDF一致です。主担当の最終説明ではデモ束生成と一部並行した測定であり、CPU専有のbenchmarkではありません。cold disk、全query、UI応答保証ではありません。取得時間の総和/重複区間/停止を含むwall時間も[まとめ](era5/full-year-acquisition-summary.json)で分けています。

デモは43.2/141.4付近の各native2×2、JRA445,056値・ERA433,344値を原全域subsetとbit照合した **各4セルの機能再生** です。[50member inventory](demo-final570/archive.json)と[通常consumer票](demo-consumer570/receipt.json)は、別data ZIPを通信なしで展開し、UTC00の12か月分布と保存GETを両商品で確認しています。全域再計算やWeb GUIの証明ではありません。デモZIP本体は証拠ZIPに重複収録しません。

## 配置の失敗と訂正、live保全の読戻し

v1保全helperの[批評](post-restart-helper-review570.md)を受け、[v2](post-restart-v2-proposal570.md)はDBのschema/column/型付き全行と全保存GETを比較します。その実配信で、旧PID終了直後のstale LISTENによるlaunch前停止と、隔離にもlive用歴史catalogを与えた設定差を検出しました。[失敗01要約/訂正票](deployment-config-review570.json)では既存3資料は全要素同じで、歴史診断窓2件だけ追加されたことを確認しています。原state応答はlocalに保持し、このZIPには要約だけを収録します。

selection03のPS1旧SHAは[before-portfix](restart-with-archives570.before-portfix.ps1)に保全し、[現在版](restart-with-archives570.ps1)の旧PIDだけの有限port待機・isolated unset/live元設定・attempt別出力へ明示対応しました。[旧post v2](check-after-restart570.v2.py)を16反例の対象として残し、[現在post](check-after-restart570.py)は `--attempt01/02` と出力名だけの変更です。古い指紋を現在版の採用根拠に流用しません。

[隔離readback02](restart-isolated-readback02/receipt.json)では3DB論理内容・8保存climate GET・project/一覧/既存weather-sourceを保持しました。単便/ensembleはともに0件で、この票だけでは既存live飛行結果を覆いません。[隔離catalog票](deployment-catalog-isolated570.json)は3資料のmanifest/支持投影と新4 static pathの到達です。

後続の[live読戻し](restart-live-readback01/receipt.json)は、3DBのschema/column/型付き全行、固定実体2,841件、保存GET 822件を比較し、GETの意味とbytesの一致を記録しました。822はGET照合件数で、run-result249件やsnapshot-trial-result242参照などを含み、独立した飛行822件ではありません。既存project・仕事一覧・weather資料一覧も同一です。別の[8551 catalog/配信票](deployment-catalog-live570.json)は3資料のmanifest/支持/帰属投影と新4・旧14 static URLを照合しました。旧14の[local基準](old-static-baseline570.json)は観測時点のコピー一致、live票はその後のHTTP到達を示し、観測以前の配信を証明しません。旧DB adapter /2→/3のsource_id移行は意図したcatalog変更、旧固定分析のGET維持は別の保全要件です。DBをまたぐ完全原子性、全lazy asset、飛行の新規実行、科学的精度の証拠へ広げません。

[最終GUI票](ui-final570.json)は主担当がlive8551で旧保存図、新JRA/ERAの月分布、UTC、気圧面自動更新、SVG生成を操作した報告です。既存の予報projectは前後で同じSHA、live計画の保存上書きは行っていません。保存・reload後のGET再訪は[ERA隔離票](ui-era-final570.json)と以前のJRA票へ戻ります。ERAのSVGは固定条件のリンク生成までで、実ファイル受領を再試験した主張にはせず、以前のJRA実保存SVG票と区別します。今回の整理担当はこのGUIを再操作・画像再視認していません。

[最終説明の編集票](narrative-final570/receipt.json)は11文書のbefore/afterと最終UI票・デモZIPの指紋を記録します。その後の[2語句訂正票](narrative-final570/two-wording-corrections.json)で、runbookの「12月」を「12か月」、「固定285点」を「固定代表点（元格子ID285）」へ明確化し、逆置換した旧bytesが先のafter hashへ一致することを記録しました。先の票は適用時点の指紋であり、現runbookとの一致は主張しません。最終source/metadataは別に固定します。これらは本文編集の証拠であり、全本文の独立再受入や最終metadata/Git閉鎖の代わりではありません。

## 旧票の訂正先

独立oracleの誤記は[archive批評](independent-archive-review.md)へ、bounds:null受領拒否は[要求解決修復](query-resolution570-review.md)へ、月12区分VMを隠れた風配24区分controlが検査した停止は[往復批評](rose-point570/roundtrip-independent-review.md)と実12遷移へ戻ります。月SVGの年間専用注記は[旧批評](svg-receipt570/independent-static-visual-review.md) → [文字列訂正](svg-receipt570/footer-edit.json)。backend09のTemp権限失敗は[旧ログ](backend-final-full09.log) → [full10の166PASS/1SKIP](backend-final-full10.log)。December費用の二重計上は[訂正理由](era5/december-ncss16-complete-measurement-correction.md) → [訂正02](era5/december-ncss16-complete-measurement02.json)です。

[DODS/NCSS経路調査](era5/failure-and-routes-review570.md)は取得経路の採否として保持します。Jan1Vの同じ元値に対するtransport間bit一致、Apr25Vの有限支持、今回の全selected原応答→NPY一致は違う主張です。初期`ui-design-review.md` / `independent-statistics-review.md`や旧[台帳批評](era5/attempt-ledger570-review.md)を現仕様単独の入口にはしません。過去の「現在/未了」は当時の記録であり、新しい操作許可ではありません。

## 収録境界と後続記録

本文166件のbytes/SHAを `inventory.json` のallowlistに固定し、このREADMEとinventoryを加えて収録します。原票を改変せず、取得の原応答/失敗bytes/大配列は常設archive、4セルdataは別ZIP、私的project/state/SQLite/WAL/backup/生API応答/秘密は収録しません。最終台帳JSONは原fileのhash/試行metadataであり、原bodyではありません。機械固有のhelperを一般向け取得CLIとして実行しないでください。

**主担当は六つの読解入口、失敗と訂正先、2024年と旧10年DBの区別、実UI観測者、機能と科学採用の境界を確認して採用しました。** ZIPの全member読戻しと最終metadata/Git閉鎖は後続の外側票へ戻ります。進行中captureや生成途中のlogに指紋を与えません。最終metadata登録/required scope/contract/state/close検査、証拠ZIP自身のSHA、Git保存/読戻しは **ZIP外** に置きます。以前のINDEX/dependency有限点検を最終承認に置き換えず、自己参照を避けます。最終化では全member再hashとREADME link/privacy確認、ZIPの全member読戻しが必要です。今回の整理は既存票の読解と指紋照合で、原値/GUIの再実行や科学的再受入ではありません。
