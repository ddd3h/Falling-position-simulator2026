"""Offline fixtures and Sep18 evidence copies; never writes to original bundles."""
from pathlib import Path
import argparse
import calendar
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / 'close-attempt-ledger570-final22.py'
SCRIPT_SHA = hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
HISTORICAL = {'close-attempt-ledger570.py': '0ad84c1aa0d72f626d60401d410ebb13f936301a00075784fc8b604f4ddbb96c',
              'test-close-attempt-ledger570.py': 'b652dbc7b0e6de7d106cc4631927caeaceca6f673c0e7541e132e98a258192e5'}
for name, expected in HISTORICAL.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, 'Historical helper/test changed'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
OUTPUT = parser.parse_args().output.resolve()
assert not OUTPUT.exists(), 'Preserve previous offline evidence; choose a new output'
spec = importlib.util.spec_from_file_location('ledger570', SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
WORK = Path(tempfile.mkdtemp(prefix='ledger570-offline-', dir=HERE))
results = []


def put(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)


def put_json(path, obj):
    put(path, (json.dumps(obj, sort_keys=True) + '\n').encode())


def observation(root, stem, slot=1, complete=True):
    info = m.identity(stem)
    name = f'{stem}-attempt{slot:02}'
    request = {'url': info['url'], 'cap_bytes': 1024, 'timeout_s': 120,
               'retries': 0, 'redirects': False, 'credentials_read': False,
               'started_utc': '2026-10-02T00:00:00+00:00'}
    raw = ('synthetic fixture ' + name).encode()
    receipt = {**request, 'complete': complete, 'http_status': 200,
               'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
               'elapsed_seconds': 1.25, 'finished_utc': '2026-10-02T00:00:01.25+00:00'}
    if not complete:
        receipt['error'] = 'IncompleteRead: synthetic DDS-only fixture'
    put_json(root / 'responses' / (name + '.request.json'), request)
    put_json(root / 'responses' / (name + '.receipt.json'), receipt)
    put(root / 'responses' / (name + ('.body' if complete else '.partial')), raw)
    return {'receipt': 'responses/' + name + '.receipt.json', **{k: receipt[k] for k in ('url', 'bytes', 'sha256')}}


def run_final(root, side, proof, terminal, label):
    output = WORK / (label + '.json')
    completed = subprocess.run([sys.executable, '-B', str(SCRIPT), '--final', '--root', str(root),
        '--side-stage', str(side), '--side-terminal', str(terminal), '--independent-values', str(proof),
        '--output', str(output)], capture_output=True, text=True, check=False)
    assert output.exists(), completed.stderr
    return completed.returncode, json.loads(output.read_text())


def check(name, function):
    function()
    results.append({'case': name, 'passed': True})


def independent_service_history():
    root = WORK / 'history'
    for slot in (1, 2, 3):
        observation(root, 'v-20241210', slot, False)
    observation(root, 'ncss-v-20241210')
    observation(root, 'catalog-202412')
    scan = m.scan(root)
    assert not scan['issues'], scan['issues']
    assert scan['summary']['all']['attempts'] == 5
    assert scan['summary']['component:dods']['failed_receipts'] == 3
    assert scan['summary']['component:ncss']['successful_receipts'] == 1
    assert scan['attempt_slots']['v-20241210'] == [1, 2, 3]
    assert scan['attempt_slots']['ncss-v-20241210'] == [1]


def damaged_raw_and_url():
    root = WORK / 'damaged'
    observation(root, 'u-20240101')
    path = root / 'responses/u-20240101-attempt01.body'
    raw = path.read_bytes()
    path.write_bytes(bytes([raw[0] ^ 1]) + raw[1:])
    scan = m.scan(root)
    assert any('SHA256 differs' in e for e in scan['issues'])
    root2 = WORK / 'url'
    observation(root2, 'v-20240101')
    request = root2 / 'responses/v-20240101-attempt01.request.json'
    obj = json.loads(request.read_text()); obj['url'] += '&different=1'; put_json(request, obj)
    assert any('URLs differ' in e for e in m.scan(root2)['issues'])


def pending_gap_and_ncss_budget():
    root = WORK / 'pending'
    put_json(root / 'responses/u-20240101-attempt01.request.json', {'url': m.identity('u-20240101')['url']})
    scan = m.scan(root)
    assert len(scan['orphans']) == 1 and scan['attempt_slots']['u-20240101'] == [1]
    root2 = WORK / 'gap'
    observation(root2, 'u-20240101', 2)
    assert any('Attempt gap' in e for e in m.scan(root2)['issues'])
    root3 = WORK / 'ncss-budget'
    for slot in (1, 2, 3): observation(root3, 'ncss-v-20240101', slot, False)
    rejected = m.scan(root3)
    assert any('exact reviewed exception' in e for e in rejected['issues'])
    assert len(rejected['files']) == 9, 'Even a budget-violating group must remain in the file ledger'
    root4 = WORK / 'forged-exception'
    for slot in (1, 2, 3): observation(root4, 'ncss-v-20240428', slot, False)
    assert any('reviewed original' in e for e in m.scan(root4)['issues'])


def side_failed_observation_must_transfer():
    root, side = WORK / 'transfer-main', WORK / 'transfer-side'
    observation(root, 'ncss-v-20241210', 1)
    observation(side, 'ncss-v-20241210', 1)
    observation(side, 'v-20241210', 1, False)
    result = m.reconcile_side(m.scan(root), m.scan(side))
    assert not result['all_original_files_carried_forward']
    assert len(result['missing_or_different_files']) == 3


def missing_final_gate():
    root, side = WORK / 'empty-main', WORK / 'empty-side'
    root.mkdir(); side.mkdir()
    code, report = run_final(root, side, WORK / 'missing-proof.json', WORK / 'missing-terminal.json', 'refused-missing')
    assert code == 2 and report['status'] == 'final_refused' and not report['final_complete']
    assert 'primary' not in report and len(report['errors']) == 3


def synthetic_annual_contract():
    root, side = WORK / 'annual-main', WORK / 'annual-side'
    side.mkdir()
    manifest = {'schema': 'balloon.wind-samples/1', 'provider': 'ERA5', 'years': [2024, 2024],
                'hours_utc': [0, 6, 12, 18], 'date_convention': 'UTC', 'months': [],
                'provenance': {'requests': [], 'metadata': []}}
    checks = []
    for month in range(1, 13):
        entry = {'month': month}
        manifest['provenance']['metadata'].append(observation(root, f'catalog-2024{month:02}'))
        for component in ('u', 'v'):
            filename = f'{component}-2024-{month:02}.npy'
            content = ('synthetic NPY placeholder ' + filename).encode()
            put(root / filename, content)
            entry[component] = {'file': filename, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
            checks.append({'month': month, 'component': component, 'values': calendar.monthrange(2024, month)[1] * 4 * 37 * 1188,
                           'bit_equal': True, 'npy_sha256': entry[component]['sha256']})
        manifest['months'].append(entry)
        for day in range(1, calendar.monthrange(2024, month)[1] + 1):
            for component in ('u', 'v'):
                stem = f'{component}-2024{month:02}{day:02}'
                if stem == 'v-20241210':
                    history = []
                    for slot in (1, 2, 3):
                        old = observation(root, stem, slot, False)
                        history.append({'attempt': slot, 'receipt': old['receipt'], 'complete': False,
                                        'http_status': 200, 'sha256': old['sha256']})
                    selected = observation(root, 'ncss-' + stem)
                    selected.update(transport='ncss', prior_dods_attempts=history)
                else:
                    selected = observation(root, stem)
                manifest['provenance']['requests'].append(selected)
    put_json(root / 'manifest-through-12.json', manifest)
    put(root / 'manifest.json', (root / 'manifest-through-12.json').read_bytes())
    for source in (root / 'responses').iterdir():
        if '20241210' in source.name:
            put(side / 'responses' / source.name, source.read_bytes())
    proof = {'manifest_sha256': m.fingerprint(root / 'manifest.json')['sha256'], 'complete_2024': True,
             'complete_months': list(range(1, 13)), 'validated_months': list(range(1, 13)),
             'component_responses': 732, 'float32_values_compared': m.EXPECTED_VALUES,
             'checks': checks, 'by_transport': {'dods': 731, 'ncss': 1}}
    proof_path, terminal = WORK / 'synthetic-proof.json', WORK / 'synthetic-terminal.json'
    put_json(proof_path, proof); put_json(terminal, {'status': 'completed', 'inventory_error': None, 'inventory': {'unresolved_files': []}})
    code, report = run_final(root, side, proof_path, terminal, 'synthetic-final-valid')
    assert code == 0 and report['final_complete'], report.get('errors')
    assert report['primary']['summary']['all']['attempts'] == 747
    proof['validated_months'] = [12]; put_json(proof_path, proof)
    code, report = run_final(root, side, proof_path, terminal, 'synthetic-final-filtered-proof')
    assert code == 2 and any('month-filtered' in e for e in report['errors'])
    proof['validated_months'] = list(range(1, 13)); put_json(proof_path, proof)
    selection = next(x for x in manifest['provenance']['requests'] if x.get('transport') == 'ncss')
    selection['prior_dods_attempts'] = []
    ledger = m.scan(root)
    assert any('history disappeared' in e for e in m.final_bindings(root, manifest, proof, ledger))
    additional = WORK / 'extra-ncss99-stage'
    observation(additional, 'ncss-u-20241101', 1, False)
    code, report = run_final(root, side, proof_path, terminal, 'synthetic-final-extra-no-terminal')
    assert code == 2 and any('Additional side terminal gate' in e for e in report['errors'])
    put_json(WORK / 'extra-ncss99-terminal.json', {'status': 'failed', 'inventory_error': None, 'inventory': {'unresolved_files': []}})
    code, report = run_final(root, side, proof_path, terminal, 'synthetic-final-extra-untransferred')
    assert code == 2 and any('Additional side original observations' in e for e in report['errors'])
    for source in (additional / 'responses').iterdir():
        put(root / 'responses' / source.name, source.read_bytes())
    code, report = run_final(root, side, proof_path, terminal, 'synthetic-final-extra-carried-forward')
    assert code == 0 and report['final_complete'], report.get('errors')


def exact_sep18_exception():
    assert set(m.NCSS_EXCEPTIONS) == {'ncss-v-20240428', 'ncss-u-20240918'}
    root = WORK / 'sep18-exception'
    auth_source = HERE.parent / 'sep18-root-plan22/receipt.json'
    auth_bytes = auth_source.read_bytes()
    fake_base = WORK / 'exception-authority/era5'
    auth_copy = fake_base.parent / 'sep18-root-plan22/receipt.json'
    put(auth_copy, auth_bytes)
    for slot in (1, 2, 3):
        stem = f'ncss-u-20240918-attempt{slot:02}'
        receipt_path = HERE / 'year2024/responses' / (stem + '.receipt.json')
        receipt = json.loads(receipt_path.read_bytes())
        for suffix in ('.request.json', '.receipt.json', '.body' if receipt['complete'] else '.partial'):
            source = receipt_path.parent / (stem + suffix)
            put(root / 'responses' / source.name, source.read_bytes())
    previous_base = m.BASE
    try:
        m.BASE = fake_base
        accepted = m.scan(root)
        assert not accepted['issues'], accepted['issues']
        exception = next(row for row in accepted['records'] if row['attempt'] == 3)
        assert exception['complete'] and exception['exception_authorization']['sha256'] == m.NCSS_EXCEPTIONS['ncss-u-20240918']['authorization_sha256']
        results.append({'case': 'exact_sep18_original_triplet_and_root_authorization_accepted', 'passed': True})
        copied_receipt = root / 'responses/ncss-u-20240918-attempt03.receipt.json'
        original = copied_receipt.read_bytes()
        forged = json.loads(original); forged['elapsed_seconds'] += 1
        put_json(copied_receipt, forged)
        assert any('Exception receipt changed' in error for error in m.scan(root)['issues'])
        results.append({'case': 'sep18_forged_receipt_sha_rejected', 'passed': True})
        put(copied_receipt, original)
        wrong_authorization = json.loads(auth_bytes)
        wrong_authorization['approved_one_request'] += '&other=1'
        put_json(auth_copy, wrong_authorization)
        assert any('Exception authorization SHA256 differs' in error for error in m.scan(root)['issues'])
        results.append({'case': 'sep18_changed_root_authorization_rejected', 'passed': True})
        put(auth_copy, auth_bytes)
        other = WORK / 'sep19-unapproved'
        for slot in (1, 2, 3): observation(other, 'ncss-u-20240919', slot, False)
        assert any('exact reviewed exception' in error for error in m.scan(other)['issues'])
        results.append({'case': 'neighbor_date_same_component_slot03_rejected', 'passed': True})
    finally:
        m.BASE = previous_base
    assert auth_source.read_bytes() == auth_bytes


check('service_history_and_metadata_separate', independent_service_history)
check('raw_corruption_and_request_url_rejected', damaged_raw_and_url)
check('pending_gap_ncss03_and_forged_exception_rejected', pending_gap_and_ncss_budget)
check('side_failed_observation_required', side_failed_observation_must_transfer)
check('final_gate_refuses_before_scan_without_prerequisites', missing_final_gate)
check('synthetic_annual_success_filtered_proof_lost_dods_and_automatic_additional_stage', synthetic_annual_contract)
exact_sep18_exception()
report = {'scope': 'Offline synthetic fixtures plus read-only copies of Sep18 original triplets/root authorization. No network or original edits. Synthetic final status tests the contract, never actual annual closure.',
          'network_calls': 0, 'actual_primary_final_invocations': 0,
          'helper_sha256': m.fingerprint(SCRIPT)['sha256'], 'historical_sha256': HISTORICAL, 'fixture_root': str(WORK), 'cases': results}
assert report['helper_sha256'] == SCRIPT_SHA, 'Helper changed during the offline test'
for name, expected in HISTORICAL.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, 'Historical helper/test changed during offline tests'
with OUTPUT.open('x', encoding='utf-8') as stream: json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps({'passed': len(results), 'output': str(OUTPUT), 'fixture_root': str(WORK)}))
