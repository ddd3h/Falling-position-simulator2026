# ERA5 attempt ledger helper — independent offline record

2026-10-02. Acquisition source/repository and all original response bundles were left unchanged. No network or acquisition was performed. This record does not close the annual acquisition.

## Delivered helper

`close-attempt-ledger570.py` SHA256 `0ad84c1aa0d72f626d60401d410ebb13f936301a00075784fc8b604f4ddbb96c`.

- Streams SHA256 and counts bytes for original request, receipt and body/partial files; checks the canonical NCAR URL, shared request/receipt fields, complete/HTTP/error/elapsed/cap policy, exact triplets, continuous attempt slots, and same-service budgets. DODS failures remain separate observations when NCSS supplies the selected sample.
- The absolute service budget is 3; fresh NCSS is limited to 2. Only `ncss-v-20240428-attempt03` is accepted as the prior explicitly authorized exception, pinned to receipt SHA256 `1774d217101fd74b7ee79e3cd36fc3677a962e93e2c3f10f53a68a8ad2cf8db2`.
- Counts component DODS, component NCSS, metadata DODS and catalog observations separately, with successful/failed receipts, HTTP/error distributions, original bytes and elapsed totals. Request-only groups are retained as unfinished attempts and block final closure.
- Two existing February recovery notes are pinned by file SHA, checked against the failed prior receipt SHA and subsequent successful receipt, and recorded as auxiliary evidence. They do not create additional attempts.
- Final mode requires the ordered full-year `manifest-through-12.json`, identical current manifest pointer, and the independent mixed-transport full-values receipt bound to that manifest. It rejects month-filtered proof and requires 732 selected daily components, 24 monthly U/V checks and 128,703,168 bit-compared float32 values. It rehashes all selected NPY files and binds every selected receipt and historical DODS list.
- December stage originals must match the primary byte for byte. Additional sibling `*-ncss*-stage` directories are discovered automatically, with the corresponding `*-terminal.json` and the same all-original-files carry-forward requirement. This includes the November stage. A failed side worker is not an excuse to omit its saved successes or failures.
- Input hashes and response-directory snapshots are rechecked before final success. Any missing/invalid gate produces `final_refused`. Reports use exclusive new files outside observed bundles. No repair, retry or budget reset exists.

## Finite verification

`test-close-attempt-ledger570.py` SHA256 `b652dbc7b0e6de7d106cc4631927caeaceca6f673c0e7541e132e98a258192e5` created synthetic local fixtures only. `attempt-ledger-offline570-03.json` records six passing test groups, with the helper hash held unchanged throughout; SHA256 `ab4956df43780bcb53598ad6f5816797c52a97a517b3654427973e7b08e05822`.

The cases include corruption and URL mismatch, unfinished/gapped attempts, unauthorized NCSS slot 3 and forged Apr28 exception, preserved DODS failures, missing side failure triplets, absent final prerequisites, synthetic annual success, month-filtered proof rejection, dropped DODS history rejection, and automatic detection of an additional side stage whose terminal or original observations have not been carried forward. Synthetic raw and NPY placeholders are explicitly artificial; synthetic final success tests only the ledger contract, not meteorological values. The actual primary has never been passed to `--final` by this reviewer.

`attempt-ledger-inspect570-03.json` is an explicit partial observation at 2026-10-02 06:13:06–06:13:08 UTC (15:13 JST), SHA256 `69a996efbfc30c316cb58c48edaad6640d6679ccdf26fdde1aeb17a0adc5c3bf`:

- Primary: 459 attempt slots, 430 successful receipts, 28 failed receipts, 458 integrity-valid receipts; one in-flight June19 V NCSS request-only group explains the two issue messages. No other integrity failure was reported.
- December: all 213 original files from 71 groups match the primary in bytes and SHA; zero missing/different files, zero side integrity issues.
- November: three completed groups / nine original files were visible and were not yet carried forward. They are explicitly reported; no final success is possible while they remain absent.
- These counts are observations of a running acquisition, not the final annual totals. The latest primary failure visible here is June18 U attempt01 timeout; historical June15 V attempt01 and Apr28 V attempt01/02 are retained.

## Use after acquisition and independent all-values verification finish

From this directory, with a fresh report filename:

```powershell
& C:\Miniforge3\python.exe -B .\close-attempt-ledger570.py --inspect --output .\attempt-ledger-inspect-NEW.json
& C:\Miniforge3\python.exe -B .\close-attempt-ledger570.py --final --independent-values .\FULL-YEAR-INDEPENDENT-VALUES.json --output .\attempt-ledger-final-NEW.json
```

The second command is documented only, not executed on the actual acquisition. The supplied independent receipt must come from the reviewed mixed-transport verifier and validate all twelve months. Operators must close/stop acquisition writers and account for any differently named external staging location before final execution. Finite hash/snapshot stability does not prove that a live writer cannot write again; this helper does not infer missing historical observations from directories outside its stated scope. Final ledger verification is separate from scientific accuracy or source equivalence adoption.

## December transfer bounded retrospective review

Read `december-ncss16-transfer.py` SHA256 `0217c4a6a7e6cea28eae6a83585363bf2e4dcc76c0cb848c7cd664d489c32820` and its frozen helper inventory function. No additional transfer execution was performed by this reviewer.

The inventory fixes file order to raw, request, receipt; transfer retains that order. Whole identical groups are kept, wholly absent groups use exclusive file creation, partial/colliding groups stop, actions are checked again against the dry-run, and each new group receives another pre-copy existence check. Final December inventory must equal the stage. NPY and manifests are excluded. No major remaining issue was found within this bounded transfer contract.

The completed transfer receipt (`december-ncss16-transfer-receipt.json`, SHA256 `d52e7332b068a44e0fc57e536824e0ccdde50cd393c7cf456432901ee9bdeb77`) records 129 copied files and 71 final groups. The independent ledger partial inspection above rehashed all 213 primary/stage files and confirms equality. A crash between files still leaves a partial group that requires explicit review rather than automatic resume; this is an intentional preserved-evidence boundary.
