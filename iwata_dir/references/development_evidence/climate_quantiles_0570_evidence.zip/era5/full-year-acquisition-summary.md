# ERA5 2024 native wind sample acquisition — final record

All requested data were acquired and the acquisition workers have exited. The final manifest is `year2024/manifest-through-12.json` (identical to `manifest.json`), SHA256 `7718ccf5f25cb10859bbe49bdf20a4dd180e1a6c9ac7d5c1f8d8eb991e82cdbe`. `full-year-independent-readback.json` binds this manifest and records `all_original_values_equal:true`; a fresh independent read compared all732 selected raw component responses with all24 monthly NPY arrays,128703168float32values. This is actual full-value rereading, not only a composition of prior month receipts.

`attempt-ledger-final23.json` is `final_verified`, with zero errors, stable original-file snapshots and all October/November/December side originals carried forward identically. Ledger SHA256 `5dcbcb61bcff7d0f0fc8888f3027340ce44e4b89291855af3910f71200af77eb`. The fixed checker/ledger sources, both narrowly authorized slot03 exceptions, and latest side terminals are retained.

## Preserved support

2024 leap year,366days and1464times (00/06/12/18UTC each day);37pressure levels;1188native0.25degree cells (27latitudes46.5→40degrees,44longitudes138→148.75degrees). U/V retain original float32values and axes. The weighting is spherical area per cell with equal selected times. No requested component and no finite-value check is missing; no interpolation, different year, reduced month, or all-hourly-year claim is used. Native published NCAR ERA5 lat/lon values are not claimed to be the original model mesh. Pressure-level values may include below-ground extrapolation.

## Original receipt totals

| Observations | Successful | Failed | Total |
|---|---:|---:|---:|
| DODS components |250|24|274|
| NCSS components |482|11|493|
| Catalog + DODS metadata |32|0|32|
| All recorded attempts |764|35|799|

The selected732components use250DODS and482NCSS originals. All35failed responses, including partial bytes, remain separate original observations. There are2397request/raw/receipt files plus2older bounded-recovery notes. No request-only orphan remains. The last main run23 made33successful new requests and one failed attempt (October31U slot01), which recovered within slot02. Apr28V and Sep18U slot03 are separate exact-URL/receipt exceptions; the general NCSS new-request limit remains2.

The October21 runner was invoked after an immediate precheck failed because the outer orchestration did not gate its next command on exit0. Its own unchanged guard stopped before HTTP; no new request or original-file mutation occurred. The event and the corrected command sequencing are retained, not omitted from the history. October partial transfer was explicitly authorized after main stop and did not claim month completion. The main later completed October and this final check compared all62originals against its NPY.

## Storage and time

The primary directory contains1050459586bytes, including originals,24NPYs, manifest/checkpoints and two recovery notes; side-stage duplicates are outside that figure. Original raw bodies and partial bodies total522462634bytes; the original request/receipt/raw evidence with auxiliary notes totals523638720bytes. Numeric float32payload is514812672bytes, and the24NPY files total514815744bytes including headers.

The first retained primary-cache request began `2026-10-02T02:59:32.332539+00:00` and the last response finished `2026-10-02T08:17:46.547809+00:00`: 5 h 18 min 14.2 s including review/recovery pauses. Union of recorded request intervals is 3 h 52 min 52.7 s; summed per-request elapsed time is 5 h 41 min 10.5 s because some requests overlapped. The observed ERA-only peak was3concurrent requests earlier in the acquisition, later bounded to2 and finally1. These counts exclude JRA and standalone metadata/range/service probes outside the primary cache. They are not CPU time or a causal speedup experiment.

Successful component responses averaged24.928seconds (median16.094seconds). The longest recorded whole response was221.703seconds. Configured120seconds is socket waiting time, not a whole-response deadline. Main and side receipts copied into primary are counted once, so side transfers do not double the performance totals. Use `december-ncss16-complete-measurement02.json`, not the preserved rejected first measurement. Earlier tail-only 'no new failures' progress observations are superseded by this final full-receipt scan.

## Boundary and next owner

This closes acquisition, raw preservation, axes/support and bitwise conversion integrity. Scientific accuracy, cross-product equivalence, UI acceptance, permanent copying, demo packaging and Git integration are separate; the parent owns those next steps. Source10 and the repository acquisition source/tests remain unchanged during the final runs. No acquisition worker remains active.
