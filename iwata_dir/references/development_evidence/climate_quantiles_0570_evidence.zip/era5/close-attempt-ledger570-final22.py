"""Offline, read-only ERA5 attempt ledger; only an exclusive new report is written.

Examples (inspect is never final):
  python close-attempt-ledger570.py --inspect --output attempt-ledger-inspect.json
  python close-attempt-ledger570.py --final --independent-values FULL_VALUES.json --output attempt-ledger-final.json
No network libraries, acquisition imports, repairs, copying or budget resets.
"""
from pathlib import Path
import argparse
import calendar
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
import hashlib
import json
import math
import re
import sys
from urllib.parse import quote, urlencode

BASE = Path(__file__).resolve().parent
HOST = 'https://tds.gdex.ucar.edu/thredds/'
YEAR = 2024
EXPECTED_VALUES = 366 * 4 * 37 * 1188 * 2
NCSS_EXCEPTIONS = {
    'ncss-v-20240428': {
        'receipt_sha256': '1774d217101fd74b7ee79e3cd36fc3677a962e93e2c3f10f53a68a8ad2cf8db2',
        'note': 'Apr28 V separately authorized recovery13; no expansion to other URLs',
    },
    'ncss-u-20240918': {
        'receipt_sha256': '27bbd503d222db6fa4953ac6eec3b9f2880eeb172c5067d80cdca8d657b8f957',
        'authorization_file': '../sep18-root-plan22/receipt.json',
        'authorization_sha256': '4c3494f296f50af6efa48139f29229c15b55a5f36e6eab535601f9a0ac9f1e82',
        'note': 'Sep18 U separately root-authorized recovery22 slot03; main resume separate; no expansion to other URLs',
    },
}
SUFFIXES = ('.receipt.json', '.request.json', '.body', '.partial')
RECOVERY_NOTES = {
    'u-20240228-attempt02.recovery.json': 'bbe0b21e2e297766d98fe5650c00d07482f13d1bc6e00ae12a9a507bdb8d856a',
    'v-20240227-attempt02.recovery.json': 'f097fc3e0a860d78e38069a8297d500ef72cb2a7fcca44436e5cb20a6a0c663d',
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def fingerprint(path):
    """Stream bytes; reject a file changed while it was read."""
    need(path.is_file() and not path.is_symlink(), f'Not a regular nonsymlink file: {path}')
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = path.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), f'File changed during read: {path.name}')
    return {'name': path.name, 'bytes': after.st_size, 'sha256': digest.hexdigest()}


def json_file(path):
    raw = path.read_bytes()
    need(len(raw) <= 32 * 1024 * 1024, f'Unexpected JSON size: {path.name}')
    return json.loads(raw), {'name': path.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def snapshot(folder):
    return {p.name: [p.stat().st_size, p.stat().st_mtime_ns] for p in folder.iterdir() if p.is_file()}


def snapshot_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def discover_side_stages(root):
    """Finite local scope: sibling month-worker stages, including later workers."""
    return sorted(p.resolve() for p in root.parent.glob('*-ncss*-stage') if p.is_dir())


def terminal_input(path):
    terminal, info = json_file(path)
    need(terminal.get('status') in ('completed', 'failed'), 'Side worker has no terminal state')
    need(terminal.get('inventory_error') is None and not terminal.get('inventory', {}).get('unresolved_files'), 'Side terminal still has unresolved observations')
    return {**info, 'path': str(path)}


def identity(stem):
    catalog = re.fullmatch(r'catalog-(2024)(\d{2})', stem)
    metadata = re.fullmatch(r'([uv])-(2024)(\d{2})-(dds|das)', stem)
    daily = re.fullmatch(r'(ncss-)?([uv])-(2024\d{4})', stem)
    if catalog:
        month = int(catalog[2]); date(YEAR, month, 1)
        return {'kind': 'metadata', 'service': 'catalog', 'metadata_type': 'catalog', 'month': month,
                'url': HOST + f'catalog/files/g/d633000/e5.oper.an.pl/2024{month:02}/catalog.xml'}
    if metadata:
        component, month, suffix = metadata[1], int(metadata[3]), metadata[4]
        stamp = date(YEAR, month, 1).strftime('%Y%m%d')
    elif daily:
        component, stamp = daily[2], daily[3]
        when = date.fromisoformat(f'{stamp[:4]}-{stamp[4:6]}-{stamp[6:]}')
        month = when.month
    else:
        raise ValueError(f'Unexpected response stem: {stem}')
    parameter = {'u': '131_u', 'v': '132_v'}[component]
    dataset = f'files/g/d633000/e5.oper.an.pl/{stamp[:6]}/e5.oper.an.pl.128_{parameter}.ll025uv.{stamp}00_{stamp}23.nc'
    if metadata:
        return {'kind': 'metadata', 'service': 'dods', 'metadata_type': suffix, 'component': component,
                'month': month, 'url': HOST + 'dodsC/' + dataset + '.' + suffix}
    service = 'ncss' if daily[1] else 'dods'
    if service == 'ncss':
        query = {'var': component.upper(), 'north': '46.5', 'south': '40', 'west': '138', 'east': '148.75',
                 'horizStride': '1', 'time': 'all', 'timeStride': '6', 'accept': 'netCDF'}
        url = HOST + 'ncss/grid/' + dataset + '?' + urlencode(query)
    else:
        query = f'{component.upper()}[0:6:18][0:1:36][174:1:200][552:1:595]'
        url = HOST + 'dodsC/' + dataset + '.dods?' + quote(query, safe='')
    return {'kind': 'component', 'service': service, 'component': component, 'date_utc': when.isoformat(),
            'month': month, 'canonical_sample': f'{component}-{stamp}', 'url': url}


def summarize(records):
    groups = defaultdict(list)
    for row in records:
        groups['all'].append(row)
        groups[f"{row.get('kind', 'unknown')}:{row.get('service', 'unknown')}"] .append(row)
    result = {}
    for key, rows in sorted(groups.items()):
        elapsed = [r['elapsed_seconds'] for r in rows if isinstance(r.get('elapsed_seconds'), (int, float)) and math.isfinite(r['elapsed_seconds'])]
        result[key] = {'attempts': len(rows), 'successful_receipts': sum(r.get('complete') is True for r in rows),
            'failed_receipts': sum(r.get('complete') is False for r in rows), 'integrity_valid': sum(r.get('integrity_valid') is True for r in rows),
            'raw_bytes': sum(r.get('bytes', 0) for r in rows if type(r.get('bytes')) is int),
            'elapsed_seconds_sum': sum(elapsed), 'elapsed_seconds_max': max(elapsed, default=None),
            'http_status': dict(Counter(str(r.get('http_status')) for r in rows)),
            'errors': dict(Counter(r['error'] for r in rows if isinstance(r.get('error'), str)))}
    return result


def scan(root):
    folder = root / 'responses'
    records, issues, files, by_stem, orphan_groups, auxiliary = [], [], {}, defaultdict(list), [], []
    if not folder.is_dir():
        return {'root': str(root), 'records': [], 'issues': ['Missing responses directory'], 'files': {}, 'summary': {}, 'snapshot_stable': False, 'orphans': []}
    initial = snapshot(folder)
    groups = defaultdict(dict)
    for name in initial:
        suffix = next((s for s in SUFFIXES if name.endswith(s)), None)
        if suffix is None:
            try:
                files[name] = fingerprint(folder / name)
                need(name in RECOVERY_NOTES, f'Unexpected file in responses: {name}')
                need(files[name]['sha256'] == RECOVERY_NOTES[name], f'Reviewed recovery note changed: {name}')
                auxiliary.append({'name': name, 'file': files[name], 'kind': 'historical_recovery_note', 'counts_as_attempt': False})
            except Exception as error:
                issues.append(f'{name}: {type(error).__name__}: {error}')
            continue
        match = re.fullmatch(r'(.+)-attempt(\d{2})', name[:-len(suffix)])
        if not match:
            issues.append(f'Unexpected attempt filename: {name}')
            try: files[name] = fingerprint(folder / name)
            except Exception as error: issues.append(f'{name}: {type(error).__name__}: {error}')
            continue
        groups[(match[1], int(match[2]))][suffix] = name
    for (stem, number), members in sorted(groups.items()):
        row = {'stem': stem, 'attempt': number, 'integrity_valid': False, 'files': []}
        by_stem[stem].append(number)
        if '.receipt.json' not in members:
            orphan = {'stem': stem, 'attempt': number, 'files': sorted(members.values()), 'meaning': 'request-only or unfinished observation; never a fresh attempt'}
            orphan_groups.append(orphan)
            issues.append(f'No receipt for {stem}-attempt{number:02}: {orphan["files"]}')
        try:
            for name in sorted(members.values()):
                item = fingerprint(folder / name); files[name] = item; row['files'].append(item)
            info = identity(stem); row.update(info)
            need(1 <= number <= 3, 'Absolute same-service attempt limit is 3')
            need(info['service'] != 'ncss' or number <= 2 or stem in NCSS_EXCEPTIONS, 'NCSS slot03 lacks an exact reviewed exception')
            need('.receipt.json' in members and '.request.json' in members, 'Missing receipt/request pair')
            receipt, receipt_info = json_file(folder / members['.receipt.json'])
            request, request_info = json_file(folder / members['.request.json'])
            need(receipt_info == files[members['.receipt.json']] and request_info == files[members['.request.json']], 'JSON changed between hash and parse')
            row.update({k: receipt.get(k) for k in ['complete', 'http_status', 'error', 'elapsed_seconds', 'bytes', 'sha256', 'started_utc', 'finished_utc']})
            row['receipt'] = 'responses/' + members['.receipt.json']
            row['request'] = 'responses/' + members['.request.json']
            row['receipt_sha256'] = receipt_info['sha256']
            need(receipt.get('url') == request.get('url') == info['url'], 'Canonical / request / receipt URLs differ')
            for key in request.keys() & receipt.keys():
                need(request[key] == receipt[key], f'Request/receipt shared field differs: {key}')
            need(type(receipt.get('complete')) is bool, 'complete must be a boolean')
            raw_suffix = '.body' if receipt['complete'] else '.partial'
            need(set(members) == {'.receipt.json', '.request.json', raw_suffix}, 'Expected exactly one request/receipt/body-or-partial triplet')
            raw = files[members[raw_suffix]]
            need(type(receipt.get('bytes')) is int and receipt['bytes'] >= 0 and receipt['bytes'] == raw['bytes'], 'Raw byte count differs')
            need(receipt.get('sha256') == raw['sha256'], 'Raw SHA256 differs')
            elapsed = receipt.get('elapsed_seconds')
            need(type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0, 'Invalid elapsed_seconds')
            status = receipt.get('http_status')
            need(status is None or (type(status) is int and 100 <= status <= 599), 'Invalid HTTP status')
            if receipt['complete']:
                need(status == 200 and not receipt.get('error'), 'Successful observation requires HTTP200 and no error')
            else:
                need(isinstance(receipt.get('error'), str) and bool(receipt['error']), 'Failed observation lacks original error')
            cap = request.get('cap_bytes')
            need(type(cap) is int and cap > 0, 'Missing/invalid original byte cap')
            need(raw['bytes'] <= cap + (0 if receipt['complete'] else 1), 'Original response cap exceeded')
            need(request.get('retries') == 0 and request.get('redirects') is False and request.get('credentials_read') is False, 'Unexpected original request policy')
            if info['service'] == 'ncss' and number == 3:
                exception = NCSS_EXCEPTIONS[stem]
                need(receipt_info['sha256'] == exception['receipt_sha256'], 'Exception receipt changed from the reviewed original')
                if 'authorization_file' in exception:
                    path = (BASE / exception['authorization_file']).resolve()
                    authorization, authorization_info = json_file(path)
                    need(authorization_info['sha256'] == exception['authorization_sha256'], 'Exception authorization SHA256 differs from the reviewed root plan')
                    need(authorization.get('approved_by') == 'root' and authorization.get('approved_one_request') == info['url']
                         and type(authorization.get('slot')) is int and authorization['slot'] == 3
                         and authorization.get('main_resume_separate') is True, 'Exception authorization is not for this exact URL and slot03')
                    row['exception_authorization'] = {**authorization_info, 'path': str(path)}
                row['explicit_exception'] = exception['note']
            row['integrity_valid'] = True
        except Exception as error:
            row['validation_error'] = f'{type(error).__name__}: {error}'
            issues.append(f'{stem}-attempt{number:02}: {row["validation_error"]}')
        records.append(row)
    for stem, numbers in sorted(by_stem.items()):
        if sorted(numbers) != list(range(1, max(numbers) + 1)):
            issues.append(f'Attempt gap for {stem}: {sorted(numbers)}')
    by_receipt = {r.get('receipt', '').removeprefix('responses/'): r for r in records if r.get('integrity_valid')}
    for item in auxiliary:
        try:
            note, info = json_file(folder / item['name'])
            need(info == item['file'], 'Recovery note changed while parsed')
            stem = item['name'].removesuffix('-attempt02.recovery.json')
            prior = by_receipt.get(stem + '-attempt01.receipt.json')
            after = by_receipt.get(stem + '-attempt02.receipt.json')
            need(prior is not None and prior['complete'] is False and after is not None and after['complete'] is True, 'Recovery note lacks its failed/successful observations')
            need(note.get('reviewed_prior_receipt') == stem + '-attempt01.receipt.json' and note.get('reviewed_prior_sha256') == prior['receipt_sha256'], 'Recovery note prior receipt hash differs')
            need(note.get('new_receipt') == stem + '-attempt02.receipt.json', 'Recovery note new receipt differs')
            item['integrity_valid'] = True
        except Exception as error:
            item['integrity_valid'] = False
            issues.append(f'{item["name"]}: {type(error).__name__}: {error}')
    final = snapshot(folder)
    stable = initial == final
    if not stable:
        issues.append('Responses directory changed during inspection; not a closed snapshot')
    return {'root': str(root), 'records': records, 'issues': issues, 'files': files, 'summary': summarize(records),
            'snapshot_stable': stable, 'orphans': orphan_groups,
            'directory_snapshot_sha256': snapshot_hash(final), 'auxiliary_records': auxiliary,
            'attempt_slots': {k: sorted(v) for k, v in sorted(by_stem.items())}}


def full_inputs(root, independent, terminal):
    errors, facts = [], {}
    manifest = proof = None
    try:
        manifest, info = json_file(root / 'manifest-through-12.json'); facts['manifest'] = info
        need(manifest.get('schema') == 'balloon.wind-samples/1' and manifest.get('provider') == 'ERA5' and manifest.get('years') == [2024, 2024], 'Wrong final source/schema/year')
        need([x['month'] for x in manifest['months']] == list(range(1, 13)), 'Final checkpoint must contain the complete ordered 12 months')
        need(manifest.get('hours_utc') == [0, 6, 12, 18] and manifest.get('date_convention') == 'UTC', 'Wrong final UTC selection')
        pointer = fingerprint(root / 'manifest.json'); facts['current_pointer'] = pointer
        need(pointer['sha256'] == info['sha256'], 'Current manifest pointer differs from through12 checkpoint')
    except Exception as error:
        errors.append(f'Annual manifest gate: {type(error).__name__}: {error}')
    try:
        need(independent is not None, '--independent-values is required for final closure')
        proof, info = json_file(independent); facts['independent_values'] = {**info, 'path': str(independent)}
        need(manifest is not None and proof.get('manifest_sha256') == facts['manifest']['sha256'], 'Independent proof is not bound to this final manifest')
        need(proof.get('complete_2024') is True and proof.get('complete_months') == list(range(1, 13)) and proof.get('validated_months') == list(range(1, 13)), 'Independent proof must validate every month; a month-filtered run is insufficient')
        need(proof.get('component_responses') == 732 and proof.get('float32_values_compared') == EXPECTED_VALUES, 'Independent full response/value count differs')
        checks = proof.get('checks', [])
        expected = {(month, component) for month in range(1, 13) for component in ('u', 'v')}
        need(len(checks) == 24 and {(x['month'], x['component']) for x in checks} == expected, 'Independent proof lacks the 24 distinct component/month checks')
        for check in checks:
            item = manifest['months'][check['month'] - 1][check['component']]
            need(check.get('bit_equal') is True and check.get('npy_sha256') == item['sha256'], 'Independent source-to-NPY bit comparison/hash mismatch')
            need(check.get('values') == calendar.monthrange(2024, check['month'])[1] * 4 * 37 * 1188, 'Wrong independent month value count')
    except Exception as error:
        errors.append(f'Independent full-values gate: {type(error).__name__}: {error}')
    try:
        facts['side_terminal'] = terminal_input(terminal)
    except Exception as error:
        errors.append(f'Side terminal gate: {type(error).__name__}: {error}')
    return manifest, proof, facts, errors


def reconcile_side(primary, side):
    errors = []
    for name, item in side['files'].items():
        if primary['files'].get(name) != item:
            errors.append(name)
    return {'side_files': len(side['files']), 'byte_identical_primary_files': len(side['files']) - len(errors),
            'missing_or_different_files': sorted(errors), 'all_original_files_carried_forward': not errors and not side['issues']}


def final_bindings(root, manifest, proof, ledger):
    errors = []
    try:
        by_receipt = {row.get('receipt'): row for row in ledger['records'] if row.get('integrity_valid')}
        selected = manifest['provenance']['requests']
        need(len(selected) == 732, 'Final manifest must select exactly 732 daily component responses')
        keys, transport_counts = set(), Counter()
        for selection in selected:
            row = by_receipt.get(selection['receipt'])
            need(row is not None and row['kind'] == 'component' and row['complete'], f'Invalid selected component receipt: {selection["receipt"]}')
            for key in ('url', 'bytes', 'sha256'):
                need(selection[key] == row[key], f'Manifest/ledger {key} differs')
            need(row['canonical_sample'] not in keys, 'Duplicate canonical sample in manifest')
            keys.add(row['canonical_sample']); transport_counts[row['service']] += 1
            need(selection.get('transport', 'dods') == row['service'], 'Wrong selected transport')
            if row['service'] == 'ncss':
                historical = [r for r in ledger['records'] if r['stem'] == row['canonical_sample']]
                expected = [{'attempt': r['attempt'], 'receipt': r['receipt'], 'complete': r['complete'], 'http_status': r['http_status'], 'sha256': r['sha256']} for r in historical]
                need(selection.get('prior_dods_attempts') == expected, 'Prior DODS attempt history disappeared or changed in manifest')
        expected_keys = {f'{component}-2024{month:02}{day:02}' for month in range(1, 13) for day in range(1, calendar.monthrange(2024, month)[1] + 1) for component in ('u', 'v')}
        need(keys == expected_keys, 'Missing daily U/V canonical samples')
        need(dict(transport_counts) == {k: v for k, v in proof['by_transport'].items() if v}, 'Independent proof transport counts differ')
        catalogs = set()
        for selection in manifest['provenance']['metadata']:
            row = by_receipt.get(selection['receipt'])
            need(row is not None and row['kind'] == 'metadata' and row['complete'], 'Invalid selected metadata receipt')
            need(all(selection[k] == row[k] for k in ('url', 'bytes', 'sha256')), 'Metadata manifest/ledger binding differs')
            if row.get('metadata_type') == 'catalog': catalogs.add(row['month'])
        need(catalogs == set(range(1, 13)), 'Missing catalog provenance for a month')
        for entry in manifest['months']:
            for component in ('u', 'v'):
                item = entry[component]; file = root / item['file']
                need(file.parent.resolve() == root.resolve(), 'NPY path escapes the bundle')
                info = fingerprint(file)
                need(info['sha256'] == item['sha256'] and info['bytes'] == item['bytes'], 'Current NPY differs from the independent proof-bound manifest')
    except Exception as error:
        errors.append(f'Final provenance binding: {type(error).__name__}: {error}')
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--inspect', action='store_true'); modes.add_argument('--final', action='store_true')
    parser.add_argument('--root', type=Path, default=BASE / 'year2024')
    parser.add_argument('--side-stage', type=Path, default=BASE / 'december-ncss16-stage')
    parser.add_argument('--side-terminal', type=Path, default=BASE / 'december-ncss16-terminal.json')
    parser.add_argument('--independent-values', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.root = args.root.resolve(); args.side_stage = args.side_stage.resolve(); args.output = args.output.resolve()
    discovered_stages = discover_side_stages(args.root)
    additional_stages = [p for p in discovered_stages if p != args.side_stage]
    need(not args.output.exists(), 'Report output already exists; preserve it and choose a new path')
    for protected in (args.root, args.side_stage, *additional_stages):
        need(not args.output.is_relative_to(protected), 'Report must not be written inside an observed acquisition bundle')
    report = {'schema': 'balloon.era5-attempt-ledger/1', 'started_utc': utc(), 'mode': 'final' if args.final else 'inspect',
        'final_complete': False, 'script_sha256': fingerprint(Path(__file__).resolve())['sha256'],
        'scope': 'All original request/receipt/raw hashes and attempt history; no network, mutation, repair or scientific accuracy claim',
        'limits': {'same_service_absolute_max': 3, 'fresh_ncss_max': 2, 'exact_ncss_slot03_exceptions': NCSS_EXCEPTIONS},
        'root': str(args.root), 'side_stage': str(args.side_stage),
        'additional_side_stages': [str(p) for p in additional_stages], 'errors': []}
    manifest = proof = None
    if args.final:
        manifest, proof, facts, gates = full_inputs(args.root, args.independent_values, args.side_terminal)
        report['final_prerequisites'] = facts; report['errors'].extend(gates)
        facts['additional_side_terminals'] = []
        for stage in additional_stages:
            try:
                path = stage.parent / (stage.name.removesuffix('-stage') + '-terminal.json')
                facts['additional_side_terminals'].append(terminal_input(path))
            except Exception as error:
                report['errors'].append(f'Additional side terminal gate for {stage.name}: {type(error).__name__}: {error}')
    if not args.final or not report['errors']:
        primary = scan(args.root); side = scan(args.side_stage)
        report['primary'] = primary; report['side'] = side
        report['side_carry_forward'] = reconcile_side(primary, side)
        report['additional_sides'] = []
        for stage in additional_stages:
            observation = scan(stage)
            report['additional_sides'].append({'ledger': observation, 'carry_forward': reconcile_side(primary, observation)})
        report['errors'].extend('Primary: ' + x for x in primary['issues'])
        if args.final:
            report['errors'].extend('Side: ' + x for x in side['issues'])
            if not report['side_carry_forward']['all_original_files_carried_forward']:
                report['errors'].append('Side original observations are not fully carried forward into primary')
            for item in report['additional_sides']:
                report['errors'].extend('Additional side: ' + x for x in item['ledger']['issues'])
                if not item['carry_forward']['all_original_files_carried_forward']:
                    report['errors'].append('Additional side original observations not fully carried forward: ' + item['ledger']['root'])
            report['errors'].extend(final_bindings(args.root, manifest, proof, primary))
            # Recheck fixed inputs after the ledger and NPY reads.
            for path, expected in [(args.root / 'manifest-through-12.json', report['final_prerequisites']['manifest']),
                                   (args.root / 'manifest.json', report['final_prerequisites']['current_pointer']),
                                   (args.independent_values, report['final_prerequisites']['independent_values']),
                                   (args.side_terminal, report['final_prerequisites']['side_terminal']),
                                   *[(Path(item['path']), item) for item in report['final_prerequisites']['additional_side_terminals']],
                                   *[(Path(row['exception_authorization']['path']), row['exception_authorization'])
                                     for row in primary['records'] if 'exception_authorization' in row]]:
                try:
                    need(fingerprint(path)['sha256'] == expected['sha256'], f'Final input changed during inspection: {path}')
                except Exception as error: report['errors'].append(str(error))
            for observed in (primary, side, *[item['ledger'] for item in report['additional_sides']]):
                try:
                    need(snapshot_hash(snapshot(Path(observed['root']) / 'responses')) == observed['directory_snapshot_sha256'], 'Responses changed after ledger scan: ' + observed['root'])
                except Exception as error: report['errors'].append(str(error))
            if discover_side_stages(args.root) != discovered_stages:
                report['errors'].append('Month-worker stage inventory changed during closure')
            report['final_complete'] = not report['errors']
    report['status'] = ('final_verified' if report['final_complete'] else 'final_refused') if args.final else 'partial_observation_not_final'
    report['finished_utc'] = utc()
    with args.output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2); stream.write('\n')
    print(json.dumps({'status': report['status'], 'final_complete': report['final_complete'], 'errors': len(report['errors']),
                      'output': str(args.output), 'primary_attempts': len(report.get('primary', {}).get('records', [])),
                      'side_untransferred_files': len(report.get('side_carry_forward', {}).get('missing_or_different_files', [])),
                      'additional_side_untransferred_files': sum(len(x['carry_forward']['missing_or_different_files']) for x in report.get('additional_sides', []))}))
    return 0 if args.inspect or report['final_complete'] else 2


if __name__ == '__main__':
    sys.exit(main())
