# ERA5: DDS 後切断と代替配布経路の有限レビュー

記録時刻: 2026-10-02T04:46:55.638425+00:00

取得は停止中。成功250/732日別成分を保持し、完成月は1–3月のみ。4月49成分日、12月19成分日は未完成月の材料であり、通年成果にしない。run04/06の各停止、既存の累積試行数、原ログ・部分応答・完成bytesを変更していない。最初の調査は既存資料と公式仕様だけ、後続の親許可でAWSの限定一覧・2 objectのHEAD・各8B Rangeだけを追加した。新しい気象数値やDODS再試行はない。

## 6失敗の共通条件

`year2024/responses/v-20240425-attempt01..03` と `prefetch202412-run06/responses/v-20241210-attempt01..03` のreceipt/partialを実読・ハッシュ再照合した。全件HTTP200、Content-Type application/octet-stream、Transfer-Encoding chunked、Connection close、XDODS-Server opendap/3.7、Content-Description dods-data。同じURL内の3応答は同一378Bで、Float32 Vの形[4,37,27,44]と座標Mapsを示すDDSが `Data:` で終わる。**その後のXDR数値bytesは0**。エラーは全てIncompleteRead(378 bytes)。認証、Cookie、Retry-After、rate-limit情報やエラー説明本文はない。

| 対象 | attempt | 開始 UTC | 終了 UTC | 経過秒 |
|---|---:|---|---|---:|
| Apr25 V | 1 | 04:30:51.463 | 04:31:56.757 | 65.297 |
| Apr25 V | 2 | 04:32:01.766 | 04:32:27.082 | 25.297 |
| Apr25 V | 3 | 04:32:32.083 | 04:33:19.922 | 47.828 |
| Dec10 V | 1 | 04:31:46.280 | 04:31:56.761 | 10.484 |
| Dec10 V | 2 | 04:32:01.763 | 04:32:19.265 | 17.500 |
| Dec10 V | 3 | 04:32:24.267 | 04:32:45.751 | 21.484 |

全て2026-10-02。2つの初回終了は約4.2ms差であり、共有された配布側または経路の障害と整合するが、原因の確定ではない。HTTP403/429/503拒否でも、設定120秒を使い切ったtimeoutでもない。DDS成功はデータ抽出成功を意味しないため、DDSだけの再確認を復旧の証明に使えない。プロキシ切断、サーバ過負荷、ファイル読出し等のどこか、また並列数との因果はこの観測から区別できない。

詳細は `six-truncated-responses570.json` と各原receipt/partial。過去03:30Zの503停止・明示復旧は別の出来事であり、今回の200後切断と混同しない。

## 同じd633000を保つ経路

### NCSS: 低転送量の最小候補、同じhostの制約は残る

取得済みJanuary catalog（SHA256 0491584e9ccdba5f34f1786fbc6ac9c43685182c10207ce69abf5e3791c72d1a）には、同じdaily componentのurlPathにOpenDAP `/thredds/dodsC/` とNetcdfSubset `/thredds/ncss/grid/`、HTTPServerが宣言されている。これは現catalogの証拠であり、今回NCSS endpointの動作は試していない。

NCSSは緯経度・時刻で部分抽出し、再標本化/再投影を行わず元の解像度と精度を保つ仕様。コンテナはCF NetCDFに変わるためファイルhash一致は求めず、既存DODSの時刻・37面・27×44座標・float32値を重複1日で比較するのが適切。ホストと物理データが同じなので独立した障害回避を保証しない。[Unidata NCSS仕様](https://docs.unidata.ucar.edu/tds/5.8/adminguide/netcdf_subset_service_ref.html)

後で試すならdaily datasetを使い `var=U` またはV、north46.5/south40/west138/east148.75、horizStride1、time=all/timeStride6、vertCoord省略で全37面を要求する。既定presentやnearest-level/nearest-timeに依存しない。応答座標を必ず現集合へ照合する。これらは候補設計で未実行。[NCSS GRID parameters](https://docs.unidata.ucar.edu/tds/5.1/adminguide/ncss_grid.html)

数値のみなら1日1成分703,296B、U/V約1.41MB、全732成分514,812,672B（メタデータ・容器追加前）。圧縮/速度は未測定。認証なしDODSの成功実績はあるが、NCSS自体の匿名到達は未確認。拒否時に別hostへ自動迂回しない。

### NCAR AWS: 2つの対象objectと匿名Rangeを確認

[公式AWS Registry](https://registry.opendata.aws/nsf-ncar-era5/) はNCAR管理bucket `nsf-ncar-era5`、同じDOI10.5065/BH6N-5N20、NetCDF4・0.25度・37面、匿名アクセスを記す。今回4つの限定ListObjectsで対象keyを確認し、Jan1 U/Vの2 objectだけHEADとbytes0–7を読み取った。いずれもHEAD200、Range206、HDF5 signature一致。

| 2024-01-01 object | 全体bytes | Range |
|---|---:|---|
| U e5.oper.an.pl.128_131_u.ll025uv.2024010100_2024010123.nc | 1,550,090,852 | bytes 0–7 / 1,550,090,852 |
| V e5.oper.an.pl.128_132_v.ll025uv.2024010100_2024010123.nc | 1,678,016,434 | bytes 0–7 / 1,678,016,434 |

keyは `e5.oper.an.pl/202401/` 以下。既存THREDDS catalogの丸めた1.550/1.678Gbytesと整合するが、**実値/whole-file同一性の証明ではない**。ETagはmultipartのsuffixを持ち、単純MD5や科学的同一性の証明に使わない。全12月のAWS存在確認はしていない。`aws-metadata570/` に全metadata request/headers/body/shaを保存した。数値取得0、object先頭計16Bと小さな一覧のみ。

Rangeは任意の値を安く得られる保証ではない。現NCAR DASのwind chunkは[1,37,721,1440]で、1UTCの非圧縮chunkは153,659,520B。AWSが同配置なら、4UTC×2成分で1日約1.229GB、通年約449.9GBのchunk展開が必要。圧縮ネットワーク量は未測定で、Rangeにより4/24時刻へ絞れるとしても空間領域だけを圧縮chunk内部から抽出できるとは限らない。今回AWS chunk metadata自体は未解読（既存2Pythonにh5pyなし、新規依存追加なし）。全文日別U/Vは既知の1日だけで約3.23GBあり、全文取得は採用しない。

### 同じNCARのOSDF / HTTPServer

[NCAR OSDF公式説明](https://gdex.ucar.edu/about-gdex/ndcc-osdf/) はGDEX全datasetをOSDFで提供する。同じ公開原ファイルの別配送として有力だが、対象object、匿名到達、Range、キャッシュ位置は未試験。HTTPServerは取得済みcatalogにあり、[Unidata仕様](https://docs.unidata.ucar.edu/tds/5.8/adminguide/available_services.html)ではRangeを支援する。ただし両方ともHDF5の配置次第で上と同様に大きなchunk転送となる。WMS画像は数値標本の代わりにしない。

## 他の公式ERA5配布

- Google full_37 ARCO: 37面/1時間/0.25度・匿名アクセス。文書上chunkは1時刻×全球×37面で、今回の抽出は同じ約450GBの非圧縮chunk量。圧縮転送量は不明。CDS由来の加工経路であり、NCAR公開float32と同一との保証はない。
- ECMWF pressure-levels-timeseries ARCO: UTC00/06/12/18だが13面（50–1000hPa）だけで、要求の37面を満たさない。CDS token/利用条件同意が必要。時系列向けchunkでも欠ける24面は復元できない。
- 通常CDS pressure levels: 37面とserver側の地域・日時抽出があるため返却量は小さくできる。新しい認証/利用条件が必要で、NCAR値との重複比較とsource来歴の区別が必要。

詳細な公式リンク、Google処理経路と精度の留保は `official-arco-routes-review.md`。同じERA5名だけで元標本へ混ぜない。

## 次の有限判断（未実施）

転送量を抑えて既存値を保つ第一候補はNCSSの1日重複比較。ただし同hostなので、今の停止中に勝手に実行しない。独立配布の第一候補はNCAR AWSで、有限HDF5 metadata解析により4UTCのcompressed chunk bytesを調べ、費用が許容できる場合のみ重複1日へ進む。今回のHEAD/Rangeだけで高価な実値取得へは進んでいない。

元DODSを再開する場合もApr25V/Dec10Vの各3失敗を消さず、回復確認後の別明示判断と累積履歴を要する。上限reset、stage名変更、無限自動retryで同じURLを再送しない。いずれの経路も成功250応答を保全し、全12月一致を通年の受入境界とする。
