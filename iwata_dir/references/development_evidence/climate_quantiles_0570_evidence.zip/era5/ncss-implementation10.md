# NCSS implementation and finite execution handoff

Only repo tool and its existing test were changed. Source is frozen as ncss-source10/ and ncss-source10.json; prior run04 copies remain untouched.

- tools/acquire_era5_climate_samples.py SHA256 d4a25c52de79ef016de45929cc5f87259bab0170b60cd04d8e928ac91506b074
- tests/test_acquire_era5_climate_samples.py SHA256 a95de89480043b258ac30635970c1426b395c5342b24e338c2a38437b1d6548a

New responsibilities: canonical_request (dataset/component/day/native support); ncss_url (coordinate/time subset); decode_ncss (raw NetCDF3/units/calendar/native dtype/order/finite values); cached_observation (all recorded slots, no send); attempt_history (preserved service-specific evidence); daily_observation (explicit transport, validated priorDODS reuse, newNCSS raw provenance). acquire defaultsDODS; explicitNCSS never requests DODS metadata or data. Published calendar prefix is checked before HTTP. probe+NCSS is rejected before any DODS send.

NCSS decoding uses existing SciPy1.17.1 by lazy import; no new package/environment installation. NetCDF3 originals are saved as their own bytes, not manufactured DODS. RawFloat32, fourUTC hours,37nativelevels,1188cells, spherical weights and complete-month publication remain the same. Runtime attempt caps are transport-specific and shown in logs; oldDODS failures never authorize a newDODS send. Body cap now stops at the limit rather than retaining one extra overflow byte. This may reject a response exactly at cap unless EOF was already known; all current valid responses are far below5MiB.

## Evidence

- ncss-tests10.log:45offlinePASS/3.44s. Initial ncss-tests08 recorded one test-fixture monkeypatch error and fixture-close warnings; fixed in tests, not hidden. ncss-tests09 had43PASS; final10 adds calendar-prefix and invalidprobe-mode regressions.
- ncss-final10-offline.json: actual January1/April25 NCSS decoding; actual December8 DODS successfulslot02 reused undernewattemptlimit1 without HTTP.
- ncss-old-checkpoints09/ is an independent copy of historical1–3month data. Finalfreeze10 replay underHTTP-forbidden changed no bytes among639files; original monthmanifest hashes retained.
- ncss-limited570/limited-result.json + native-dtype-bits.json: two finiteV probes only. January1's175,824windvalues and every nativeaxis array match DODS bytes/dtypes. April25V has no completeDODS comparator; only returned native support/finiteFloat32 was validated. Neither is a proof for allU/V dates.
- ncss-import10-apply.json and ncss-import11-readback.json: originalApril25NCSS3files andDecember10DODS3failedtriplets copied exclusively; exactoriginalbytes retained; all900preexistingprimaryfiles unchanged.
- verify-mixed-ncss11.py is separate from acquisition code, reading DAP2 directly or NetCDF3 throughSciPy and comparing all values/axes/times/hashes to NPYS. It was checked offline on1–3months and January1 cross-service overlap. A fourth-month manifest has not been published and cannot yet be verified.

## Run11 stopped

Parent authorized months1,2,3,4; explicitNCSS; resume;1worker;120ssockettimeout; cumulative2attempts. Session64342 endedexit1. Five newNCSS requests succeeded(mean9.175s,median9.110s,range4.766–15.172s). April28V first attempt timed out duringread after120.328s with0B/noHTTPheaders; second ended WinError10060 after21.125s with0B/noHTTPheaders. NoHTTP403/429/503 was observed in thisrun; missingheaders do not identify the cause.

Together with importedApril25V,6NCSS distinctsamples supplement250DODS samples:256/732; April55/60component-days. Published complete months remain1–3 and currentmanifestSHA remains6c2387476560e548b3c96048556e8ca729ef5a3f144a37461a70ec4b8c875575. No completion, month04NPY comparison, reliability improvement or provider recovery is claimed. Original900files were againhash-checked unchanged afterstop.

All acquisition is now stopped. No upper-limit reset, transport auto-fallback or parallelism increase. Root must decide any further recovery attempt while retaining both consumedNCSS attempts and historicalDODS evidence. Full2024/37levels/fourUTC remains the objective, not a completed result.
