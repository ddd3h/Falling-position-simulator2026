"""Independent saved-source to NPY verification; no HTTP or acquisition imports."""
from pathlib import Path
import argparse,calendar,hashlib,io,json,re,struct,datetime,urllib.parse
import numpy as np
from scipy.io import netcdf_file
LEVELS=[1,2,3,5,7,10,20,30,50,70,100,125,150,175,200,225,250,300,350,400,450,500,550,600,650,700,750,775,800,825,850,875,900,925,950,975,1000]
def sha(b):return hashlib.sha256(b).hexdigest()
def arrays(body,component,transport):
    if transport=='ncss':
        assert body[:4] in [b'CDF\x01',b'CDF\x02']
        with netcdf_file(io.BytesIO(body),'r',mmap=False) as f:
            a={k:f.variables[k].data.copy() for k in [component.upper(),'time','level','latitude','longitude']}
            assert f.variables[component.upper()].dimensions==('time','level','latitude','longitude')
            assert f.variables[component.upper()].units==b'm s**-1'
            assert f.variables['level'].units==b'hPa'
            assert f.variables['latitude'].units==b'degrees_north' and f.variables['longitude'].units==b'degrees_east'
            assert f.variables['time'].units==b'hours since 1900-01-01 00:00:00' and f.variables['time'].calendar==b'gregorian'
            assert all(not hasattr(f.variables[k],v) for k in a for v in ['scale_factor','add_offset'])
            for attr in ['_FillValue','missing_value']:
                fill=getattr(f.variables[component.upper()],attr,None)
                if fill is not None:assert not np.any(a[component.upper()]==fill)
        return a
    assert transport=='dods'
    header,data=body.split(b'\nData:\n',1)
    declarations=re.findall(rb'(Float32|Float64|Int32)\s+(\w+)\s*((?:\[[^\]]+\])+);',header)
    assert [(d,n) for d,n,_ in declarations]==[(b'Float32',component.upper().encode()),(b'Int32',b'time'),(b'Float64',b'level'),(b'Float64',b'latitude'),(b'Float64',b'longitude')]
    a={};offset=0
    for kind,name,dims in declarations:
        shape=[int(x) for x in re.findall(rb'=\s*(\d+)\]',dims)];n=int(np.prod(shape));dtype={b'Float32':'>f4',b'Float64':'>f8',b'Int32':'>i4'}[kind]
        assert struct.unpack_from('>II',data,offset)==(n,n);offset+=8
        a[name.decode()]=np.frombuffer(data,dtype=dtype,count=n,offset=offset).reshape(shape).copy();offset+=n*np.dtype(dtype).itemsize
    assert offset==len(data)
    return a

def main():
    parser=argparse.ArgumentParser();parser.add_argument('manifest',type=Path);parser.add_argument('--receipt',type=Path,required=True);parser.add_argument('--month',type=int,choices=range(1,13));args=parser.parse_args()
    root=args.manifest.parent;raw=args.manifest.read_bytes();m=json.loads(raw)
    assert m['schema']=='balloon.wind-samples/1' and m['provider']=='ERA5' and m['years']==[2024,2024] and m['hours_utc']==[0,6,12,18] and m['date_convention']=='UTC'
    assert m['levels']==[{'level_id':i,'level_hpa':v} for i,v in enumerate(LEVELS)]
    grid=[(iy*1440+ix,90-iy*.25,ix*.25) for iy in range(174,201) for ix in range(552,596)]
    assert [(x['cell_id'],x['lat'],x['lon']) for x in m['grid']]==grid
    lat=np.array([x[1] for x in grid]);weights=np.array([x['weight'] for x in m['grid']]);assert np.allclose(weights,np.sin(np.radians(lat+.125))-np.sin(np.radians(lat-.125)),rtol=1e-12,atol=0)
    selected=[entry for entry in m['months'] if args.month is None or entry['month']==args.month];assert selected
    records=m['provenance']['requests'];index={}
    for row in records:
        parsed=urllib.parse.urlsplit(row['url']);assert parsed.scheme=='https' and parsed.netloc=='tds.gdex.ucar.edu'
        match=re.search(r'/e5\.oper\.an\.pl\.128_(131_u|132_v)\.ll025uv\.(2024\d{4})00_(2024\d{4})23\.nc',parsed.path)
        assert match and match[2]==match[3]
        if args.month is not None and int(match[2][4:6])!=args.month:continue
        key=(match[2],match[1][-1]);assert key not in index;index[key]=row
    checks=[];count=0;by_transport={'dods':0,'ncss':0};prior_failures=set()
    for month in selected:
        mm=month['month'];days=calendar.monthrange(2024,mm)[1]
        times=[f'2024-{mm:02}-{d:02}T{h:02}:00:00Z' for d in range(1,days+1) for h in [0,6,12,18]];assert month['times_utc']==times
        for component in ['u','v']:
            item=month[component];b=(root/item['file']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
            target=np.load(io.BytesIO(b),allow_pickle=False);assert target.dtype==np.float32 and target.shape==(days*4,37,1188)
            for day in range(1,days+1):
                stamp=f'2024{mm:02}{day:02}';row=index[(stamp,component)];transport=row.get('transport','dods');by_transport[transport]+=1
                rp=root/row['receipt'];r=json.loads(rp.read_bytes());request=json.loads(rp.with_name(rp.name.replace('.receipt.json','.request.json')).read_bytes());body=rp.with_name(rp.name.replace('.receipt.json','.body')).read_bytes()
                assert r['complete'] and r['http_status']==200 and r['url']==request['url']==row['url'] and r['sha256']==row['sha256']==sha(body) and r['bytes']==row['bytes']==len(body)
                a=arrays(body,component,transport);wind=a[component.upper()];assert wind.dtype==np.dtype('>f4') and wind.shape==(4,37,27,44) and np.isfinite(wind).all() and (np.abs(wind)<9e20).all()
                expectedhours=[int((datetime.datetime(2024,mm,day,h)-datetime.datetime(1900,1,1)).total_seconds()/3600) for h in [0,6,12,18]]
                assert np.array_equal(a['time'],expectedhours) and np.array_equal(a['level'],LEVELS) and np.array_equal(a['latitude'],np.arange(46.5,39.99,-.25)) and np.array_equal(a['longitude'],np.arange(138,148.751,.25))
                assert wind.astype('<f4').tobytes()==target[(day-1)*4:day*4].astype('<f4').tobytes()
                if transport=='ncss':
                    canonical={'dataset':'d633000','dataset_path':urllib.parse.urlsplit(row['url']).path.removeprefix('/thredds/ncss/grid/'),'component':component,'date_utc':f'2024-{mm:02}-{day:02}','hours_utc':[0,6,12,18],'levels_hpa':LEVELS,'latitude':[46.5-i*.25 for i in range(27)],'longitude':[138+i*.25 for i in range(44)],'units':'m s**-1'}
                    assert row['canonical_request']==canonical and row['canonical_sha256']==sha(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode())
                    expectedquery={'var':[component.upper()],'north':['46.5'],'south':['40'],'west':['138'],'east':['148.75'],'horizStride':['1'],'time':['all'],'timeStride':['6'],'accept':['netCDF']}
                    assert urllib.parse.parse_qs(urllib.parse.urlsplit(row['url']).query)==expectedquery
                    for prior in row['prior_dods_attempts']:
                        priorpath=root/prior['receipt'];old=json.loads(priorpath.read_bytes());partial=priorpath.with_name(priorpath.name.replace('.receipt.json','.partial')).read_bytes()
                        assert not old['complete'] and old['sha256']==prior['sha256']==sha(partial) and old['bytes']==len(partial);prior_failures.add(prior['receipt'])
                count+=wind.size
            checks.append({'month':mm,'component':component,'values':target.size,'bit_equal':True,'npy_sha256':item['sha256']})
    assert len(index)==sum(calendar.monthrange(2024,x['month'])[1]*2 for x in selected)
    result={'manifest':str(args.manifest),'manifest_sha256':sha(raw),'complete_months':[x['month'] for x in m['months']],'complete_2024':sorted(x['month'] for x in m['months'])==list(range(1,13)),'validated_months':[x['month'] for x in selected],'component_responses':len(index),'float32_values_compared':count,'by_transport':by_transport,'prior_failed_dods_receipts_checked':sorted(prior_failures),'checks':checks,'scope':'separate DAP2 parser or direct scipy NetCDF3 read, exact native dtype/axes/UTC/finiteness/raw hashes and all source float32 bits against NPY; no HTTP; no reanalysis accuracy claim'}
    with args.receipt.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
if __name__=='__main__':main()
