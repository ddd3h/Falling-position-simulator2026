"""One explicitly reviewed Sep18U NCSS slot03; never resets or loops attempts."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json
import numpy as np
P=Path(__file__).parent
ROOT=P/'year2024';RESP=ROOT/'responses'
SOURCE=P/'ncss-source10/acquire_era5_climate_samples.py'
SOURCE_SHA='d4a25c52de79ef016de45929cc5f87259bab0170b60cd04d8e928ac91506b074'
CHECKER=P/'verify-mixed-ncss15.py'
CHECKER_SHA='49546f47691aa74878352b1ba291855f41543b4538fe7a3d4912b219a01270ec'
OLD={
'ncss-u-20240918-attempt01.request.json':'359334f466bda718efcee535507fa495db09b2fd97f9f89546d17af1a5080b57',
'ncss-u-20240918-attempt01.receipt.json':'22605f27d80aed4e8cee58309f23c9e2e2dc6178ed1969406c511f55039905f2',
'ncss-u-20240918-attempt01.partial':'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
'ncss-u-20240918-attempt02.request.json':'232d3636db77e343001f6b0e9ff9dd3e499cec86e099bbd9792351669643bf65',
'ncss-u-20240918-attempt02.receipt.json':'de5e0c4e3d4935cbe124e16ffb6a107806623356b4d47b8e67a848e264ada0f0',
'ncss-u-20240918-attempt02.partial':'342417f8e047698ea319b02933eb61771e623f5881e65e6446ffe236dd945d9e'}
DAY=datetime.date(2024,9,18)
DATASET='files/g/d633000/e5.oper.an.pl/202409/e5.oper.an.pl.128_131_u.ll025uv.2024091800_2024091823.nc'
STEM=RESP/'ncss-u-20240918-attempt03'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def module(name,path,digest):
 assert sha(path.read_bytes())==digest
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def check_old():
 for name,digest in OLD.items():assert sha((RESP/name).read_bytes())==digest
 assert not list(RESP.glob('ncss-u-20240918-attempt04*'))
def inspect(m):
 check_old();assert not list(RESP.glob('ncss-u-20240918-attempt03*'))
 axes=m.selection();url=m.ncss_url(DATASET,'u',axes,DAY)
 for i in [1,2]:
  r=read(RESP/f'ncss-u-20240918-attempt0{i}.receipt.json');q=read(RESP/f'ncss-u-20240918-attempt0{i}.request.json')
  assert not r['complete'] and r['url']==q['url']==url and r.get('http_status',0)<400
  assert r['cap_bytes']==5*1024*1024 and r['timeout_s']==120 and r['retries']==0
 assert max(x['month'] for x in read(ROOT/'manifest.json')['months'])==8
 return {'helper_sha256':sha(Path(__file__).read_bytes()),'source_sha256':SOURCE_SHA,'checker_sha256':CHECKER_SHA,'url':url,'canonical_request':m.canonical_request(DATASET,'u',axes,DAY),'old_originals':OLD,'new_slot':3,'new_http_calls_max':1,'cap_bytes':5*1024*1024,'timeout_s':120,'retries':0,'automatic_resume':False}
def request_one(m,url):
 # Direct single fetch: no observation loop and no hidden retry.
 return m.fetch(url,STEM,5*1024*1024,timeout=120)
def run(m):
 current=inspect(m);assert current==read(P/'sep18u-slot03-preflight22.json')
 status='failed';error=None;proof={}
 try:
  body=request_one(m,current['url'])
  y,times=m.decode_ncss(body,'u',m.selection(),DAY)
  v=module('independent_sep18',CHECKER,CHECKER_SHA);a=v.arrays(body,'u','ncss');x=a['U']
  assert x.dtype==np.dtype('>f4') and x.shape==(4,37,27,44) and np.isfinite(x).all()
  expected=[int((datetime.datetime(2024,9,18,h)-datetime.datetime(1900,1,1)).total_seconds()/3600) for h in [0,6,12,18]]
  assert np.array_equal(a['time'],expected) and np.array_equal(a['level'],v.LEVELS)
  assert np.array_equal(a['latitude'],np.arange(46.5,39.99,-.25)) and np.array_equal(a['longitude'],np.arange(138,148.751,.25))
  assert x.reshape(4,37,1188).astype('<f4').tobytes()==y.astype('<f4').tobytes()
  proof={'response_sha256':sha(body),'receipt_sha256':sha(STEM.with_suffix('.receipt.json').read_bytes()),'values':int(x.size),'native_axes_times_finite':True,'independent_vs_decoder_bit_equal':True,'monthly_npy_not_yet_checked':True};status='completed'
 except Exception as e:
  error=f'{type(e).__name__}: {e}';raise
 finally:
  check_old()
  write(P/'sep18u-slot03-result22.json',{'at':now(),'status':status,'error':error,'plan':current,'proof':proof,'old_originals_unchanged':True,'main_resume_not_started':True})
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','run']);args=parser.parse_args()
 m=module('source10_sep18',SOURCE,SOURCE_SHA)
 if args.phase=='prepare':write(P/'sep18u-slot03-preflight22.json',inspect(m));print('Prepared; no HTTP')
 else:run(m)
