# Full overlap accounting correction

Use `december-ncss16-complete-measurement02.json`. The first complete-measurement.json was generated afterrawtransfer and mistakenly counted the43 copied side receipts again as mainrequests. It is retained as a rejected calculation. No source data or acquisition receipt changed. The corrected measurement excludes the known side receipt identities from the primary directory before attributing requests to the main series.

Correct finite window:860.290s, side43 + main31 completed =74 distinctresponses,5.161responses/min,52,332,304returnedbodybytes. One mainrequest crossed the startboundary; excluding it gives73 distinctresponses/860.290s. No failures occurred in either series in thiswindow. Mainfully-contained30responses hadmean26.499s/median22.875s/max76.328s; side43mean19.913s/median11.360s/max70.843s.

The original first10measurement was generated beforetransfer and remains valid. Neither comparison is controlled for dates/servercache/load, so observed overlap is not a causal speedup or proof of stablefutureperformance. Aggregateworkerlimit remains2.
