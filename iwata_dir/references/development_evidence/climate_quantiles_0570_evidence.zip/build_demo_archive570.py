"""Fixed two-product native-cell demo; requires both complete yearly bundles."""
from pathlib import Path
import json,hashlib,zipfile,datetime,sys,zlib,os
import numpy as np
P=Path(__file__).resolve().parent;R=Path.cwd()
sys.path.insert(0,str(R));from backend.climate.samples import MonthlySamples
from tools.prepare_climate_demo import subset,extract_repository_demo
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={
 'jra3q':Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q/manifest.json'),
 'era5':Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/era5/manifest.json')}
sources={name:MonthlySamples(path) for name,path in inputs.items()}
for name,source in sources.items():
 assert source.years==[2024,2024] and set(source.months)==set(range(1,13))
 assert (source.manifest['provider'],len(source.levels),len(source.grid))==({'jra3q':('JRA-3Q',38,570),'era5':('ERA5',37,1188)}[name])
 source.assert_current()
out=P/'demo-final570';out.mkdir(exist_ok=False)
results={}
for name,path in inputs.items():
 source=sources[name]
 target=out/name
 results[name]=subset(path,target,43.2,141.4)
 demo=MonthlySamples(target/'manifest.json')
 # Independent selection check: map stable native IDs back into full source.
 ids=[c['cell_id'] for c in demo.grid];indices=[next(i for i,c in enumerate(source.grid) if c['cell_id']==ident) for ident in ids]
 assert len(indices)==4 and len(set(indices))==4
 # Independent interval selection; do not derive the expected corners from demo IDs.
 latitudes=sorted({c['lat'] for c in source.grid});longitudes=sorted({c['lon'] for c in source.grid})
 south=max(v for v in latitudes if v<=43.2);north=min(v for v in latitudes if v>43.2)
 west=max(v for v in longitudes if v<=141.4);east=min(v for v in longitudes if v>141.4)
 corners={(y,x) for y in (south,north) for x in (west,east)}
 assert {(c['lat'],c['lon']) for c in demo.grid}==corners
 assert demo.grid==[source.grid[i] for i in indices] and demo.levels==source.levels and demo.weighting==source.weighting
 assert demo.manifest['hours_utc']==source.manifest['hours_utc'] and demo.manifest['date_convention']==source.manifest['date_convention']
 checked=0
 for month in range(1,13):
  assert demo.months[month]['times']==source.months[month]['times']
  for comp in ['u','v']:
   a=np.load(source.months[month]['files'][comp],mmap_mode='r',allow_pickle=False);b=np.load(demo.months[month]['files'][comp],allow_pickle=False)
   expected=np.ascontiguousarray(a[:,:,indices])
   assert b.dtype==expected.dtype and b.shape==expected.shape and b.tobytes()==expected.tobytes()
   checked+=b.size
 source.assert_current();demo.assert_current()
 results[name].update(bit_checked_values=checked,original_native_ids=ids,source_manifest_sha256=source.bundle_sha256,subset_manifest_sha256=demo.bundle_sha256)
names={f.relative_to(out).as_posix():f for name in inputs for f in (out/name).rglob('*') if f.is_file()}
assert len(names)==50 and max(p.stat().st_size for p in names.values())<=5*1024*1024
z=out/'wind-samples.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,f in sorted(names.items()):
  info=zipfile.ZipInfo(name,(2024,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  archive.writestr(info,f.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in sorted(names.items())}
inventory={'schema':'balloon.climate-demo-package/1','scope':'Separate JRA-3Q and ERA5 four-native-cell functional samples; calendar2024 all00/06/12/18UTC; no interpolation, quantization or flight field','file':'wind-samples.zip','bytes':z.stat().st_size,'sha256':sha(z),'members':members,'provenance':results,'zip':{'ordered':True,'timestamp':'2024-01-01T00:00:00','compression':'deflate9','zlib':zlib.ZLIB_VERSION},'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'archive.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2,allow_nan=False)+'\n','utf8')
# Verify the exact future repository layout without publishing incomplete inputs.
shadow=out/'package-root';pkg=shadow/'references/climate_demo_057';pkg.mkdir(parents=True)
for name in ['wind-samples.zip','archive.json']:(pkg/name).write_bytes((out/name).read_bytes())
extracted=extract_repository_demo(shadow,out/'replay')
assert extracted['network_requests']==0
for n,v in members.items():assert sha(out/'replay'/n)==v['sha256']
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper_sha256':sha(Path(__file__)),'numpy_version':np.__version__,'results':results,'archive_bytes':inventory['bytes'],'archive_sha256':inventory['sha256'],'members':len(members),'replay':extracted,'all_member_readback_match':True,'repo_published':False,'limits':'four cells for functional replay, not a representative regional/yearly climatology or flight weather field'}
(out/'verification.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n','utf8')
print(json.dumps(record,ensure_ascii=False))

