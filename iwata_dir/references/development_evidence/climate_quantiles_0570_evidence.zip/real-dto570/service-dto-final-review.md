# 通常ClimateService・実DTOの有限検証

## 結果

完成JRA原標本2024の常設manifest（SHA 3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60）を、通常のClimateServiceへ起動設定として渡し、P570/real-dto570/raw/state の新規SQLiteへ集計・保存した。既存application stateやHTTPサーバーへは接続していない。source編集なし。正常なcreate_analysis/get_analysis経路を使い、内部結果を差し替えていない。

確認したrawケース:

- 全域570セル・全4UTC・300hPa：全12月、1,464時刻、38面。
- 同全域・UTC00のみ：366時刻、38面を保持。2月の前後半は15/14時刻。実風配も利用可能。
- 全域全UTC・500hPa：空間図/風配の対象面が変更。全高度を持つmonthly_profilesは300hPa要求と完全一致。
- 指定点周辺の元格子範囲：cell IDs 249/250/279/280、全月cell_count=4。補間や他の格子への差替えなし。

4結果とも保存GETが完全一致し、同request IDの受理済retryも一致した。archive未設定の別ClimateServiceを同じ隔離storeへ起動し、保存4結果と受理済retryを再読して一致した。元archive/旧DB input hashとadapter snapshotは実行前後で変化しなかった。入力、要求、artifact、summary、sourceなし保存GET、時間計測はservice-proof.jsonとraw/各票に固定。独立CDF少数点一致は既票jra-partial-performance.jsonを参照し、同じ全数統計の再試験には広げていない。

実測create_analysis: full300 6.97秒、UTC00 4.15秒、full500 3.33秒、4セル0.89秒。これはこの端末・実装・既にfilesystem cacheがある状態の通常保存サービス計測であり、UI応答保証ではない。

## 旧DB外部2probe

既存climate-expansion.test.tsの外部2件は、旧2016–2025集計DBの38面/時刻subset20面、固定代表点285、時刻subset風配不可を検査する専用probeだった。新rawはsubsetでも38面/風配可で代表点284のため、期待へ合わせたDTO改変をしなかった。

旧DBを別の通常ClimateServiceと新規legacy-db/stateへ起動し、全域300hPaのallUTC/UTC00を生成。legacy-db/summary-full.json、summary-hours.jsonをBALLOON_CLIMATE_SAMPLE_DIRへ渡し、当該既存testファイルを実行して25/25成功・skip0・failure0。外部2件もpassed。結果はfrontend-external-results.json、実行logはfrontend-external-run02.log。

初回はsandboxの子プロセス起動がspawn EPERMで拒否され、Vitest自体が起動しなかった（frontend-external.log）。同じ依頼済み検査を必要な実行権限で再試行して成功した。これは数値/契約の失敗ではなく、元失敗票も残してある。

## 新raw FE probeへの契約案

root担当の別probeへ渡す入力はraw/summary-full.json、summary-hours.json、summary-level500.json、summary-native-subset.json。rawは以下を実データのまま確認することが適切。

- provider/archive schemaと2024固定支持、全12月available、38面を全UTC/00で保持する。
- half/month/season projectionが24/12/4期間で、profileの全高度/共通軸/二本の半月中央値と月p10–p90帯を維持する。
- 風配は00 subsetでも利用可能。point IDを285に固定せずsource/rose metadataとの一致を見る。今回は全域代表点284。count+calm countの分母は選択UTC時刻数で、570格子数を掛けない。
- 300→500ではquery/spatial/roseの面が一致し、母集団と全高度profileを黙って変えない。
- 4セル範囲はselected IDsとsample_count/time_countの区別、代表風配点が範囲外であるmetadataの表示を守る。全域固定結果と4セル結果を同じ母集団として扱わない。
- 保存snapshotのsource/year/hour/bounds/selected pressureと表示/出力labelを一致させる。圧力や未適用の草案で固定SVGの母集団を上書きしない。

この担当では新raw FE probeを実行したとは主張しない。UI視認、HTTPルーティング、送信権、ブラウザslider非同期挙動はこのサービス検査の範囲外。

## 全域固定summaryを参考保存する案

任意の追加参考としては有用。4セルdemoだけでは地域全域の図を再現できないので、2024・570元格子・全4UTC・空間図/風配300hPaという固定条件の比較資料を残せる。ただし再計算可能な全域原標本として登録せず、固定結果の閲覧用途と4セル原標本の再集計を明確に分ける。全38高度profileは保存されるが、固定spatial/roseはqueryの300hPaであり、任意面/任意地域/UTC subsetの再計算を裏付けない。

現raw/summary-full.jsonは10,448,866 bytes、canonical compactでも6,581,657 bytes。prepare_climate_demo.pyのZIP member上限5MiBを超えるため、そのまま既存wind-samples.zipへ入れるとextractで拒否される。gzip参考量は1,328,926 bytesだが、ZIPのmember検査は展開後sizeなので普通のZIP圧縮で解決しない。

今回は必須ではないため、wind-samples.zipは4セル原標本として保ち、固定全域summaryを別添のreference artifactとして入力manifest/query/method/年月/面/結果hash/attribution付きで保存する案を推奨する。既存extractへ組み込むなら、別責務の明示仕様と限定したサイズ・path検証をrootが設計する必要がある。4セルから全域を再集計したように見せる運用は不可。

入力・保存物・結果・検査対象のhashはverification-inventory.json、サイズ票はreference-summary-size-review.json。source hashはサービスが前後snapshotを検査し、FE関係は成功後に指紋を採取した範囲である。
