"""Finite cached-file timing and independent January empirical CDF check."""
from pathlib import Path
import datetime,hashlib,json,sys,time
import numpy as np
P=Path(__file__).resolve().parent; R=Path.cwd();sys.path.insert(0,str(R))
from backend.climate.samples import MonthlySamples
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=R/'backend/climate/samples.py'; source_hash=sha(source)
manifest=Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/era5/manifest.json')
t=time.perf_counter();data=MonthlySamples(manifest);activation=time.perf_counter()-t
assert data.manifest['provider']=='ERA5' and data.years==[2024,2024] and len(data.levels)==37 and len(data.grid)==1188
assert set(data.months)==set(range(1,13))
results={};times={}
for name,levels,hours in [('all37_four_utc',data.levels,[0,6,12,18]),('all37_utc00',data.levels,[0]),('one300hpa_four_utc',[l for l in data.levels if l['level_hpa']==300],[0,6,12,18])]:
 t=time.perf_counter();results[name]=data.profiles(data.grid,levels,hours);times[name]=time.perf_counter()-t
 assert [m['month'] for m in results[name]['months'] if m['available']]==list(range(1,13))
level=next(i for i,l in enumerate(data.levels) if l['level_hpa']==300)
u=np.load(data.months[1]['files']['u'],mmap_mode='r',allow_pickle=False);v=np.load(data.months[1]['files']['v'],mmap_mode='r',allow_pickle=False)
speed=np.hypot(u[:,level,:].astype(np.float64),v[:,level,:].astype(np.float64))
weights=np.array([r['gauss_weight'] for r in data.grid]);half=15*4
def quantile(values,probability):
 flat=values.ravel();weight=np.tile(weights,len(values));order=np.argsort(flat,kind='stable')
 cdf=np.cumsum(weight[order]);cdf=cdf/cdf[-1]
 return float(flat[order[int(np.searchsorted(cdf,probability,'left'))]])
expected={'p10':quantile(speed,.1),'p90':quantile(speed,.9),'half_medians':[quantile(speed[:half],.5),quantile(speed[half:],.5)]}
actual=results['one300hpa_four_utc']['months'][0]['rows'][0]
assert all(np.array_equal(np.asarray(expected[k]),np.asarray(actual[k])) for k in expected)
data.assert_current();assert sha(source)==source_hash
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'offline full calendar2024 support, cached-file timing, independent January300hPa inverse empirical CDF; no API/network/UI','manifest_sha256':data.bundle_sha256,'samples_source_sha256':source_hash,'numpy':np.__version__,'activation_seconds':activation,'query_seconds':times,'months_available':list(range(1,13)),'independent_january_300hpa':{'expected':expected,'actual':actual,'exact_equal':True},'limits':['single cached-filesystem observation on this machine, not cold-disk or UI latency SLA','regional space-time wind distribution, not forecast uncertainty or representative ten-year climatology']}
output=P/'era5-final-performance.json'
with output.open('x',encoding='utf8') as f:f.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
