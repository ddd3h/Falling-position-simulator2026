# catalog / 旧 asset helper の有限レビュー

原 helper `check-deployment-catalog570.py` を読み、archive/samples/source/contracts の該当接点と比較した。元 helper・repo/source・runtime/state は変更せず、別名 `check-deployment-catalog570.v2.py` を作成した。主担当が採用判断するための **未実行案** であり、API/ブラウザ/process の操作はしていない。SHA、before、diff は同名 JSON と `deployment-catalog-helper-review570/` に保存した。

採用された訂正は次の 3 点。

- **支持の値を照合する**。v1 の件数一致では、同じ 570/1,188 セルや 38/37 面でも座標・重み・面値が違う反例が残る。v2 は manifest に対して順序を含む ID/lat/lon/weight と ID/hPa の全 projection、gauss_weight alias、bounds と既定一点、weighting、年/UTC/schema、12 月の全原時刻メタデータ、対応 capability を照合する。出典は manifest に存在する欄だけを明示して照合し、元配列の再検査や法的評価へ広げない。
- **静的 bytes を固定票へ束縛する**。新 JS/CSS/index は `preparation09.new_dist_files` の SHA、旧 14 件は `old-static-baseline570.json` の SHA を要求する。今回、`prep.old_root` の実物と `dist-live09` のコピーを通信なしで読み、14 件全て byte 一致を確認した。これは票に記載した観測時点の事実であり、以前のブラウザ配信や過去時点の bytes の証明ではない。
- **source_id 移行と保存 GET を分ける**。legacy の /3 identity を固定 profile+adapter+DB SHA から計算し、statistics /3 と固定点 285 を照合する。旧 /2 identity も根拠式で併記する。v1 の未実行 `old_saved_results_remain_separate_GET_artifacts=True` は削除し、保存 GET の成功は `restart-<mode>-readback01/receipt.json` へ戻す。

構文とオフライン **15/15 成功**。実 JRA manifest のメタデータから作った合成 DTO を使い、件数が同じ座標/ID/面値変更、順序変更、alias/weighting/UTC/原時刻/出典/境界/既定点/source_id の不一致を拒否し、旧 /2 を現 /3 と誤認しないことを確認した。実 API 応答や ERA 全配列の再検証ではない。

v2 は proxy/redirect を無効化した localhost GET だけを行い、応答は 64 MiB 上限、既存証拠出力を上書きしない。対象は選んだ index/CSS/JS と旧 14 hashed path で、全 scene3d/画像/font/worker や GUI 動作は対象外。公開元の原値照合・完全 archive の採否、manifest の帰属内容の正しさ、保存結果 GET、再起動 owner/health はそれぞれ既存の別票へ戻す。これらの境界で D1–D3 の欠落は改訂案に反映され、追加の source 上の阻害点は見つからなかった。実行成功はまだ主張しない。
