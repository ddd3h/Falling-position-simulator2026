from pathlib import Path
import copy,hashlib,json,sys,time,datetime
sys.path.insert(0,str(Path.cwd()))
from backend.climate.service import ClimateService
from backend.climate.contracts import ClimateQuery,Bounds
from backend.climate.source import adapter_source_snapshot

p=Path('C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570/real-dto570')
p.mkdir(parents=True,exist_ok=False)
archive=Path('C:/Users/genia/AppData/Local/SpaceBalloonSimulator/climate-archives-2024/jra3q/manifest.json')
database=Path('C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb')

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def save(path,obj):
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

snapshot=adapter_source_snapshot(); proofs=[]; inputs={'raw_manifest':{'path':str(archive),'sha256':sha(archive)},'legacy_database':{'path':str(database),'sha256':sha(database)}}
assert inputs['raw_manifest']['sha256']=='3eada6b606ec83db559795dbbf84e4adbc9f0fa7a59704d6201316822f072e60'
assert inputs['legacy_database']['sha256']=='1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a'
raw=p/'raw';raw.mkdir()
service=ClimateService(raw/'state',archive_paths=[archive]);catalog=service.sources()
assert len(catalog['sources'])==1 and catalog['errors']==[]
d=catalog['sources'][0]; save(raw/'sources.json',catalog)
ids={r['level_hpa']:r['level_id'] for r in d['levels']}
assert d['capabilities']['years_fixed']==[2024,2024] and len(d['levels'])==38
bounds=Bounds(141.375,141.75,42.892791748046875,43.267398834228516)
cases=[('full',ClimateQuery(d['source_id'],ids[300.])),('hours',ClimateQuery(d['source_id'],ids[300.],hours_utc=[0])),('level500',ClimateQuery(d['source_id'],ids[500.])),('native-subset',ClimateQuery(d['source_id'],ids[300.],bounds=bounds))]
artifacts={}; bodies={}
for name,query in cases:
 body={'client_request_id':'independent-jra-'+name,'query':query.as_dict()};bodies[name]=body
 t=time.perf_counter();a=service.create_analysis(body);elapsed=time.perf_counter()-t
 assert service.get_analysis(a['analysis_id'])==a and service.create_analysis(body)==a
 save(raw/f'artifact-{name}.json',a);save(raw/f'summary-{name}.json',a['summary']);save(raw/f'request-{name}.json',body)
 artifacts[name]=a
 proofs.append({'provider':'JRA-3Q original 2024','case':name,'seconds':elapsed,'analysis_id':a['analysis_id'],'result_hash':a['result_hash'],'saved_get_exact':True,'accepted_retry_exact':True})
full=artifacts['full']['summary'];hours=artifacts['hours']['summary'];level500=artifacts['level500']['summary'];subset=artifacts['native-subset']['summary']
assert len(full['levels'])==len(hours['levels'])==38
assert full['population']['selected_cell_count']==hours['population']['selected_cell_count']==570
assert sum(t['n_analyses_expected'] for t in full['population']['timebins'])==1464
assert sum(t['n_analyses_expected'] for t in hours['population']['timebins'])==366
assert all(m['available'] for m in full['monthly_profiles']['months'])
assert full['monthly_profiles']['population']['years_fixed']==[2024,2024]
assert hours['monthly_profiles']['months'][1]['half_time_counts']==[15,14]
assert full['wind_rose']['available'] and hours['wind_rose']['available']
assert full['monthly_profiles']==level500['monthly_profiles']
assert full['spatial']['level_id']==ids[300.] and level500['spatial']['level_id']==ids[500.]
assert full['spatial']['rows']!=level500['spatial']['rows']
assert subset['population']['selected_cell_ids']==[249,250,279,280]
assert subset['population']['selected_cell_count']==4
assert all(m['cell_count']==4 for m in subset['monthly_profiles']['months'])
assert full['source']['dataset_sha256']==inputs['raw_manifest']['sha256']
assert full['source']['capabilities']['flight_weather_field'] is False
# A source-free service must be able to read accepted immutable results and retries.
offline=ClimateService(raw/'state')
for name,a in artifacts.items():
 assert offline.get_analysis(a['analysis_id'])==a
 assert offline.create_analysis(bodies[name])==a
 save(raw/f'saved-get-offline-{name}.json',offline.get_analysis(a['analysis_id']))
proofs.append({'case':'raw-source-unconfigured-saved-read','artifacts':4,'all_exact':True,'accepted_retries_without_source':True})
legacy=p/'legacy-db';legacy.mkdir()
old=ClimateService(legacy/'state',source_path=database,expected_sha256=inputs['legacy_database']['sha256']);catalog=old.sources()
assert len(catalog['sources'])==1 and catalog['errors']==[]
d=catalog['sources'][0];save(legacy/'sources.json',catalog)
level=next(r['level_id'] for r in d['levels'] if r['level_hpa']==300.)
for name,hours_utc in [('full',None),('hours',[0])]:
 body={'client_request_id':'independent-legacy-'+name,'query':ClimateQuery(d['source_id'],level,hours_utc=hours_utc).as_dict()}
 t=time.perf_counter();a=old.create_analysis(body);elapsed=time.perf_counter()-t
 assert old.get_analysis(a['analysis_id'])==a
 save(legacy/f'artifact-{name}.json',a);save(legacy/f'summary-{name}.json',a['summary']);save(legacy/f'request-{name}.json',body)
 expected_levels=38 if name=='full' else 20
 assert len(a['summary']['levels'])==expected_levels
 if name=='full':assert a['summary']['wind_rose']['available'] and a['summary']['wind_rose']['point']['cell_id']==285
 else:assert not a['summary']['wind_rose']['available']
 assert ClimateService(legacy/'state').get_analysis(a['analysis_id'])==a
 proofs.append({'provider':'legacy JRA-3Q 2016-2025 DB','case':name,'seconds':elapsed,'analysis_id':a['analysis_id'],'result_hash':a['result_hash'],'saved_get_without_source_exact':True,'expected_levels':expected_levels})
assert sha(archive)==inputs['raw_manifest']['sha256'] and sha(database)==inputs['legacy_database']['sha256']
assert adapter_source_snapshot()==snapshot
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'actual ClimateService on new isolated SQLite stores, create/query + saved GET + no-source accepted retry; no HTTP server or existing application state touched','inputs':inputs,'adapter_snapshot':snapshot,'proofs':proofs,'raw_contract':{'years':[2024,2024],'full_levels':38,'hours_subset_levels':38,'full_time_count':1464,'utc00_time_count':366,'rose_available_with_hours_subset':True,'native_subset_cell_ids':[249,250,279,280],'pressure_only_change_retains_full_profiles':True},'prior_independent_cdf':'../jra-partial-performance.json','legacy_fe_inputs':'legacy-db/summary-full.json and summary-hours.json','source_edits':False}
save(p/'service-proof.json',result)
print(json.dumps({k:v for k,v in result.items() if k!='adapter_snapshot'},ensure_ascii=False,indent=2))
