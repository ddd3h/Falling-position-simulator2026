# 初回実気象集計のnull全域要求と固定結果の照合修復

2026-10-02。親担当が8570の新状態で旧10年DBの初回集計を操作し、POST201の後に「要求した条件と受領した集計が一致しません」と表示された。比較基準は記録C2 `98b6dad115e4ac30c03f06ff3366fc6468022b8a`。最初は読取専任で切り分け、その後親の明示割当で `frontend/src/useClimateWorkspace.ts` と `climate.test.ts`、全体回帰の失敗確認後に追加許可された `restoration.test.ts` だけを編集した。

## 原因と実票

`defaultClimateQuery` は `bounds:null`（その資料の全域）を作る。旧DB `source.py` と新raw `archive.py` はこのnullを資料のnative boundsへ解決して `summary.query` に置き、serviceはそのresolved queryを固定artifactへ保存する。serviceの受付票は元の要求queryを別に保持し、同じ要求IDの再試行は元要求との完全一致を検査する。この分離は妥当である。

frontendの受領検査だけが、hoursの正規化後に元queryとartifact.queryを文字列一致させていた。bounds:nullと明示全域が不一致となるため、計算・保存成功後もUIは採用しなかった。これは旧DBだけの問題ではなく、新rawも同じresolved応答を返すので同じ初回経路が対象である。

`state-ui01/climate.sqlite3` を `mode=ro`、`PRAGMA query_only=ON` で読んだ。analyses/requests/cacheは各1件。requestはlevel18、bounds:null。artifactのboundsは west138/east148.875/south39.89591598510742/north46.638885498046875 でdescriptorと一致し、source/level/grainは同一だった。厳密query比較はfalse、要求のnullだけdescriptorの全域へ解決するとtrue。固定artifactとsummaryのqueryも一致した。DBの前後SHA256は `9616e8e5af1b39f8b29687194d07c23d27c024bf1a0db7c8617cb229d824ff1f` で不変。取得範囲は票の件数と最初の最大5受付を上限にし、実際は1件だけを読んだ。根拠は `query-resolution570-sqlite-proof.json`。

## 修正の境界

送信直前のcatalogから該当descriptorを取り、そのboundsをdeepcopyして比較用queryを作る。要求がnullならこの捕捉した全域、明示範囲なら元の明示範囲を比較に使う。POSTするq、receipt.key、client_request_idは変更しない。返却queryのhours正規化と元来の全条件比較は保持し、返却source_id/dataset_sha256も送信時descriptorと一致させる。

応答自身のboundsを使って期待条件を作らないため、null要求へ勝手に部分領域が返る場合も拒否できる。後からcatalogオブジェクトが変化しても、先の要求の意味は変わらない。別source、別dataset、別UTC、別level、明示部分領域への全域返却も採用しない。

backendの受付票、query cache、固定artifact、保存済みquery/hashは変更していない。global normalizeClimateQueryやdefaultのbounds:nullも変更しない。既存の受領後処理により、明示集計成功後のdraftには受領したresolved queryを採用する。pressure探索の後着抑止、未適用draft保持、保存GETの識別照合も変更していない。数値計算や原データには手を入れていない。

## 反例と回帰

`climate.test.ts` に、初回null/明示全域、応答不明後の同ID・同query再試行、部分/別source/別dataset/別UTC/別level/部分領域拡大の拒否、送信後descriptor変更、後続の地域/UTC草案保持を追加した。既存の2応答mockはbounds:nullを返しており、実APIが返すresolved queryへ訂正した。

関連3ファイルは97 PASS、既存の実DBopt-in2件は省略（計99）。型検査exit0。その後親の指示による全frontend回帰の初回は373 PASS/1 FAIL/2省略（計376）。失敗は `restoration.test.ts` の新集計応答がbounds:null、descriptorのdataset_sha256も欠けていたためだった。保存草案はnullのまま、固定artifact/summary.queryはresolved全域、descriptorとartifactのsource/hashを合わせ、遅い旧GETが新固定結果を上書きしない元の試験目的を維持した。拒否条件は緩めていない。

訂正後の全frontend回帰は374 PASS/0 FAIL/2省略（計376）、型検査もexit0。省略2件は `received real summary projection (finite supplied DB)` の `summary-full.json` / `summary-hours.json` であり、今回の受領照合試験の省略ではない。前回票を上書きせず `query-resolution570-full01.json` と `full02.json` を保持した。

最初のnpm launcherはPATHに無く試験未開始だったため、導入済みlocal vitest.cmdを使用した。通常sandboxではVite設定の子プロセス起動がspawn EPERMとなり、同じ限定試験をrequire_escalated指定で再実行して成功した。自動承認拒否ではない。以降の全回帰も同じ試験環境を使った。

## 保存物と未実施

- `query-resolution570-edit-receipt.json`：変更前後hash。各sourceのbeforeとdiffも同Pへ保存。
- `query-resolution570-tests.json`：関連回帰原票。
- `query-resolution570-full01.json` / `query-resolution570-full02.json`：全体初回/訂正後。
- `query-resolution570-verification.json`：最終3path hash、読取接点、全体試験要約、frontend/srcの現hash一覧。

useClimateWorkspace最終SHA256 `19a8014f511cd6854236aaeb19633bb27f42614ce2b4ab12d0468a1ed3616054`。climate.test `0736afc2a234c9dad95d3d0fa2997ff653ee34411e7071e9fee32a32fe87e141`。restoration.test `4bb4cae7b7acb424f9ec4afa3083fb20a7b294e4a71834d1df780d15e6ae26b9`。

担当内ではAPI/ブラウザ操作、build配信、実UI再受入、Git保存を行っていない。主担当がこの版からbuildし、既存受付の再試行と初回集計の実画面を確認する。元local.gitへの操作なし。執筆・修正を兼務したため、独立切分けと修正後の自己検証を区別し、主担当のdiff/実UI確認へ引き渡す。
