# 隔離配信の設定差とhelper訂正 — 有限レビュー

**weather-sources は3件→5件で、既存3件の全field・順序と source_errors=[] は同一。** 追加は `historical-jra3q-hokkaido-2024-01-01-00-06utc` と `historical-jra3q-hokkaido-2024-07-01-00-06utc` の2件だけ。削除・既存変更は0件だった。追加2件を除き同じcompact JSONで再構成すると、元応答のbytesそのものと一致した（SHA `5c9aab459206169e322aa7435f477d33c2f0abad21d90652c80eeca1edb68011`）。後応答全体のSHAは `de8f16660a7e8215ce1e77d73174ba31dab7ff24cc6051fd9e32978dcd684d37`。

隔離にもlive用 `BALLOON_HISTORICAL_CATALOG` を設定したという主担当報告に、旧restart/resume helperの無条件設定と `application.py:200–202` の追加登録が一致する。catalog未指定なら追加登録しない実装も読んだ。これは配置設定の差として説明でき、既存3資料の変更や製品不具合を示す差ではない。process環境そのものとstale LISTEN発生は独立に観測していない。

訂正差分を読んだ。PS1は旧PID消滅後にそのPID名義の残留LISTENだけを10秒deadline/250ms間隔で待ち、別PIDなら即拒否、期限後も残れば停止する。isolatedは該当process環境変数をunset、liveは既知の元pathを使う。既存のcapture鮮度/identity/backup/runtime/state検査は維持される。Attempt01/02は証拠出力先を分け、旧失敗票を上書きしない。

post helperの変更は `--attempt` と出力suffixの2箇所だけで、逆置換すると旧本文と完全一致した。照合条件と排他的出力作成は変更していない。PowerShell構文error0、Python AST構文成功。既存weather-sources同一性の要求を緩めず、正しい配置設定へ戻してreadback02を別結果として採る方針は妥当。

この票は保存済み応答の比較とsource/diff/syntax読解だけで、API・process・port・環境の操作はしていない。訂正後readback02の全DB/保存結果保全は未確認。liveの元設定との一致、起動後owner/health、実GETは主担当の別票へ戻す。生weather-source応答・project・SQLite/backupは転載せず、同名JSONにはID/hash/件数だけを残した。
