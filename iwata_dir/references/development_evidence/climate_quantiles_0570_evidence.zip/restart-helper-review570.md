# 保全・限定再起動helperの有限レビュー

capture SHA `2137461a308a9ee91ce34711339bf22c1c1eb1cb90fc186f5b1043613cadf16a`、補強後PS1 SHA `6747bfdb577f5206179ba2e28672af4da51fb323868655a2685e917c45424201`を直接再読した。構文解析のみ成功し、helperの実行・API/SQLite接続・停止・起動はしていない。

全既存`*.sqlite3`への読取SQLite backup、WALを含む各DB整合コピー、integrity/件数/hash、固定成果物hash inventoryの分担は妥当。跨DB atomicityや成果物本体コピーとは呼んでいない。現在のregistry・weather registry・climate保存DBの命名を覆う。`flight_execution.available`の参照も正しい。

初稿PS1 `822dee…`について返した3点は、次の処置へ整理された。

- 成功保全票を同mode/port/state/instance・10分以内に限定し、全DB backup hashを照合。Stop直前にproject/runs/ensembles/weather-acquisitionsのhashも再一致させる。コメントだけの保全依存は解消した。
- Stop後は最大10秒待機し、旧process不在とport空を確認する。起動後の実listener owner・health version/instance・保存結果は主担当が別票で確認し、確認前に利用成功とはしない。wrapper PIDだけでは成功判定しない。
- 起動Pythonの存在とruntime75実体・dist新428実体のhashをStop前に確認する。参照runtime票のpathは起動先runtime04と一致し、isolatedのdist09にも必要pathが存在することを読取確認した。原標本の月数確認は別の完全年検証票の代替ではない。

**追加の阻害点は見つからない。** ただし利用者の新しい保存やclimate集計をジョブ一覧だけで排他できない。captureから停止まで新規書込みを始めない管理下の区間と、主担当の起動後読戻しを前提にする。強制停止を正常終了の証拠や跨DB atomicityへ読み替えない。registry backup内instanceの別照合まではコードにないこと、固定成果物は本体コピーでないこともJSON票へ限界として残した。

初稿票を書き出す際のSHA固定検査が主担当の並行修正を検出したため、誤版の票は保存されなかった。今回票は補強版を再読した結果であり、初稿helperの物理copyを事前保存したとは記さない。新helper/hash/採否・実行していない範囲は同名JSONに記録。source/helper/runbook/状態は編集していない。
