"""Offline-only finite counterexamples. Does not invoke either helper main/API/process."""
from pathlib import Path
import ast
import hashlib
import io
import json
import runpy
import sqlite3
import sys
import time
import unittest
import uuid

P = Path(__file__).resolve().parent
TARGET = P / 'check-after-restart570.v2.py'
N = runpy.run_path(str(TARGET), run_name='offline_definitions_only')
G = N['record_saved'].__globals__
RUN = sys.argv[1] if len(sys.argv) == 2 else ''
if RUN and (not RUN.isascii() or not RUN.isdigit()):
    raise RuntimeError('Optional run suffix must be ASCII digits')
F = P / ('post-restart-v2-offline570' + RUN)
F.mkdir(exist_ok=False)
ID = lambda n: str(uuid.UUID(int=n))


def mem(rows=(('one', 1),)):
    con = sqlite3.connect(':memory:')
    con.execute('CREATE TABLE t(name TEXT, value)')
    con.executemany('INSERT INTO t VALUES (?,?)', rows)
    con.commit()
    return con


class FiniteReview(unittest.TestCase):
    def test_syntax_both_and_no_main_execution(self):
        for name in ['capture-before-restart570.v2.py', 'check-after-restart570.v2.py']:
            ast.parse((P / name).read_text(encoding='utf8'))

    def test_row_order_ignored(self):
        a, b = mem([('a', 1), ('b', 2)]), mem([('b', 2), ('a', 1)])
        self.assertEqual(N['database_logical'](a), N['database_logical'](b))
        a.close(); b.close()

    def test_duplicate_rows_not_dropped(self):
        a, b = mem([('a', 1)]), mem([('a', 1), ('a', 1)])
        self.assertNotEqual(N['database_logical'](a), N['database_logical'](b))
        a.close(); b.close()

    def test_types_remain_distinct(self):
        representations = [N['typed'](x) for x in [None, 1, 1.0, '1', b'1']]
        self.assertEqual(len(set(map(str, representations))), 5)
        a, b = mem([('a', '1')]), mem([('a', b'1')])
        self.assertNotEqual(N['database_logical'](a), N['database_logical'](b))
        a.close(); b.close()

    def test_manifest_hash_only_change_detected(self):
        con = sqlite3.connect(':memory:')
        con.execute('CREATE TABLE runs(id TEXT,manifest_hash TEXT)')
        con.execute('INSERT INTO runs VALUES (?,?)', (ID(1), 'original'))
        con.commit()
        old = N['database_logical'](con)
        con.execute('UPDATE runs SET manifest_hash=?', ('corrupt',)); con.commit()
        self.assertNotEqual(old, N['database_logical'](con)); con.close()

    def test_climate_integrity_column_change_detected(self):
        con = sqlite3.connect(':memory:')
        con.execute('CREATE TABLE climate_analyses(analysis_id TEXT,artifact_json TEXT,artifact_sha256 TEXT)')
        con.execute('INSERT INTO climate_analyses VALUES (?,?,?)', (ID(2), '{"fixed":true}', 'correct'))
        con.commit()
        old = N['database_logical'](con)
        old_json = con.execute('SELECT analysis_id,artifact_json FROM climate_analyses').fetchall()
        con.execute('UPDATE climate_analyses SET artifact_sha256=?', ('corrupt',)); con.commit()
        self.assertEqual(old_json, con.execute('SELECT analysis_id,artifact_json FROM climate_analyses').fetchall())
        self.assertNotEqual(old, N['database_logical'](con)); con.close()

    def test_column_schema_change_detected(self):
        con = mem(); old = N['database_logical'](con)
        con.execute('ALTER TABLE t ADD COLUMN extra TEXT'); con.commit()
        self.assertNotEqual(old, N['database_logical'](con)); con.close()

    def test_user_version_change_detected(self):
        con = mem(); old = N['database_logical'](con)
        con.execute('PRAGMA user_version=2'); con.commit()
        self.assertNotEqual(old, N['database_logical'](con)); con.close()

    def test_readonly_cannot_insert(self):
        path = F / 'readonly.sqlite3'
        con = sqlite3.connect(path); con.execute('CREATE TABLE t(a)'); con.commit(); con.close()
        con = N['readonly'](path)
        with self.assertRaises(sqlite3.OperationalError): con.execute('INSERT INTO t VALUES (1)')
        con.close()

    def test_catalog_includes_all_completed_runs(self):
        root = F / 'catalog'; root.mkdir()
        con = sqlite3.connect(root / 'registry.sqlite3')
        con.executescript('CREATE TABLE runs(id TEXT,result_path TEXT,spec TEXT); CREATE TABLE jobs(run_id TEXT,state TEXT); CREATE TABLE ensemble_plans(id TEXT); CREATE TABLE ensemble_snapshots(id TEXT); CREATE TABLE ensemble_analyses(id TEXT);')
        for i, kind in [(10, 'single_run'), (11, 'ensemble_trial')]:
            con.execute('INSERT INTO runs VALUES (?,?,?)', (ID(i), 'result', kind))
            con.execute('INSERT INTO jobs VALUES (?,?)', (ID(i), 'completed'))
        con.commit(); con.close()
        catalog = N['saved_catalog'](root)
        self.assertEqual(sum(kind == 'run-result' for kind in catalog.values()), 2)
        self.assertIn('/api/v1/runs/' + ID(11) + '/result', catalog)
        con = sqlite3.connect(root / 'registry.sqlite3')
        con.execute('UPDATE runs SET result_path=NULL WHERE id=?', (ID(11),)); con.commit(); con.close()
        with self.assertRaisesRegex(RuntimeError, 'Completed run'): N['saved_catalog'](root)

    def test_snapshot_available_trials_only_and_bad_id_rejected(self):
        endpoint = '/api/v1/ensemble-snapshots/' + ID(20)
        doc = {'schema': 'balloon.ensemble.snapshot/1', 'snapshot_id': ID(20), 'cases': [{'trials': [
            {'trial_id': ID(21), 'result_available': True}, {'trial_id': ID(22), 'result_available': False}]}]}
        self.assertEqual(len(N['snapshot_trial_endpoints'](endpoint, doc)), 1)
        doc['cases'][0]['trials'][0]['trial_id'] = '../escape'
        with self.assertRaises((RuntimeError, ValueError)): N['snapshot_trial_endpoints'](endpoint, doc)

    def test_get_json_key_order_only_is_reported_not_failure(self):
        endpoint = '/api/v1/runs/' + ID(30)
        catalog = {endpoint: 'run-detail'}
        original = G['local_get']
        try:
            G['local_get'] = lambda port, path: b'{"a":1,"b":2}'
            before = N['record_saved'](0, F / 'order-before', catalog)
            G['local_get'] = lambda port, path: b'{"b":2,"a":1}'
            after = N['record_saved'](0, F / 'order-after', catalog, before)
            self.assertFalse(after[endpoint]['same_raw_bytes'])
        finally: G['local_get'] = original

    def test_changed_saved_result_rejected(self):
        endpoint = '/api/v1/runs/' + ID(31) + '/result'
        catalog = {endpoint: 'run-result'}
        original = G['local_get']
        try:
            G['local_get'] = lambda port, path: b'{"value":1}'
            before = N['record_saved'](0, F / 'result-before', catalog)
            G['local_get'] = lambda port, path: b'{"value":2}'
            with self.assertRaisesRegex(RuntimeError, 'semantic content changed'):
                N['record_saved'](0, F / 'result-after', catalog, before)
        finally: G['local_get'] = original

    def test_snapshot_dynamic_trial_get_called(self):
        endpoint = '/api/v1/ensemble-snapshots/' + ID(40)
        doc = {'schema': 'balloon.ensemble.snapshot/1', 'snapshot_id': ID(40), 'cases': [{'trials': [
            {'trial_id': ID(41), 'result_available': True}]}]}
        calls = []
        original = G['local_get']
        try:
            def fake(port, path):
                calls.append(path)
                return json.dumps(doc if path == endpoint else {'result': 'fixed'}).encode()
            G['local_get'] = fake
            records = N['record_saved'](0, F / 'snapshot-read', {endpoint: 'ensemble-snapshot'})
            self.assertEqual(len(records), 2)
            self.assertEqual(calls[1], endpoint + '/trials/' + ID(41) + '/result')
        finally: G['local_get'] = original

    def test_parent_path_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'Unsafe relative path'):
            N['safe_file'](F, '../outside.json')

    def test_local_get_disables_proxies_without_real_io(self):
        request = G['urllib'].request
        original = request.build_opener
        seen = []
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def geturl(self): return 'http://127.0.0.1:8570/test'
            def read(self, count): return b'{}'
        class Opener:
            def open(self, url, timeout):
                seen.append((url, timeout))
                return Response()
        try:
            def build(*handlers):
                self.assertIsInstance(handlers[0], request.ProxyHandler)
                self.assertEqual(handlers[0].proxies, {})
                self.assertIsNone(handlers[1].redirect_request(None, None, None, None, None, None))
                return Opener()
            request.build_opener = build
            self.assertEqual(N['local_get'](8570, '/test'), b'{}')
            self.assertEqual(seen, [('http://127.0.0.1:8570/test', 30)])
        finally: request.build_opener = original


if __name__ == '__main__':
    started = time.monotonic()
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FiniteReview))
    log = stream.getvalue()
    with (P / ('post-restart-v2-offline-tests570' + RUN + '.log')).open('x', encoding='utf8') as f: f.write(log)
    receipt = {'scope': 'Offline synthetic/in-memory SQLite and mocked GET only; helper main, live state, API and processes were never invoked.',
               'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
               'elapsed_seconds': round(time.monotonic() - started, 6),
               'inputs': {name: hashlib.sha256((P / name).read_bytes()).hexdigest() for name in ['capture-before-restart570.v2.py', 'check-after-restart570.v2.py', 'post-restart-v2-offline-tests570.py']}}
    with (P / ('post-restart-v2-offline-tests570' + RUN + '.json')).open('x', encoding='utf8') as f: json.dump(receipt, f, indent=2)
    print(log)
    print(json.dumps(receipt))
    raise SystemExit(0 if result.wasSuccessful() else 1)
