"""Unexecuted V2 proposal. Source/readback review only; parent must approve before use."""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import json
import math
import sqlite3
import time
import urllib.parse
import urllib.request
import uuid

MAX_GET_BYTES = 64 * 1024 * 1024
MAX_SAVED_GETS = 4096
MAX_TABLE_ROWS = 250000
ENDPOINTS = ('health', 'project', 'runs', 'ensembles', 'weather-acquisitions', 'weather-sources', 'climate-sources')
UNCHANGED_ENDPOINTS = ('project', 'runs', 'ensembles', 'weather-acquisitions', 'weather-sources')
ACTIVE = {'queued', 'running', 'cancelling', 'acquiring'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf8')


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def dump_new(path, value):
    with Path(path).open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def safe_file(root, relative):
    require(isinstance(relative, str) and '\\' not in relative, 'Invalid relative path')
    parts = PurePosixPath(relative).parts
    require(parts and not PurePosixPath(relative).is_absolute() and all(p not in ('', '.', '..') and ':' not in p for p in parts), 'Unsafe relative path')
    candidate = Path(root).joinpath(*parts)
    require(candidate.resolve().is_relative_to(Path(root).resolve()), 'Path escaped root')
    current = candidate
    while current != Path(root):
        require(not current.is_symlink() and not (hasattr(current, 'is_junction') and current.is_junction()), 'Linked file or directory')
        current = current.parent
    require(candidate.is_file(), 'Missing regular file: ' + relative)
    return candidate


def sqlite_paths(state):
    return {p.relative_to(state).as_posix(): safe_file(state, p.relative_to(state).as_posix())
            for p in sorted(state.rglob('*.sqlite3'))}


def readonly(path):
    require(Path(path).is_file(), 'SQLite input does not exist')
    connection = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)
    connection.execute('PRAGMA query_only=ON')
    return connection


def typed(value):
    if value is None:
        return ['null']
    if isinstance(value, int):
        return ['integer', str(value)]
    if isinstance(value, float):
        require(math.isfinite(value), 'Nonfinite SQLite real')
        return ['real', value.hex()]
    if isinstance(value, str):
        return ['text', value]
    if isinstance(value, bytes):
        return ['blob', value.hex()]
    raise RuntimeError('Unsupported SQLite value type')


def database_logical(connection):
    # Transaction gives one database a stable read view; never implies cross-DB atomicity.
    connection.execute('BEGIN')
    try:
        require(connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'SQLite integrity check failed')
        schema = connection.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
        tables = {}
        for kind, name, _, _ in schema:
            if kind != 'table':
                continue
            quoted = '"' + name.replace('"', '""') + '"'
            columns = connection.execute('PRAGMA table_xinfo(' + quoted + ')').fetchall()
            row_hashes = []
            for row in connection.execute('SELECT * FROM ' + quoted):
                row_hashes.append(sha(canonical([typed(value) for value in row])))
                require(len(row_hashes) <= MAX_TABLE_ROWS, 'Table exceeds bounded review cap')
            # Sort hashes, keeping duplicates. Row order does not represent stored semantics.
            row_hashes.sort()
            tables[name] = {'columns': columns, 'rows': len(row_hashes), 'rows_sha256': sha(canonical(row_hashes))}
        value = {'schema_sha256': sha(canonical(schema)), 'tables': tables,
                 'user_version': connection.execute('PRAGMA user_version').fetchone()[0],
                 'application_id': connection.execute('PRAGMA application_id').fetchone()[0]}
        return json.loads(canonical(value))
    finally:
        connection.rollback()


def logical_path(path):
    con = readonly(path)
    try:
        return database_logical(con)
    finally:
        con.close()


def compare_databases(state, backups_root, backups):
    paths = sqlite_paths(state)
    require(set(paths) == set(backups), 'SQLite inventory changed')
    records = {}
    for relative, expected in backups.items():
        backup = safe_file(backups_root, relative)
        require(backup.stat().st_size == expected['bytes'] and file_hash(backup) == expected['sha256'], 'Captured backup changed: ' + relative)
        old = logical_path(backup)
        new = logical_path(paths[relative])
        require(new == old, 'SQLite logical content changed: ' + relative)
        records[relative] = {'logical_sha256': sha(canonical(old)), 'tables': old['tables'], 'schema_sha256': old['schema_sha256']}
    return records


def fixed_inventory(state):
    found = {}
    for path in sorted(state.rglob('*')):
        if not path.is_file() or '.sqlite3' in path.name or path.suffix == '.lock':
            continue
        relative = path.relative_to(state).as_posix()
        path = safe_file(state, relative)
        found[relative] = {'bytes': path.stat().st_size, 'sha256': file_hash(path)}
    return found


def compare_fixed(state, expected):
    # Exact inventory catches unexpected newly published artifacts as well as missing/changed ones.
    require(fixed_inventory(state) == expected, 'Fixed-file inventory/content changed')


def local_get(port, endpoint):
    require(endpoint.startswith('/') and not endpoint.startswith('//') and '#' not in endpoint, 'Invalid local GET path')
    url = 'http://127.0.0.1:' + str(port) + endpoint
    # Fail redirects rather than accidentally following an external endpoint.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    with urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect()).open(url, timeout=30) as response:
        require(response.status == 200 and response.geturl() == url, 'Unexpected GET response')
        raw = response.read(MAX_GET_BYTES + 1)
        require(len(raw) <= MAX_GET_BYTES, 'GET body exceeds bounded review cap')
        return raw


def identifier(value):
    require(isinstance(value, str) and str(uuid.UUID(value)) == value, 'Noncanonical saved UUID')
    return value


def saved_catalog(backups_root):
    catalog = {}
    def add(endpoint, kind):
        require(endpoint not in catalog, 'Duplicate catalog endpoint')
        catalog[endpoint] = kind
    con = readonly(safe_file(backups_root, 'registry.sqlite3'))
    try:
        con.execute('BEGIN')
        runs = con.execute('SELECT r.id,j.state,r.result_path FROM runs r JOIN jobs j ON r.id=j.run_id ORDER BY r.id').fetchall()
        require(len(runs) == con.execute('SELECT COUNT(*) FROM runs').fetchone()[0], 'Orphan run without job')
        for key, status, result_path in runs:
            require(status not in ACTIVE, 'Active run in captured registry')
            key = identifier(key)
            add('/api/v1/runs/' + key, 'run-detail')
            if status == 'completed':
                require(bool(result_path), 'Completed run has no committed result')
                add('/api/v1/runs/' + key + '/result', 'run-result')
        for table, route, kind in [('ensemble_plans', 'ensemble-plans', 'ensemble-plan'),
                                    ('ensemble_snapshots', 'ensemble-snapshots', 'ensemble-snapshot'),
                                    ('ensemble_analyses', 'ensemble-analyses', 'ensemble-analysis')]:
            for (key,) in con.execute('SELECT id FROM ' + table + ' ORDER BY id'):
                add('/api/v1/' + route + '/' + identifier(key), kind)
    finally:
        con.close()
    climate = backups_root / 'climate.sqlite3'
    if climate.is_file():
        con = readonly(climate)
        try:
            for (key,) in con.execute('SELECT analysis_id FROM climate_analyses ORDER BY analysis_id'):
                add('/api/v1/climate-analyses/' + identifier(key), 'climate-analysis')
        finally:
            con.close()
    require(len(catalog) <= MAX_SAVED_GETS, 'Saved GET catalog exceeds review cap')
    return catalog


def snapshot_trial_endpoints(endpoint, document):
    result = {}
    require(document['schema'] == 'balloon.ensemble.snapshot/1', 'Unexpected saved snapshot schema')
    require(endpoint.endswith('/' + identifier(document['snapshot_id'])), 'Snapshot identity mismatch')
    for case in document['cases']:
        for trial in case['trials']:
            if trial['result_available']:
                trial_id = identifier(trial['trial_id'])
                path = endpoint + '/trials/' + trial_id + '/result'
                require(path not in result, 'Repeated snapshot trial identity')
                result[path] = 'snapshot-trial-result'
    return result


def record_saved(port, destination, catalog, baseline=None):
    destination.mkdir(exist_ok=False)
    queue = list(sorted(catalog.items()))
    known = dict(catalog)
    records = {}
    cursor = 0
    while cursor < len(queue):
        endpoint, kind = queue[cursor]
        started = time.monotonic()
        raw = local_get(port, endpoint)
        document = json.loads(raw)
        file = f'{cursor:04d}.json'
        with (destination / file).open('xb') as stream:
            stream.write(raw)
        record = {'kind': kind, 'file': 'saved-get/' + file, 'bytes': len(raw), 'sha256': sha(raw),
                  'json_sha256': sha(canonical(document)), 'elapsed_seconds': round(time.monotonic() - started, 6)}
        if baseline is not None:
            require(endpoint in baseline and kind == baseline[endpoint]['kind'], 'Unexpected saved GET endpoint')
            require(record['json_sha256'] == baseline[endpoint]['json_sha256'], 'Saved GET semantic content changed: ' + endpoint)
            record['same_raw_bytes'] = record['sha256'] == baseline[endpoint]['sha256']
        records[endpoint] = record
        if kind == 'ensemble-snapshot':
            for path, trial_kind in sorted(snapshot_trial_endpoints(endpoint, document).items()):
                require(path not in known, 'Duplicate derived GET')
                known[path] = trial_kind
                queue.append((path, trial_kind))
        require(len(queue) <= MAX_SAVED_GETS, 'Saved GET catalog exceeds review cap')
        cursor += 1
    if baseline is not None:
        require(set(records) == set(baseline), 'Saved GET endpoint inventory changed')
    return records


def capture_endpoints(port, out):
    records, values, raws = {}, {}, {}
    for name in ENDPOINTS:
        raw = local_get(port, '/api/v1/' + name)
        with (out / (name + '.json')).open('xb') as stream:
            stream.write(raw)
        values[name] = json.loads(raw)
        raws[name] = raw
        records[name] = {'bytes': len(raw), 'sha256': sha(raw)}
    health = values['health']
    require(health['status'] == 'ok' and health['flight_execution']['available'] and not health['flight_execution']['restart_required'], 'Flight service is unavailable')
    records['health'].update(instance_id=health['instance_id'], version=health['version'])
    for name, key in [('runs', 'runs'), ('ensembles', 'ensembles'), ('weather-acquisitions', 'acquisitions')]:
        require(not any(x['state'] in ACTIVE for x in values[name][key]), 'Active work at capture/readback')
        records[name]['count'] = len(values[name][key])
    return records, values, raws


def quiet_endpoints(port, raws):
    for name in UNCHANGED_ENDPOINTS:
        require(local_get(port, '/api/v1/' + name) == raws[name], 'Concurrent endpoint change: ' + name)


def paths_for(mode):
    root = Path(__file__).resolve().parent
    state = root / 'state-ui01' if mode == 'isolated' else root.parent / 'balloon-seasonal-550/state-review550'
    port = 8570 if mode == 'isolated' else 8550
    return root, state, port


def main():
    parser = argparse.ArgumentParser(description='Readonly local preservation readback after an explicit restart.')
    parser.add_argument('--mode', choices=['isolated', 'live'], required=True)
    args = parser.parse_args()
    started = time.monotonic()
    root, state, port = paths_for(args.mode)
    pre = root / ('restart-' + args.mode + '-preflight02')
    before = json.loads((pre / 'receipt.json').read_bytes())
    require(before['schema'] == 'balloon.local-preservation-capture/2', 'V2 capture is required')
    require(before['mode'] == args.mode and before['port'] == port and Path(before['source_state']).resolve() == state.resolve(), 'Capture mode/port/state mismatch')
    require(file_hash(pre / 'fixed-files.json') == before['fixed_files_inventory_sha256'], 'Fixed inventory changed')
    require(file_hash(pre / 'saved-get.json') == before['saved_get_inventory_sha256'], 'Saved GET inventory changed')
    fixed = json.loads((pre / 'fixed-files.json').read_bytes())
    saved_before = json.loads((pre / 'saved-get.json').read_bytes())
    require(len(fixed) == before['fixed_file_count'] and len(saved_before) == before['saved_get_count'], 'Capture inventory count mismatch')
    for record in saved_before.values():
        path = safe_file(pre, record['file'])
        require(path.stat().st_size == record['bytes'] and file_hash(path) == record['sha256'], 'Captured GET body changed')
        require(sha(canonical(json.loads(path.read_bytes()))) == record['json_sha256'], 'Captured GET JSON hash mismatch')
    logical = compare_databases(state, pre / 'sqlite', before['sqlite_backups'])
    require(logical == before['sqlite_logical'], 'Capture logical fingerprint mismatch')
    compare_fixed(state, fixed)
    out = root / ('restart-' + args.mode + '-readback01')
    out.mkdir(exist_ok=False)
    records, values, raws = capture_endpoints(port, out)
    require(records['health']['version'] == '0.57.0' and records['health']['instance_id'] == before['endpoints']['health']['instance_id'], 'Version or service identity mismatch')
    for name in ENDPOINTS:
        records[name]['same_as_capture'] = records[name]['sha256'] == before['endpoints'][name]['sha256']
        if name in UNCHANGED_ENDPOINTS:
            require(records[name]['same_as_capture'], 'Existing endpoint changed: ' + name)
    # Full identity/attribution acceptance of newly registered archives belongs to the separate archive/UI receipt.
    catalog = values['climate-sources']
    require(not catalog['errors'] and len(catalog['sources']) == 3, 'Expected three error-free climate sources')
    records['climate-sources']['source_ids'] = [row['source_id'] for row in catalog['sources']]
    old_catalog = json.loads((pre / 'climate-sources.json').read_bytes())
    require(sha((pre / 'climate-sources.json').read_bytes()) == before['endpoints']['climate-sources']['sha256'], 'Captured source catalog changed')
    old_ids = {row['source_id'] for row in old_catalog['sources']}
    new_ids = set(records['climate-sources']['source_ids'])
    records['climate-sources']['added_source_ids'] = sorted(new_ids - old_ids)
    records['climate-sources']['removed_source_ids'] = sorted(old_ids - new_ids)
    records['climate-sources']['identity_transition_scope'] = 'Catalog identity may change with the adopted adapter version. Expected manifest/profile/adapter matching is a separate parent receipt; saved artifacts must still pass all fixed GET readbacks below.'
    saved = record_saved(port, out / 'saved-get', saved_catalog(pre / 'sqlite'), baseline=saved_before)
    dump_new(out / 'saved-get.json', saved)
    project = values['project']['project']
    applied = project.get('ui_state', {}).get('weather_real', {}).get('applied')
    if applied and applied.get('analysis_id'):
        endpoint = '/api/v1/climate-analyses/' + identifier(applied['analysis_id'])
        require(endpoint in saved, 'Applied climate artifact was not captured/read back')
        artifact = json.loads(safe_file(out, saved[endpoint]['file']).read_bytes())
        require(artifact['analysis_id'] == applied['analysis_id'] and artifact['result_hash'] == applied['result_hash'], 'Applied climate identity/result mismatch')
    index = local_get(port, '/')
    require(index == (root / 'dist09/index.html').read_bytes(), 'Served index differs from prepared index')
    # Guard against writes during the potentially large finite saved-result pass.
    require(compare_databases(state, pre / 'sqlite', before['sqlite_backups']) == logical, 'Database changed during readback')
    compare_fixed(state, fixed)
    quiet_endpoints(port, raws)
    elapsed = round(time.monotonic() - started, 6)
    kinds = {kind: sum(row['kind'] == kind for row in saved.values()) for kind in sorted({row['kind'] for row in saved.values()})}
    receipt = {'schema': 'balloon.local-preservation-readback/2', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'helper_sha256': file_hash(Path(__file__)), 'capture_receipt_sha256': file_hash(pre / 'receipt.json'),
               'mode': args.mode, 'endpoints': records, 'sqlite_logical': logical,
               'fixed_files_unchanged': len(fixed), 'saved_get_count': len(saved), 'saved_get_kinds': kinds,
               'saved_get_inventory_sha256': file_hash(out / 'saved-get.json'),
               'all_saved_get_semantics_unchanged': True, 'all_saved_get_raw_bytes_unchanged': all(row['same_raw_bytes'] for row in saved.values()),
               'served_index_sha256': sha(index), 'elapsed_seconds': elapsed,
               'limits': 'Readonly localhost/API/files/SQLite logical comparison. Raw project and saved-result responses stay local. Not cross-database atomicity, UI/scientific acceptance, new flight execution, Google reconnection or proof of all old lazy asset URLs. New archive exact identity/attribution and process owner are checked separately; no recovery/reset occurs.'}
    dump_new(out / 'receipt.json', receipt)
    print(json.dumps({'mode': args.mode, 'same_project_and_job_lists': True, 'sqlite_count': len(logical),
                      'saved_get_count': len(saved), 'saved_get_kinds': kinds, 'fixed_files': len(fixed), 'elapsed_seconds': elapsed}))


if __name__ == '__main__':
    main()
