"""Independent finite review fixture; never modifies repository or real archives."""
from pathlib import Path
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
from copy import deepcopy
import hashlib, json, math, sys, traceback, time
import numpy as np

R = Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
P = Path(r'C:/Users/genia/AppData/Local/Temp/balloon-climate-quantiles570')
sys.path[:0] = [str(R), str(R/'backend/tests')]
from backend.climate.archive import WindArchiveSource
from backend.climate.samples import MonthlySamples
from backend.climate.service import ClimateService
from backend.climate.contracts import ClimateError, ClimateQuery, Bounds

OUT = P/'independent-archive-fixtures'/str(time.time_ns())
OUT.mkdir(parents=True)
FILES = ['backend/climate/'+p for p in ('archive.py','samples.py','source.py','service.py','periods.py','statistics.py','contracts.py')] + ['backend/application.py','backend/tests/test_climate_archive.py','backend/tests/test_climate_samples.py']
def hashes(): return {p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in FILES}
before = hashes()
checks = []
def check(name, fn):
    t = time.monotonic()
    try:
        detail = fn()
        checks.append({'name':name,'status':'PASS','details':detail,'seconds':time.monotonic()-t})
    except Exception as e:
        checks.append({'name':name,'status':'FAIL','error':type(e).__name__+': '+str(e),'traceback':traceback.format_exc(),'seconds':time.monotonic()-t})
def require(x, why):
    if not x: raise AssertionError(why)
def close(a,b): require(math.isclose(a,b,rel_tol=1e-13,abs_tol=1e-12),f'{a} != {b}')
def error(fn, code=None):
    try: fn()
    except ClimateError as e:
        require(code is None or e.code==code, f'expected {code}, got {e.code}')
        return e.code
    raise AssertionError('accepted unsupported input')
def times():
    d=datetime(2024,1,1,tzinfo=timezone.utc)
    while d.year==2024:
        yield d
        d+=timedelta(hours=6)
calendar = {m:[d for d in times() if d.month==m] for m in range(1,13)}
GRID=[{'cell_id':101,'lat':35.,'lon':138.,'weight':1.}, {'cell_id':13,'lat':36.,'lon':139.,'weight':3.}, {'cell_id':9,'lat':37.,'lon':140.,'weight':2.}]
LEVELS=[{'level_id':8,'level_hpa':1000.},{'level_id':51,'level_hpa':1.}]
vectors=[(0,0),(0,-5),(-10,0),(0,20),(30,0),(3,4),(-50,0),(0,-1)]
def vector(d, li, ci):
    if ci==0: return (d.month*3+d.day+d.hour//6,(li+1)*2)
    if ci==1: return vectors[(d.day+d.hour//6+d.month+li)%len(vectors)]
    return ((d.day%5)*7+d.month,d.hour+li)
def fixture(label, provider='ERA5'):
    root=OUT/label;root.mkdir(exist_ok=True)
    manifest={'schema':'balloon.wind-samples/1','provider':provider,'label':provider+' independent synthetic 2024',
        'years':[2024,2024],'date_convention':'UTC','hours_utc':[0,6,12,18],
        'weighting':'spherical-area-equal-times' if provider=='ERA5' else 'gaussian-area-equal-times',
        'grid':deepcopy(GRID),'levels':deepcopy(LEVELS),'months':[],
        'provenance':{'dataset_url':'https://example.invalid/independent-fixture','citation':'synthetic, not real weather'}}
    for m, dates in calendar.items():
        uv=np.array([[[vector(d,li,ci) for ci in range(3)] for li in range(2)] for d in dates],dtype='float32')
        item={'month':m,'times_utc':[d.strftime('%Y-%m-%dT%H:%M:%SZ') for d in dates]}
        for k,c in [('u',0),('v',1)]:
            f=root/f'{m:02d}-{k}.npy';np.save(f,uv[:,:,:,c],allow_pickle=False)
            item[k]={'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
        manifest['months'].append(item)
    path=root/'manifest.json';path.write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True),encoding='utf8')
    return path,manifest
def cdf(pairs,q):
    # Integer frequency expansion: independent of numpy weighted quantile.
    expanded=sorted(v for v,w in pairs for _ in range(int(w)))
    return expanded[math.ceil(q*len(expanded))-1]
path, manifest=fixture('era')
source=WindArchiveSource(path)
def numeric():
    details=[]
    for hours, cis, bounds in [(None,[0,1,2],None),([6,18],[1,2],Bounds(139,140,35,37)),([0],[2],Bounds(140,140,37,37))]:
        a=source.query(ClimateQuery(source.source_id,51,bounds,hours_utc=hours))
        hs=hours or [0,6,12,18]
        maxdiff=0.
        for m in range(1,13):
            ds=[d for d in calendar[m] if d.hour in hs]
            item=a['monthly_profiles']['months'][m-1]
            require(item['time_count']==len(ds),'wrong UTC count')
            require(item['half_time_counts']==[sum(d.day<=15 for d in ds),sum(d.day>15 for d in ds)],'wrong half support')
            require(item['sample_count']==len(ds)*len(cis),'wrong grid-time count')
            for li,level in enumerate(LEVELS):
                row=next(r for r in item['rows'] if r['level_id']==level['level_id'])
                pairs=[(math.hypot(*vector(d,li,ci)),GRID[ci]['weight']) for d in ds for ci in cis]
                for key,q in [('p10',.1),('p90',.9)]:
                    wanted=cdf(pairs,q);close(row[key],wanted);maxdiff=max(maxdiff,abs(row[key]-wanted))
                for half in range(2):
                    wanted=cdf([(math.hypot(*vector(d,li,ci)),GRID[ci]['weight']) for d in ds if (d.day<=15)==(half==0) for ci in cis],.5)
                    close(row['half_medians'][half],wanted)
                got=next(r for r in a['summaries_by_grain']['month']['annual'] if r['timebin_id']==m-1 and r['level_id']==level['level_id'])
                for key,index in [('mean_u',0),('mean_v',1),('mean_speed',None)]:
                    wanted=math.fsum((math.hypot(*vector(d,li,ci)) if index is None else vector(d,li,ci)[index])*GRID[ci]['weight'] for d in ds for ci in cis)/(len(ds)*sum(GRID[ci]['weight'] for ci in cis))
                    close(got[key],wanted)
        winter=a['summaries_by_grain']['season']['annual'][0]
        require(winter['time_count']==91*len(hs),'DJF leap support')
        require(a['population']['selected_cell_ids']==[GRID[i]['cell_id'] for i in cis],'noncontiguous cell identity')
        details.append({'hours':hs,'cells':cis,'months':12,'levels':2,'maximum_quantile_difference':maxdiff})
    return details
check('original-grid-time-weighted-month-quantiles-half-medians-and-moments',numeric)
def roses():
    checked=0
    for hs in ([0,6,12,18],[6,18]):
        a=source.query(ClimateQuery(source.source_id,8,Bounds(140,140,37,37),hours_utc=hs))
        rose=a['summaries_by_grain']['month']['wind_rose']
        require(rose['point']['cell_id']==13 and not rose['point_in_selected_region'],'fixed representative point mislabeled')
        for m in range(1,13):
            ds=[d for d in calendar[m] if d.hour in hs]; counts={};calm=0
            for d in ds:
                u,v=vector(d,0,1); speed=math.hypot(u,v)
                if speed==0:calm+=1;continue
                # Cardinal expected sector or independently evaluate compass quadrant.
                sector=12 if v==0 and u>0 else 4 if v==0 and u<0 else 8 if u==0 and v>0 else 0 if u==0 and v<0 else 10
                cls=sum(speed>=x for x in [5,10,20,30,50]);counts[(sector,cls)]=counts.get((sector,cls),0)+1
            rows=[r for r in rose['rows'] if r['timebin_id']==m-1]
            for row in rows:
                require(row['count']==counts.get((row['sector'],row['speed_class']),0),f'rose month {m} sector/bin mismatch')
                close(row['frequency'],row['count']/len(ds));checked+=1
            cr=rose['calm_counts'][m-1];require(cr['count']==calm,'calm mismatch')
            require(sum(r['count'] for r in rows)+calm==len(ds),'denominator')
            close(sum(r['frequency'] for r in rows)+cr['frequency'],1)
    return {'rose_cells_compared':checked,'calm_and_thresholds':[0,5,10,20,30,50]}
check('native-point-FROM-rose-hour-mask-calm-and-speed-thresholds',roses)
def cache():
    fresh=WindArchiveSource(path)
    with patch.object(fresh._samples,'profiles',wraps=fresh._samples.profiles) as p:
        a=fresh.query(ClimateQuery(fresh.source_id,8));b=fresh.query(ClimateQuery(fresh.source_id,51))
        require(p.call_count==1,'pressure recomputes profiles')
    require(a['monthly_profiles']==b['monthly_profiles'],'pressure changed common all-level profiles')
    a['monthly_profiles']['months'][0]['rows'][0]['p10']=-100
    require(fresh.query(ClimateQuery(fresh.source_id,8))['monthly_profiles']['months'][0]['rows'][0]['p10']>=0,'mutable cache leak')
    return {'profile_calls_two_levels':1,'returned_copy_isolated':True}
check('pressure-cache-and-fixed-output-isolation',cache)
def invalids():
    reports={}
    for name,mutator in [('missing-month',lambda m:m['months'].pop()),('duplicate-time',lambda m:m['months'][1]['times_utc'].__setitem__(1,m['months'][1]['times_utc'][0])),('wrong-hash',lambda m:m['months'][0]['u'].__setitem__('sha256','0'*64)),('wrong-level-identity',lambda m:m['levels'][1].__setitem__('level_id',8))]:
        changed=deepcopy(manifest);mutator(changed);f=path.parent/(name+'.json');f.write_text(json.dumps(changed),encoding='utf8')
        reports[name]=error(lambda:WindArchiveSource(f))
    f,mm=fixture('changed');s=WindArchiveSource(f);s.query(ClimateQuery(s.source_id,8))
    raw=f.parent/mm['months'][0]['u']['file'];data=raw.read_bytes();raw.write_bytes(data[:-1]+bytes([data[-1]^1]))
    reports['changed-array-after-cache']=error(lambda:s.query(ClimateQuery(s.source_id,8)),'CLIMATE_SOURCE_CHANGED')
    fresh=WindArchiveSource(path)
    with patch('backend.climate.archive.np.load',side_effect=OSError('independent injected read failure')):
        reports['read-failure']=error(lambda:fresh.query(ClimateQuery(source.source_id,8)),'CLIMATE_SAMPLES')
    return reports
check('missing-changed-corrupt-support-rejected-without-partial-output',invalids)
def service_probe():
    jpath,_=fixture('jra','JRA-3Q');svc=ClimateService(OUT/'store',archive_paths=[path,jpath])
    ds=svc.sources();require(len(ds['sources'])==2 and not ds['errors'],'catalog')
    results=[svc.create_analysis({'client_request_id':'independent-'+d['provider'],'query':ClimateQuery(d['source_id'],8).as_dict()}) for d in ds['sources']]
    require(results[0]['analysis_id']!=results[1]['analysis_id'],'mixed providers')
    offline=ClimateService(OUT/'store')
    for a in results:require(offline.get_analysis(a['analysis_id'])==a,'offline fixed read')
    return {'distinct_sources':len({d['source_id'] for d in ds['sources']}),'offline_fixed_reads':len(results)}
check('two-native-providers-distinct-and-source-free-saved-read',service_probe)
def cache_runtime():
    svc=ClimateService(OUT/'runtime-store',archive_paths=[path]);d=svc.sources()['sources'][0]
    q=ClimateQuery(d['source_id'],8).as_dict()
    a=svc.create_analysis({'client_request_id':'runtime-old','query':q})
    with patch('numpy.__version__','independent-new-runtime'):
        b=svc.create_analysis({'client_request_id':'runtime-new','query':q})
        direct=svc._archives[d['source_id']].query(q)
    require(a['analysis_id']!=b['analysis_id'],'old runtime artifact reused')
    require(direct['provenance']['query_hash']==b['query_hash'],'direct and saved runtime identity mismatch')
    return {'same_artifact_reused':a['analysis_id']==b['analysis_id'],'returned_runtime':b['summary']['provenance']['numpy_version'],
        'direct_runtime':direct['provenance']['numpy_version'],'direct_query_hash_differs':direct['provenance']['query_hash']!=b['query_hash'],
        'finding': 'runtime omitted from service identity' if a['analysis_id']==b['analysis_id'] else 'none'}
check('numpy-runtime-change-cache-identity-observation',cache_runtime)
def legacy_probes():
    from test_climate import create_fixture
    from test_climate_periods import add_extensions
    db=OUT/'legacy.duckdb'
    if not db.exists():create_fixture(db);add_extensions(db)
    mixed=ClimateService(OUT/'legacy-store',source_path=db,archive_paths=[path])
    ds=mixed.sources();require(len(ds['sources'])==2,'mixed catalog')
    old=mixed._source.source_id
    verify=error(lambda:mixed.verify_source('climate-nonexistent'),'CLIMATE_SOURCE_CHANGED')
    create=error(lambda:mixed.create_analysis({'client_request_id':'unknown-source','query':ClimateQuery('climate-nonexistent',0).as_dict()}))
    bad=ClimateService(OUT/'bad-legacy-store',source_path=OUT/'absent.duckdb',archive_paths=[path])
    catalog=bad.sources()
    require(len(catalog['sources'])==1 and catalog['errors']==[bad._source_error],'configured missing legacy hidden')
    return {'unknown_verify_rejected':verify,'legacy_source_id':old,
        'unknown_create_rejected':create,'bad_legacy_saved_error':bad._source_error,'bad_legacy_catalog_errors':catalog['errors'],
        'bad_legacy_valid_raw_source_count':len(catalog['sources'])}
check('legacy-coexistence-source-selection-and-partial-error-observation',legacy_probes)
after=hashes()
result={'schema':'independent-archive-probe/1','fixture':'synthetic complete leap-year 2024; 3 unequal-weight native cells, 2 levels; no network/real archive mutation',
        'input_hashes':before,'final_hashes':after,'input_unchanged':before==after,'numpy_version':np.__version__,'checks':checks,
        'counts':{'pass':sum(c['status']=='PASS' for c in checks),'fail':sum(c['status']=='FAIL' for c in checks)}}
(P/'independent-archive-probe-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
