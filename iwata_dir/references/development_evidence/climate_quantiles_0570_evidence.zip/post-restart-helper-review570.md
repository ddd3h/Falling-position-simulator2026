# 再起動後読戻し helper の有限レビュー（v1）

ソース読解のみ。helper/API/プロセス/UI は実行せず、repo/state は変更していない。対象 SHA は同名 JSON に固定した。

結論: project と主要一覧の応答 byte、列挙済み非 DB 固定 file の byte、気象 artifact_json の保全は確認する構造になっている。一方「既存の保存飛行結果・全 artifact が再読可能」は、現状の照合だけでは十分に裏付けられない。主担当は以下 R1/R2 を採用し、別名 v2 案を依頼した。

- **R1（必要）** `check-after-restart570.py:23–30` は全 SQLite の論理行を比較していない。`application.py:393–405` の一覧には `manifest_hash` が出ず、同ファイル `426–437` の GET はこの DB 値を用いて整合性を検査する。したがって DB の参照ハッシュだけ変わると、一覧・実ファイルが一致しても結果 GET は失敗し得る。climate も `artifact_json` だけでは `artifact_sha256/artifact_bytes/query_hash/result_hash` の破損を検出できない（`climate/service.py:181–207`）。全 DB の schema/column/型付き row 集合を backup と readonly 比較する。
- **R2（必要）** `31–35` の GET は適用中 climate だけ。`list_runs()` は既定で ensemble trial を除外するため、単便一覧からだけでは試行結果を覆わない。backup の `runs JOIN jobs` から全 completed を列挙し、各 run/result と ensemble plan/snapshot/analysis、保存 climate の GET を capture・再照合する。raw 応答はローカルに保持し、証拠票は count/hash とする。
- **R3（範囲明示または小検査）** weather-sources 不一致は記録だけ、climate 3 件は identity の証明ではなく、index 一致も旧 lazy asset の到達性までは証明しない。無変更予定の weather-sources は一致を要求できる。新 catalog の期待 identity と旧 asset の読戻しは別票で補うか、helper の主張から明示的に除く。

capture の全 DB consistent backup と固定 file inventory、PS1 の mode/state/port/instance・backup/runtime/dist hash・直前一覧再照合・旧 PID 終了確認は、補強済み手順として対応している。post 側でも inventory/backup hash を capture receipt と束縛すると、比較元の取り違えを検出できる。SQLite の物理 bytes は WAL/checkpoint で変化するため、live DB の物理 SHA 一致を要求してはいけない。

跨 DB atomicity、検査中の新規ユーザー書込み排除、起動 process owner はこの helper 単独では証明しない。8551→8550 の全 path forward は主担当による別確認として受け取り、自分が確認したとはしない。新計算・Google 接続・科学的受入・UI 成功の証明へ広げない。
