"""Finite independent review probes. Writes only to P570 fixtures, never repo."""
from pathlib import Path
import calendar,copy,hashlib,json,sys,datetime as dt,zipfile
from unittest.mock import patch
import numpy as np
R=Path.cwd();P=Path(__file__).resolve().parent
sys.path.insert(0,str(R));sys.path.insert(0,str(R/'backend/tests'))
from backend.climate.samples import MonthlySamples
from backend.climate.contracts import ClimateError

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['backend/climate/samples.py','backend/climate/source.py','backend/climate/contracts.py','backend/climate/service.py','backend/application.py','backend/tests/test_climate_samples.py']
before={n:sha(R/n) for n in names};F=P/'independent-sample-fixtures';F.mkdir(exist_ok=False)
grid=[{'cell_id':4,'lat':40.,'lon':140.,'gauss_weight':1.},{'cell_id':8,'lat':41.,'lon':141.,'gauss_weight':4.},{'cell_id':20,'lat':42.,'lon':142.,'gauss_weight':2.}]
levels=[{'level_id':9,'level_hpa':300.},{'level_id':30,'level_hpa':1000.}]
times=[]
for y in range(2016,2026):
 for d in range(1,calendar.monthrange(y,2)[1]+1):
  for h in [0,6,12,18]:times.append(dt.datetime(y,2,d,h,tzinfo=dt.timezone.utc))
u=np.empty((len(times),2,3),dtype=np.float32)
for i,t in enumerate(times):
 for l in range(2):
  for c in range(3):u[i,l,c]=(t.year-2016)*3+t.day+(70 if t.day>15 else 0)+t.hour+17*c+5*l
v=np.zeros_like(u)
for name,a in [('u',u),('v',v)]:np.save(F/(name+'.npy'),a,allow_pickle=False)
manifest={'schema':'balloon.climate.raw-months/1','dataset_sha256':'1'*64,'years':[2016,2025],'grid':[{k:x[k] for k in ['cell_id','lat','lon']} for x in grid],'levels':levels,'months':[{'month':2,'times_utc':[t.strftime('%Y-%m-%dT%H:00:00Z') for t in times],**{name:{'file':name+'.npy','bytes':(F/(name+'.npy')).stat().st_size,'sha256':sha(F/(name+'.npy'))} for name in ['u','v']}}]}
path=F/'manifest.json'
def write(m):path.write_text(json.dumps(m),'utf8',newline='\n')
write(manifest);source=MonthlySamples(path,'1'*64,grid,levels);results=[]
def oracle(values,weights,q):
 # Independent integer cumulative weights; no NumPy quantile or product helper.
 pairs=sorted(zip(values,weights));target=sum(weights)*q;total=0
 for value,w in pairs:
  total+=w
  if total>=target:return float(value)
 raise AssertionError('empty')
for cells,hours in [(grid,None),(grid,[0]),([grid[0],grid[2]],[6,18])]:
 p=source.profiles(cells,levels,hours);feb=p['months'][1]
 assert len(p['months'])==12 and [x['month'] for x in p['months'] if x['available']]==[2]
 assert all(x.get('reason')=='month_not_acquired' and 'rows' not in x for x in p['months'] if not x['available'])
 indices=[i for i,t in enumerate(times) if hours is None or t.hour in hours];ci=[grid.index(g) for g in cells];weights=[int(g['gauss_weight']) for g in cells]
 for li in range(2):
  values=[float(u[i,li,c]) for i in indices for c in ci];ws=weights*len(indices);row=feb['rows'][li]
  assert row['p10']==oracle(values,ws,.1) and row['p90']==oracle(values,ws,.9)
  for k in [0,1]:
   ii=[i for i in indices if (times[i].day<=15)==(k==0)];vv=[float(u[i,li,c]) for i in ii for c in ci]
   assert row['half_medians'][k]==oracle(vv,weights*len(ii),.5)
  half_q=[oracle([float(u[i,li,c]) for i in indices if (times[i].day<=15)==(k==0) for c in ci],weights*sum((times[i].day<=15)==(k==0) for i in indices),.1) for k in [0,1]]
  assert row['p10']!=sum(half_q)/2
 assert feb['time_count']==len(indices) and feb['sample_count']==len(indices)*len(ci)
 results.append({'case':'independent_weighted_pool','cells':[g['cell_id'] for g in cells],'hours':hours,'time_count':feb['time_count'],'half_counts':feb['half_time_counts'],'rows':feb['rows'],'ok':True})
mutations={
 'wrong_db_sha':lambda m:m.update(dataset_sha256='2'*64),
 'wrong_level_order':lambda m:m.update(levels=list(reversed(m['levels']))),
 'wrong_cell_order':lambda m:m.update(grid=list(reversed(m['grid']))),
 'duplicate_time':lambda m:m['months'][0]['times_utc'].__setitem__(1,m['months'][0]['times_utc'][0]),
 'missing_leap_time':lambda m:m['months'][0]['times_utc'].pop(),
 'duplicate_month':lambda m:m['months'].append(copy.deepcopy(m['months'][0])),
 'path_escape':lambda m:m['months'][0]['u'].update(file='../outside.npy'),
 'wrong_hash':lambda m:m['months'][0]['u'].update(sha256='0'*64),
 'reused_component':lambda m:m['months'][0].update(v=copy.deepcopy(m['months'][0]['u']))}
for label,change in mutations.items():
 m=copy.deepcopy(manifest);change(m);write(m)
 try:MonthlySamples(path,'1'*64,grid,levels)
 except ClimateError as e:results.append({'case':label,'code':e.code,'ok':True})
 else:raise AssertionError(label+' accepted')
write(manifest)
np.savez(F/'fake.npz',data=u);m=copy.deepcopy(manifest);m['months'][0]['u']={'file':'fake.npz','bytes':(F/'fake.npz').stat().st_size,'sha256':sha(F/'fake.npz')};write(m)
try:MonthlySamples(path,'1'*64,grid,levels)
except ClimateError as e:results.append({'case':'npz_not_ndarray','code':e.code,'ok':True})
else:raise AssertionError('NPZ accepted')
write(manifest);source=MonthlySamples(path,'1'*64,grid,levels)
with patch('backend.climate.samples.digest',side_effect=OSError('finite read failure probe')):
 try:source.verify_full()
 except ClimateError as e:results.append({'case':'verify_hash_read_failure','code':e.code,'ok':True})
 else:raise AssertionError('read error escaped')
# Simulate an ordinary I/O failure after the stat guard. This should reach callers
# as a bounded source failure, not an unhandled raw exception.
with patch('backend.climate.samples.np.load',side_effect=OSError('finite reopen failure probe')):
 try:source.profiles(grid,levels,None)
 except ClimateError as e:results.append({'case':'profiles_reopen_io_error','code':e.code,'bounded':True})
 except OSError as e:results.append({'case':'profiles_reopen_io_error','exception':type(e).__name__,'bounded':False})
 else:raise AssertionError('failed read accepted')
assert {n:sha(R/n) for n in names}==before
receipt={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'numpy_version':np.__version__,'source_hashes':before,'source_unchanged':True,'results':results,'limits':'Synthetic arrays and fault injection only; no completed real source month, no scientific accuracy or runtime UI acceptance.'}
(P/'independent-samples-probe-result.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n','utf8',newline='\n');print(json.dumps({'probes':len(results),'ordinary_pass':sum(x.get('ok',False) for x in results),'unbounded_errors':[x for x in results if x.get('bounded') is False]},ensure_ascii=False))
