from pathlib import Path
import duckdb,json
P=Path(__file__).resolve().parent
DB=P.parent/'climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb'
c=duckdb.connect(str(DB),read_only=True,config={'enable_external_access':'false','threads':'1','memory_limit':'128MB','max_temp_directory_size':'0B'})
r={'fact_wind_columns':[x[0] for x in c.sql('describe fact_wind').fetchall()],
 'support_checks':c.sql("SELECT count(*) row_count, count(*) FILTER (WHERE speed_p10 IS NULL OR speed_p50 IS NULL OR speed_p90 IS NULL) missing, count(*) FILTER(WHERE NOT (speed_p10 <= speed_p50 AND speed_p50 <= speed_p90)) unordered FROM fact_wind").fetchall(),
 'sample_cell285_january_300hPa':c.sql("SELECT timebin_id, month, bin, n, speed_mean,speed_p10,speed_p50,speed_p90 FROM fact_wind WHERE cell_id=285 AND month=1 AND level_hpa=300 ORDER BY timebin_id").fetchall(),
 'interpretation':'Native half-month and cell empirical quantiles exist; this is not evidence that pooled regional/monthly quantiles can be reconstructed exactly.'}
c.close();(P/'quantile-support-result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(r,ensure_ascii=False))
