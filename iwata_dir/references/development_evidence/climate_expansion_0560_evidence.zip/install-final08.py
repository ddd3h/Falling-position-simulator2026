from pathlib import Path
import shutil, hashlib, json
P=Path(__file__).resolve().parent
src=P/'dist08'
targets=[P/'dist01',P.parent/'repair-background550/dist02']
for dst in targets:
    assert dst.is_dir() and src.is_dir()
    for p in src.rglob('*'):
        if p.is_file() and p.name!='index.html':
            out=dst/p.relative_to(src);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
    temp=dst/'index.next';shutil.copy2(src/'index.html',temp);temp.replace(dst/'index.html')
h=hashlib.sha256((src/'index.html').read_bytes()).hexdigest()
assert all(hashlib.sha256((d/'index.html').read_bytes()).hexdigest()==h for d in targets)
record={'dist':'dist08','ports':[8551,8560],'index_sha256':h,'old_assets_preserved':True,'backend_restarted':False}
(P/'static-final.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(record))
