$ErrorActionPreference='Stop'
$taskRoot='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/climate-expansion550'
$runtimeRoot=Join-Path $taskRoot 'runtime01'
$stateRoot='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/state-review550'
$beforeRoot=Join-Path $taskRoot 'service-before'
$owner=Get-NetTCPConnection -LocalPort 8550 -State Listen
if($owner.OwningProcess -ne 115504){throw 'Unexpected live process; do not stop'}
foreach($pair in @(@('runs','runs'),@('ensembles','ensembles'),@('weather-acquisitions','acquisitions'))){
  $data=Invoke-RestMethod ('http://127.0.0.1:8550/api/v1/'+$pair[0])
  foreach($row in $data.($pair[1])){if($row.state -in @('queued','running','cancelling','acquiring')){throw 'Active work; restart refused'}}
}
$health=Invoke-RestMethod 'http://127.0.0.1:8550/api/v1/health'
if($health.instance_id -ne 'a01d2deb-6082-4a3c-a749-59bbc0bbb02b'){throw 'Unexpected instance'}
if(!(Test-Path -LiteralPath (Join-Path $stateRoot 'registry.sqlite3'))){throw 'Missing existing registry'}
# This process is the observed 8550 service only. Its SQLite state remains in place.
Stop-Process -Id 115504
$env:BALLOON_DATA_DIR=$stateRoot
$env:BALLOON_FRONTEND_DIST='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/repair-background550/dist02'
$env:BALLOON_CLIMATE_DB='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb'
$env:BALLOON_CLIMATE_SHA256='1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a'
$env:BALLOON_HISTORICAL_CATALOG='C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/historical-catalog550-02.json'
$launched=Start-Process -FilePath 'C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe' -ArgumentList @('-X','utf8','-B','-m','uvicorn','backend.app:create_app','--factory','--host','127.0.0.1','--port','8550') -WorkingDirectory $runtimeRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRoot 'live-api.stdout') -RedirectStandardError (Join-Path $taskRoot 'live-api.stderr')
@{wrapper_pid=$launched.Id;state=$stateRoot;runtime=$runtimeRoot;port=8550;expected_instance=$health.instance_id} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskRoot 'live-launch.json') -Encoding utf8
$launched.Id
