# 0.56 SVG明示保存の有限再批評

2026-10-02。担当 map_refresh_review。repo変更・ブラウザ操作・API/DB操作・追加通信は行っていない。round05のhelper/controllerを読み、round06で追加された「生成時の条件」欄の接点だけ再確認した。以前の `final-independent-review.md/json` はround04までの票として変更していない。

## 結論

確認したsourceで、非同期完了・失敗・破棄によって異なるSVGへ無言で差し替わる重大な残存点は見つからなかった。旧リンクの母集団を読みにくいという指摘は、round06の専用条件欄で解消している。

これはsourceの寿命・固定snapshot・表現の有限な確認である。旧dist04でdownloadイベントと新fileが得られなかった原因を特定したものではなく、新方式で実ファイルが必ず受領されることの認定でもない。

## 確認した接点

- `climateController.js:78–85` は、準備開始時に表示DOMとVMの図/条件/来歴からSVG snapshotを同期生成してから背景埋込みをawaitする。完了後に現在の図を再読しない。後続準備は旧AbortControllerへ中止を通知し、旧準備の専用statusを更新する。後着完了は `disposed` と `exportAbort === ac` の照合を通らなければpublishしない。
- `export.ts:createPreparedWindDownload` は、自動clickと1500 ms失効を廃止し、明示的なa[download]を保持する。新Blob URLの作成が成功してからhref/filename/表示を差替え、その後に旧URLを失効させる。URL生成が失敗すれば旧hrefをまだ変更していない。
- `begin` / `failed` は説明statusだけを変更する。前回成功分のhref・filename・条件欄は保持される。初回失敗ではリンクを作らない。`dispose` は現在URLを一度だけrevokeし、hrefとclick handlerを外し、リンク/条件欄を隠す。破棄後のpublishは拒否する。
- controllerの `dispose` は未完了embedをabortしてから全helperを破棄する。画面の表示変更やdraft変更はhelperを再生成せず、旧生成物を現在の結果に見せかけて書き換えない。
- statusは「SVGを準備」「ブラウザへ保存を要求」に分かれ、ダウンロード一覧の確認を利用者へ戻す。ファイル受領を観測したと断定しない。

## 指摘と処置

初稿のリンクは図種/粒度/頁/analysis ID先頭だけを表示していた。反例は「全4時刻の風配Aを準備した後、UTC00の結果Bへ適用し、現在の風配は利用不可になった状態」。旧Aを保持すること自体は妥当だが、リンク近傍に全4時刻と気圧面が見えないとBの図と混同し得る。

親が採用したround06では `windDownloadConditions(output.metadata)` が生成したsnapshotの資料名・母集団（UTC時刻を含む）を読む。地域図/風配には選択気圧面も付ける。専用 `conditions` 要素へ「生成時の条件」としてpublishし、リンクと同じ成功時だけ更新する。

`begin` / `failed` / `onclick` とcontrollerの `sync` はこの専用欄を変更していない。したがって上のA→Bでも、旧Aのhrefと全4時刻・300 hPaなどの条件が一組で残る。新しいBの条件だけを旧Aへ後付けしていない。平均プロファイルは全対応面を描くため、単一選択面の説明を付けない。この接点で追加の重大指摘はない。

## 証拠と未確認

- `download-review-round05.json`: 初稿の読取指紋と指摘。`frontend-implementation05.json` と初稿指紋を比較した結果は最終JSONに保存。
- `final-download-review.json`: 最小修正後4ファイルのSHA-256、source上の確認、未確認範囲。記録準備前後で4ファイル指紋一致。
- 担当票のround05は41/41、型検査/build成功。`frontend-tests07.json` は追加の生成条件保持例を含む42/42成功。本担当は試験を再実行していない。試験はURL mockと有限な描画/状態境界を支え、実ブラウザの受領証拠にはしていない。

実ブラウザの明示リンク操作、downloadイベント、実ファイルの存在/bytes、SVGを単独で開いた表示は主担当の受入へ残す。背景付き地域SVGのfetchには専用期限がないという継承境界も残るが、新しいprofile/roseは背景tile通信を必要としない。リンクが受領されなかった場合も保持した同一生成物を再要求できる。初回失敗の原因を、この設計変更で解明済みとは扱わない。
