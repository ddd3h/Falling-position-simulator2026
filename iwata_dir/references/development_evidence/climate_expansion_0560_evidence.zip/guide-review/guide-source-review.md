# 0.56 PROGRAM / THEORY の限定更新票

2026-10-02。担当 `/root/map_refresh_review`。repo編集は `docs/PROGRAM_GUIDE.tex` と `docs/THEORY_GUIDE.tex` のみ。PDF/txt生成、INDEX、他資料、実画面操作は主担当へ引継ぐ。

## 比較と理由

固定基準は PR31 `cbc197276d14c5753cc112643e449abaeb3bb29f`、親から渡された採用mainは `06936856ee0deab2fe0b3f3b04220d60652ffba6`。`../basis.json` に保存された2 TeXのSHA-256と現行編集前bytesを照合し、`W/detail-lease-repair550/record-c2/candidate` の実体とも完全一致を確認した。元local .gitへアクセス/書込みはしていない。

旧ガイドは実風統計を半月・年間/地域図として記載し、時刻選択を未対応としていた。今回の実装は月/季節をn重みで結合し、提供20面の時刻選択、固定1地点の経験風配と平均プロファイルを扱うため、その担当と母集団を更新した。0.55の旧検証や物理全体を再検証済みと書かない。

## PROGRAMの読取・編集範囲

版入口/ヘッダーと `PROGRAM-READ`、`PROGRAM-DEPENDENCY`、`WEB-FRONTEND`、`WEB-SCREENS`、`WEB-CLIMATE-FRONTEND`、`WEB-HISTORICAL`、`WEB-CLIMATE-BACKEND`。FE/BEの実気象統計に届くカードだけを更新した。他23ページの本文は固定版と同一。

新しい子ページ `WEB-CLIMATE-AGGREGATION` を追加した。TeXのPage定義は30→31。sourceが検査/支持/結果を束ね、aggregationは各cellの時間結合→Gaussian地域集約、periodsはUTC期間、extensionsは追加表/時刻支持/風配、statisticsはR/FROM/独立加重和、serviceは別SQLiteでの固定保存という担当を示す。半月互換本体+summaries_by_grain、旧artifact読取、図の粒度切替でPOSTしない点を結ぶ。

FEは担当frontend430から最終パスと責務を受領し、climateController.js、climateDistributions.ts、sources/climateSummary.ts、ClimateFlightHandoff.tsxの現コードを読んだ。`../frontend-implementation01.md/json` が同担当のsource01凍結票。WeatherScreen/useClimateWorkspaceの操作受入はこの資料編集で代替しない。

## THEORYの読取・編集範囲

版入口、`th:climate` 全体、その実装参照文。気象節より前の物理/数値/標本集合の本文は固定版と文字単位で同一。既存の半月検証値は従来の照合例として明示して継承した。

追加は `th:climate-periods` / `th:climate-rose`、式 `eq:climate-pool-time` / `eq:climate-rose`。明示改頁を1つ追加した。各格子のn重み結合→Gaussian地域平均、合成後R/来向と格子平均幅、UTC/JST対応、DJFが資料内月poolであること、20面の時刻subset、全4時刻38面への復帰を明記した。風配はcell285の全時刻count/N、16方向・元6速度階級、静穏独立区分なし、地域外属性、時刻subset時は利用不可を分けた。分位/共分散の存在と今回未表示、raw共同場/飛行確率へ直結しない境界を保持した。

## 静的確認と引継ぎ

`check-guides.py` と `source-update-receipt.json` に指紋・ページ単位差分・参照/環境の有限検査を保存。両TeXのbegin/end対応、THEORYの重複labelなし・全ref解決、PROGRAMの全Go宛先解決は成功。これはTeXコンパイル・視認の代わりではない。

PDF生成、文字折返し/カードの重なり、最終ページ数、TOC/INDEX同期は未確認で主担当へ引継ぐ。本担当は完成PDFや実画面を見ていない。親の生成後に新ページと変更カードのレイアウト確認が必要。

## 保存した証拠

- `before/PROGRAM_GUIDE.tex`, `before/THEORY_GUIDE.tex`, `before-receipt.json`: 固定cbc197と一致する編集前原本。
- `PROGRAM_GUIDE.diff`, `THEORY_GUIDE.diff`: 固定版→編集後の差分。
- `source-update-receipt.json`: 2ファイルの前後SHA-256、読取時点の関連source指紋、検査と未確認範囲。
- `../independent-backend-review.md`: 最終独立backend票。数値比較6組・対象全行、現source境界probe、修正済み単位検査、受入限界を区別。今回のガイド更新でレビュー対象版や検証結果を付替えていない。

backendの数値根拠は `../independent-backend-sql-probe.py/result.json`、境界根拠は `../independent-backend-boundary-probe.py/result.json`。実ファイル名はそれぞれ `independent-backend-sql-result.json` / `independent-backend-boundary-result.json`。広域の科学精度・raw取得・実UI性能・main統合はこの票の認定対象外。


## 追記：指定PDFページの視認と局所調整

主担当の生成後、guides01のPROGRAM PDF 7/15/16、THEORY PDF 21–24を実画像で視認した。先の「本担当は完成PDFを見ていない」はsource改訂完了時点の記録であり、現在の有限視認範囲は `pdf-visual-review.md/json` に追記した。

PROGRAM p7の固定summaryラベルが点線へ重なる1点を発見し、親の明示依頼により `fill=white,inner sep=1pt` だけを追加。修正後PROGRAM SHA-256は `db17d58610e8dd6396855a3312deaeb9a0a3b6dbd972dc07b928bd0507adf3ee`。THEORYは `70afa7c008525326fd9d0aa72c6f4130ebc9b05ffa0d98560c457d152b0e318a` のまま。指紋票とdiff、静的検査を更新した。局所修正後の再build/render/視認は主担当へ引継ぐ。
