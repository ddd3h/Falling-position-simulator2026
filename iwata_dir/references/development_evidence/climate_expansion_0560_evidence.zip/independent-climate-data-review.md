# 提供JRA統計の能力と拡張経路：独立読解

2026-10-02 JST。基準は主担当固定 PR31 cbc197276d14c5753cc112643e449abaeb3bb29f / main 06936856ee0deab2fe0b3f3b04220d60652ffba6 と現source。Git再照会なし。source・原tarの文書/コード・既存抽出DuckDBを読取り専用で調査した。DB書込み・UI/API操作・新規ネット取得・Google操作なし。提供コードは実行/importしていない。

再現: `climate-data-review-probe.py` を既存 `C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe -B` で実行。実出力は `climate-data-review-evidence.json`。DBは external_access=false/read_only=true/threads=1/memory_limit=128MB/max_temp_directory_size=0B。

## 判断

現APIの3平均だけを提供資料全体の能力と扱わない。今回の月/季節grain、下層時刻filter、実mean profile、代表点の経験風配は、新たなrawを取らずに作れる有力な経路である。共分散・分位・fitted分布は後続表示の材料として存在する。ここで後続機能の禁止や全国/上層対応の断念を採用するものではない。

## 実体と利用可能列

原tarは195,352,205 bytes、SHA256 `7a1a64b495a22f1b75703709ff21ce7132ef1642bebd366f08b96572e208dfbc`、97 member。DBは309,866,496 bytes、SHA256 `1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a`。今回は実ファイルを再hashし既存票と一致した。原時系列NetCDF/GRIB/CSV/Parquetは同梱されず、windclim本体もない。source_netcdfは半月統計の入力名で、未提供の原6時間場が同梱されたという意味ではない。

| 実表 | 支持 | 使用可能な内容と境界 |
|---|---|---|
| fact_wind / 519,840行 | 24 UTC半月 × 38気圧面(3–1000hPa) × 570格子、2016–2025全4UTC帯をpool | n、u/v平均・u/v分散・uv共分散、単位方向成分平均、scalar/vector平均風速、speed_std/max、p10/25/50/75/90/95、10/20/30/40m/s超過割合、定常度、円周量、楕円、時期/地点別幾何高度平均、shear等。year/hour列なし |
| fact_wind_diurnal / 1,094,400行 | 同24半月 × 20面(300–1000hPa) × 570格子 × 4UTC時刻 | n,u_mean,v_mean,speed_mean,speed_std,constancy,dir_vector_mean_deg。各時刻n=133–160、上記平均/std欠損0。u/v分散・共分散、分位、風配、年別列は無い |
| fact_wind_rose / 87,552行 | 24半月 × 38面 × 16方向 × 6速度階級 × 代表1格子 | 経験count。月/季節へのcount合算が可能。選択地域全体の風配、時刻別風配、他格子の経験風配ではない |
| fact_speed_fit / 1,559,520行 | fact_wind各組にnormal / Weibull(loc=0) / uniform | fittedパラメータ、loglik/AIC/delta、KS、負値確率、選択/曖昧フラグ。新しい月/季節の単一族パラメータへ平均して置換できない |
| fact_dir_fit / 1,559,520行 | fact_wind各組にvon Mises / wrapped normal / circular uniform | 円周分布パラメータ・Kuiper等。wrapped normalはmomで、全族がMLEではない。速度fitと掛けても速度方向のjointにならない |
| fact_drift / 13,680行 | 24半月 × 570格子 | 5m/s上昇・30km到達・6m/s下降という供給側の公称移動統計。現在の飛行核/機体モデルの結果へ代用しない |

DB総時間支持は独立暦とdim_timebinから14,612。PDF/period注記の14,610、tar READMEの上端1hPaは従来レビューで指摘済みの説明差で、実体は3hPa。年別軸はどのfactにもない。年filterには別粒度のデータが要る。

## FEに渡す風配の正確な定義

- `dim_sector`: sector SMALLINT 0..15、centre_deg DOUBLE = sector×22.5、lo_deg DOUBLE=(centre−11.25)%360、hi_deg DOUBLE=centre+11.25、wraps_north BOOLEAN（sector0だけtrue）、compass_16 VARCHAR。N,NNE,NE,ENE,E,ESE,SE,SSE,S,SSW,SW,WSW,W,WNW,NW,NNW。北sectorは348.75°から11.25°を跨ぐ。sector番号は境界ではなく中心。
- `dim_speed_class`: speed_class SMALLINT 0..5、lo_ms DOUBLE=[0,5,10,20,30,50]、hi_ms DOUBLE=[5,10,20,30,50,null]、label VARCHAR=['0-5','5-10','10-20','20-30','30-50','50+']。記述上は下限以上・上限未満。最終binに架空の有限上端を置かない。
- `fact_wind_rose`: timebin_id/level_id/cell_id/sector/speed_classが集計を識別し、month/bin/level_hpaも冗長列として持つ。count INTEGER。全912半月×面でcount合計=fact_wind.n、最大差0。
- `dim_grid WHERE is_rose_cell`: cell_id=285,lat_idx=9,lon_idx=15,lat=43.267398834228516,lon=143.625,lon_0_360=143.625,gauss_weight=0.004760850686579943,is_rose_cell=true の1件。`meta_dataset.rose_cell_lat` は43.2674005620574という元精度の文字列で微差があり、表示・結合の正本はdim_gridの実cellとする。
- 気象風向はFROM、北0°・時計回り、西風270°。ベクトル(u東,v北)から `(atan2(u,v)*180/pi+180)%360`。TOはfact_drift.bearing_degだけ。風配の矢印やラベルを流下方向と混同しない。
- 無風専用count/閾値はない。0–5m/s階級を「無風」と呼ばない。dir_fit schemaは無風を除外と記すが、このDBではdir_fit.nも全行fact_wind.nと同じで、uniformが記録する最小speedは0.0003525449m/s。rose元集計のcalm閾値は供給windclimがなく実装確認できない。実体を勝手に再分類せず「0–5m/s」を保持する。

## 再集約と反例

1. **月/季節のmean**: 同一格子・面の非重複bin iについて N=Σn_i、μ=Σn_i μ_i/N。地域平均はその後gauss_weightを正規化して合成する。方向角・定常度を直接平均せず、pooled u/v/sから再計算する。地域の平均scalar speedは「各格子のscalar speedを重み付けした平均」であり、「各日時の地域平均ベクトルの速さ」とは異なる。
2. **時間帯**: dim_hourは00/06/12/18UTC=09/15/21/翌03JST。時刻maskはその4観測時刻の選択。間の毎時観測があるように補間しない。全4時刻をn結合すると全半月nが完全一致し、u/v/sの最大差2.87e-6m/s以下。speed_stdをddof1の群内＋群間分散式で結合した差は最大5.39e-5 (m/s)^2で、Float32丸め規模。
3. **月・JSTの日付**: DBのmonth/binはUTC暦。18UTC=翌03JSTというラベルだけでJSTの月境界へ再区分したことにはならない。「UTC月 × JST表示時刻」は可能。厳密なJST月/半月には境界原日時が必要。DJFも2016–2025の12/1/2月をpoolした季節であり、年ごとの連続した10冬を復元した集合ではない。
4. **風配**: 同じcell/level/sector/speed_classのcountを合算し、選択binの合算nで割る。実例: 8月・3hPa・E方向・20–30m/sは半月割合の単純平均42.78646%に対しcount合算41.77419%（差1.01226ポイント）。件数と分母を返すと反証可能になる。代表点が地域外にあるとき、地域全体の図へ見せかけない。時刻filterでmeanだけが変わり風配が全時刻のままなら、その非対応を図の近くに明示する。
5. **共分散/速度分散の後続**: n,平均,同じ分母定義の分散があれば、Σ_i[(n_i−1)S_i+n_i(μ_i−μ)(μ_i−μ)^T]/(N−1) で非重複時間群を結合できる。speed_stdのddof1は明記、u/v分散・covのddofは供給説明が薄く、採用時に追加確認する。これは各格子の時間分布。空間重み付き混合分布の広がりと、地域平均風の時間分散は別で、後者には格子間同時共分散が要る。
6. **分位/fit**: 既存分位は各原半月・格子・面の経験値として直接提示可能。月・地域分位を単純/重み付き平均してはいけない。代表roseの階級CDFはcount合算で正当な粗い分布になる。原fitの重み付きPDF/CDF混合は近似分布として可能だが経験分布ではなく、bin内・尾部を仮定する。混合CDFから求める近似分位と原分位を明確に区別する。Gaussian楕円は共分散を可視化するものと確率被覆を主張するものを分ける。
7. **独立数と同時場**: nは格子あたりの解析時刻数。n×格子数を独立気象標本数としない。n_effやlag1を月/季節で足して新しいn_effにできない。層間・格子間・時刻間の同時共分散はDBに無く、今回の実統計表示から気象MC共同場を生成したことにはならない。

## 後続rawの規模と候補経路

年filter、厳密JST暦、上層時刻別分布、任意地点の経験風配は不足データを取得することで進められる。風分析だけならまずnative圧力面u/vでよく、飛行用100モデル面5量を初めから全期間取得する必要はない。時期・地点別の実高さへ変換するなら同時Hも選ぶ。温湿度/地表量と連続空間haloを含む飛行場は別の費用判断である。

以下は14,612時刻×38面、Float32の**値配列だけ**の計算。HTTP転送量・圧縮容量・全処理RAM・配布サーバーの最小取得単位の実測ではない。

| 候補 | u/v配列量 |
|---|---:|
| 代表1格子・10年・全時刻/38面 | 4,442,048 bytes = 4.24 MiB |
| 近隣2×2格子・同条件 | 16.95 MiB |
| 570格子・1年(365日) | 241.27 MiB |
| 570格子・10年分の1月 | 204.91 MiB |
| 570格子・10年通年 | 2,531,967,360 bytes = 2.358 GiB |
| 570格子・10年・1UTC時刻だけ | 603.67 MiB |
| 570格子・10年のu/v/H | 3.537 GiB |

一半月600時刻・全域u/vなら99.15MiB。月や年でchunk化し、原UTC/軸/欠測/入力hashを保持すれば、数GiBの全期間をRAMへ同時展開せず集計できる。厳密分位は選択binの値を保持するか外部sort等、時系列相関は連続した年内の順序を保持して求める。代表1点/小領域から同じAPI形を育て、全域へ広げる案は具体的な費用の段階を作れる。

優先候補は、(A)今回の提供済みDBを追加通信0で活用、(B)同じ提供者の原u/v cacheが存在するならhash/軸/原日時を照合して再利用、(C)公開配布のsubsetを代表1点または2×2、まず1年/2か月程度で取得し、実転送/待ち時間/復号RAMを測ってから10年へ広げる、の順。同梱hokduckは原windclim readerを参照しており、それだけで新取得器が揃うわけではない。現時点で原cacheの所在や最新配布のsubset成功は未確認。上記値配列見積りをダウンロード保証へ読み替えない。

## 主な根拠

- backend/climate/contracts.py: ClimateQueryはgrain=halfのみ。source.py:REQUIRED/descriptor/queryは既存3means専用adapterの契約で、原資料能力の上限ではない。statistics.py:vector_summary/combine_cells/utc_half_months。
- 提供tar内 hokduck/schema.py、ingest/facts.py、ingest/fitjob.py、ingest/meta.py、docs/datamodel.rst、docs/caveats.rst、docs/distributions.rst。DB実schema/metadata/集計検算は同梱evidence JSONへ保存。
- references/WIND_REPORT_REVIEW.md 第1–4/8節、wind_analysis_report.txt（検索用原本控え）の方法p10–15/限界p98–99/依存p103–109。今回PDF画像は再視認していない。
- S36の0.48/0.49/0.55は、半月統計と原日時共同場、実行成功と科学精度を分ける。月/時間帯の実統計を育てる今回の目的と矛盾しない。