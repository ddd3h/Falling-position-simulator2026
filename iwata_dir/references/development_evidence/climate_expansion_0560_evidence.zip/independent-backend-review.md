# 気象拡張backendの独立実装レビュー

2026-10-02 JST。対象は現作業sourceの backend/climate/{contracts,source,aggregation,periods,extensions,statistics,service}.py。主担当基準 PR31 cbc197276d14c5753cc112643e449abaeb3bb29f / main06936856ee0deab2fe0b3f3b04220d60652ffba6。repo編集・実DB書込み・API/UI操作・ネット取得なし。最終境界probe中のsource指紋は前後一致し、その実値を `independent-backend-boundary-result.json` へ記録した。

結論：確認した実DBと出力では、追加の重大阻害点を見つけなかった。最初に指摘した時間別3平均の単位検査欠落は主担当が修正し、現extensions.py:31–33のm s-1検査と不正単位の回帰例を読んだ。今回の追加は、実平均profile・月/季節集約・対応する下層時刻選択・代表1点の経験風配という用途に合う。

## 独立数値比較

`independent-backend-sql-probe.py` はproductionのperiods/aggregation/statisticsをimportせず、CASEによる期間区分、原行を時間・空間同時に重み付けした平均、cellごとの期間平均からのextrema、独立のPython暦計算で比較した。入力は主担当出力 `summary-full.json` / `summary-hours.json`。入力hashと署名result_hash検証、詳細差分は `independent-backend-sql-result.json`。

- 全時刻・00/18UTCの各half/month/season、計6組で失敗0。
- annual 2,320行、spatial 45,600行、rose 3,840行の対象全行を比較。
- 地域u/v/s平均の最大絶対差3.06e-13 m/s以下、来向3.42e-13度以下、pooled constancy8.89e-15以下。独立な和の順序の丸め差。
- time_count、cell_count、期間内cellmean幅/最大値、風配countは一致。風配の分母は実count総数と一致し、各frequency、暦日数、選択時刻による期待解析数、各表示尺度も一致した。

保存出力には単位検査追補前のsource指紋が含まれる。数値比較はその固定JSONの検証であり、現sourceへ無言に付替えていない。現sourceの別途読取queryと境界検証は次項。

## 現sourceの境界確認

`independent-backend-boundary-probe.py` / `independent-backend-boundary-result.json` は実DBをread_onlyで使い、次を確認した。

- 代表点を含まない1格子矩形でも、風配は代表cell285のまま `available=true, point_in_selected_region=false`。地域の風配へ変換しない。FEはこの属性を可視説明へ使う必要がある。
- 1UTC時刻を選ぶと20面・最初の半月n150、風配はhour_subset_not_available。上層へのhour要求はCLIMATE_HOUR_SUPPORT。空・重複・boolean・非native・float・文字列のhoursはCLIMATE_INPUT。
- 全4UTCを順不同で指定しても省略時と同じqueryになり、annual再SQLを禁止した状態でcache再利用できた。返却済みannualを意図的に書換えても内部cacheは変わらなかった。
- source snapshotをmemory mockで変更すると、cached queryもCLIMATE_ADAPTER_CHANGED。実ファイルの改変試験ではない。
- service identityは全4UTCを正規化し、hour subsetを別の保存cacheキーへ結ぶ。
- v2追加項目を除きv1版名を付けた合成の旧artifactを、memory-only SELECT応答から `_read_artifact` が読めた。実旧DBへの書込み/移行/再起動試験ではなく、旧形状の読取経路を確認したもの。

## コード上の判断

`aggregation.py` は各cellでn重みの時間合成を先に行い、その後Gaussian重みで地域平均する。cellmean幅も合成後の最大−最小であり、元半月の幅を平均していない。方向・定常度は合成u/v/sから再計算し、undefinedを保持する。periodsは非重複のUTC半月集合を月/季節へ結び、DJFを連続10冬と呼ばない。

`extensions.py` はpresentな拡張表の型・件数・重複・key・n支持・finite/風速条件・使用単位を検査する。roseは16方向/6速度binを実定義と照合し、全期/全層のcount総数をnへ合わせる。欠けた拡張は能力なし、存在するが壊れた拡張は登録拒否という境界で、subset欠測を全時刻値で補わない。

sourceの地域cacheにはhoursが入り、上限4とdeepcopyを維持する。新7pyのhashはadapter snapshotに入り、DB statとcode guardを読取り前後で通る。serviceは長いDuckDB集計をSQLite transaction外・別work lockで行い、公開前にsourceを再確認する。保存GET/同じ受付IDの再読は現在sourceを要求せず、旧artifactの保存hashを検査する。adapter/statistics版とcode/DB/duckdb/queryの識別を新しい保存cacheへ含める。sourceを差替えたことを旧結果の再解析へ読み替えない。

## 残る受入範囲

FEは今回の並行担当範囲で、本レビューでは実画面を見ていない。地域外代表点、UTC暦/JST時刻、非対応上層・風配、圧力面とISA目安高度、旧artifactに月/季節がない場合の表示をユーザーが読めるかは、画面受入で確認する。

全時刻summaryのcompact UTF-8は6,560,144 bytes、00/18UTCは5,911,862 bytes（JSON本体の計算値でHTTP転送量ではない）。grain操作で再SQLしない利点と引換えに応答・保存・parse量が増える。DuckDBの128MB指定をprocess全体のRSS上限としない。実表示までの待ち時間は未測定で、主担当のUI確認へ残す。

source登録は時刻別と全時刻のmeansを相互再合成照合していないが、提供実DBについては前巡probeで4時刻のn完全一致・平均最大差2.87e-6m/s以内を独立確認済み。別の同形式DBにも一般化する場合は、その整合検査が拡張候補となる。今回の固定提供DBで追加の取得・科学モデルを採用する必要条件とはしない。

この結果は実統計の読取・集約の有限確認である。raw時系列の取得完全性、年別推定、任意時刻内の風、共同気象場、飛行精度、較正済み予報確率の受入ではない。