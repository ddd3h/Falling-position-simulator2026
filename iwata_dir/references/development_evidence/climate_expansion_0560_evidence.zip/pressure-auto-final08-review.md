# round08 圧力探索と平均補助ラベル：最終の有限批評

2026-10-02 JST。担当 map_refresh_review。対象は frontend-implementation08.json の固定候補と、frontend-source08 / index07/source。source 読解と固定 byte 照合だけを実施し、repo 編集、UI/API/DB 操作、テスト/build の再実行は行っていない。実画面は主担当が別途確認する。基準・旧票を上書きせず round07 の見落としと処置を維持する。

## 判断

今回の限定差分では、新しい重大なデータ競合や、母集団を混ぜるキャッシュ誤採用は見つからなかった。圧力の自動適用、旧応答の失効、既受領面への再訪はコード上で整合する。平均図の 2 文変更は未接続を正しく知らせる訂正として妥当であり、中央値＋月 p10–p90 の要求を実装済みにする変更ではない。

## 読解結果

- useClimateWorkspace.ts の selectPressure は invalidate 前に pending.due を取得し、後続 input でも最初の 300 ms の期限を延ばさない。queue は 1 active＋最新 1 pending のまま、active 完了後に due 済みの最新要求を実行する。cache hit と表示済み面への復帰も、先に epoch を進めるので途中の応答を誤採用しない。
- LRU は最大 6 artifact。key は dataset SHA＋正規化した query 全体（source/領域/UTC/grain/level）。remember は現在表示の populationKey と dataset も確認する。異なる母集団の面を同じ level という理由だけで取り出さない。
- 明示再集計、source 変更、restore、dispose、catalog 受領が cache generation を更新する。古い valid response は、同じ cache 世代かつ同じ母集団なら cache に限って保存できるが、表示採用は token 一致の後に限る。後でその面を利用者が再選択して初めて表示できる。manual 世代を越えた応答は cache も再充填しない。
- 応答採用時の明示 draft query は clone、editQuery 入力も clone。圧力採用は draft 全体を書き戻さない。mutable draft の編集で cache 内の artifact.query を変える経路は、この接点では見つからなかった。
- reader でも同じ画面で受領済みの cache は POST なしで再表示できる。未受領面は送信権確認後だけ送る。送信権の取得だけで古い希望を自動送信しない。source 不在/支持外の要求は図を保持して理由を表示する。
- WeatherScreen と controller の round07 の対処（自動圧力待ち中の valid 手動適用、2 本の slider の希望/表示区別）は保持されている。controller の新差分は「平均風速（補助図）」と「中央値と10–90%幅の図は未接続」の 2 箇所のみで、統計値や固定図/保存 capture を変更していない。

## 今回の限界を明示する

1. 300 ms は、前の active request が終わっている場合の送信開始待ちであり、応答・描画完了の上限ではない。未受領面を連続変更し続ければ最新希望に一致する応答がない間は旧図を保持する。古い圧力結果を途中で見せて更新したように扱わない設計なので、人工 RAF と同等の滑らかさをこの source 検査から認定しない。
2. 6 面 LRU はこの画面内の有限再訪用で、全 38 面の事前集計/cache、再訪履歴の永続化、ネット障害からの瞬時復帰を実装した意味ではない。cache の表示は保存参照 applied を更新するが、cache 自体は計画保存の権威にはならない。
3. HTTP timeout/abort と server work の停止は別。1 active の保証は client promise の寿命についてであり、通信が切れた backend 計算が既に終了した証明ではない。
4. mean の補助表示と未接続注記は当面の誤認を減らす。中央値＋月内幅の実接続、同じ 12 月比較、必要な原標本取得/再利用は analysis-question-review.md の未達要件・優先順として残る。
5. 実 UI の drag 追従、描画負荷、全地域/全端末の性能、科学的妥当性は本票で確認していない。主担当の実画面証拠は本票とは別に扱う。

## 固定照合と試験票の扱い

changed 3 path は current / frontend-source08 / index07/source / frontend-implementation08 と一致した。WeatherScreen、climateSummary、export の追加 3 接点も current と index07/source および inputs の hash が一致した。6 path のみを自分で照合しており、全 233 source を自分で再監査したとは扱わない。

frontend-tests10.json は 52/52、失敗 0、success true と読取確認。担当 implementation08 票は tsc/build exit 0、dist08 を記録し、build log 末尾も成功を確認した。全 319/319 の frontend-full02 は round07 の以前の結果であり、最終 max-wait/LRU に対する全 suite の再実行と読み替えない。自分は今回テストを実行していない。index07 receipt/readback の全 233 一致記録も担当の検査結果として受領した。

詳細 byte 指紋、読取票 hash は pressure-auto-final08-review.json に保存する。新しい阻害指摘はなし。ここで閉じるのは上記差分の有限 source review であり、気象分布機能全体の完成・main への統合・利用者採用ではない。
