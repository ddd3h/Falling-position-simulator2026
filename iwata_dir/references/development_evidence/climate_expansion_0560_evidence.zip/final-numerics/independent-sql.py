"""Compare saved implementation JSON with independent SQL expressions and calendar arithmetic.
Never writes DBs or calls app/API/network. Output is a separate JSON receipt.
"""
import calendar, hashlib, json, math, sys
from collections import defaultdict
from pathlib import Path
import duckdb
P=Path(__file__).resolve().parent
DB=Path('C:\\Users\\genia\\AppData\\Local\\Temp\\balloon-seasonal-550\\climate-input550\\jra3q_hokkaido_wind_2016-2025_v1.duckdb')
con=duckdb.connect(str(DB),read_only=True,config={'enable_external_access':False,'threads':1,'memory_limit':'128MB','autoload_known_extensions':False,'autoinstall_known_extensions':False,'max_temp_directory_size':'0B'})
def readrows(sql,args=()):
 c=con.execute(sql,args);names=[d[0] for d in c.description];return [dict(zip(names,r)) for r in c.fetchall()]
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def canon(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
result={'method':'saved output versus independent SQL with CASE period grouping, raw time-space weighted means, cell-wise extrema; no production aggregation/statistics/periods imports','inputs':{},'cases':{},'failures':[]}
def near(a,b,path,tol=1e-9):
 if a is None or b is None:
  ok=a is None and b is None;delta=0 if ok else None
 else:delta=abs(a-b);ok=delta<=tol
 if not ok:result['failures'].append({'path':path,'actual':a,'expected':b,'difference':delta})
 return delta or 0
for filename in ('summary-full.json','summary-hours.json'):
 path=P/filename;s=json.loads(path.read_text(encoding='utf-8-sig'));result['inputs'][filename]={'sha256':digest(path),'bytes':path.stat().st_size,'query':s['query']}
 signed=s['provenance']['result_hash'];unsigned=json.loads(json.dumps(s));unsigned['provenance'].pop('result_hash');near(int(signed,16),int(hashlib.sha256(canon(unsigned).encode()).hexdigest(),16),filename+'/result_hash',0)
 hours=s['query'].get('hours_utc');table='fact_wind_diurnal' if hours else 'fact_wind';bounds=s['query']['bounds'];args=[bounds['west'],bounds['east'],bounds['south'],bounds['north']]+(hours or [])
 where='g.lon>=? AND g.lon<=? AND g.lat>=? AND g.lat<=?'+(' AND w.hour_utc IN ('+','.join('?' for _ in hours)+')' if hours else '')
 grainresults={}
 for grain,expr in [('half','w.timebin_id'),('month','CAST(floor(w.timebin_id/2) AS INTEGER)'),('season','CASE WHEN w.timebin_id IN (0,1,2,3,22,23) THEN 0 WHEN w.timebin_id BETWEEN 4 AND 9 THEN 1 WHEN w.timebin_id BETWEEN 10 AND 15 THEN 2 ELSE 3 END')]:
  block={'annual':s['annual'],'spatial_rows':s['spatial']['rows'],'timebins':s['population']['timebins'],'wind_rose':s['wind_rose'],'display_scales':s['display_scales']} if grain=='half' else s['summaries_by_grain'][grain]
  base=f'SELECT {expr} AS period_id,w.level_id,w.cell_id,w.n,cast(w.u_mean as double) u,cast(w.v_mean as double) v,cast(w.speed_mean as double) speed,g.gauss_weight weight FROM {table} w JOIN dim_grid g USING(cell_id) WHERE {where}'
  sql=f'''WITH base AS ({base}),cells AS (SELECT period_id,level_id,cell_id,sum(n*speed)/sum(n) speed,sum(n) n FROM base GROUP BY ALL),
    regional AS (SELECT period_id,level_id,sum(u*n*weight)/sum(n*weight) mean_u,sum(v*n*weight)/sum(n*weight) mean_v,sum(speed*n*weight)/sum(n*weight) mean_speed FROM base GROUP BY ALL),
    spread AS (SELECT period_id,level_id,max(speed)-min(speed) spatial_mean_speed_range,max(speed) max_cell_mean_speed,count(*) cell_count,min(n) time_count,max(n) max_n FROM cells GROUP BY ALL)
    SELECT * FROM regional JOIN spread USING(period_id,level_id) ORDER BY period_id,level_id'''
  reference=readrows(sql,args);actual={(r['timebin_id'],r['level_id']):r for r in block['annual']};max_errors=defaultdict(float)
  near(len(actual),len(reference),filename+'/'+grain+'/annual_row_count',0)
  for r in reference:
   key=(r['period_id'],r['level_id']);a=actual[key];r['pooled_constancy']=math.hypot(r['mean_u'],r['mean_v'])/r['mean_speed'] if r['mean_speed'] else None;r['from_deg']=(math.degrees(math.atan2(r['mean_u'],r['mean_v']))+180)%360 if math.hypot(r['mean_u'],r['mean_v']) else None
   for name in ('mean_u','mean_v','mean_speed','spatial_mean_speed_range','max_cell_mean_speed','cell_count','time_count','pooled_constancy','from_deg'):
    max_errors[name]=max(max_errors[name],near(a[name],r[name],f'{filename}/{grain}/annual/{key}/{name}'))
   near(a['valid_time_count'],r['time_count'],f'{filename}/{grain}/valid/{key}',0);near(a['missing_time_count'],0,f'{filename}/{grain}/missing/{key}',0);near(r['time_count'],r['max_n'],f'{filename}/{grain}/uniform_support/{key}',0)
  sref=readrows(f'WITH base AS ({base}) SELECT period_id,cell_id,sum(n*u)/sum(n) mean_u,sum(n*v)/sum(n) mean_v,sum(n*speed)/sum(n) mean_speed,sum(n) time_count FROM base WHERE level_id=? GROUP BY ALL ORDER BY period_id,cell_id',args+[s['spatial']['level_id']]);sactual={(r['timebin_id'],r['cell_id']):r for r in block['spatial_rows']};near(len(sref),len(sactual),filename+'/'+grain+'/spatial_row_count',0)
  for r in sref:
   key=(r['period_id'],r['cell_id']);a=sactual[key];r['constancy']=math.hypot(r['mean_u'],r['mean_v'])/r['mean_speed'] if r['mean_speed'] else None;r['from_deg']=(math.degrees(math.atan2(r['mean_u'],r['mean_v']))+180)%360 if math.hypot(r['mean_u'],r['mean_v']) else None
   for name in ('mean_u','mean_v','mean_speed','time_count','constancy','from_deg'):max_errors['spatial_'+name]=max(max_errors['spatial_'+name],near(a[name],r[name],f'{filename}/{grain}/spatial/{key}/{name}'))
  days_by_month={m:sum(calendar.monthrange(y,m)[1] for y in range(2016,2026)) for m in range(1,13)}
  for period in block['timebins']:
   idx=period['timebin_id'];days=(150 if idx%2==0 else days_by_month[idx//2+1]-150) if grain=='half' else days_by_month[idx+1] if grain=='month' else sum(days_by_month[m] for m in [[12,1,2],[3,4,5],[6,7,8],[9,10,11]][idx]);near(period['n_days_total'],days,filename+'/'+grain+'/days',0);near(period['n_analyses_expected'],days*len(hours or [0,6,12,18]),filename+'/'+grain+'/expected',0)
  rose=block['wind_rose']
  if hours:
   if rose!={'available':False,'reason':'hour_subset_not_available'}:result['failures'].append({'path':filename+'/'+grain+'/rose_unavailable','actual':rose})
   rose_count=0
  else:
   rexpr=expr.replace('w.','r.');rref=readrows(f'SELECT {rexpr} period_id,r.sector,r.speed_class,sum(r.count) AS count FROM fact_wind_rose r WHERE r.level_id=? GROUP BY ALL ORDER BY period_id,sector,speed_class',[s['spatial']['level_id']]);ra={(r['timebin_id'],r['sector'],r['speed_class']):r for r in rose['rows']};totals=defaultdict(int)
   for row in rref:totals[row['period_id']]+=row['count']
   for row in rref:
    key=(row['period_id'],row['sector'],row['speed_class']);a=ra[key];near(a['count'],row['count'],f'{filename}/{grain}/rose/{key}/count',0);near(a['time_count'],totals[row['period_id']],f'{filename}/{grain}/rose/{key}/n',0);near(a['frequency'],row['count']/totals[row['period_id']],f'{filename}/{grain}/rose/{key}/frequency')
   near(len(ra),len(rref),filename+'/'+grain+'/rose_row_count',0);rose_count=len(rref)
  scales=block['display_scales']
  for name,key,sel in [('all_level_cell_mean_speed_max','max_cell_mean_speed',reference),('selected_level_cell_mean_speed_max','max_cell_mean_speed',[r for r in reference if r['level_id']==s['spatial']['level_id']]),('annual_mean_speed_max','mean_speed',reference),('spatial_mean_speed_range_max','spatial_mean_speed_range',reference)]:near(scales[name],max(r[key] for r in sel),filename+'/'+grain+'/scale/'+name)
  grainresults[grain]={'annual_rows_checked':len(reference),'spatial_rows_checked':len(sref),'rose_rows_checked':rose_count,'max_absolute_errors':dict(max_errors)}
 result['cases'][filename]=grainresults
con.close();result['failure_count']=len(result['failures']);print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(bool(result['failures']))