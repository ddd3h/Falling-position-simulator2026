# 気圧面スライダー自動更新：事前の有限批評

2026-10-02。担当 map_refresh_review。ユーザーの追加指示は「実気象の気圧面sliderも、人工と同様にグラフを自動更新したい」。本票はround07実装前の設計読解と受入反例であり、実装済み/試験済みとは扱わない。repo編集、UI/API操作、DB操作なし。実装後の再批評は同票に版と根拠を区別して追記する。

## 目的に合う最小分離

圧力sliderの操作は、表示中の固定artifactのsource・地域・UTC時刻を保ち、level_idだけを変える要求にする。現在の `calculate()` をそのまま呼ぶとdraft_query全体を送るため、未適用の地域/時刻まで適用してしまう。さらに現在の成功処理 `draft_query:r.query` は未適用編集を消す。この2点をauto専用経路で分ける必要がある。

1. 自動要求は `{...appliedArtifact.query, level_id: requestedLevel}` を基礎に検証する。入力途中の地域空欄や、未適用UTCと面の不適合を、自動圧力要求の検証へ持ち込まない。圧力の支持はapplied条件で判断する。
2. 希望面は即座に表示し、300 ms程度の短いdebounce後に自動送信する。タブ内では送信中1件＋最後の希望1件だけを持つ。input/change二重通知と同じqueryの重複を除く。クリックのたびに全要求を積む構成にしない。
3. 受領するのは今も希望されているqueryだけ。旧artifactを描き続け、採用できる最新応答で図・面ラベル・固定出典を一括更新する。希望500/表示300を分け、受領前に旧図を500の図と表示しない。
4. 成功時はapplied/artifactを更新し、draftの地域/時刻を維持する。draftの面も合わせる場合は、ユーザーが後から面を編集していないことを照合する。別sourceの草案へ旧sourceの面を混ぜない。
5. manual再集計、別sourceへの編集、明示restore、disposeはauto待ちtimer/queuedの失効境界とする。manualも同じ送信待ちへまとめるなら、古いauto応答はmanualの新しい意図を巻き戻せないようにする。
6. 現資料不在、旧sourceだけのartifact、reader、対応外の面は理由を出して送信しない。権取得で過去の要求を無言に再送しない。失敗/blockedからの明示的な「この面を再試行」は通常操作時の再集計ボタンとは分ける。

frontend担当の計画も、300 ms・1 in-flight/最新1 pending・manualとの共通queue・artifact.queryからの圧力要求・草案の他項目保持・2本sliderの希望面共有・readerの明示retryという方針で一致した。これは計画の受領で、実コードの認定ではない。

## 必須の反例

| 操作 | 保つべき結果 |
|---|---|
| 地域B/UTC00を草案入力したまま、表示A（全時刻）の面を300→500 | POSTはAのsource/地域/全時刻と500だけ。B/UTC00は未適用のまま残る。 |
| 表示300、500送信中に300へ戻す | 最後の希望は300。新POSTが不要でも500の後着採用を失効させる。 |
| 300→500→700と連打、500が送信中 | 全中間値を送らず最後の700だけを待ち受ける。500の旧応答で表示が跳ね戻らない。 |
| auto500の待機中に準備欄の面selectを700へ編集 | draft700を500の受領で消さない。面編集を希望へ同期するか、面編集世代で受領mergeを抑える。 |
| auto500の待機中に地域/UTCだけを編集 | 最新の地域/UTCを保持する。auto要求には混入させず、旧条件の圧力比較として継続できる。 |
| auto待機中に手動Bを適用、または別sourceへ移る | 古いautoのqueue/応答はBを置換しない。manualの完了とbusy解除も別要求の状態を壊さない。 |
| source/restore/disposeが切り替わる直前に応答が来る | lifetimeと意図世代を照合し、別の保存図を巻き戻さない。 |
| 全時刻38面→UTC subset20面を明示適用 | sliderの面列とindexは新artifactに追従し、古いindexを別圧力のIDとして使わない。 |
| 最新圧力要求が失敗、旧図はある | 図/図保存は旧artifact、希望面と失敗理由を表示。再試行は同じ要求の受付を照合し、失敗を別母集団で補わない。 |
| readerまたは旧sourceの図を再読 | 図は維持し、権限/source更新の理由が見える。自動POSTを連打しない。 |

HTTP abort/timeoutは、backend計算の取消完了を意味しない。1件送信中という整理はタブ内の待機制御であり、未知の受付を未実行と断定するものではない。同じ固定queryの再試行では既存の受付/結果照合を活用する。

## ラベルと保存の境界

地域図と風配は同じselectedLevelを使うため、2本sliderは共有した希望面に同期する。旧図の選択面はartifact、希望面はpendingとして分ける。annual/profileが全高度を描くという意味は変えない。通常の面操作では別の「再集計」クリックを要求せず、blocked/失敗時にだけ回復操作を出す。

SVG準備中の自動面更新も、既存のcapture済みsnapshotを変更しない。生成済みlinkと生成時条件は旧図の一組として残り、次の成功生成でだけ置換する。

## 前件の保存受領証拠

主担当から、ユーザーが「保存できた」と報告し、rootが実SVGを読戻したという別票 `export-final-receipt.json` を受領した。本担当はその票を読み、ファイル名、641,772 bytes、SHA-256 `0a00045cedb12c0c45f5e32427953f59f56f102e667c14087f6836512ae84000`、XML parse、期間名一重、month/300 hPa/artificial=falseという記録を確認した。本担当自身がブラウザや実SVGを操作/検証したという扱いにはしない。

前票 `final-download-review.md` の未確認は本担当の当時の直接確認範囲として維持し、主担当の受領実績をこの別票で補う。dist04の失敗原因が確定したとは読み替えない。

## 実装後に読む接点

useClimateWorkspaceのqueue/epoch/receipt、WeatherScreenのbridgeと草案入力、climateControllerのinput/change・2本slider同期・旧図ラベル、SVG準備のcapture境界に限定して再批評する。新しい待機制御が旧保存GET/復元を止めないことも確認する。テスト成功だけで実ユーザーが期待する操作速度や連続ドラッグの読みやすさを認定しない。


## round07 実装の有限読解（2026-10-02 JST）

repo 編集・UI/API/DB 操作・テスト実行は行っていない。useClimateWorkspace.ts、WeatherScreen.tsx、climateController.js、climate.test.ts を読み、climateDomain/climateApi と既存 export の固定 snapshot 接点を照合した。読解後の初回照合では 4 source の SHA256 が frontend-implementation07.json と全て一致した。その後の票保存時照合では climateController.js だけ後続並行変更を検出したため、この節は round07 読解の記録であり現編集全体の閉鎖判定ではない（詳細 pressure-auto-review-round07.json）。frontend-tests09.json の 49/49 と frontend-full02.json の 319/319、担当票の tsc/build exit 0 を読取確認した。これは自分で回帰や実画面を実行した証拠ではない。

### 安全性・接点の判断

この有限読解では、新しい重大なデータ race は見つからなかった。

- useClimateWorkspace.ts の selectPressure は最初に invalidate し、固定 artifact.query に level_id だけを重ねる。既に表示中の面へ戻って POST 不要になる場合も古い応答は失効する。入力時に同 source の draft の level だけを変え、受領時には draft を変更しないため、地域/UTC 草案や後続の明示面編集を巻き戻さない。
- editQuery は pressure 意図があるときの同 source・同 level の地域/UTC 編集だけを継続扱いする。別 source/明示 level/manual/restore/dispose は待ち timer と pending を破棄する。実行中 promise は最後まで 1 active として占有し、世代が違う応答を図へ採用しない。
- pump は active が終わってから最新 pending だけを実行する。manual も同じ queue を使う。受付不明の同 query 再試行は同じ receipt を使い、owner 取得だけでは再送しない。HTTP timeout が server 作業の終了を証明するものではないという制限は残る。
- WeatherScreen の bridge は selectPressure/retryPressure を呼ぶ。地域と UTC の未適用表示は維持する。controller は input から起動し change で二重送信せず、2 本の slider が同じ pressure 希望面を表示する。実図・表示面ラベル・SVG capture は artifact のままなので、希望面を未受領の図へ付けない。
- 旧保存 GET は再集計を伴わず利用できる。現 source 不在/reader/対応外は理由を表示して POST を止め、明示 retry を用意する。固定図や既存生成済み SVG link をエラーで消さない。

### 独立指摘と処置

1. 自動圧力 POST の待機中に地域/UTC を編集しても busy が続くため、旧ボタン条件では valid な手動適用を最大 60 秒押せなかった。担当は busy && !pressure のときだけ手動ボタンを止め、自動探索中には「この対象で再集計（気圧面探索を置換）」を許すよう訂正した。source 再読で確認。manual 開始後 pressure は null なので二重クリック抑止を保つ。
2. 表示中の面へ戻って early return した際、以前の待機 status が残る点を指摘。担当は「表示中の気圧面に戻りました。途中の更新要求は図へ適用しません。」へ更新し、回帰期待を追加した。source 再読で確認。
3. **目的上の残件：300 ms は trailing debounce である。** input が 300 ms 未満で連続するドラッグでは図の POST は始まらず、止めてから更新する。「追加クリックなしで自動適用」は成立するが、人工 RAF と同じ「動かしながら図形/色を追う」ことは同義ではない。自分の事前案もこの点を詰め不足だった。root/frontend430 へ通知済み。短期候補は throttle/max-wait と 1 active/latest pending の組合せ、長期候補は同母集団の多面集計/cache を読取って圧力を表示操作にする経路。採用・実装・実UI性能は未確認であり、この版を「人工と同等のドラッグ途中更新も完了」とは判定しない。

### 別の目的上の残件

中央値＋月 p10–p90 の主図が平均線へ置き換わった問題は、圧力 queue が正しくても解決しない。新しい独立票 analysis-question-review.md に、問いの差、提供 DB の有効な活用と限界、原標本取得/再利用からの実装優先順を分けて記録した。元図との対応・科学的妥当性・利用者による採用を、この hook の 319 tests 成功から導かない。

保存時追記：climateController.js は round07 の 689998bcf12f371b601b774cd8a520d2e0f594a01830b631894c4d5b3d019f1b から current 75a6ef05dddbaa1b0a202a05208e5e173ce4727d04baed073c8cd89fd314727e へ変化を検出。hook/WeatherScreen/test は round07 と一致。後続変更の意味はこの票ではまだ認定しない。


## round08 の閉鎖先

最終 max-wait / 6 面 cache / 平均補助 2 文の有限 source review は pressure-auto-final08-review.md と JSON に保存した。新しい阻害指摘なし。最終 3 source の固定候補一致を確認。round07 の trailing debounce 留保と並行変更検出は当時の記録として保持し、round08 の更新と限界は新票へ戻る。
