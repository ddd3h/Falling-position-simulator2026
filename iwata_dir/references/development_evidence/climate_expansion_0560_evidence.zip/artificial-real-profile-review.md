# Artificial / real profile meaning: bounded code read

## What the artificial profile actually shows
- `frontend/src/screens/weather/controller.js:36-40` selects artificial records by chosen JST years/hours, partitions those actual dated records into calendar month/half/quarter, and builds `monthStats` and `halfStats`.
- `frontend/src/screens/weather/sources/fixtureSummary.ts:2` pools `F.value(record,point,level)` over every selected record and all nine original grid points separately at each pressure level. There is no area weighting; the artificial mean and distribution population includes both temporal and spatial variability.
- `frontend/src/screens/weather/fixture.js:35-36` converts each vector to scalar speed, sorts speeds, and uses linear order-statistic interpolation at `(N-1)*p` for p10, median and p90.
- `frontend/src/screens/weather/controller.js:70` draws a **monthly** p10–p90 polygon and two curves: preceding/following half-month medians. `:77` states that same definition. The profile is always twelve monthly panels; the month/half/season selector belongs to rose mode, not to profile statistics.
- `fixture.js:14-22` defines artificial half-month calendar splits with rotating spare days. This is not invariably UTC days1–15/16–end. `:7` uses approximate `z=7.2 ln(1000/p)` km at sixteen levels.

## What the real profile currently shows
- `frontend/src/screens/weather/sources/climateSummary.ts:17` carries fixed supplied period mean scalar speed, Gregorian UTC groups, selected grid support and a Gaussian spatial-weight definition. `frontend/src/screens/weather/climateDistributions.ts:47-53` plots that **one mean-speed curve** on fixed ISA altitude.
- It does not currently display empirical median or variability width. Renaming it "mean vertical structure" is truthful, but it answers a different question from the artificial monthly distribution profile.
- Therefore the missing width is a functional gap for reading seasonal variability, not merely a cosmetic difference justified by avoiding fabricated quantiles. The supplied real-data quantiles need their original population/grain/support evaluated before choosing how to display them. A regional pooled quantile cannot be obtained by averaging per-cell or per-half quantiles, but an honestly labelled supported point/period quantile view may still be useful. Data feasibility is parent work.

## Implication / limits
Keep both the user's distribution question and the original artificial experience visible in the design decision. Do not claim the mean-only replacement reproduces the artificial profile. Likewise do not promise an identical region-pooled monthly band until the real source supports it. Differences in year/hours availability, UTC/JST calendar, spatial weights, pressure support and altitude axis must be stated where they affect interpretation; they are not a reason to silently remove the distribution question.

Read-only review; no new profile implementation, no independent numerical validation of the database, and no browser acceptance claimed.
