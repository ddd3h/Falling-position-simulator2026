"""Read-only adapter boundary checks; legacy artifact is an in-memory synthetic row, not a DB write."""
import copy,hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
sys.path.insert(0,str(ROOT))
from backend.climate.source import ClimateSource,adapter_source_snapshot
from backend.climate.contracts import ClimateQuery,ClimateError,Bounds
from backend.climate.service import ClimateService,ARTIFACT_SCHEMA
P=Path(r'C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/climate-expansion550')
DB=P.parent/'climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb'
r={'method':'actual source read-only queries and memory-only mocks; no test DB created; no API','source_snapshot_before':adapter_source_snapshot(),'checks':{}}
s=ClimateSource(DB,expected_sha256='1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a');d=s.descriptor();c=d['native_grid'][0];b=Bounds(c['lon'],c['lon'],c['lat'],c['lat']);q=ClimateQuery(s.source_id,18,b)
a=s.query(q);r['checks']['outside_region_rose']={'point_in_selected_region':a['wind_rose']['point_in_selected_region'],'selected_cells':a['population']['selected_cell_count'],'rose_cell':a['wind_rose']['point']['cell_id'],'available':a['wind_rose']['available']};assert a['wind_rose']['point_in_selected_region'] is False and a['wind_rose']['available']
a['annual'][0]['mean_speed']=-999
with patch('backend.climate.aggregation.annual',side_effect=AssertionError('cached annual should not be recomputed')):
 fixed=s.query(ClimateQuery(s.source_id,18,b,hours_utc=[18,0,6,12]));assert fixed['annual'][0]['mean_speed']>=0
r['checks']['explicit_all_hours_normalization_and_unpoisoned_annual_cache']=True
one=s.query(ClimateQuery(s.source_id,18,b,hours_utc=[0]));assert len(one['levels'])==20 and one['wind_rose']['available'] is False and one['annual'][0]['time_count']==150
r['checks']['single_hour_support']={'levels':len(one['levels']),'first_time_count':one['annual'][0]['time_count'],'rose':one['wind_rose']}
def rejected(label,fn,expected):
 try:fn()
 except ClimateError as e: assert e.code==expected,(label,e.code);r['checks'][label]=e.code
 else:raise AssertionError(label+' unexpectedly accepted')
rejected('unsupported_upper_hour_selection',lambda:s.query(ClimateQuery(s.source_id,0,b,hours_utc=[0])),'CLIMATE_HOUR_SUPPORT')
for label,h in [('empty',[]),('duplicate',[0,0]),('bool',[False]),('non_native',[3]),('float',[0.0]),('string','0')]:rejected('invalid_hours_'+label,lambda h=h:ClimateQuery(s.source_id,18,hours_utc=h),'CLIMATE_INPUT')
with patch('backend.climate.source.adapter_source_snapshot',return_value={'files':{},'sha256':'changed'}):rejected('source_guard_rejects_cached_query',lambda:s.query(q),'CLIMATE_ADAPTER_CHANGED')
# _identity makes bounds and normalized hours part of the persistent cache identity.
base=ClimateService._identity(d,q);allhours=ClimateService._identity(d,ClimateQuery(s.source_id,18,b,hours_utc=[12,18,6,0]));hour=ClimateService._identity(d,ClimateQuery(s.source_id,18,b,hours_utc=[0]));assert base==allhours and base!=hour;r['checks']['service_identity_distinguishes_subset_and_normalizes_all']=True
# Strip the additive v2 members to model the prior artifact shape. This is synthetic compatibility evidence.
legacy=copy.deepcopy(fixed);legacy.pop('summaries_by_grain');legacy.pop('wind_rose');legacy['source']['adapter_version']='jra3q-halfmonth-summary/1';legacy['source']['statistics_version']='gaussian-pooled-wind/1';legacy['provenance']['adapter_version']='jra3q-halfmonth-summary/1';legacy['provenance']['statistics_version']='gaussian-pooled-wind/1'
for k in ['display_grains','hour_level_ids','wind_rose','wind_rose_hours_utc']:legacy['source']['capabilities'].pop(k,None)
legacy['source']['capabilities']['hour_filter']=False;legacy['source'].pop('wind_rose_point',None)
for v in legacy['population']['timebins']:v.pop('member_timebin_ids',None);v.pop('label',None)
def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def h(x):return hashlib.sha256(x.encode()).hexdigest()
legacy['provenance'].pop('result_hash');legacy['provenance']['result_hash']=h(canonical(legacy));aid='10000000-0000-4000-8000-000000000001';artifact={'schema':ARTIFACT_SCHEMA,'analysis_id':aid,'created_at':'2026-10-02T00:00:00Z','query':legacy['query'],'summary':legacy,'query_hash':legacy['provenance']['query_hash'],'result_hash':legacy['provenance']['result_hash']};raw=canonical(artifact);row={'artifact_json':raw,'artifact_sha256':h(raw),'artifact_bytes':len(raw.encode()),'query_hash':artifact['query_hash'],'result_hash':artifact['result_hash']}
class Cursor:
 def fetchone(self):return row
class ReadOnlyFakeConnection:
 def execute(self,sql,args):assert sql.startswith('SELECT ');return Cursor()
assert ClimateService._read_artifact(ReadOnlyFakeConnection(),aid)==artifact;r['checks']['synthetic_v1_artifact_read_without_source']=True
r['source_snapshot_after']=adapter_source_snapshot();assert r['source_snapshot_before']==r['source_snapshot_after'];print(json.dumps(r,ensure_ascii=False,indent=2))