# 0.56 最終の有限リスク評価

2026-10-02。担当 map_refresh_review。基準は主担当固定PR31 `cbc197276d14c5753cc112643e449abaeb3bb29f` / main `06936856ee0deab2fe0b3f3b04220d60652ffba6`、評価対象はその後の現作業source。repo変更、ブラウザ/UI、API呼出、DB照会/書込、再build/test、追加通信は本巡で行っていない。本文の批評と、主担当の実UI実績、数値証拠を分ける。

## 結論

0.56の目的である「供給DBを用い、月/季節と対応時刻の平均を比較し、固定代表点の経験風配を見る」範囲で、新しい重大な残存不具合は見つからなかった。根拠は成功テスト件数だけではなく、入力から固定保存・表示・図出力までのsource接点と、実DBからの独立数値照合である。将来の飛行確率、raw共同場、任意地点/時刻の分布を受け入れた判定ではない。

既知round04の3点も最終sourceで読戻した。旧sourceは現在の資料に見せずdisabledの明示optionを置く。季節図のHTML見出しは視覚上だけ隠してSVG内の期間名を残す。exportはSVG内期間ラベルがあるprofile/roseに外側ラベルを重ねない。これらを新しい指摘や本担当によるUI確認へ数え直していない。

## 主要接点の判断

| 観点 | 根拠となる実装 | 有限な判断 |
|---|---|---|
| 実資料の範囲 | source.py:226–253, 269–272 / WeatherScreen.tsx:23–33 / climateSummary.ts | 全4時刻は38面、subsetはdescriptorの20面。未対応上層を低層値で補わず、年部分選択/raw/分位再構成を表示能力に加えていない。圧力面のISA目安を地表や同時刻実高度と呼ばない。 |
| 月/季節と時刻の重み | aggregation.py:17–77 / periods.py:9–28 / statistics.py:12–27 | cell内でn重み結合し、その後Gaussian重み。期間のcellmean幅とR/FROMを再計算する。角度・R・半月幅・分位の平均で代用しない。DJFは供給暦年内の月pool。 |
| 風配の分母 | extensions.py:98–119 / climateDistributions.ts:8–19, 29–51 | 元16方向×6速度階級のcountを合算し一点のNで割る。FEもcount/N・全階級合計・期間/面キーを照合。全時刻限定、固定代表点と地域内外を明示。subsetなら風配不可を表示し、全時刻の風配へ無言で置換しない。静穏の独立分類を作らない。 |
| 旧保存互換 | service.py:_read_artifact/get_analysis/create_analysis / climateSummary.ts:7–12 / climateController.js:40–56 | 旧固定GETは現DB/現sourceを要求しない。halfだけのartifactはhalfだけから描画し、月/季節を持つように見せない。再集計は現sourceの明示選択とPOSTへ分ける。旧queryの同じ受付IDは先に既存受付を照合する。 |
| 固定結果と編集 | useClimateWorkspace.ts:8–28 / WeatherScreen.tsx:19–33 | 草案変更は表示済artifactを書き換えず、generation/epoch/acceptedが後着応答を選別する。未適用の地域/時刻も気圧面変更と同時に適用される場合は説明を出す。失敗時に人工値へ切替えず、GET復帰とPOST再試行を区別する。 |
| 保存SVG | climateController.js:78–85 / export.ts:3–19 | 保存開始時にDOM、VM metadata、表示粒度・対象期間・選択面・source/query/resultの識別を同期して固定。await中の画面変更で内容を再読しない。元期間全体の所属情報と実際に保存した表示期間を別項目で保持。風配は代表1格子の母数と元階級凡例を保存する。 |
| 関心の引継ぎ | ClimateFlightHandoff.tsx:3–10 / historicalWorkspace.ts:5–23 | UTC期間・元半月ID・有効時刻の関心を渡すだけで、放球時刻や瞬時場へ置換しない。旧half関心も読める。 |
| 操作の継続 | climateController.js:38–44, 85–93 / useClimateWorkspace.ts:10–27 / api.ts:24–52 | 粒度変更は固定VM内で完結しPOSTしない。読取/再集計に待機時間とdispose時abortがある。新しい集計中も旧図は保持。write leaseはPOSTの入口で要求し、読取図はwriter専用にしていない。 |

上の行番号は読取時点のsourceで、全文の全分岐・全プラットフォームの動作保証ではない。関連22ファイルの終端指紋は `final-independent-review.json`。小さな読取窓の前後でその集合の指紋が一致した。

## 数値証拠と実操作の区別

本担当が作った独立SQL probeを主担当が最終版に対して再実行した `final-numerics/independent-backend-sql-result.json` を読んだ。結果は6組（全時刻/00・18 UTC × 半月/月/季節）、annual 2,320行、spatial 45,600行、rose 3,840行でfailure 0。本巡では再実行していない。`binding.json` のbackend全8py指紋が現在sourceと一致し、入力2 JSONの実bytesが結果票のSHA-256と一致することを別途確認した。既存の境界probeにある1時刻、未対応上層、地域外代表点、cache保護、旧形状読取の確認は `independent-backend-review.md` を参照する。

主担当は実UIで、4季節/300 hPaの実風配、時刻subset平均、旧half artifact再読、新source選択と再集計、送信権取得、保存/restore、SVG export、夏UTC00関心引継ぎを確認したと報告している。本担当はこの実UIを操作/視認しておらず、この列挙は主担当実績である。テスト成功をこれらの代替にはしていない。

## 非阻害の残存境界

背景付き地域SVGの `embedWindBackground` はfetch/Blob/FileReaderをawaitするが、専用の期限を設けていない。通信が停滞すると図保存待ちが長引く可能性がある。画面の図/集計結果やナビゲーションは保持され、画面破棄または後続export時にabortされる。新しいprofile/rose SVGは地理院tileを使わない。これは継承された地域図exportの耐障害性の課題であり、本拡張の数値/旧保存互換を壊す重大阻害点とは判定しない。将来の短い期限/明示取消追加候補として残す。

原再解析との再照合、別DB版の科学的整合、任意year/hour、共同場、較正済み将来確率、全ブラウザ/全通信障害時の応答性は未確認。これらを未確認とすることは、提供DBで今回の比較機能を採用しない理由へ自動的に広げない。
