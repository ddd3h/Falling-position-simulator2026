"""Read-only supplied climate inventory/reaggregation check. No network or SQL writes."""
import calendar, hashlib, json, tarfile
from pathlib import Path
import duckdb
ROOT = Path(r'C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550')
TAR = Path(r'C:/Users/genia/Downloads/jra3q_hokkaido_wind_2016-2025_v1.tar.gz')
DB = ROOT/'climate-input550/jra3q_hokkaido_wind_2016-2025_v1.duckdb'
def digest(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
result={'method':'independent read-only SQL, supplier code not imported; no raw retrieval', 'duckdb':duckdb.__version__, 'archive':{'path':str(TAR),'bytes':TAR.stat().st_size,'sha256':digest(TAR)},'database':{'path':str(DB),'bytes':DB.stat().st_size,'sha256':digest(DB)}}
with tarfile.open(TAR,'r:gz') as t:
    result['archive']['members']=[{'name':m.name,'bytes':m.size,'type':'file' if m.isfile() else 'other'} for m in t.getmembers()]
    result['archive']['raw_members']=[m.name for m in t.getmembers() if m.name.endswith(('.nc','.grib','.grb','.csv','.parquet'))]
con=duckdb.connect(str(DB),read_only=True,config={'enable_external_access':False,'threads':1,'memory_limit':'128MB','autoload_known_extensions':False,'autoinstall_known_extensions':False,'max_temp_directory_size':'0B'})
def rows(sql):
    cur=con.execute(sql); names=[x[0] for x in cur.description]; return [dict(zip(names,row)) for row in cur.fetchall()]
result['schema']=rows("select table_name,column_name,data_type,is_nullable from information_schema.columns where table_schema='main' and table_name not like 'v_%' order by table_name,ordinal_position")
result['counts']={t:rows('select count(*) AS n from '+t)[0]['n'] for t in ['fact_wind','fact_wind_diurnal','fact_wind_rose','fact_speed_fit','fact_dir_fit','fact_drift']}
result['hours']=rows('select * from dim_hour order by hour_utc')
result['sectors']=rows('select * from dim_sector order by sector')
result['speed_classes']=rows('select * from dim_speed_class order by speed_class')
result['rose_cell']=rows('select * from dim_grid where is_rose_cell')
result['levels']=rows('select * from dim_level order by level_hpa')
result['timebins']=rows('select * from dim_timebin order by timebin_id')
result['metadata']=rows('select * from meta_dataset')
result['selected_definitions']=rows("select * from meta_column where table_name in ('fact_wind_diurnal','fact_wind_rose') or column_name in ('u_var','v_var','uv_cov','speed_std','u_unit_mean','v_unit_mean','exceed_gt10','resultant_length','n_eff')")
result['diurnal_support']=rows('select hour_utc,count(*) row_count,min(n) n_min,max(n) n_max,count(distinct cell_id) cells,count(distinct timebin_id) bins,count(distinct level_id) levels,sum(case when u_mean is null or v_mean is null or speed_mean is null or speed_std is null then 1 else 0 end) null_count from fact_wind_diurnal group by hour_utc order by hour_utc')
result['rose_n_conservation']=rows('select max(abs(r.n-w.n)) max_n_diff,min(r.n) min_n,max(r.n) max_n from (select timebin_id,level_id,cell_id,sum(count) n from fact_wind_rose group by all) r join fact_wind w using(timebin_id,level_id,cell_id)')
result['direction_fit_n']=rows('select min(d.n-w.n) min_diff,max(d.n-w.n) max_diff from fact_dir_fit d join fact_wind w using(timebin_id,level_id,cell_id)')
result['lowest_speed_min']=rows("select min(uniform_a_ms) speed_min from fact_speed_fit where family='uniform'")
result['hour_pooling']=rows('select max(abs(d.mu-w.u_mean)) u_error,max(abs(d.mv-w.v_mean)) v_error,max(abs(d.ms-w.speed_mean)) s_error,max(abs(d.sn-w.n)) n_error,max(abs(d.m2/(d.sn-1)-pow(cast(w.speed_std as double),2))) sample_speed_var_error from (select timebin_id,level_id,cell_id,sum(n) sn,sum(n*cast(u_mean as double))/sum(n) mu,sum(n*cast(v_mean as double))/sum(n) mv,sum(n*cast(speed_mean as double))/sum(n) ms,sum((n-1)*pow(cast(speed_std as double),2)+n*pow(cast(speed_mean as double),2))-pow(sum(n*cast(speed_mean as double)),2)/sum(n) m2 from fact_wind_diurnal group by all) d join fact_wind w using(timebin_id,level_id,cell_id)')
result['rose_unweighted_counterexample']=rows('select month,level_id,sector,speed_class,avg(cast(r.count as double)/w.n) unweighted_fraction,sum(r.count)*1.0/sum(w.n) correct_fraction,abs(avg(cast(r.count as double)/w.n)-sum(r.count)*1.0/sum(w.n)) absolute_error from fact_wind_rose r join fact_wind w using(timebin_id,level_id,cell_id,month,bin,level_hpa) group by all order by absolute_error desc limit 1')
con.close()
T=sum((366 if calendar.isleap(y) else 365)*4 for y in range(2016,2026)); result['calendar_analyses']=T
result['raw_array_estimates']={}
for label,times,levels,cells,variables in [('one_cell_ten_years_uv',T,38,1,2),('four_cells_ten_years_uv',T,38,4,2),('all_region_one_year_365days_uv',365*4,38,570,2),('january_ten_years_uv',31*10*4,38,570,2),('all_region_ten_years_uv',T,38,570,2),('all_region_one_hour_ten_years_uv',T//4,38,570,2),('all_region_ten_years_uv_H',T,38,570,3),('one_halfmonth_all_region_uv',600,38,570,2)]:
    b=times*levels*cells*variables*4;result['raw_array_estimates'][label]={'float32_bytes':b,'MiB':b/2**20,'GiB':b/2**30,'time_count':times,'levels':levels,'cells':cells,'variables':variables}
result['raw_array_estimates_note']='Uncompressed Float32 value arrays only. Not measured transfer/archive/RAM; excludes metadata, coordinates, temporary arrays and acquisition granularity. No remote availability claim.'
print(json.dumps(result,ensure_ascii=False,indent=2))