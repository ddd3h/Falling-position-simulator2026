# Pressure-only automatic exploration plan

User trigger: real-climate pressure sliders should update graphs as the artificial screen does, without applying unrelated draft population edits.

Read basis: frontend/src/useClimateWorkspace.ts, WeatherScreen.tsx, weather/climateController.js, climateDomain.ts, climateApi.ts and writeLease.ts. Existing calculate posts draft_query and replaces that draft with result.query, so directly calling it from the slider would apply or erase unrelated edits. Existing epoch drops late responses but permits simultaneous manual requests; the new small queue will serialize climate calculation requests.

- A slider request freezes artifact.query plus only level_id. Source descriptor/support validation uses that frozen source and population, not draft bounds/hours. Missing source, unsupported plane, and reader ownership cause a visible blocked state and no POST.
- Debounce 300 ms, maximum one active request and one latest pending request. New selections invalidate older response adoption immediately; an in-flight request is allowed to settle and only the latest queued pressure is sent. Manual apply uses the same serialization boundary and supersedes automatic intent.
- Keep slider requested plane separate from fixed displayed plane. Share one requested plane across map and rose sliders. Fixed diagrams, their labels and prepared SVG links retain the artifact until a complete matching response is accepted.
- Pressure response updates fixed artifact/applied reference. Preserve current draft region/hours and other edits; reflect the chosen level into same-source draft only when it has not subsequently been explicitly changed. Common-region/hour edits do not prevent the applied-population pressure operation, even if their draft is invalid. Explicit source change/manual apply/restore/dispose invalidates queued automatic work.
- Save/reopen keeps the accepted artifact reference and current draft. No automatic POST on reopen. Reader ownership acquisition alone does not start a blocked or uncertain request; nearby explicit retry uses the latest desired pressure. Existing API ownership guard remains in force.
- Tests: coalesced selections; at most one in flight; stale response suppression; manual supersession; retained invalid/edited drafts; both slider labels; reader/source/support blocks; uncertain retry request identity; restore/dispose cancellation; accepted save/reopen reference. tsc and dist07 after targeted tests. INDEX index06 re-extracts exact current inventory; old round06/dist06/index05 retained.

Scope: frontend climate only, no backend/science/forecast/3D/lease-policy changes. Browser receipt and visual acceptance remain parent work. No claim that request completion establishes scientific accuracy.

## Final refinement after independent purpose review

Round07 passed 319 full frontend tests. The trailing-only debounce was then replaced in round08 by an initial 300ms deadline that later pressure input does not extend. A bounded six-plane same-population LRU makes backtracking immediate where already received; explicit request/restore/source/disposal resets its generation. Valid stale responses may populate the same-generation cache but still cannot update the figure until explicitly selected. Final targeted tests10 passed52 and tsc/builddist08 passed. Uncached requests remain dependent on server time and continuous motion does not promise a displayed update on every frame. The original planning bullets above record the first proposal; this paragraph states the adopted refinement.
