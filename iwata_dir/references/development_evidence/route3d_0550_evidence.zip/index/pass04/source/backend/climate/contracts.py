"""Small input contract independent of HTTP, SQL and application storage."""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping

ADAPTER_VERSION = "jra3q-halfmonth-summary/1"
STATISTICS_VERSION = "gaussian-pooled-wind/1"


class ClimateError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ClimateError("CLIMATE_INPUT", f"{name} must be finite.")
    return float(value)


@dataclass(frozen=True)
class Bounds:
    west: float
    east: float
    south: float
    north: float

    def __post_init__(self):
        for key in ("west", "east", "south", "north"):
            object.__setattr__(self, key, finite_number(getattr(self, key), key))
        if not (-180 <= self.west <= self.east <= 180 and -90 <= self.south <= self.north <= 90):
            raise ClimateError("CLIMATE_BOUNDS", "Use ordered, non-wrapping native-grid bounds.")

    def as_dict(self):
        return {k: getattr(self, k) for k in ("west", "east", "south", "north")}


@dataclass(frozen=True)
class ClimateQuery:
    source_id: str
    level_id: int
    bounds: Bounds | None = None
    grain: str = "half"

    def __post_init__(self):
        if not isinstance(self.source_id, str) or not self.source_id:
            raise ClimateError("CLIMATE_INPUT", "A registered source_id is required.")
        if isinstance(self.level_id, bool) or not isinstance(self.level_id, int):
            raise ClimateError("CLIMATE_INPUT", "level_id must be an integer native level ID.")
        if self.bounds is not None and not isinstance(self.bounds, Bounds):
            raise ClimateError("CLIMATE_INPUT", "bounds must be Bounds or null.")
        if self.grain != "half":
            raise ClimateError("CLIMATE_UNSUPPORTED", "This source supports UTC half-month summaries only.")

    @classmethod
    def from_mapping(cls, value: Mapping):
        if not isinstance(value, Mapping):
            raise ClimateError("CLIMATE_INPUT", "Expected a query object.")
        unknown = set(value) - {"source_id", "level_id", "bounds", "grain"}
        if unknown:
            raise ClimateError("CLIMATE_UNSUPPORTED", "Unsupported query fields: " + ", ".join(sorted(unknown)))
        if "source_id" not in value or "level_id" not in value:
            raise ClimateError("CLIMATE_INPUT", "source_id and level_id are required.")
        bounds = value.get("bounds")
        if bounds is not None:
            if not isinstance(bounds, Mapping) or set(bounds) != {"west", "east", "south", "north"}:
                raise ClimateError("CLIMATE_INPUT", "bounds needs exactly west/east/south/north.")
            bounds = Bounds(**bounds)
        return cls(value["source_id"], value["level_id"], bounds, value.get("grain", "half"))

    def as_dict(self):
        return {"source_id": self.source_id, "level_id": self.level_id,
                "bounds": self.bounds.as_dict() if self.bounds else None, "grain": self.grain}
