import {useState} from 'react';
import type {ClimateArtifact} from './climateDomain';
export function ClimateFlightHandoff({artifact,view,handoff}:{artifact:ClimateArtifact|null;view:unknown;handoff:(v:any)=>void}){
 const [period,setPeriod]=useState<number|null>(null);
 if(!artifact)return <p>先に固定した年間・地域図を読み込んでください。図と同じ対象・出典を試算へ渡します。</p>;
 const selected=artifact.summary.population.timebins.find(p=>p.timebin_id===period)??artifact.summary.population.timebins[0];
 const b=artifact.query.bounds??artifact.summary.source.bounds;
 const label=`${selected.month}月${selected.bin===1?'前半':'後半'} · ${b.south}–${b.north}°N / ${b.west}–${b.east}°E`;
 return <div className="climate-flight-handoff"><h3>気になる時期を、原日時の飛行で確かめる</h3><p>年間・地域図は時期や場所を絞る材料です。飛行には別に、原日時の高度・時間方向に連続な気象場が必要です。</p><label>まず試したい時期（UTC半月）<select value={selected.timebin_id} onChange={e=>setPeriod(Number(e.target.value))}>{artifact.summary.population.timebins.map(p=><option key={p.timebin_id} value={p.timebin_id}>{p.month}月{p.bin===1?'前半':'後半'}</option>)}</select></label><p>{label}。集計は2016–2025年です。次画面で試す原年・原放球日時と取得済み場を明示し、共通の機体で実計算します。</p><button className="primary" onClick={()=>handoff({kind:'historical-flight-interest',returnState:view,selection_context:{schema:'balloon.climate-flight-interest/1',analysis_id:artifact.analysis_id,query_hash:artifact.query_hash,result_hash:artifact.result_hash,dataset_sha256:artifact.summary.source.dataset_sha256,label,bounds:b,period:selected,years:artifact.summary.population.years_fixed,date_convention:artifact.summary.population.date_convention}})}>この関心条件を原日時の試算へ渡す</button><p>半月の平均風から瞬時場を再生成しません。少数の明示日時による試算と、多年を代表する季節分散は区別します。</p></div>;
}
