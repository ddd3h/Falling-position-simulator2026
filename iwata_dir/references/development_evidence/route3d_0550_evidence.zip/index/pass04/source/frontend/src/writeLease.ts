/** One browser tab owns request/ledger writes; other tabs retain read access. */
export type WriteLeaseState={state:'unclaimed'|'requesting'|'owner'|'reader'|'unavailable';message:string};
let state:WriteLeaseState={state:'unclaimed',message:'送信担当の確認前です。'},generation=0,release:(()=>void)|null=null,pending:Promise<void>|null=null;
const listeners=new Set<(value:WriteLeaseState)=>void>();
const emit=(value:WriteLeaseState)=>{state=value;for(const fn of listeners)fn({...value});};
export const writeLeaseState=()=>({...state});
export const ownsWriteLease=()=>state.state==='owner';
export function observeWriteLease(fn:(value:WriteLeaseState)=>void){listeners.add(fn);return()=>{listeners.delete(fn);};}
export function requireWriteLease(){if(!ownsWriteLease())throw Error('このタブには送信権がありません。保存・計算・新しい群集計の要求を開始せず保持しています。送信担当のタブを閉じた後、「このタブで送信権を取得」を選んでください。');}
export function claimWriteLease():Promise<void>{
 if(ownsWriteLease())return Promise.resolve();if(pending)return pending;
 if(typeof navigator==='undefined'||!navigator.locks){emit({state:'unavailable',message:'このブラウザではタブ間の送信担当を固定できません。Web Locksに対応したブラウザのlocalhost画面で開いてください。保存結果の閲覧は続けられます。'});return Promise.resolve();}
 const epoch=++generation;emit({state:'requesting',message:'このブラウザの送信担当を確認しています。'});
 let finish!:()=>void;const work=new Promise<void>(resolve=>{finish=resolve;});pending=work;
 void navigator.locks.request('balloon.request-ledger-writer/1',{mode:'exclusive',ifAvailable:true},async lock=>{
  if(epoch!==generation){finish();return;}
  if(!lock){emit({state:'reader',message:'別のタブが送信を担当しています。このタブでは保存結果を閲覧できます。'});finish();return;}
  emit({state:'owner',message:'このタブが保存・計算要求の送信を担当しています。'});finish();
  await new Promise<void>(resolve=>{release=resolve;});
  if(epoch===generation)emit({state:'reader',message:'このタブの送信権を終了しました。'});
 }).catch(error=>{if(epoch===generation)emit({state:'unavailable',message:error instanceof Error?error.message:String(error)});finish();});
 void work.finally(()=>{if(pending===work)pending=null;});return work;
}
export function releaseWriteLease(){generation++;release?.();release=null;pending=null;emit({state:'unclaimed',message:'送信担当の確認前です。'});}
