import {readFailure,type FixedResultRead} from './fixedResultRead';
import {useEffect,useRef,useState} from 'react';
import {climateApi} from './climateApi';
import {climateError,defaultClimateQuery,queryIssue,queryKey,type ClimateArtifact,type ClimateDescriptor,type ClimateQuery,type ClimateView} from './climateDomain';
export function useClimateWorkspace(saved:ClimateView|undefined,onView:(v:ClimateView)=>void){
 const [sources,setSources]=useState<ClimateDescriptor[]>([]),[sourceErrors,setSourceErrors]=useState<string[]>([]),[artifact,setArtifact]=useState<ClimateArtifact|null>(null),[view,setView]=useState<ClimateView>(()=>saved??{schema:'balloon.climate-view/1'}),[status,setStatus]=useState('保存した集計を確認しています。'),[error,setError]=useState(''),[restoreError,setRestoreError]=useState(''),[busy,setBusy]=useState(false);
 const [restoreRead,setRestoreRead]=useState<FixedResultRead|undefined>(saved?.applied?{state:'loading'}:undefined);const restorePending=useRef<Promise<void>|null>(null);
 const latest=useRef({view,onView});latest.current={view,onView};const life=useRef(0),epoch=useRef(0),accepted=useRef(0),controllers=useRef(new Map<AbortController,ReturnType<typeof setTimeout>>()),receipt=useRef<{key:string;id:string}|null>(null);
 function change(patch:Partial<ClimateView>,persist=true){const next={...latest.current.view,...patch,schema:'balloon.climate-view/1' as const};latest.current={...latest.current,view:next};setView(next);if(persist)latest.current.onView(next);}
 async function call<T>(fn:(signal:AbortSignal)=>Promise<T>,ms:number){const ac=new AbortController();const timer=setTimeout(()=>ac.abort(),ms);controllers.current.set(ac,timer);try{return await fn(ac.signal);}finally{clearTimeout(timer);controllers.current.delete(ac);}}
 const refreshSources=async()=>{const generation=life.current;try{const r=await call(signal=>climateApi.sources(signal),20000);if(generation!==life.current)return;setSources(r.sources);setSourceErrors(r.errors.map(e=>climateError(new Error(e.code+': '+e.message))));if(!latest.current.view.draft_query&&r.sources.length)change({draft_query:defaultClimateQuery(r.sources[0])},false);}catch(e){if(generation===life.current)setSourceErrors([climateError(e)]);}};
 function restoreSaved(){
  if(restorePending.current)return restorePending.current;
  const a=latest.current.view.applied;if(!a)return Promise.resolve();
  const generation=life.current,token=epoch.current,displayVersion=accepted.current;
  setRestoreRead({state:'loading'});setRestoreError('');
  const work=call(signal=>climateApi.get(a.analysis_id,signal),20000).then(r=>{
   if(generation!==life.current||displayVersion!==accepted.current)return;
   if(r.analysis_id!==a.analysis_id||r.summary.source.source_id!==a.source_id||r.query_hash!==a.query_hash||r.result_hash!==a.result_hash||r.summary.source.dataset_sha256!==a.dataset_sha256)throw new Error('保存した図と固定集計の識別情報が一致しません。');
   setArtifact(r);setRestoreRead({state:'ready'});setRestoreError('');
   if(token===epoch.current)setStatus('保存した固定集計を再表示しました。再集計は行っていません。');
  }).catch(e=>{if(generation===life.current&&displayVersion===accepted.current){setRestoreRead(readFailure(e));setRestoreError(climateError(e));}}).finally(()=>{if(restorePending.current===work)restorePending.current=null;});
  restorePending.current=work;return work;
 }
 useEffect(()=>{++life.current;void refreshSources();if(saved?.applied)void restoreSaved();else setStatus('資料と範囲を確認し、「この対象で再集計」を押してください。');return()=>{life.current++;epoch.current++;restorePending.current=null;controllers.current.forEach((timer,c)=>{clearTimeout(timer);c.abort();});controllers.current.clear();};},[]);
 function editQuery(query:ClimateQuery){epoch.current++;setBusy(false);setError('');change({draft_query:query});setStatus(artifact?'入力中の条件は未適用です。図は表示中の固定集計を保持しています。':'入力条件を設定しています。');}
 async function calculate(){const q=latest.current.view.draft_query,d=sources.find(s=>s.source_id===q?.source_id);if(!q||!d){setError('利用できる資料を選択してください。');return;}const issue=queryIssue(q,d);if(issue){setError(issue);return;}const key=queryKey(q);if(receipt.current?.key!==key)receipt.current={key,id:crypto.randomUUID()};const id=receipt.current.id,token=++epoch.current,generation=life.current;setBusy(true);setError('');setStatus('固定する集計を読み出しています。表示中の図はまだ変更していません。');try{const r=await call(signal=>climateApi.create(q,id,signal),60000);if(generation!==life.current||token!==epoch.current)return;accepted.current++;setRestoreRead({state:'ready'});setRestoreError('');setArtifact(r);change({applied:{analysis_id:r.analysis_id,source_id:r.summary.source.source_id,dataset_sha256:r.summary.source.dataset_sha256,query_hash:r.query_hash,result_hash:r.result_hash},draft_query:r.query});setStatus('固定集計を受領し、図を更新しました。');}catch(e){if(generation===life.current&&token===epoch.current){setError(climateError(e));setStatus('集計の応答を確認できません。図は保持しています。同じ入力の再試行は同じ受付IDで照合します。');}}finally{if(generation===life.current&&token===epoch.current)setBusy(false);}}
 function show(patch:Partial<ClimateView>){change(patch);}
 return {sources,sourceErrors,artifact,view,status,restoreRead,restoreSaved,error:error||restoreError,busy,refreshSources,editQuery,calculate,show};
}
