import {afterEach,expect,it,vi} from 'vitest';
const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
afterEach(()=>vi.unstubAllGlobals());
it('allows one writer across tabs and explicitly transfers ownership without changing reads',async()=>{
 const held=new Set<string>();vi.stubGlobal('navigator',{locks:{request:(name:string,_options:unknown,callback:any)=>{if(held.has(name))return Promise.resolve(callback(null));held.add(name);return Promise.resolve(callback({name})).finally(()=>held.delete(name));}}});
 vi.resetModules();const a=await import('./writeLease');vi.resetModules();const b=await import('./writeLease');await a.claimWriteLease();await b.claimWriteLease();expect(a.ownsWriteLease()).toBe(true);expect(b.ownsWriteLease()).toBe(false);expect(()=>b.requireWriteLease()).toThrow('送信権');a.releaseWriteLease();await flush();expect(b.ownsWriteLease()).toBe(false);await b.claimWriteLease();expect(b.ownsWriteLease()).toBe(true);b.releaseWriteLease();await flush();
});
it('does not seize ownership from a late grant after unmount',async()=>{
 let callback!:(lock:any)=>Promise<void>;vi.stubGlobal('navigator',{locks:{request:(_name:string,_options:unknown,fn:any)=>{callback=fn;return new Promise(()=>{});}}});vi.resetModules();const a=await import('./writeLease'),pending=a.claimWriteLease();a.releaseWriteLease();await callback({name:'late'});await pending;expect(a.ownsWriteLease()).toBe(false);
});
it('does not write a ledger or send POST from a reader tab',async()=>{
 vi.stubGlobal('navigator',{locks:{request:(_name:string,_options:unknown,callback:any)=>Promise.resolve(callback(null))}});const fetch=vi.fn(),setItem=vi.fn();vi.stubGlobal('fetch',fetch);vi.stubGlobal('localStorage',{getItem:()=>null,setItem});vi.resetModules();const lease=await import('./writeLease'),identity=await import('./serviceIdentity'),ledger=await import('./submissionLedger'),api=await import('./api');identity.setServiceIdentity('same');await lease.claimWriteLease();expect(()=>ledger.putSubmission({id:'p',kind:'weather-acquisition',createdAt:'today',payload:{plan_id:'p',client_request_id:'p'}})).toThrow('送信権');expect(()=>api.writeRequest('/runs',{method:'POST',body:'{}'})).toThrow('送信権');expect(setItem).not.toHaveBeenCalled();expect(fetch).not.toHaveBeenCalled();
});
