"""Finite syntax snapshot and candidate only. Verified application is a separate tool."""
from pathlib import Path
import argparse,copy,datetime,difflib,hashlib,json,os,re,shutil,subprocess

HERE=Path(__file__).resolve().parent
ROOT=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
REFERENCE=HERE.parents[1]/'repair-hit550/index-final'
NODE=Path(r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
BASIS='b9d960c858e886666167e841dee240801fcfd2a4'
NEW={
 'frontend/scene3d/data/README.md':'表示用EGM96格子の出所・形式・帰属とASL表示規約の限界を記録する',
 'frontend/scene3d/data/WW15MGH.DAC':'実ASLを表示用楕円体高へ換算する固定EGM96全球15分格子。DEMや飛行核の入力ではない',
 'frontend/scene3d/src/route-geometry.js':'実ASLの全経路を表示用地下下端まで連続幕で示し、線と幕の節点/曲率を揃える。人工AGLは全節点の地物高が揃うまで一括保留する',
 'frontend/scene3d/src/route-layer.js':'既存viewerに立体経路と表示用EGM96読込を保持する。実ASLの地物照会は起動せず、人工AGLだけ有限照会・取消・復元を所有する',
 'frontend/scene3d/src/vertical-datum.js':'同梱EGM96 bytesを検査し、周期経度と極を扱う双一次補間で表示用ジオイド高mを返す',
 'frontend/src/scene3d-datum.test.ts':'固定格子のhash・参照点・符号・周期境界・極と不正入力を有限に検査する',
 'frontend/src/scene3d-geometry.test.ts':'実ASLの連続幕・同じ上端曲率・全原節点fallback・地物照会ゼロ、人工AGLの全体待機と照会寿命、描画rollback後の応答採否を検査する',
 'frontend/src/scene3d-routes.test.ts':'可視/注目/詳細選択、三種の経路対応、高度基準と表示状態の受信契約を検査する',
}
KEYS=('typescript_modules','javascript_modules','frontend_assets')
rd=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def frontend_files(root):
 names=set();front=root/'frontend';excluded={front/'node_modules',front/'dist'}
 for folder,dirs,files in os.walk(front,followlinks=False):
  dirs[:]=[d for d in dirs if Path(folder)/d not in excluded]
  assert not any((Path(folder)/d).is_symlink() for d in dirs),'source directory symlink'
  for name in files:
   p=Path(folder)/name;assert not p.is_symlink(),'source file symlink';names.add(p.relative_to(root).as_posix())
 return names
def tree(rows):
 root={'name':'frontend','path':'frontend','kind':'directory','children':[]}
 for row in sorted(rows,key=lambda r:r['path']):
  parts=row['path'].split('/');node=root
  for end,part in enumerate(parts[1:],2):
   path='/'.join(parts[:end]);child=next((c for c in node['children'] if c['path']==path),None)
   if child is None:
    child={'name':part,'path':path,'kind':'file' if end==len(parts) else 'directory'}
    if child['kind']=='file':child['source_sha256']=row['source_sha256']
    else:child['children']=[]
    node['children'].append(child)
   node=child
 return root

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=HERE);args=ap.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
 baseline=HERE/'baseline-index550.json'
 if not baseline.exists():shutil.copyfile(ROOT/'docs/IMPLEMENTATION_INDEX.json',baseline)
 base=rd(baseline);m0=base['structure']['manual_interpretation'];front0=[r for k in KEYS for r in m0[k]];other=base['structure']['physical_modules']+base['structure']['supporting_files'];old={r['path']:r['source_sha256'] for r in other+front0}
 assert len(old)==215 and len(front0)==118 and len(other)==97,'baseline inventory changed'
 front_names=frontend_files(ROOT);assert front_names=={r['path'] for r in front0}|set(NEW),'unexpected frontend addition/removal'
 assert all(sha(ROOT/r['path'])==r['source_sha256'] for r in other),'nonfrontend source changed'
 names=set(old)|set(NEW);assert len(names)==223 and len(front_names)==126
 assert not (out/'extraction-input550.json').exists(),'choose a new output directory; preserve earlier evidence'
 current={n:sha(ROOT/n) for n in sorted(names)}
 for n in names:
  dest=out/'source'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,dest);assert sha(dest)==current[n],'source changed during capture'
 changed=sorted(n for n in old if old[n]!=current[n])
 manifest={'schema':'route3d-index-input/1','basis_commit':BASIS,'basis_index_sha256':sha(baseline),'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':current,'scope':{'baseline_sources':215,'baseline_frontend':118,'added_paths':sorted(NEW),'expected_sources':223,'expected_frontend':126,'frontend_runtime_exclusions':['frontend/node_modules','frontend/dist']},'changed_existing_paths':changed,'limits':'Fixed read-only source snapshot, not code execution, UI acceptance or science review.'}
 put(out/'extraction-input550.json',manifest)
 linked={};reference_tests=rd(REFERENCE/'linked-tests.json')
 for name in sorted({e['test_path'] for e in base['entries']}-names):
  assert sha(ROOT/name)==reference_tests[name],'linked API test changed'
  dest=out/'linked-tests'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest);linked[name]=sha(dest)
 put(out/'linked-tests.json',linked)
 put(out/'frontend-source-index550.json',{'rows':[{'path':n,'source_sha256':current[n]} for n in sorted(front_names)]})
 shutil.copyfile(REFERENCE/'extract_frontend550.cjs',out/'extract_frontend550.cjs')
 run=subprocess.run([str(NODE),str(out/'extract_frontend550.cjs'),str(out/'source'),str(out/'frontend-source-index550.json'),str(out/'frontend-index550.json'),str(ROOT/'frontend/node_modules/typescript')],capture_output=True,check=True)
 (out/'syntax.stdout').write_bytes(run.stdout);(out/'syntax.stderr').write_bytes(run.stderr)
 syntax=rd(out/'frontend-index550.json');after={r['path']:r for r in syntax['files']};assert set(after)==front_names and not any(r.get('parse_diagnostics') for r in after.values())
 j=copy.deepcopy(base);m=j['structure']['manual_interpretation']
 for key in KEYS:
  for row in m[key]:row.update(after[row['path']])
 for n,purpose in NEW.items():
  key='typescript_modules' if n.endswith(('.ts','.tsx')) else 'javascript_modules' if n.endswith(('.js','.mjs')) else 'frontend_assets'
  row={**after[n],'purpose':purpose,'current_role':'verification-source' if '.test.' in n else 'fixed-display-datum' if n.endswith('.DAC') else 'current-source','structure_anchor':'WEB-SCENE3D'}
  if key!='frontend_assets':row['method']='TypeScript createSourceFile syntax and source fingerprint; ownership/data-flow interpretation is separate.'
  m[key].append(row)
 purposes={
  'frontend/scene3d/src/main.js':'独立rendererの接続・地表overlay・空中route・名称/クリック・視点・終了を束ね、経路表示意図を親へ返す',
  'frontend/scene3d/src/protocol.js':'v2 snapshotの図形・候補と地表/空中/幕の対応、高度基準・表示boolean・有限半透明値を検査する',
  'frontend/scene3d/src/overlays.js':'地表投影の点・輪郭・経路・領域をCesium entityへ変換し、空中線と幕は別layerへ委ねる',
  'frontend/scene3d/src/fixture.js':'単独の人工地表確認で使う輪郭・禁止領域・点と、模式AGLの空中経路/幕を供給する',
  'frontend/scene3d/index.html':'写真3Dの地図・候補・接続と、軌道/地表線一体表示・連続幕・明示視点移動・人工AGL専用の高さ再確認を構成する',
  'frontend/src/screens/forecast/scene-document.js':'可視/注目/詳細選択の同じ経路を独立optionで立体化し、全対象KML inventoryと表示snapshotを区別する',
  'frontend/src/screens/forecast/controller.js':'予報の候補・延期・群・地図・詳細図を操作へ結び、3DとKMLと保存ui_stateへ同じ経路表示設定を渡す',
 }
 for key in KEYS:
  m[key].sort(key=lambda r:r['path'])
  for row in m[key]:
   if row['path'] in purposes:row['purpose']=purposes[row['path']]
   if row['path'].startswith('frontend/scene3d/'):row['structure_anchor']='WEB-SCENE3D'
 front=[r for key in KEYS for r in m[key]];m['frontend_physical_tree']=tree(front)
 # Existing bounded controller contact keeps its meaning; refresh its source binding and exact lines.
 contacts=next(r for r in m['screen_bindings'] if r.get('symbol_lines'))
 controller=(out/'source'/contacts['path']).read_text(encoding='utf8').splitlines();contacts['source_sha256']=current[contacts['path']]
 for name in contacts['symbol_lines']:
  locations=[i+1 for i,line in enumerate(controller) if re.match(r'(?:async )?function '+re.escape(name)+r'\(',line)]
  assert len(locations)==1,(name,locations);contacts['symbol_lines'][name]=locations[0]
 binding=next(r for r in m['screen_bindings'] if r['owner']=='frontend/vite.config.ts')
 binding['meaning']='scene3dの独自sourceと固定EGM96 dataをdist/scene3dへ複写し、npm由来Cesiumの配布物と区別する。backend/app.pyが同originへmount。DACは再生成runtimeではなく固定表示入力。'
 m['screen_bindings'] += [
  {'owner':'forecast/controller.scene3dSnapshot / snapshot / restore','receiver':'scene3d/protocol → main; KML initial visibility; Project.ui_state','kind':'postMessage and explicitly shared display state','structure_anchor':'WEB-SCENE3D','meaning':'routeDisplayの二つのbooleanを共有し、地表線+空中線を一体表示、幕は別OFF可。allObjectsはKML全対象用、includeElevatedRoutesは可視/注目/詳細選択の同じ経路用。固定結果や高度を表示操作で変更しない。'},
  {'owner':'scene3d/main','receiver':'route-layer → route-geometry / vertical-datum; shared surface-session','kind':'direct module imports and explicit callbacks','structure_anchor':'WEB-SCENE3D','meaning':'既存viewer/providerに全経路の空中線と連続幕を追加する。実ASLの描画に地物sampleHeightは使わず、人工AGLだけ専用layerで有限照会する。通常更新は視点を保持し、fitRouteの範囲に地下下端を含めない。hover/クリックから自作entityを除外し、root再接続を起こさない。表示rollback後に旧awaitの続きを採用しない。'},
 ]
 flow=next(r for r in m['data_flows'] if r.get('from')=='current forecast result / display set');flow['changed_in']='0.55.0';flow['through'] += ['scene3d/src/route-layer.js','scene3d/src/route-geometry.js']
 flow['boundary']='postMessage境界でありcontrollerから3Dへの直接importではない。可視/注目/選択群を同じ地表線・空中線・幕へ渡す。実ASLは地物照会なしの全経路連続幕、人工AGLは全上端確定まで一括保留。原ASL/人工AGLと通常更新時の接続/視点を保ち、写真上の実観察は別。'
 m['data_flows'] += [
  {'source_version':'0.55.0','from':'scene3d routeDisplay intent','through':['forecast/controller route-display message','controller.snapshot / restore','App.keepView → Project.ui_state','analysisDocument(allObjects:true) → export390'],'to':'再閲覧する二つの経路表示選択とKML初期visibility','boundary':'幾何/科学結果は変更しない。キー/Google接続/一時視点は保存しない。'},
  {'source_version':'0.55.0','from':'fixed frontend/scene3d/data/WW15MGH.DAC + data/README.md','through':['frontend/vite.config.ts sceneAssets.closeBundle copy','dist/scene3d/data','route-layer.loadDatum','vertical-datum.parseEgm96 / heightOffset','route-geometry.routeSections'],'to':'表示用の h_ellipsoid = z_model_ASL + N_EGM96','boundary':'固定dataをローカル配布。DEM/科学核/KML高度を改変せず、読込失敗時0補正へ代替しない。地物meshへNを二重加算しない。'},
  {'source_version':'0.55.0','from':'current mesh and finite route display nodes','through':['route-geometry.groundNodes','route-layer sample cursor (relativeToGround only)','surface-session.read → scene.sampleHeight','route-geometry.routeSections / routeDefinitions'],'to':'全節点の地物高が揃った人工AGLの全空中線と連続幕','boundary':'人工上端に地物高を使い、欠測/分割上限では全相の線と幕を一括保留する。実ASLはEGM96で上端を決め、地物照会ゼロ。地下下端はmin(-12000,min upper-1000)という表示用値で地形推定ではない。余長はmesh深度で隠すが穴/未読では見え得る。下端線とfit範囲から地下を除外し、4096分割超の実ASLは原節点全経路を保持。線/幕のGEODESICとgranularityを揃え、衝突判定にしない。'},
 ]
 j['extraction']['route3d_display']={'basis_commit':BASIS,'basis_index_sha256':sha(baseline),'input_manifest_sha256':sha(out/'extraction-input550.json'),'syntax_manifest_sha256':sha(out/'frontend-index550.json'),'method':'Exact prior 215 plus named eight additions; TypeScript syntax and separately bounded ownership/data-flow reading; unchanged Python/API/HTTP branches checked independently.','generated_by':'P550/route3d-implementation550/index/update-index-route550.py','self_hash_excluded':True,'added_paths':sorted(NEW),'changed_existing_paths':changed,'status':'snapshot-structural-correspondence-not-UI-or-science-acceptance'}
 j['extraction']['route3d_display']['continuous_curtain_refinement']={'previous_input_manifest_sha256':sha(HERE/'pass03/extraction-input550.json'),'retained_evidence':'P550/route3d-implementation550/index/pass03','reason':'Replace sampled partial curtain with full-path real-ASL display curtain; artificial AGL alone retains ground queries and all-or-none readiness. Prior observation belongs to the former implementation.'}
 put(out/'index-candidate550.json',j)
 (out/'index.diff').write_text(''.join(difflib.unified_diff(json.dumps(base,ensure_ascii=False,indent=2).splitlines(True),json.dumps(j,ensure_ascii=False,indent=2).splitlines(True),fromfile='PR31-basis-index',tofile='route3d-index')),encoding='utf8')
 shutil.copyfile(ROOT/'docs/PROGRAM_GUIDE.tex',out/'PROGRAM_GUIDE.tex')
 put(out/'snapshot-receipt.json',{'basis_commit':BASIS,'baseline_sources':215,'source_count':223,'frontend_count':126,'new_paths':sorted(NEW),'changed_existing_paths':changed,'syntax_parse_errors':0,'input_manifest_sha256':sha(out/'extraction-input550.json'),'syntax_manifest_sha256':sha(out/'frontend-index550.json'),'candidate_sha256':sha(out/'index-candidate550.json'),'index_crlf_on_apply':True,'apply_requested':False})
 print(json.dumps({'sources':223,'frontend':126,'changed':changed,'candidate':str(out/'index-candidate550.json'),'applied':False}))
if __name__=='__main__':main()
