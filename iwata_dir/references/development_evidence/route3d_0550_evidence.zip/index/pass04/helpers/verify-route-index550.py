"""Independent finite correspondence and mutant checks; never imports application code."""
from pathlib import Path
import ast,copy,hashlib,json,os,re,subprocess,sys

HERE=Path(__file__).resolve().parent
P=Path(sys.argv[1]).resolve();R=P/'source'
rd=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=rd(HERE/'baseline-index550.json');manifest=rd(P/'extraction-input550.json');expected=manifest['source_files']
KEYS=('typescript_modules','javascript_modules','frontend_assets')
NEW={
 'frontend/scene3d/data/README.md','frontend/scene3d/data/WW15MGH.DAC',
 'frontend/scene3d/src/route-geometry.js','frontend/scene3d/src/route-layer.js','frontend/scene3d/src/vertical-datum.js',
 'frontend/src/scene3d-datum.test.ts','frontend/src/scene3d-geometry.test.ts','frontend/src/scene3d-routes.test.ts',
}
base_m=base['structure']['manual_interpretation'];base_rows=base['structure']['physical_modules']+base['structure']['supporting_files']+[r for key in KEYS for r in base_m[key]]
assert len(base_rows)==215 and len({r['path'] for r in base_rows})==215
assert len(expected)==223 and set(expected)=={r['path'] for r in base_rows}|NEW
assert sorted(NEW)==manifest['scope']['added_paths']
actual_files={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}
assert actual_files==set(expected),'snapshot source extras or omissions'
# A second TypeScript source parse is independent of the candidate JSON. It uses
# the same compiler API/extractor, not an independent language implementation.
repo=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
node=r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
run=subprocess.run([node,str(P/'extract_frontend550.cjs'),str(R),str(P/'frontend-source-index550.json'),str(P/'verification-syntax550.json'),str(repo/'frontend/node_modules/typescript')],capture_output=True,check=True)
(P/'verification-syntax.stdout').write_bytes(run.stdout);(P/'verification-syntax.stderr').write_bytes(run.stderr)
syntax={r['path']:r for r in rd(P/'verification-syntax550.json')['files']}
tex=(P/'PROGRAM_GUIDE.tex').read_text(encoding='utf8');anchors=set(re.findall(r'\\Page\{[^}]+\}\{([^}]+)\}',tex)+re.findall(r'\\hypertarget\{([^}]+)\}',tex))

def check(c):
 assert c['entries']==base['entries'] and len(c['entries'])==34,'public API meaning/history changed'
 for entry in c['entries']:
  n=ast.parse((R/entry['path']).read_text(encoding='utf8'))
  for part in entry['symbol'].split('.'):
   n=next(n for n in n.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==part)
  assert ast.unparse(n.args)==entry['signature'],'wrong public signature'
  target=R/entry['test_path']
  if not target.is_file():
   target=P/'linked-tests'/entry['test_path'];assert target.is_file() and sha(target)==rd(P/'linked-tests.json')[entry['test_path']],'missing linked API test source'
 for key in ('schema','version','role','legacy_tools','structure_basis','test_contract'):assert c[key]==base[key],key
 for key in ('physical_modules','supporting_files','lexical_call_edges','extraction_limits'):assert c['structure'][key]==base['structure'][key],key
 assert {k:v for k,v in c['extraction'].items() if k!='route3d_display'}==base['extraction'],'older extraction history changed'
 m=c['structure']['manual_interpretation'];front=[r for key in KEYS for r in m[key]];rows=c['structure']['physical_modules']+c['structure']['supporting_files']+front
 assert len(rows)==len({r['path'] for r in rows})==223 and {r['path'] for r in rows}==set(expected),'wrong exact source set'
 assert len(front)==126 and {r['path'] for r in front}==set(syntax),'wrong frontend set'
 for row in rows:assert row['source_sha256']==expected[row['path']]==sha(R/row['path']),'source fingerprint mismatch'
 for row in front:
  assert all(row.get(k)==v for k,v in syntax[row['path']].items()),'frontend syntax mismatch'
  assert not row.get('parse_diagnostics'),'frontend parse failure'
  if row.get('structure_anchor'):assert row['structure_anchor'] in anchors,'missing guide anchor'
 by_path={r['path']:r for r in front}
 assert by_path['frontend/scene3d/src/route-layer.js']['imports']==['./vertical-datum.js','./route-geometry.js'],'wrong layer dependencies'
 assert './route-layer.js' in by_path['frontend/scene3d/src/main.js']['imports'],'missing main/layer dependency'
 assert by_path['frontend/scene3d/data/WW15MGH.DAC']['current_role']=='fixed-display-datum','wrong fixed data classification'
 assert by_path['frontend/scene3d/data/WW15MGH.DAC']['bytes']==2076480,'wrong data size'
 assert by_path['frontend/scene3d/data/WW15MGH.DAC']['source_sha256']=='9dcaf4efd6857aaa2e1e2e2c574d3f5264eacf47024cdcd5291c40ddad5e5acc','wrong fixed data'
 assert '../data/WW15MGH.DAC' in (R/'frontend/scene3d/src/route-layer.js').read_text(encoding='utf8')
 assert "cpSync('scene3d',resolve(outputDirectory,'scene3d'),{recursive:true})" in (R/'frontend/vite.config.ts').read_text(encoding='utf8'),'missing data distribution copy'
 leaves={}
 def walk(n):
  if n['kind']=='file':assert n['path'] not in leaves;leaves[n['path']]=n['source_sha256']
  else:
   for child in n['children']:walk(child)
 walk(m['frontend_physical_tree']);assert leaves=={r['path']:r['source_sha256'] for r in front},'physical tree mismatch'
 app=ast.parse((R/'backend/app.py').read_text(encoding='utf8'));factory=next(n for n in app.body if isinstance(n,ast.FunctionDef) and n.name=='create_app');actual={}
 for n in factory.body:
  if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
  for d in n.decorator_list:
   if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and isinstance(d.func.value,ast.Name) and d.func.value.id=='app' and d.func.attr in ('get','post','put','delete','patch'):
    actual[(d.func.attr.upper(),ast.literal_eval(d.args[0]))]=(n.name,n.lineno)
 assert m['http_routes']==base_m['http_routes'] and len(m['http_routes'])==40,'HTTP meaning/history changed'
 given={(r['method'],r['path']):(r['handler'].removeprefix('backend.app.create_app.'),r['line']) for r in m['http_routes']}
 assert given==actual,'HTTP handler correspondence'
 for key in ('duck_types_and_callbacks','logical_groups_are_not_modules','absence_confirmed','service_entries'):assert m[key]==base_m[key],key
 assert len(m['data_flows'])==len(base_m['data_flows'])+3
 mesh_flow=next(r for r in m['data_flows'] if r.get('from')=='current mesh and finite route display nodes')
 assert mesh_flow['to']=='全節点の地物高が揃った人工AGLの全空中線と連続幕','stale partial-curtain flow'
 assert '実ASLはEGM96で上端を決め、地物照会ゼロ' in mesh_flow['boundary'],'wrong real/AGL ownership'
 assert '連続幕' in by_path['frontend/scene3d/src/route-geometry.js']['purpose'],'stale geometry purpose'
 assert '人工AGLだけ' in by_path['frontend/scene3d/src/route-layer.js']['purpose'],'stale layer purpose'
 geometry=(R/'frontend/scene3d/src/route-geometry.js').read_text(encoding='utf8')
 layer=(R/'frontend/scene3d/src/route-layer.js').read_text(encoding='utf8')
 assert 'CURTAIN_FLOOR_M=-12000' in geometry and 'const coords=route.nodes.length?route.nodes:g.coordinates' in geometry,'missing display floor or real fallback contact'
 assert "routes.every(r=>r.properties.altitudeMode==='absolute')" in layer,'missing real query exclusion'
 for a,b in zip(m['data_flows'],base_m['data_flows']):
  if b.get('from')!='current forecast result / display set':assert a==b,'unrelated flow changed'
 assert len(m['screen_bindings'])==len(base_m['screen_bindings'])+2
 for a,b in zip(m['screen_bindings'],base_m['screen_bindings']):
  if b['owner']=='frontend/vite.config.ts':assert '固定EGM96' in a['meaning'];continue
  if b.get('symbol_lines'):
   assert {k:v for k,v in a.items() if k not in ('source_sha256','symbol_lines')}=={k:v for k,v in b.items() if k not in ('source_sha256','symbol_lines')}
   assert a['source_sha256']==expected[a['path']]
   lines=(R/a['path']).read_text(encoding='utf8').splitlines()
   for name,number in a['symbol_lines'].items():assert re.match(r'(?:async )?function '+name+r'\(',lines[number-1]),'wrong bounded contact line'
  else:assert a==b,'unrelated binding changed'

candidate=rd(P/'index-candidate550.json');check(candidate)
cases=[{'case':'34 API / 40 HTTP unchanged; exact 215+8 source and 118+8 frontend; reparsed syntax; tree; anchors; new dependencies and fixed data copy','passed':True}]
def row(c,path):return next(r for k in KEYS for r in c['structure']['manual_interpretation'][k] if r['path']==path)
mutants=[
 ('wrong API signature',lambda c:c['entries'][-1].update(signature='self,other')),
 ('missing new layer',lambda c:c['structure']['manual_interpretation']['javascript_modules'].__setitem__(slice(None),[r for r in c['structure']['manual_interpretation']['javascript_modules'] if r['path']!='frontend/scene3d/src/route-layer.js'])),
 ('missing layer dependency',lambda c:row(c,'frontend/scene3d/src/route-layer.js').update(imports=[])),
 ('wrong declaration location',lambda c:row(c,'frontend/scene3d/src/vertical-datum.js')['top_level_declarations'][0].update(line=999)),
 ('fixed datum called runtime',lambda c:row(c,'frontend/scene3d/data/WW15MGH.DAC').update(current_role='generated-runtime')),
 ('missing guide anchor',lambda c:row(c,'frontend/scene3d/src/main.js').update(structure_anchor='MISSING-ANCHOR')),
 ('wrong source fingerprint',lambda c:row(c,'frontend/scene3d/src/protocol.js').update(source_sha256='0'*64)),
 ('missing HTTP handler',lambda c:c['structure']['manual_interpretation']['http_routes'].pop()),
 ('unrelated flow rewrite',lambda c:c['structure']['manual_interpretation']['data_flows'][0].update(boundary='changed')),
 ('stale partial-curtain semantics',lambda c:next(r for r in c['structure']['manual_interpretation']['data_flows'] if r.get('from')=='current mesh and finite route display nodes').update(to='取得地物へ接続する有限な幕と人工AGLの空中線')),
]
for name,change in mutants:
 c=copy.deepcopy(candidate);change(c)
 try:check(c)
 except (AssertionError,StopIteration) as e:cases.append({'case':name,'rejected':True,'reason':str(e)})
 else:raise AssertionError('mutation passed: '+name)
result={'schema':'route3d-index-verification/1','source_count':223,'frontend_count':126,'public_api_count':34,'http_count':40,'candidate_sha256':sha(P/'index-candidate550.json'),'input_manifest_sha256':sha(P/'extraction-input550.json'),'verifier_sha256':sha(Path(__file__)),'new_anchor':'WEB-SCENE3D','guide_snapshot_sha256':sha(P/'PROGRAM_GUIDE.tex'),'cases':cases,'repository_written':False,'limits':['Finite syntax/decorator/source and explicit contact checks, not full semantic review.','Second syntax extraction uses the same TypeScript compiler and extractor, not an independent parser implementation.','No application import, UI action, numerical/scientific acceptance or Git action.','Existing review stamps/history retained; source snapshot may precede parent final source freeze.']}
(P/'index-verification550.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'checks':len(cases),'sources':223,'frontend':126,'candidate':result['candidate_sha256']}))
