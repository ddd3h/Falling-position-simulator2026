"""Apply only a verified candidate to the sole owned repository path."""
from pathlib import Path
import datetime,hashlib,json,sys
HERE=Path(__file__).resolve().parent;P=Path(sys.argv[1]).resolve()
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rd=lambda p:json.loads(p.read_bytes())
proof=rd(P/'index-verification550.json');candidate=P/'index-candidate550.json';manifest=rd(P/'extraction-input550.json');target=R/'docs/IMPLEMENTATION_INDEX.json'
assert proof['candidate_sha256']==sha(candidate)
assert proof['input_manifest_sha256']==sha(P/'extraction-input550.json')
assert all(x.get('passed') or x.get('rejected') for x in proof['cases']) and len(proof['cases'])==11
expected_current=sys.argv[2] if len(sys.argv)>2 else sha(HERE/'baseline-index550.json')
assert sha(target)==expected_current,'repository index changed; review before replacing'
drift={n for n,h in manifest['source_files'].items() if sha(R/n)!=h}
assert not drift,sorted(drift)
text=json.dumps(rd(candidate),ensure_ascii=False,indent=2)+'\n';target.write_bytes(text.replace('\n','\r\n').encode('utf8'))
assert rd(target)==rd(candidate)
receipt={'schema':'route3d-index-apply/1','applied_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'only_repository_write':'docs/IMPLEMENTATION_INDEX.json','previous_sha256':expected_current,'applied_crlf_sha256':sha(target),'candidate_json_sha256':sha(candidate),'extraction_input_sha256':sha(P/'extraction-input550.json'),'source_paths':223,'frontend_paths':126,'source_drift_at_apply':[]}
(P/'apply-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt))
