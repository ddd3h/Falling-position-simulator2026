# pass04: 連続幕方式の最終索引同期

比較元は PR31 `b9d960c858e886666167e841dee240801fcfd2a4`。現在の source/test/data README freeze を再取得し、repo では `docs/IMPLEMENTATION_INDEX.json` だけを反映した。前の部分幕方式の `pass03/` と `helpers-before-pass04/` は当時の証拠として保持した。

- 厳密集合は基準215 + 列挙8 = 223実体、frontend118 + 8 = 126。TypeScript70、JavaScript38、資産18。旧97非frontendのbytesを保持。
- 物理API34、HTTP40、旧Python構造と無関係なflow/bindingを維持。data flow36、screen binding17、WEB-SCENE3Dは30行へ接続。
- `source/`、`extraction-input550.json`、`frontend-index550.json` が今回入力と構文抽出。パース診断0。確定mainのSHA256は `c4fc03057ac30800da5e8d52dfeafc5cb2102502086b16fed49873bee2cc047d`。
- `index-verification550.json` は正例1・反例10の有限11検査。従来の型/依存/指紋/anchor/API/HTTP保護に、旧部分幕の意味が残る反例を追加した。TypeScript compiler/extractorは二巡とも同じであり、別実装parserによる検証ではない。
- 実ASL経路はEGM96変換した上端から表示専用floorへの全経路連続幕。floorは地形推定ではなく、real ASLは地物高を照会しない。人工AGLだけは上端のための現mesh照会と全節点が揃うまでの全体保留を区別した。固定dataのdist配布と元ASL/KMLを変えない関係も保持。
- `index.diff` は基準索引との差分、`from-pass03.diff` は前の適用索引との差分。pass03以降のsource変更は9実体。`helpers/` に今回生成/検証/適用プログラムの同一コピーを保存。
- `apply-receipt.json` と `final-readback.json` はsource drift 0、候補と適用bytes一致、CRLF保持を記録する。

確定SHA256:

- 索引: `1b8c51877bb2d8c36e7f9afaf2892295a04578cd96d859d2a45a321db3588062`
- 入力manifest: `7f440333e031f5adc5a0e320dac8bf896aa1b2cc56f6d5c92971709820bb12b9`
- frontend構文抽出: `a186c82e0096ff964e9245049a81d8a64f45048078b0d93cd31a7f519c5b73ef`

この票は構造・有限接点の検査である。アプリ起動、ブラウザ、数値計算、科学的受入、Git保存の実施票ではない。主担当の新方式ブラウザ観察とfrontend全試験の実績は別票へ戻す。検証票の一般的なsource-freeze警告について、今回のmain一致と全223実体の最終一致は `final-readback.json` で追記確認した。後続source変更時は再同期が必要。
