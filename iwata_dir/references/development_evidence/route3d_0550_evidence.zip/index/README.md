# 現行の索引票

現在の適用票は [pass04/README.md](pass04/README.md)。連続幕への設計変更後、全223 sourceを取り直し、11有限検査を通して索引だけへ適用した。旧pass03と旧helperは履歴として保存している。

---

# 0.55 3D 経路追加の構造索引

以下は旧部分幕方式の `pass03/` 当時の記録であり、現在の適用票ではない。比較元は主担当指定 PR31 `b9d960c858e886666167e841dee240801fcfd2a4`、変更前索引の保存コピーは `baseline-index550.json`。Git には接続・書込みしていない。

## 有限範囲

- 旧登録215実体を基準に、新規8実体を名前で列挙した厳密集合223。frontendは118+8=126（TypeScript 70、JavaScript 38、その他資産18）。frontendの実探索は `node_modules` / `dist` のみ除外し、索引へ未登録の追加・欠落を拒否した。
- 新規は route-layer / route-geometry / vertical-datum、固定DACとdata README、routes / geometry / datumの3試験。旧97非frontendのbytesを保持した。
- 新しい `WEB-SCENE3D` アンカーをPROGRAM編集元で確認し、3D枝と追加試験の計30行へ接続した。controllerの既存4関数の限定接点は意味を保ってhashと所在行を更新した。
- 物理API34件の辞書とAST署名、HTTP40件の辞書・実handler/行を保持・照合した。他のPython構造、旧抽出履歴、無関係な手動flow/bindingを同値検査した。
- 手動接点は従来の3D flowを限定更新し、表示状態共有、固定dataのdist配布、有限のmesh照会を3 flow追加（計36）。screen bindingは2追加（計17）。

## 保存票

- `pass03/extraction-input550.json`：223入力のSHA256と固定時刻。SHA256 `d1ed81f4dcacd5d112d8648a5fc2c081b29583ae18edb87bc6e9e83d166e3c00`。
- `pass03/source/`：当該223実体のコピー。APIに参照されるが旧215登録外の `tests/test_ensemble.py` は従来票のhashを確認して `linked-tests/` へ別保存した。
- `pass03/frontend-index550.json`：TypeScript compiler APIによる126実体の構文/指紋。パース診断0。
- `pass03/index-candidate550.json` / `index.diff`：検査済み索引候補と旧版との差分。
- `pass03/index-verification550.json`：正例1と有限反例9を含む10検査。欠落module、誤依存、誤宣言行、誤data分類、誤anchor、誤hash、物理API/HTTP/他flow改変を拒否した。
- `pass03/apply-receipt.json`：唯一のrepo書込みは `docs/IMPLEMENTATION_INDEX.json`。適用直前の223入力driftは0。JSONのCRLFを保持し、適用hashは `5343be190fc41dbe295e24c60db75c4dbe1a1feb4da154b300ba6ab4221905d8`。

確定mainのhashは `4ad05c01a7d57c5c3ef678630938560b30c3c7ec130e1d1341c90a9154a25d80`、geometry試験は `7880197fe770be714cece7980a2fe8ccab2b9e9b3a0d8e681fc0e984ac122c22`。主担当が通知した最終値と一致する。

## 再同期と限界

`update-index-route550.py --out <新しい保存先>` は旧索引＋列挙8実体で再抽出する。`verify-route-index550.py <同保存先>` は候補から独立して再度ソースをparseし検算する。同じTypeScript compiler/extractorを使う二巡であり、別実装の言語parserによる独立検証ではない。最上位宣言/import文字列の抽出であって、全closure・動的束縛・実行時依存の証明ではない。手動解釈をその構文値へ混ぜない。

適用は `apply-index-route550.py <保存先> [現在索引の期待SHA256]` に分けた。検証票・candidate・入力hashを照合し、現在sourceのdriftと索引の先行変更を拒否してから、所有path一つへ書く。初回の省略値は旧索引hash。再同期時は主担当が現在索引を確認したうえで期待hashを明示する。

外側直下の初回snapshotと `pass02/` は途中票として保存している。初回は既存async関数を単純な行頭検索で拾えず停止し、pass02の初回検査は旧索引から別保存する参照試験の取り扱い不足で停止した。検索をasync対応し、従来linked-testのhash照合を復元したpass03で成功した。これらの失敗時にrepo索引は書かなかった。

アプリ起動、ブラウザ、数値計算、科学的受入、Git保存の検査ではない。既存確認印を一括で更新していない。後続編集があれば、この入力票を最新だと扱わず主担当が再同期する。
