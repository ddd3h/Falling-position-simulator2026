---
document_id: BJP-COMMANDS
revision: 0.55.0
as_of: 2026-09-30
role: 本体の実行・再現・検査コマンド
---

# 本体を実行し、結果を再現する

[更新:0.55.0] [確認:0.55.0] — COMMANDS-CORE / REV-550-TECH-COMMANDS-CORE

<!-- LOGIC:COMMANDS-CORE:BEGIN -->

**0.55の確認範囲。** C-09の予報取得・原要求の保持/受付照合・単一送信タブ・原日時の有限比較を現ソースに照らし、旧CLI例と科学モデルの説明を保持した。比較元は0.54 C2 `cc7b0fd0463a69ad495debb7f03f1b3eb734e0e6`。確認印はこの操作契約と継承境界の読解であり、全コマンド/全UIの再実行を意味しない。実画面・取得費用・失敗と未確認は[S36](../BOOTSTRAP_RUNBOOK.html#s36-result550)へ戻る。

**0.54の改訂範囲（履歴）。** C-09の配布一覧、モデル地表の確認、単便・取得状況の再確認と保存再開を現在のソースへ合わせる。0.53で確認した保存JRAの秒付き本命/延期・領域該当・詳細を継承し、同じ画面で現在の予報を使える行程へつなぐ。本文と実画面の確認・費用・未確認は[S36](../BOOTSTRAP_RUNBOOK.html#s36-plan540)へ戻る。記述の追加だけで操作受入・科学精度・Google写真3Dの再試験を完了としない。

この一覧は既存CLIと、実予報の取得・一飛行・機体条件の仮感度集合・保存JRA-3Q統計を接続したローカル画面の実行入口である。0.50の保存再読修復、0.51の固定原本によるstrictの支持停止[C-10](#c-10固定jra-3q原本から飛行を計算し支持不足を読む)を保ち、0.52では明示的な地上再構成を使う実過去一窓の全飛行[C-11](#C-11)を加える。画面から始める場合は[C-09](#c-09同じ計画で画面を使い計算保存再開する)へ進む。GFSでは、まず保存された実気象の例で上昇・破裂・着地までを実行し、次に独自の時刻・領域で取得する。式と仮定は[理論ガイド](THEORY_GUIDE.pdf)、実体の階層と依存は[プログラム構造ガイド](PROGRAM_GUIDE.pdf)、処理・APIの挙動と例外は[実装ノート](IMPLEMENTATION_NOTES.md)と[環境契約](ENVIRONMENT_CONTRACT.md)、製品仕様は[気象データガイド](WEATHER_DATA_GUIDE.md)へ戻す。ここに同じ説明の別原本を作らず、実行に必要な入力と停止・再開の判断を示す。

0.52の確認はC-11、C-10との時点区分、CLI/保存schemaの接点、0.53はC-09の保存JRA操作であった。今回の改訂対象は上記C-09であり、旧CLI・科学モデル・全UIを一括して再実行した印ではない。

各操作はrepo rootで行う。既存CLIはインストール済みコマンド名への登録が不要で、`python -m balloon_sim`が入口である。本体の導入版は0.20.0、責務の配置・互換入口・SciPyへの数値移行は0.24.0。新しい画面とAPIの起動はC-09へ分ける。下記の固定例は数値検証用であり、実際の飛行計画を指定するものではない。

## C-01：実行環境と最短の確認

既存CLIの受入環境はPython 3.12.12である。ソース構文の下限と数値依存の対応Pythonは別で、別環境では採用するSciPy/NumPyの条件も満たす必要がある。保存された気象場の`inspect`は標準ライブラリ、`simulate`はSciPyとNumPy、`fetch`と`replay`はGRIB復号のecCodesとNumPyを必要とする。依存不足を本体が自動インストールすることはない。

このWindows環境では、取得・復号・飛行に既存の`C:/Miniforge3/python.exe`を使う。0.24の数値受入はSciPy 1.17.1 / NumPy 2.4.4で行った。別の環境を使う場合も実際のPython・SciPy・NumPy・ecCodesの版を記録する。画面用環境はC-09のlockから構築し、ecCodes 2.48.0・GeographicLib 2.1に加えて、0.49の保存風統計用にDuckDB 1.5.5を含む。下のPowerShell変数は既存CLIの後続例で共通に使い、永続PATHや既存環境を変更しない。

```powershell
$taskPython = 'C:\Miniforge3\python.exe'
$taskOutputRoot = Join-Path $env:TEMP ('balloon-run-' + [guid]::NewGuid().ToString('N'))
& $taskPython --version
& $taskPython -B -m balloon_sim --help
```

`-B`はrepo内の`__pycache__`生成を避ける指定で、計算式には影響しない。四つのサブコマンド`fetch`、`inspect`、`replay`、`simulate`が表示されることを確認する。`No module named balloon_sim`なら、まず実行場所がrepo rootかを確認する。

飛行を計算する前に、同じPythonで数値依存を確認する。

```powershell
& $taskPython -B -c "import sys, scipy, numpy; print(sys.version); print('SciPy', scipy.__version__); print('NumPy', numpy.__version__)"
```

取得・再復号の前には、復号依存も確認する。

```powershell
& $taskPython -B -c "import sys, eccodes, numpy; print(sys.version); print('ecCodes', eccodes.codes_get_api_version()); print('NumPy', numpy.__version__)"
```

ecCodesの確認が失敗しても、数値依存が確認できれば保存JSONからの計算は独立に進められる。SciPy不足なら飛行は開始せず、`inspect`による保存場の確認まで行える。環境整備の記録と承認範囲は[BUILD](BUILD.md)・指示書の当該手順へ戻し、別のPythonに切り替えただけで同じ環境と扱わない。

| ID | 操作 | 入力 | 出力・副作用 | 通信 |
|---|---|---|---|---|
| C-02 | `inspect` | 保存気象JSONまたはgzip | 検証後のメタデータをstdoutへ出す。ファイル変更なし | なし |
| C-03 | `simulate` | 飛行設定と保存気象 | 新しいディレクトリに結果・来歴・図を保存 | なし |
| C-04 | `fetch` | 固定run・時刻・領域・上限の要求JSON | 新しいディレクトリにraw、来歴、気象場を保存 | NOAA NOMADSへの明示要求 |
| C-05 | `replay` | C-04のrawと要求・来歴 | raw照合後、新しい気象ファイルを作る | なし |
| C-06 | 試験 | repoのコード・保存fixture | 試験結果。CLI試験の成果物は一時領域 | なし |
| C-07 | ガイド生成 | 編集元TeX二冊 | 新しい外側フォルダーにPDF・検索txt・ログ | なし |
| C-09 | 共通の計画・分析画面（予報・受付回復・原日時比較） | 保存GFS・登録した原日時JRA場・直接入力・ローカルJRA-3Q集計DB／人工の画面確認 | repo外に草案・表示状態・仕事・固定結果、図/KML等 | 導入時registry。NOMADSは明示観測/取得、地理院は地図表示、Google写真3Dは明示接続 |
| C-10 | 固定JRA原本→保存場→支持内の飛行と停止 | 保存済みモデル面原本と診断用設定 | 新規出力先にbundle・変換receipt・飛行結果 | なし |
| C-11 | 実過去一窓で地上→30 km→モデル地形への着地 | 地上解析量付きJRA保存場と明示B設定の固定例 | 新規出力先に飛行結果・来歴・図 | なし |

## C-02：保存された気象の範囲を確認する

```powershell
& $taskPython -B -m balloon_sim inspect references/flight_fixture/hokkaido-weather.json.gz
$LASTEXITCODE
```

終了0でメタデータが表示される。ここで使う気象場は2026-09-22 18:00 UTCのGFS runから取得した実データの小領域切出しである。切出しの来歴とハッシュは[fixture manifest](../references/flight_fixture/manifest.json)に残す。北海道と和歌山のファイルは、それぞれの固定例を通信なしで再現する入力であり、全国の任意地点を覆う配布データではない。

`inspect`はファイル全体のスキーマと場を構成できる前提を検証するが、stdoutはメタデータである。特定の飛行が最後までその領域・時刻を保つことや、気象予報が現実と一致することを保証する操作ではない。

## C-03：固定例の飛行を実行する

最初は設定を書き換えず、同じ例が全工程を通ることを確認する。次の二例は上昇則が異なるが、同じ取得run・時刻系・気象照会・積分・保存経路を使う。

```powershell
& $taskPython -B -m balloon_sim simulate examples/hokkaido-simple.json --weather references/flight_fixture/hokkaido-weather.json.gz --output (Join-Path $taskOutputRoot 'hokkaido-simple')
$LASTEXITCODE
& $taskPython -B -m balloon_sim simulate examples/wakayama-isothermal.json --weather references/flight_fixture/wakayama-weather.json.gz --output (Join-Path $taskOutputRoot 'wakayama-isothermal')
$LASTEXITCODE
```

期待する終端は終了0、stdoutの`status: "landed"`、`complete: true`である。`result.json`の`events`に`burst`と`landing`があり、最大高度30000 m、最後の`height_agl_m`が0付近となる。ここでの着地は粗いGFS地形との交差である。

各例の`report.html`をブラウザーで開くと、水平軌道、高度と地形、時刻スライダー、設定と来歴を見られる。例としてPowerShellでは次を使える。

```powershell
Invoke-Item -LiteralPath (Join-Path $taskOutputRoot 'hokkaido-simple\report.html')
```

水平図は背景地図なしの局所投影である。地物の確認用の地図としては扱わず、別のGISへ渡す場合は`trajectory.geojson`を使う。GeoJSONの座標順は経度・緯度・高度である。

### 保存されるものと、最初に読む値

| ファイル | 内容・再現上の役割 |
|---|---|
| `input.json` | 渡した設定ファイルの元バイト。既定値展開前の入力を保持 |
| `result.json` | 採用設定、状態、記録点、イベント、停止理由、仮定、`numerics`（方法・依存版・許容誤差）を含む計算結果 |
| `provenance.json` | 元設定・保存気象のパスとSHA-256、気象メタデータ、パッケージ版、本体の下位パッケージも再帰した全`.py`の相対パスとSHA-256、数値法・依存版・設定 |
| `trajectory.csv` | UTF-8 BOM付きの軌道表。複合値はJSON文字列で記録 |
| `trajectory.geojson` | 軌道LineStringとイベントPoint |
| `report.html` | 通信を使わない図と時刻別状態表示。上の結果を読むための表示 |
| `manifest.json` | 他の成果物のバイト数・SHA-256、結果の完了状態。自分自身はハッシュ対象外 |

まず`status`・`complete`・`stop_reason`、次にイベントと最終地上高、最後に時刻範囲と品質フラグを読む。`landed`は「この入力と仮定で接地まで解けた」という判定であり、着地位置の予測精度や実機の係数の採用判断とは分ける。

### 終了コードを区別する

| 終了 | 意味 | 次の処理 |
|---|---|---|
| `0` | 取得・検査・再生の成功、または飛行が`landed` | 各出力と来歴を確認する |
| `2`、stdoutに`stopped`結果 | 計算途中の支持不足・物理拒否・時間/歩数上限等。部分結果を保存済み | `stop_reason`と最後の支持範囲を読み、変更条件を決める |
| `1`、stderrに`status: "error"` | 計算前入力拒否、既存出力、環境、取得、保存等のエラー | `code`と`message`を読む。計算済みだと扱わない |
| `2`、usageと引数エラー | argparseによるコマンド指定の誤り。飛行の`stopped`とは別 | 必須引数を修正し、結果ディレクトリの有無だけで成功を判定しない |

取得や保存の途中で失敗すれば部分ファイルが残ることがある。ディレクトリの存在だけで完了とはしない。既存出力の上書きは拒否されるため、原記録を保ったまま新しい出力名で再実行する。

## C-04：別の時刻・地域のGFSを取得する

### 要求と打上げ時刻は別の設定である

予報runは00/06/12/18 UTCで指定し、`run_utc <= start_utc <= end_utc <= run_utc + 384時間`を要求する。予報の最大384時間はrun起点であり、任意の打上げからさらに16日先まで取得できるという意味ではない。飛行が続く時間もこの支持範囲に含める。

時刻には`Z`または`+00:00`を明記する。JSTを表す`+09:00`やタイムゾーンなしの文字列は、このAPIでは自動変換せず拒否する。たとえば2026-09-23 12:30 JSTを使うなら、入力は2026-09-23 03:30 UTCとする。

0～120時間先は1時間刻み、その後は123,126,…,384時間先の配布時刻を使う。本体は要求区間を挟む最小の配信時刻を選ぶので、打上げを配布時刻に合わせる必要はない。固定例の03:30 UTCは03時と04時の場の間にある。単一run内で同じ高度の場を時間補間し、途中で新しいrunへ自動更新しない。

全国での利用は地域名の選択ではなく、`bounds`と飛行設定の座標を変える。範囲には予想される移流先まで余裕を含める。取得矩形は0.25度へ外向きに丸めるが、日付変更線等の経度継ぎ目をまたぐ要求は本版の一回取得では扱わない。

### 要求JSONと実行

[固定取得例](../examples/gfs-japan-request.json)の実体は次の値である。**これは旧取得の記録で、0.47のメモリ受入上限では大きすぎるため、そのまま新規取得するコマンドには使わない。**これは取得成功時の再現用の例であり、配布期間を過ぎた後までこのrunがNOMADSに残ることは保証しない。後日の新規取得では別ファイルへ、実際に公開されているrunと必要な期間を明示して作る。

```json
{
  "run_utc": "2026-09-22T18:00:00+00:00",
  "start_utc": "2026-09-23T03:30:00+00:00",
  "end_utc": "2026-09-23T09:00:00+00:00",
  "bounds": {"west": 130.0, "east": 151.0, "south": 30.0, "north": 46.0},
  "max_bytes": 50000000
}
```

```powershell
# my-gfs-request.json に、現配布run・必要時刻と飛行に必要な小領域を明示する
& $taskPython -B -m balloon_sim fetch my-gfs-request.json --output (Join-Path $taskOutputRoot 'gfs-acquisition')
$LASTEXITCODE
```

`max_bytes`は一要求の合計取得上限で、1024～50000000 bytesを許す。省略時も50000000である。上限内に収まらなければ範囲・期間の設計を見直す。0.47では復号作業メモリの概算が512 MiBを超える要求も通信前に拒否する。画面の取得計画では実行前に概算を読める。概算はRSS保証ではない。失敗時に全地球・別run・別URLを自動的に試す仕組みはない。

成功時は`request.json`、`decoder.json`、`fNNN.grib2`群、`provenance.json`、`weather.json.gz`、`receipt.json`が保存される。全圧力面の風・温度・高度・比湿と地上量を復号し、各列で幾何高度30 kmを支えることを確認してから保存場を作る。HTTP成功だけでは取得受入にならない。

取得開始後の失敗は`failure.json`と途中までのrawを残す。要求・依存・メモリ上限・既存出力等の事前拒否では取得ディレクトリを作らずstderrへ理由を返す。提供側の未配布、保存期限、欠測、単位、格子、上限超過を区別し、元の要求と結果を指示書へ記す。CLIの通信再試行は新しい出力ディレクトリへ行う。画面の明示再試行は保存要求・復号器・完了rawの照合により同じ仕事から再開する。raw入力の上限には、新規取得・再利用・保全した部分rawを含める。新規通信bytesとは区別する。NOMADSの索引/GRIB取得は同じOSユーザーで間隔を共有し、直前の完了から10秒以上を空ける。待機を未応答や停止と取り違えず、進捗と取消状態を読む。runを変えるなら新しい予報比較であり、元の同一入力再現とは区別する。

### 独自の飛行設定を作る

設定の全例は[北海道・指定上昇率](../examples/hokkaido-simple.json)と[和歌山・等温浮力](../examples/wakayama-isothermal.json)を参照する。変更はコピーしたJSONへ行い、元例と比較できるようにする。

| 部分 | 選択と必須入力 | 単位・組合せ |
|---|---|---|
| `launch` | `time_utc`, `latitude_deg`, `longitude_deg`, `altitude_m` | UTC、degree、海面基準のモデル幾何高度m。地上高を直接渡す欄ではない |
| `ascent` | `mode: "constant_speed"`, `speed_m_s` | 正の上昇速度m/s |
| `ascent` | `mode: "isothermal_buoyancy"`, `gas_mass_kg`, `envelope_mass_kg`, `payload_mass_kg`, `drag_coefficient` | 質量kg、Cd無次元。任意`gas_constant_j_kg_k`の既定値2077.1 J/(kg K) |
| `burst` | `mode: "altitude"`, `altitude_m` | 打上げ高度より高い海面基準m |
| `burst` | `mode: "diameter"`, `diameter_m` | 正の直径m。等温浮力上昇が必要 |
| `descent` | `mode: "constant_cda"`, `mass_kg`, `drag_area_m2` | 正の降下質量kg、Cdを含む有効抗力面積m² |
| `descent` | `mode: "rated_speed"`, `reference_speed_m_s`, `density_model: "weather"` | 正の基準降下率m/s。任意`reference_density_kg_m3`は既定値1.225 kg/m³ |
| `descent` | `mode: "rated_speed"`, `reference_speed_m_s`, `density_model: "exponential"` | 正の海面基準降下率m/s。任意`scale_height_m`は既定値8400 m |
| `integration` | `max_step_s`, `max_duration_s`, `event_tolerance_s`, `max_steps` | 任意。採用間隔上限10 s、時間上限14400 s、時間根xtol 0.001 s、採用上限200000歩が既定 |
| `integration` | `relative_tolerance` | 任意、既定1e-9。100×double epsilon未満は拒否 |
| `integration.absolute_tolerance` | `latitude_deg`, `longitude_deg`, `altitude_m` | 任意。正の有限値。既定は経緯度各1e-9 degree、高度1e-3 m |

数値積分はSciPy RK45の適応刻みで、結果の記録点は不等間隔になる。固定出力間隔への再標本化は未実装である。破裂では同時刻の上昇/下降2行があり、相とイベントで読む。`numerics.record_sampling`と、比較する各行の時刻を確認する。

モデル内の未知キー・未実装modeは拒否する。`gas_mass_kg`等を真偽値や文字列として渡さず、JSONの有限な数値で指定する。`density_model`省略時は`weather`である。`constant_cda`の値と`rated_speed`の値を同じ選択へ混在させない。

固定例の打上げ高度は、選んだGFS地形の5 m上に置いた数値例である。別地点へ緯度経度だけ移した場合、その高度は再利用できない。打上げが地表下なら`LAUNCH_BELOW_GROUND`となるため、場の地形を確認し、どの高度基準を採ったかを記録する。粗いモデル地形と実測標高の差を、黙って設定値の修正で吸収しない。

上の取得出力を使う際のコマンドは、設定ファイルを明示して次の形になる。`my-flight.json`は利用者が作った新しい設定ファイルである。

```powershell
& $taskPython -B -m balloon_sim simulate my-flight.json --weather (Join-Path $taskOutputRoot 'gfs-acquisition\weather.json.gz') --output (Join-Path $taskOutputRoot 'my-flight')
$LASTEXITCODE
```

気象の領域・時間外、地上から最初の有効圧力面への橋渡し、寄与格子の地形延長が結果をどう制限するかは、気象品質と理論ガイドで確認する。必要量がないときに比湿0や標準大気へ暗黙に代替することはない。

## C-05：取得済みrawを照合し、通信なしで再復号する

```powershell
& $taskPython -B -m balloon_sim replay (Join-Path $taskOutputRoot 'gfs-acquisition') --output (Join-Path $taskOutputRoot 'weather-replayed.json.gz')
$LASTEXITCODE
```

終了0で`weather_replayed`が表示される。保存した要求、lead集合、URL、ファイル名、バイト数、SHA-256を確認してからecCodesで再復号する。rawが欠けている、変わっている、来歴と一致しない場合は止まり、ネットワークで不足分を補わない。

同じ復号コード・依存版を使った場合、元の`receipt.json`の`bundle_sha256`と新しいファイルのハッシュを比較する。PowerShellでの読取例は次のとおりである。

```powershell
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $taskOutputRoot 'weather-replayed.json.gz')
Get-Content -LiteralPath (Join-Path $taskOutputRoot 'gfs-acquisition\receipt.json')
```

別版のecCodes等を使えばメタデータも変わるため、ハッシュ不一致を直ちに物理量の不一致とも、問題なしとも決めない。版・正規化した数値・スキーマの差を確認して記録する。

保存気象からの飛行再現では、`input.json`の元設定、元の気象ファイル、同じ本体コード・SciPy/NumPy版・数値設定を使い、新しい出力先へ`simulate`する。`result.json`の同一バイトは再現確認になるが、`provenance.json`には入力の絶対パスが入るので、別の配置の全フォルダー同一バイトまでは期待しない。

## C-06：コードと資料の対応を検査する

```powershell
& $taskPython -B -m unittest discover -s tests -v
$LASTEXITCODE
& $taskPython -B tools/check_state.py .
$LASTEXITCODE
& $taskPython -B tools/check_health.py .
$LASTEXITCODE
```

本体の試験は`tests/test_flight_weather.py`、`tests/test_trajectory.py`、`tests/test_flight_numerics.py`、`tests/test_flight_cli.py`にある。アフィン場・独立な解析解・モデルの拒否条件・実気象fixtureを使い、CLI実行中は通信を禁止して反復一致を調べる。主要APIの署名は[IMPLEMENTATION_INDEX](IMPLEMENTATION_INDEX.json)から実ASTへ照合する。

一つの層を変更した際に絞るなら、たとえば次を使う。実行した試験名と範囲を記録し、部分検査を全検査の合格として記さない。

```powershell
& $taskPython -B -m unittest discover -s tests -p test_trajectory.py -v
```

数値設定の比較では、まず同じ保存場で`max_step_s`を20、10、5へ変え、着地時間・位置・最大高度を比べる。次に最大刻みを固定して`relative_tolerance`と成分別`absolute_tolerance`を厳しくする。適応刻みのため同じ行番号でなく時刻・イベント・終端を対応させる。`event_tolerance_s`はdense補間上の時間根の絶対許容誤差であり、着地点のm単位の精度保証ではない。局所数値誤差、気象補間、物理モデル、実飛行誤差を分けて判断する。

`check_state`と`check_health`は資料と台帳の整合を調べる。成功しても、最新GitHub状態、科学的妥当性、HTMLの実表示、PDFのページ品質まで確認済みとはしない。旧版との変更受入では、[DOCUMENT_CONTROL](DOCUMENT_CONTROL.md)に従い固定した旧版を使う検査も別に実施する。

## C-07：TeXから必要なガイドを生成する

`THEORY_GUIDE.tex`と`PROGRAM_GUIDE.tex`は直接編集する原本である。計画書の`PROJECT_PLAN.md → tools/build_docs.py`とは生成経路が異なる。初版は既存専用XeLaTeX、Noto Sans CJK JP / Noto Sans Mono CJK JPと、検索テキスト抽出用のpypdfを使う。詳細な既存環境とフォントの照合は[BUILD](BUILD.md)を参照する。

この環境ではpypdfはbundled Python側にあり、Miniforge側へ新しく導入しない。次はprocess内の環境変数を元へ戻す生成例である。

```powershell
$taskDocsRuntime = 'C:\Users\genia\.local\share\balloon-docs'
$taskDocPython = 'C:\Users\genia\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$taskGuideOut = Join-Path $env:TEMP ('balloon-guides-' + [guid]::NewGuid().ToString('N'))
$taskOldPath = $env:PATH
$taskOldFontConfig = $env:FONTCONFIG_FILE
try {
    $env:PATH = (Join-Path $taskDocsRuntime 'TinyTeX\bin\windows') + ';' + $taskOldPath
    $env:FONTCONFIG_FILE = Join-Path $taskDocsRuntime 'fonts.conf'
    & $taskDocPython -B tools/build_guides.py . --output-dir $taskGuideOut
    if ($LASTEXITCODE -ne 0) { throw 'ガイド生成が失敗。外側ログを確認する。' }
} finally {
    $env:PATH = $taskOldPath
    $env:FONTCONFIG_FILE = $taskOldFontConfig
}
```

生成器は新規出力先だけを受け入れ、各TeXを3回コンパイルして相互参照を解決する。PDFと検索用txt、各passのログ、入力・出力ハッシュを含む`build.json`を保存する。検索用txtはpypdfによる抽出であり、文字が得られたことと数式の正しい表示は別である。

終了0を確認した後も、既存`pdftoppm`等で全ページを描画し、文字欠け・数式・表・見出し・改ページ・リンクを確認する。表示を修正したらTeXへ戻し、新しい外側出力先で再生成する。PDFだけを手直ししない。

指定なしでは両冊を生成する。一冊だけ変更した場合は `--guide PROGRAM_GUIDE` または `--guide THEORY_GUIDE` を付ける（繰返し指定可）。選択したPDF/txtをrepoへ反映する操作は、同じコマンドへ`--publish`を付ける。この場合も新しい`--output-dir`を使い、生成器は選択した全冊のビルド成功後に、そのPDF/txtだけを`docs/`へ複写する。`build.json`の`selected_guides`を確認する。未選択の既存ガイドは再生成しない。版・元TeX・表示確認が一致した組を保存し、生成物だけ先に公開しない。

## C-08：途中停止から次の判断につなぐ

| 観測 | 原因の確認先 | 次に変える対象 |
|---|---|---|
| 時刻の支持を失った | `stop_reason`、runと有効時刻、飛行時間 | 取得期間。runの最終予報時刻を超えるなら打上げ/利用runの条件を再検討 |
| 緯度・経度の支持を失った | 最終採用点と取得矩形 | 領域と取得量。地域名の特例コードは足さない |
| `LAUNCH_BELOW_GROUND` / `BELOW_GROUND`、地形衝突 | 打上げ高度基準、局所地形、相 | 入力高度と地形の意味。衝突を着地成功へ変換しない |
| `INSUFFICIENT_LIFT` | 等温モデルのガス・膜・搭載質量と密度 | 物理入力・仮定。指定上昇率へ自動切替しない |
| 必要量欠測・GRIB識別不一致 | raw、要求、取得来歴、フィールド名・単位 | 取得/正規化契約。類似量への無記録な代替はしない |
| `MAX_DURATION` / `MAX_STEPS` | `integration`と最後の相・高度 | 必要な計算上限と異常の有無。上限だけ無条件に増やさない |
| `OUTPUT_EXISTS`等 | 指定したファイル/ディレクトリ | 新しい出力名。旧成果物を消して再利用しない |

停止理由を読んだ後、変更した入力、採用/保留の理由、再実行の条件と結果を同じ指示書の実施欄へ戻す。気象APIやモデル仕様の新しい知見は担当ガイドへ集め、手順書だけに長文の仕様を埋めない。この対応が、会話なしで次の計算と判断を再開するための記録になる。

## C-09：同じ計画で画面を使い、計算・保存・再開する

0.55は、以下の予報操作に受付の復旧と原日時比較を加える。0.54で接続した経路は、現在の配布を観測して選び、必要な予報を取得し、放球地点のモデル地表を確認して、以下の既存比較・保存経路へ進む。通信が途切れた場合も草案と固定結果を保持して状態を再確認する。0.53で加えたC-11と同じ保存JRA一窓の代表手順、0.49時点の到達範囲は以下へ残す。

0.49の開発中の画面は、既存の打上げ計画・詳細・気象分析・季節計画を共通の入口へつなぐ。0.47で加えた実予報の準備と明示適用に続き、固定GFSでのn=1と、一変量の仮幅から作る集合を選べる。集合は一つの固定気象に対する機体条件の感度であり、校正済みの気象誤差や過去場の統計ではない。実風統計は、提供されたJRA-3Qの半月集計DBを年間・地域図で読む。原気象場を復元して飛行する接続ではない。人工データの四つの気象画面・季節計画は別に残る。以下は現在のソースに対応する操作で、実UIの受入済みを意味しない。受入・未確認はS36に記録する（0.46の画面統合実績はS35）。

### 初回の依存と画面ビルド

Node.jsは `frontend/package.json` の下限を満たす版、Pythonは3.12を使う。専用のbackend/.venvへ固定requirementsを入れる。npm ci/pip installは依存配布先へ通信する。requirements.lockは版の固定で、wheel hash lockではない。

```powershell
python -m venv backend/.venv
& backend/.venv/Scripts/python -m pip install -r backend/requirements.lock
npm --prefix frontend ci
npm --prefix frontend run build
```

`frontend/node_modules`、`frontend/dist`、`backend/.venv` は再生成可能なruntimeで、正本ソースや唯一の結果の置場ではない。buildはReact画面に加えて、現役sourceの `frontend/scene3d` を `dist/scene3d` へ、npmで解決したCesiumを `dist/cesium` へ配置する。旧模型ZIPのvendorを別に手作業でコピーする手順ではない。出典と配布の境界は [SCREEN_PROVENANCE](../frontend/SCREEN_PROVENANCE.md) に戻る。依存不足やbuild失敗時は出力を確認し、別の既存Pythonへ無言で切り替えない。

### 起動と画面の使い分け

```powershell
& backend/.venv/Scripts/python -B -m uvicorn backend.app:create_app --factory --host 127.0.0.1 --port 8451
```

同じPCのブラウザで `http://127.0.0.1:8451/` を開く。APIが `/api/v1`、画面資産が `/assets`、独立3D画面が `/scene3d`、Cesiumが `/cesium` で配信される。起動前に `$env:BALLOON_DATA_DIR = 'C:\任意の保存先\balloon-state'` を設定すれば別の保存先を使える。省略時は `%LOCALAPPDATA%/BalloonSimulator/state`。検査用に別buildを配信する場合は `BALLOON_FRONTEND_DIST` をその絶対パスへ設定する。同じ保存先を二つのserviceから同時に開かない。上の例はloopbackへ限定したローカル起動である。

1. 「打上げ計画」の「表示するデータ」で「保存気象・実計算」を選ぶ。旧版の表示名は「固定GFS・実計算」で、0.53候補では保存JRAも同じ入口から選ぶ。北海道/和歌山のGFS例や東海のJRA例は固定された過去の入力で、最新予報ではない。資料名、解析/予報の区別、有効UTC、支持範囲を読む。この名称と保存JRAの代表操作は0.53の実画面でも確認した。
2. 必要な候補を追加し、条件棚で入力を編集する。一飛行なら「標本の作り方」の「計算方法」を「指定条件の一飛行（n=1）」にして「この条件で計算」を押す。延期系列は親の条件から時刻差を持つ草案として作る。系列の作成だけでは計算しない。親の計算操作は親と延期列を対象にする。入力編集中も、旧固定結果は別の計算時の版として保持される。
3. 候補タブ、共有地図、詳細の履歴と時刻操作で結果を読む。実n=1には50/90/95%の分布域を生成しない。着地と支持不足等による停止を区別し、停止時の最後の有効位置を着地点とみなさない。灰破線の水平境界に加え、高度/時刻の支持も確認する。保存視点がない初回は結果の読込み後に全体へ合わせる。保存した視点や、その後のパン・ズームを状態の再確認で巻き戻さない。詳細の風速・風配の軸は選択標本の本数を整数で示し、n=1を確率分布に読み替えない。
4. 表示結果の選択欄、または「保存結果を開く」で固定runを選び直す。入力を変えた草案と、表示中の計算結果が同じ条件かを確認する。図やKML等の出力は現在表示対象の保存であり、project全体の別PC移送とは区別する。
5. 「気象を分析」は「保存JRA-3Q集計」を開く。接続は下記の「保存した風統計DBを分析する」を使う。「表示するデータ」を「画面確認用の人工データ」へ替えると、従来の四つの気象画面と地点/時期を季節計画へ渡す操作を使える。0.55の「季節計画」には下記の原日時比較があり、人工データの画面とは切り替えて使う。

背景の「未接続」という利用状態を選ぶ項目は0.47で取り除き、通常の地図または衛星・航空写真を表示する。地図表示は地理院タイルへ接続する。写真3Dは引き続き明示接続である。保存場の数値計算そのものは、地理院やGoogleへ通信しない。背景地物と計算に用いた地形の精度は同じではない。

<a id="C-09-JRA"></a>
### 保存JRAの一窓で本命と延期を比べる（0.53候補）

上の同じbuild・起動手順を使う。新しいJRA取得service、APIキー、DuckDBの起動設定は不要である。保存JRAの計算は原NetCDFや取得時の外側pathを読み直さない。これは取得済み実気象を画面で使う行程で、任意の過去日時をダウンロードするUIではない。以下は0.53候補で実行した代表手順である。別版・別環境では、秒や由来表示を含む対応を確認して使う。

1. 「共通の準備」→「気象の準備」の「保存済みの気象」を開き、「東海・保存JRA-3Q解析例（暫定地表接続）」を確認する。2024-01-01の00/06/12 UTC、100モデル面と対象範囲、モデル地形・暫定再構成の注意を読む。「配布一覧を更新」やGFS取得操作は、この保存例を使うためには押さない。
2. 「この保存例から候補を作る」でC-11の入力例を作り、機体・放球地点・幾何ASL高度・最大時間を確認する。初期日時は **2024-01-01 11:17:13 JST（02:17:13 UTC）**。既存候補に「選択候補へ適用」した場合は、入力例へ戻るのでなく、その候補の物理条件を保って気象だけが変わる。
3. 06 UTCを跨ぐ比較を調べる場合は、親の放球日時だけを **2024-01-01 13:17:13 JST（04:17:13 UTC）**へ明示変更する。13秒が残ることを確認する。これはC-11の既定日時を無変更で実行した例とは分ける。地点や機体は変えず、地上高度を別地点へ黙って流用しない。
4. 親候補の延期列の編集で **＋30分**を追加する。子は13:47:13 JST（04:47:13 UTC）で、機体・ガス質量・同じ保存場を継承する。親子それぞれの「放球＋最大飛行時間」が保存窓内かを確認する。「指定条件の一飛行（n=1）」で親の「この条件で計算」を押す。各候補は別受付なので、一方の拒否を両方完了と読まない。
5. 共有地図と延期列で固定結果を選び、軌道・着地または停止・元日時を比較する。必要なら検査用と明記したGeoJSON領域を読み、該当した同じ結果から詳細へ進む。n=1は点と軌道であり、50/90/95%の分布域や校正済みの干渉確率ではない。CLIとの数値比較では画面が受理した各固定入力と同じ場・数値環境を使い、全records・events・status/summaryを比較する。候補名・run ID・出力pathの差は分ける。
6. 地図・詳細時刻・選択対象を確認して「計画を保存」する。同じ保存先で再起動し、「保存結果を開く」→「保存した計画を読み直す」で親子、固定結果、領域・選択・時刻を確かめる。草案を編集しても、表示中の旧結果は以前の入力・気象に固定される。再読失敗は下の再読操作を使い、再計算で上書きしない。

現在場と固定結果の資料が一致しない表示、利用不能、照合情報不足は、入力差分や結果の未読とは分けて読む。現在場が無いことは保存resultの欠損を意味しない。旧票のhash不足も「別内容へ変わった」と断定しない。現在の資料名やhashで旧結果の来歴を更新せず、新しい計算が必要なら明示して固定結果を作る。場の初回読込・検査、待ち行列・計算、結果読込/描画、保存再読の費用を分け、保存場利用の通信0を新規取得の速さと呼ばない。

北海道の半月風統計からこの東海窓を選んだ実証ではない。当時未実装だった原日時の複数窓は、0.55の明示比較へ接続する。任意過去日時の新規取得UI・多年を代表する季節MCは未了である。再構成の定義とCLIの保存例は[C-11](#C-11)、由来の四状態は[実装ノート](IMPLEMENTATION_NOTES.md#IM-JRA-GUI)へ戻る。

### 実際の予報を準備する

「共通の準備」→「気象の準備」から始める。既存の保存例の場を、実際に選んだ予報へ替えるための行程である。

1. 「配布一覧を更新」を明示して配布中の初期時刻を観測し、使う初期時刻を選ぶ。固定runを調べる場合はUTC欄へ入力する。観測時刻と一部失敗の有無を読み、選択中のrunと今回観測した新しいrunを区別する。選択中のrunが新一覧から欠けても別runへ自動で替えず、「この観測で配布未確認」と示す。新しいrunを使う場合は明示して選ぶ。一覧は観測時の配布ファイル名であり、GRIBの内容を検査済みという意味ではない。
2. 対象候補を選ぶ。延期子は親と一緒に含め、秒を含む放球時刻から最大飛行時間までの必要窓を表示する。全対象の放球点を含む範囲（「範囲へ合わせる」で地点群へ拡張できる）、raw入力・作業メモリ上限を指定して「取得計画を確認」を押す。この段階では外部取得しない。
3. 「固定計画」で必要窓と取得する有効時刻、外向きに丸めた範囲、量の概算を読む。「取得範囲を地図で確認」で橙破線と候補を比較し、「取得条件へ戻る」で調整する。取得条件や延期列の必要時間窓を変えたら再計画する。配布・依存・上限不足がある計画は開始しない。
4. 「この固定計画で気象を取得」を明示する。待機/保存rawの照合・コピー/取得/復号とファイル数・新規通信/再利用bytesを確認する。同じ正規化要求・復号器の完成場は照合して再利用する。窓を延ばした場合も、登録済み完成資産に同じrun・lead・量指定・丸め後矩形・URLのrawがあり、bytes/hash等の検査を通れば独立にコピーし、不足時刻だけ取得する。コピー後は新しい全時間窓を現在の復号器で検査する。例えば6時刻から7時刻への拡張で必ず1時刻だけの通信になるとは限らず、一致する登録資産と正常なrawが必要である。取消は処理途中の安全な境界で反映されるため、取消要求と取消完了を区別する。
5. 完成後、適用先を確認し「完成した気象を選択候補へ適用」を押す。候補の物理入力を保ち、選択場だけを替える。取得完了だけでは候補や旧計算結果は変わらない。条件棚で放球地点・時刻・高度を確認し、新しい計算を実行して固定結果として比較する。

放球地点や選択気象を変えたときは、条件棚の「モデル地表を確認」で、その場のモデル地表と現在の幾何ASL高度との差を読む。必要なら地表からの余裕を指定し、「地表＋指定高さを放球高度へ反映」を押す。照会だけでは入力は変わらず、移動前の応答を別地点へ適用しない。既定の5 mは入力の提案であり、現地の必要高度を決める値ではない。計算に使うモデル地形は粗く、実DEM・建物・樹木とは異なる。この一点の地表が取得できても、全高度の気象支持や全飛行を保証しない。

時間窓は取得時と計算時の両方で検査する。取得後に延期列や最大飛行時間を延ばし`WEATHER_WINDOW_UNSUPPORTED`となった場合は、新しい必要窓で気象を準備する。単に放球時刻が入っているだけでは足りない。範囲・高度支持を飛行途中で外れる場合は停止結果として読む。完成した場の上端最小値や30 km支持は、任意の破裂条件まで全軌道を解ける保証ではない。

raw入力上限は新規通信・再利用raw・保全partialの合計に対する受付制限で、節約した通信量やgzip容量を示す値ではない。一致候補に破損や同URLで異なる内容があれば停止するため、再利用失敗を黙ってダウンロードへ置き換えない。

取得失敗/取消/中断は原rawと失敗理由を残す。「同じ計画を再試行」は照合後に再開し、自動で別runへ替えない。`SOURCE_CHANGED`ではコードと起動状態が違うためserviceを再起動する。復号器も変わり`DECODER_CHANGED`となる場合は新しい計画が必要で、同じ仕事を無条件に再開しない。保存閲覧と取消は引き続き可能。依存不足は同じbackend環境へlockを導入して再起動し、別Pythonの成功を流用しない。

「状況を取得できない」は、取得処理が失敗したと確定した意味ではない。画面は最後に確認した状態と時刻を残し、実行中の仕事を間隔を延ばして再確認する。「状況を確認」は保存された仕事のGETであり、「同じ計画を再試行」と異なり取得処理を再送しない。初期の資料一覧・依存情報・取得履歴の読取り失敗も、表示された再確認から読み直す。現在の入力・選択run・固定計画は保持する。

### 仮幅を固定し、対応する集合を比較する

親候補の「条件を編集」→「標本の作り方」で、「計算方法」を「一変量の仮幅を共通標本で調べる」にする。今回の選択は次の三つで、比較に含める全候補がその量を使う必要がある。

| 「変える元量」 | 単位 | 使える方式 |
|---|---|---|
| ガス質量 | kg | 等温浮力上昇。破裂後の下降質量を同時に変える入力ではない |
| 破裂高度 | m | 高度による破裂。海面基準で、径破裂には適用しない |
| 基準下降速度 | m/s | 定格速度による下降 |

1. 「下端」「上端」「標本数 N」「seed」と「一様分布の仮幅を置く理由」を入力する。下端 < 上端にする。初めに表示される同じ値の上下端は、採用済みの幅ではない。気象誤差・製品の校正済み分布・事故確率の入力とは区別する。
2. 親の延期列は一緒に含まれる。モデル等の違いも比較するなら「同じ実現値で比較する独立候補を追加」で選ぶ。全候補に同じ固定気象と同じ元実現値を使う。延期子では時刻だけが変わり、モデルを変えたい場合は独立候補にする。候補ごとの結果を一つの分布へ混ぜない。
3. 「標本と計算入力を固定して確認」を押す。予定試行数、入力不成立数、元実現値、必要な時間窓と固定気象の有効範囲を読む。この操作だけでは飛行しない。候補数 × Nは256以下、同時進行集合は4以下という初期の運用制限がある。適切な標本数を保証する値ではない。
4. 固定内容を確認して「この固定計画で実行」を押す。入力や比較候補を変えたら、古い計画を使わず固定し直す。時間窓が不足する候補名と終了時刻が出た場合は「気象の準備」でその窓を含む場を取得・適用するか、放球時刻/最大飛行時間の意味を見直してから再計画する。実行可能にするためだけに飛行時間を切り詰めない。
5. 状態別の数を確認し、固定結果ができたら「この集合の候補を表示」を押す。計算や再開の完了だけでは地図の旧結果を置き換えない。着地L/予定Nを読み、50/90/95%は得られた着地点の経験的な包含域として見る。停止・未実行・失敗を非干渉着地へ含めない。点や線に退化した結果にも、人工的な幅を足さない。
6. 「共通の準備」→「落下を避ける領域」からGeoJSON/KMLを追加する。「この候補を詳しく →」の「干渉」で該当した着地群を選び、元量の分布・「全予定試行の入力・終了理由」・相別履歴を読む。「全記録」で予定Nへ戻り、地図上の囲みや一点選択でも掘り下げられる。干渉H/着地Lの割合を、全予定の安全確率とは扱わない。領域や標本の選択を変える操作は集計だけで、飛行を再計算しない。
7. 見たい固定結果と群を選び、分析の読込み完了を確認して「計画を保存」へ進む。図を渡す場合は詳細の「PNG保存」「SVG保存」を使う。群は固定結果と領域に対応して保存され、再読時に一致しなければ全予定試行へ戻った案内を読む。古い群を新しい結果へ無言で適用しない。

「残る試行を取り消す」は実行中の一飛行を強制終了せず、未開始分を止める。「未完了の試行を再開」は未投入・取消・中断・実行失敗の行だけを同じ実現値で再投入する。着地・物理停止・入力不成立を成功するまで引き直す操作ではない。仮幅や物理条件を直す場合は新しい固定計画を作る。再開前のsnapshotも残り、保存結果一覧で以前の計算回を選べる。

履歴集計の対象 `result.json` 合計が64 MiBを超えると、履歴の未生成理由と省略数を返す。着地点・経験域・予定数・原履歴は保持するので、地図で対象を絞って再分析する。空の履歴図を「飛行しなかった」と解釈しない。これはサーバ側の履歴集計を受け付けるための制限で、ブラウザ通信量やプロセスの実メモリ上限保証ではない。詳細の原履歴は、現在の選択に対応する集計がこの制限を通った後に、画面内で最大4件ずつ読む。制限を超えた群の全原履歴を先回りして取得しない。表示読込みだけが失敗した場合は「表示データの読込を再試行」を使い、物理試行の再開と区別する。

集合の状態を取得できない場合、画面は「現在の状態を確認できません」と最終確認時刻を示す。表示件数は最後に読めた値であり、計算の失敗・停止の確定ではない。集合関連のGETは応答本文を含め30秒で読取りを打ち切る。進行中集合の状態確認は読取り完了/失敗後に通常0.9秒待機し、失敗が続くと次の確認までの待機を最大15秒まで延ばす。応答を待つ時間は別に掛かる。「状況を確認」はGETだけを行い、計算・取消・再開のPOSTを再送しない。別の送信エラーは状態GETの回復で消さない。画面の保存再読/終了では旧監視を解放し、表示中の固定結果を保つ。

### 保存した風統計DBを分析する

提供された `jra3q_hokkaido_wind_2016-2025_v1.duckdb` を、repo外の原資料の場所に置く。任意のDuckDBを読み込む入口ではなく、この資料のテーブル・量・支持を検査する専用接続である。serviceを正常終了してから、同じPowerShellで次を設定し、上記uvicornコマンドで再起動する。例のpathだけを実際の所在へ置き換える。

```powershell
$env:BALLOON_CLIMATE_DB = 'C:\資料の場所\jra3q_hokkaido_wind_2016-2025_v1.duckdb'
$env:BALLOON_CLIMATE_SHA256 = '1af26d91500252c285f89e2cc50eb32fd325f6df9905ad0c5162282791d5137a'
```

このSHA-256は[提供風資料の受入記録](../references/WIND_REPORT_REVIEW.md)にあるv1 DBの固定識別である。DBは読取専用で、ブラウザからpath/SQLを送らない。SHA指定は省略可能だが、その場合も起動時に全内容をhashし、画面と保存集計へ識別を残す。別内容を使うために既定の期待hashを無条件に計算し直さず、その資料の採用を判断する。DB未設定/不一致なら実資料を利用不可として示し、人工値へ補完しない。環境変数を変えただけでは稼働中の資料を切り替えない。

1. 「気象を分析」→「保存JRA-3Q集計」で資料名/hashを確認する。「資料の状態を再確認」は現在の登録状態を読む操作で、別DBの登録や全内容hashの再計算ではない。
2. 「対象の元格子と表示面」で経緯度の範囲と地域図の気圧面を選び、「この対象で再集計」を押す。範囲に中心が入る元格子を含める。「全元格子へ戻す」は範囲入力を戻すだけで、適用は再集計ボタンで行う。入力中は従来の固定図を保持し、「入力は未適用」を読む。地域図の気圧面バーを操作した場合は、その面の集計要求を送る。
3. 「年間の高度構造」で平均風速・平均来向・定常度・地点別平均風速の幅を読む。「地域差」は同じ気圧面の平均風速/風向または定常度を12半月ずつ表示し、矢印ボタンで残り12半月へ進む。色尺度・凡例を併読する。地図色セルは元中心間から作る表示区画であり、連続気象場の支持範囲ではない。
4. 「表示中の固定集計と出典」でanalysis ID、query/result hashと適用範囲を確認する。資料一覧は登録DBを必要とするが、保存済み集計の再表示はDBがなくても可能である。固定集計を表示した状態で「計画を保存」し、後で保存計画を読み直す。草案queryと表示中の集計参照は別に保存されるため、未適用の入力を表示図の条件と取り違えない。
5. 「この組の図を保存」または「表示中の図を保存」で、保存開始時の図・凡例・集計条件/識別を単独表示できるSVGへまとめる。地域図は地理院背景も読み出して埋め込むため外部通信がある。出典/背景情報は図へ実際に含めた背景だけを記録し、年間図には地図背景を付けない。背景の取得に失敗したときは保存せず、表示中の集計は保持する。SVGは図の配布物であり、任意再集計を行うDBやprojectの代わりではない。

この接続は2016–2025年、UTC 00/06/12/18時をまとめた半月（1–15日、16–月末）24区分、38気圧面・最大570元格子を対象とする。年・時刻マスクの変更、週区分、原標本の分位分布/風配図、「季節による分布」「打上げへの影響」や実季節飛行は未対応であり、人工画面の機能を実資料の機能としない。時刻数と格子数は別で、積を独立な気象標本数と読まない。高度軸はISA補助高度、幾何高度の補足は元DB全域・全期間の集計である。統計量の定義と解釈はTHEORYへ戻る。

資料一覧と保存集計のGETは20秒、新集計のPOSTは60秒を画面の応答待ちの期限とし、ブラウザの読取り中断を要求する。POSTの待機終了はサーバ集計の取消/未受付を意味しない。同じ画面で同じ入力を再試行すると同じ受付IDで照合する。入力を変えても旧図は保持し、遅れて到着した別入力の応答へ無言で切り替えない。保存計画の再読は固定集計のGETであり、再集計POSTを自動実行しない。

### 計画を保存して再開する

「計画を保存」は草案・候補の親子関係・元量の仮幅/理由と、表示する固定runまたは集合snapshot/case参照に加えて、用途別の `ui_state` を保存する。予報では候補/群の選択、表示・色、禁止領域、詳細指標・時刻、地図/衛星の背景種類・位置/高さ、3Dの軌道とカーテンの表示状態等、気象では分析条件等が保存対象である。保存された内容の詳細は [IMPLEMENTATION_NOTES](IMPLEMENTATION_NOTES.md) に戻る。Googleのキー・接続、ブラウザの一時対話は保存対象に含めない。

人工候補だけの書出しは候補メニューのJSON保存を使い、読込みは「すべての候補 · ＋」内の「人工候補JSONを開く」から行う。これは上記APIの計画保存・固定run読込みとは別の形式で、実計算表示では入口を出さない。実候補を削除しても固定runは残るが、草案の即時取消は未接続である。人工候補の削除直後の取消とは区別する。

未保存の表示を確認してから保存し、ブラウザやserviceを閉じる。同じ保存先で起動後、「保存結果を開く」から「保存した計画を読み直す」を使って草案・固定結果・画面状態を確かめる。別の集合結果を見る場合は同じ一覧の「固定集合を表示」で計算回と候補を選ぶ。保存内容の再読は今の未保存編集を置き換えるので、仕事の状態だけを確認したいときは下記の再確認を使う。保存や再読だけで新しい計算は送信されない。科学結果は不変のrun/snapshot参照として読み、再試行の最新結果や画面状態で書き換えない。

単便の状況は画面上部で確認できる。通信失敗時は最後の確定状態・確定時刻を保ち、実行中の仕事は自動再確認する。「状態と結果を再確認（再計算なし）」はGETだけを行い、新しい計算を送信しない。計算終了と結果の読取り成功は別なので、結果の読取り中断も計算失敗へ変えない。単便/気象準備の各GETは応答本文を含め20秒で待機を打ち切り、正常な観測の後は約0.9秒、失敗後は約1.8秒から最大15秒の間隔で次を確認する。これは1 GETの期限で、複数のGETを使う観測全体の所要時間ではない。集合の30秒期限は前節のままである。入力編集中や別の固定結果を選んだ後に旧応答が届いても、草案やその表示選択を取り消さない。

保存結果の復元中は「保存結果を読込中」とし、未計算・0標本とは区別する。読取り失敗や保存先の404はそのまま表示する。「保存結果を再読込」は保存済みrun/caseのGETを再試行し、新しい軌道計算や気象取得を開始しない。表示する選択群・干渉群に保存済み集計がない場合は、表示側が別途その集計を作成することがある。保存分析への参照が一致すれば分析もGETで復元する。概要・3D・KMLは干渉した個別着地点を示し、外周だけのための集計は要求しない。干渉群全体を調べるときは件数または詳細の「干渉」から進む。風統計の「保存した図を再読込（再集計なし）」は固定した図のGETであり、元DBを再集計しない。詳細の選択群と時刻、比較参照、未適用の草案は復元を待つ間も保持する。時間範囲が未読の間は保存時刻を表示し、時刻バーは結果の読込後に表示する。保存先の404は再読ボタンで結果を再生成するものではない。

serviceは同時1飛行・最大4待機で、集合も同じworkerへ順に投入する。直接n=1の取消は待機中だけ。集合の「残る試行を取り消す」は未開始分を止め、実行中の一飛行の結果を残してから取消を終える。端末のCtrl+Cによる正常終了も実行中仕事を待つ。再起動時は完成物の照合・回復を先に行い、なお未完の集合と投入済の仕事をinterruptedへ移し、未投入行は未投入のまま残す。自動再送しない。ブラウザ再読は既存仕事を観察し、後着結果で保存済みの比較選択を置き換えない。 ただし受付不明の固定要求を明示照合して回復した単便は、その候補の表示選択が空で、草案が送信時点と一致し、選択世代も変わっていなければ初期表示へ入る。編集後の草案や既存の比較選択を回復結果へ置き換えない。応答不明の単便・集合要求は、ブラウザ再読後も固定本文と同じ要求IDを保持する。下記の受付回復節に従って確認・明示再送し、編集した別入力へ置換しない。受付後の新しい「計算」操作は新runになる。原場が後で不足しても固定結果は読めるが、再計算可能とは限らない。

### 原日時の複数窓を、共通機体で比較する（0.55）

「季節計画」→「保存気象・実計算」が入口になる。「気象を分析」の固定した年間・地域図から「打上げへの影響」へ進むと、関心の半月・領域・集計出典を渡せる。半月平均から瞬時場を生成する操作ではない。人工データは切替で残る。

1. 「原日時の比較候補を追加」で保存場の診断用入力から候補を作り、「条件を編集」で地点・ASL・機体・最大飛行時間を確認する。各原日時へ共通適用する条件である。診断例のASLを別地点へ無条件に流用しない。
2. 「原日時を追加」で、実際の放球日時（JST、秒付き）・その日の登録場・選んだ理由を入力する。季節分析から渡された関心条件と、取得済みの日時が一致するかを利用者が判断する。未取得日は場を「未取得・未登録」のまま残せる。
3. 「原日時と計算入力を固定して確認」で、予定数と実行可能数、各日時の時刻/放球点の支持を読む。未取得・最大時間不足・領域外の行を予定から自動で除かない。この事前確認は全軌道の支持保証ではない。
4. 「この原日時集合で実計算」で同じ飛行核へ渡す。完成後「この原日時集合を地図へ表示」から、従来の地図・禁止域群・履歴・図保存へ進む。全予定数、着地数、停止/不成立を分ける。少数日時の経験域は将来の落下確率ではない。
5. 原日時・理由・共通機体を変えたとき、表示中の固定結果は以前の計算に残る。新計画を確認して実行するまでは変更前の結果として読む。「計画を保存」で草案の日時一覧、固定計画/結果への参照と画面を保持する。

登録済みのJRA例以外は、起動前の `BALLOON_HISTORICAL_CATALOG` にローカルJSONの絶対pathを指定する。schemaは `balloon.historical-catalog/1`、`sources` の各要素に `id`（historical-で始まる一意名）、`label`、`path`（catalog基準の相対pathも可）、保存bundleの `sha256`、任意の `default_config` を置く。原UTCのJRA modelまたは明示B schemaだけを受け付ける。C-10は旧小領域原本からstrict場への固定変換、C-11は既成B場の飛行例であり、任意NCSS応答の汎用変換器ではない。今回の北海道2窓はS36の固定原応答と外側normalizerへ戻る。Webから任意pathを開かせるAPIではなく、任意年月の自動取得UIもまだない。catalog一件が壊れても旧固定結果の閲覧は独立している。

### 受付が分からなくなった場合と、保存先の同一性（0.55）

送信前の完全な入力・要求IDはブラウザのlocalStorageへ保存し、送信の待機は60秒で打ち切る。時間切れは未受付の証明ではない。単便と延期列は一件ずつ投入し、再読込み後は勝手に続きを送らない。「受付を確認（読取りのみ）」で同じ要求IDを調べ、未送信分の続行は明示する。集合も保存した同一ID・本文で確認/再送し、現在の編集中入力を混ぜない。

ブラウザの未確定要求は保存先の不透明なinstance IDへ結び付く。同じURLでもinstance IDが異なる台帳には、旧要求を自動移植しない。独立に初期化した保存先には別IDが付き、同じ台帳のバックアップ・複製は同IDを保つため、複製や巻戻しを検出する機能ではない。旧未束縛要求や形式不正の記録も削除せず保留する。ブラウザの保存消去や別PCへの自動引継ぎを保証する仕組みではない。

計画保存の応答が不明なら「保存先と照合」で送信時点の草案・revisionを確認する。送信後の編集も保持される。異なる保存版が見つかった場合は相違を読み、どちらを基準にするかを選ぶ。通信回復だけで現在の草案を上書きしない。計算器停止の表示が出た場合は保存結果を読みながらserviceを再起動し、未完了分を明示再開する。完成ファイルが揃った実行は固定specと全出力hashを照合して回復し、不完全な仕事を完了へ変えない。

同じブラウザの同じorigin（scheme・host・port）では、送信担当を一つのタブに限る。他のタブでも保存結果・地図・接続済み3Dは閲覧できるが、保存・計算・取得・新しい群集計は送信担当で行う。担当タブを閉じて移る場合は「このタブで送信権を取得」を押し、残った固定要求を確認してから明示再開する。受付確認はサーバーへの再計算要求を送らないが、共有要求台帳の更新には送信権が必要となる。Web Locksに対応しない環境では送信を止め、保存結果の閲覧を残す。別origin・別ブラウザ・CLIまで排他制御する仕組みではない。

### 同じ表示対象を3Dで確認する

地図の「3Dで周辺を確認」で、現在の対象を独立rendererへ渡す。Google写真3Dを使うときだけ、その画面の入力欄へMap Tiles APIキーを入れ「Google写真3Dへ接続」を押す。キーは保存計画・出力やURLへ書かない。接続には外部要求と利用枠の消費がある。同じ打上げ計画画面内での2D/3D往復は同じ接続を保持する。実計算/人工データの切替、気象/季節への用途移動、保存計画の再読込みでは画面が破棄され、3D接続も終了する。自動再接続はしない。これらの切替後や解除後に写真3Dを使う場合は、改めて明示接続する。

概要では表示中の注目候補、詳細では現在の選択群の同じ経路を、地表投影線と空中線で読む。「軌道＋地表線」は二本を一組で切り替え、「カーテン」はその間の薄い幕だけをOFFにできる。どちらも既定はONで、軌道をOFFにすると幕も隠れ、幕の選択値は保持される。この二つの表示設定は「計画を保存」の `ui_state` とKMLの初期表示に共通して使う。候補や表示設定の通常更新では視点を保持し、「軌道全体を見る」を押したときに経路全体を見渡す位置へ移る。これらは固定した飛行結果を再計算する操作ではない。

実結果の空中線は保存ASL高度を使い、3D表示だけで同梱EGM96を加えて楕円体高へ換算する。科学計算とKMLの元高度は変えない。人工結果の高さは地物からの高さと見立てた模式AGLで、実飛行高度ではない。地表投影や幕は地物との接触・衝突判定を表さない。高度基準の詳細と限界は [実装ノート](IMPLEMENTATION_NOTES.md) の「3Dの地表投影と空中経路」へ戻る。

「地物への接続」の取得点数が不足する区間では、幕の下端を0で補わず保留する。必要な場所へ近づいて表示が静止するのを待ち、必要なら「地物への接続を更新」を押す。一回の照会には上限があり、続きは次の更新で調べる。実軌道が取得した地物より低い部分でも軌道を持ち上げず、その部分の幕を省く。人工AGLの空中線にも地物高の取得が必要である。経路表示や地物への接続更新のためにGoogleのroot接続を作り直すことはなく、同じ接続中のタイル読込みとは区別する。

以上は0.55の追加実装に対する操作説明であり、この追記時点では追加部分のブラウザ観察と最終試験は未了である。実施結果と残る制約は[S36](../BOOTSTRAP_RUNBOOK.html#s36-plan550)へ記録する。

外部写真へ接続しない人工地表の確認入口は `http://127.0.0.1:8451/scene3d/index.html?probe=synthetic`。これは投影・名称・描画処理用の人工fixtureで、実地物の確認ではない。写真上の輪郭・禁止領域・軌道の関係と、2Dへ戻った後の継続操作は、実接続の観察記録と分けて確認する。0.40.1での観察を、そのまま0.46の受入結果へ転記しない。

### 開発・検査と、失敗後の判断

別端末で `npm --prefix frontend run dev` を実行すると `http://127.0.0.1:8450/` のViteから8451へAPIをproxyする。`npm --prefix frontend run preview` はbuild済み画面を8452で確認する。通常配信は8451、開発/previewの停止は各端末のCtrl+C。APIが起動していなければ、画面だけでは計算・保存できない。

```powershell
npm --prefix frontend test
& backend/.venv/Scripts/python -B -m pytest backend/tests -p no:cacheprovider
```

| 表示/応答 | 次の判断 |
|---|---|
| 入力拒否422、JSON_REQUIRED 415 | 条件とJSON外枠を直す。未実行の入力を着地/停止結果としない。 |
| QUEUE_FULL 429 | 待機が空いてから明示再送。同じ要求IDと同じ内容は同じrunへ戻る。 |
| ENSEMBLE_QUEUE_FULL 429、総試行数の上限 | 同時集合が減るまで待つか、対象候補/Nを見直して新しい計画を固定する。途中の一部だけ受理されたとは扱わない。 |
| WEATHER_WINDOW_UNSUPPORTED、PLAN_UNAVAILABLE | 不足候補の放球から最大飛行時間までを気象の有効範囲と比べる。必要窓/場/条件を見直して再計画する。 |
| SOURCE_CHANGED、ENSEMBLE_SOURCE_CHANGED 409 | 稼働中コードの変化ならserviceを再起動する。元計画からコード/数値環境が変わった場合は新しい計画を作り、旧集合をそのまま再開しない。 |
| WEATHER_UNAVAILABLE / WEATHER_CHANGED 409、UNKNOWN_WEATHER_SOURCE 422 | 現在の保存場の所在・内容・登録状態を確認する。新実行の拒否と旧固定結果の閲覧を区別し、別資料へ無言で差し替えない。 |
| ENSEMBLE_WEATHER_CHANGED 409 | 元の場の所在/hashを確認する。新しい予報へ無言で差し替えず、別の場なら新計画へ進む。原場がなくても保存済み結果の閲覧は可能。 |
| INSTANCE_MISMATCH 409 | 未確定要求を保持し、接続先の台帳を確認する。旧要求を別instanceへ再送しない。接続先を替える場合は計画を明示的に読み直す。 |
| EXECUTION_UNAVAILABLE 503、WORKER_PROCESS_BROKEN | 保存結果は閲覧可能。serviceを再起動し、完成物の回復と残った未完了状態を確認してから明示再開する。自動再計算はしない。 |
| 既存台帳のinstance識別が欠落・破損し起動できない | 台帳を保全して原因を調べる。新UUIDの自動生成やDB削除で隠さない。 |
| PROJECT_REVISION_CONFLICT 409 | 編集を残し、保存済み内容と比べる。無条件の再保存で上書きしない。 |
| 物理stopped、complete=false | 停止理由・最後の支持・有効履歴を読む。最終点を着地点へ替えない。 |
| failed/interrupted、結果なし | 仕事のエラー/中断を読む。必要なら利用者が新しい実行を明示する。 |
| RESULT_INTEGRITY_ERROR、結果読込失敗 | 元保存物を保ち、hash/不足を調べる。再計算で無言に差し替えない。 |
| RESULT_RECOVERY_FAILED | 原specとmanifestによる完成候補の照合が失敗した。元保存物と旧error履歴を残し、不足・変更を調べる。再計算で上書きして隠さない。 |
| RESULT_RECOVERY_REQUIRED、ENSEMBLE_INTEGRITY_ERROR | 既存完成結果/集合の照合ができない。原本を保って不足・変更を調べ、別attemptを作る前に回復判定を解決する。 |
| CLIMATE_UNCONFIGURED、CLIMATE_UNAVAILABLE、CLIMATE_DEPENDENCY | 起動設定のDB所在・専用PythonのDuckDBを確認する。保存済み分析は参照IDから再閲覧できる。 |
| CLIMATE_SOURCE_CHANGED、CLIMATE_ADAPTER_CHANGED | 登録後の資料/実装変更を調べ、元の保存物を保つ。別資料へ差し替えず、同一性を確認してserviceを再起動する。 |
| CLIMATE_INPUT、CLIMATE_BOUNDS、CLIMATE_UNSUPPORTED | 元格子範囲・面・対応する半月入力を確認する。未対応の年/時間帯指定を無視して集計しない。 |
| CLIMATE_CORRUPT、CLIMATE_RESULT_CONFLICT、CLIMATE_STORAGE | 保存集計/対応表/保存先を確認する。壊れた保存物を再集計で上書きして隠さない。 |
| 画面未build/接続不可 | build、起動端末、portとAPI応答を確認。build後はserviceを再起動する。 |
| 2D地図の表示確認で停止した | 地図表示の案内と「地図表示を読み直す」を使う。表示が整うまでpaneを隠すinline CSSがあり、分断した地図を通常表示として扱わない。 |
| 3Dの部品/ライセンスリンクが見つからない | dist/scene3d・dist/cesiumの生成と配信を確認。欠けた資産を外部CDNへの自動接続で補わない。 |
| 写真3Dの認証/利用枠/通信エラー | 画面の接続状態を読み、必要な設定を確認してから明示再接続する。自動反復しない。 |

稼働中のSQLiteやstagingを手で整理しない。結果削除や別PCへのproject import/exportは未実装。このコマンド表の更新、実行成功、図の保存を、全操作行程や科学的な予測精度の受入へ拡張しない。


## C-10：固定JRA-3Q原本から飛行を計算し、支持不足を読む

この経路は、repoに保持した`references/jra3q_model_fixture/source_bundle.json`の2024-01-01 00/06 UTC・100モデル層・2×2格子を、飛行CLIが読める保存場へ変換する。原本のダウンロードや別時刻の取得は行わない。北海道の半月統計DBとは別の資料である。この旧strict例は支持停止を読む対照として保持する。0.52の地上全飛行は別入力の[C-11](#C-11)へ進み、任意過去窓の取得画面と代表性を定めた多年の季節MCは未実装である。登録済み原日時の有限比較はC-09の「原日時の複数窓」へ進む。

C-01で確認したPythonを使い、repo rootで次を実行する。原本の変換と`inspect`には標準ライブラリ、`simulate`にはSciPy/NumPyが必要で、ecCodesやDuckDBはこの経路では使わない。`taskOutputRoot`を毎回新しくし、既存出力へ重ねない。

```powershell
$taskOutputRoot = Join-Path $env:TEMP ('balloon-jra3q-' + [guid]::NewGuid().ToString('N'))
$taskBundleDir = Join-Path $taskOutputRoot 'weather'
$taskBundlePath = Join-Path $taskBundleDir 'weather.json.gz'
$taskFlightDir = Join-Path $taskOutputRoot 'flight'

& $taskPython -B -m tools.prepare_jra3q_flight_fixture --root . --output $taskBundleDir
if ($LASTEXITCODE -ne 0) { throw 'JRA固定原本の変換に失敗。元入力と部分出力を保って原因を確認してください。' }
& $taskPython -B -m balloon_sim inspect $taskBundlePath
if ($LASTEXITCODE -ne 0) { throw '保存場の検査に失敗。simulateへ進まず出力を確認してください。' }

& $taskPython -B -m balloon_sim simulate examples/jra3q-support-flight.json --weather $taskBundlePath --output $taskFlightDir
$taskFlightExit = $LASTEXITCODE
$taskFlightExit
if ($taskFlightExit -eq 1) { throw '入力・依存または保存処理のエラーです。stopped結果とは区別してください。' }
$taskResult = Get-Content -LiteralPath (Join-Path $taskFlightDir 'result.json') -Raw | ConvertFrom-Json
$taskResult | Select-Object status, complete, summary
$taskResult.stop_reason | Format-List code, message, elapsed_s
$taskResult.events | Format-Table type, elapsed_s, altitude_m
$taskResult.records | Select-Object -Last 1 | Format-List elapsed_s, phase, altitude_m, ground_altitude_m, height_agl_m
```

時刻の原表記はCLI出力または`result.json`本文で確認する。PowerShellの版によっては`ConvertFrom-Json`がUTC文字列をローカル日時へ自動変換するため、上の読取り例では経過秒を表示している。保存されたUTC自体が変化したわけではない。

変換成功時には`weather.json.gz`と変換用`receipt.json`ができる。`inspect`が返すのは場のmetadataで、`product`、`time_kind`、`source`の原応答・係数・hash、圧力補間と地表支持の方針を読む。これは指定した飛行時間窓全体の事前被覆検査ではない。原本と生成bundle、飛行結果の各hashは別物で、同じ名前の新しい気象へ差し替えない。

`jra3q-support-flight.json`は実放球計画ではなく、支持内の上空から等温浮力上昇、指定高度1500 mの破裂、気象密度を使う降下をつなぐ診断例である。開始は非native時刻02:17:13 UTC、幾何高度約311.66 m。0.51の同条件の観察では、破裂後に地表近傍の支持下端へ達して`HEIGHT_OUT_OF_RANGE`で停止した。**終了コード2、`status: stopped`、`complete: false`、`summary.landing: null`はこの例で読むべき結果**である。終了2だけでは原因を決めず、`stop_reason.code`と最後の有効記録を確認する。

| 観察するもの | 次の判断 |
|---|---|
| `HEIGHT_OUT_OF_RANGE`、`BELOW_MODEL_SURFACE` | 必要な各列の鉛直支持を確認する。地表高度を最下層へ上げたり、最終点を着地点に替えたりしない。地表量と列ごとの接続方針が次の課題になる。 |
| `TIME_OUT_OF_RANGE`、緯度/経度の範囲外 | 放球から最大飛行時間までの時刻窓と移流の余白を見直す。今回の固定原本変換は不足日時/地域を追加取得しない。 |
| `MAX_DURATION` | 設定時間内に着地しなかった。時間を短くして完飛行の代わりにはしない。 |
| 終了1、変換receiptや飛行manifestがない | 入力検証・依存・I/O等を調べる。残ったdirectoryだけを成功とせず、次の試行は新しい出力先へ作る。 |

`flight/report.html`、原`result.json`、CSV、GeoJSON、`provenance.json`と`manifest.json`をC-03と同じ意味で読む。最後の有効点と破裂イベントは保存されるが、支持不足の例から着地点・禁止域の干渉率は得られない。実行行程と未確認範囲はS36、補間と責務の違いは[実装ノートのJRA接点](IMPLEMENTATION_NOTES.md#IM-HISTORICAL-NEXT)へ戻る。

<a id="C-11"></a>
## C-11：実過去一窓を使い、モデル地形から30 kmを経て着地する

`examples/jra3q-ground-flight.json`と`references/flight_fixture/jra3q-weather.json.gz`は、2024-01-01の00/06/12 UTC・100層・20×46格子から作った固定検査例である。放球は非native時刻02:17:13 UTC、34.8°N/137°Eのモデル地形高度で、等温浮力上昇、幾何ASL 30000 mの破裂、気象密度を使う下降を同じ核で計算する。製品気球の既定条件や実放球計画ではない。

同じ入力を既存GUIへ渡す0.53候補の手順は[C-09の保存JRA操作](#C-09-JRA)へ進む。以下の0.52 CLI再現手順と期待終端はそのまま保持する。

この保存場は`balloon.weather.jra3q_surface/1`、`native_horizontal_first_surface_v1`を明示し、0.51のstrict場とは別の再構成を選ぶ。人工場や半月統計から作った配列ではない。以下は保存場の読取と計算だけで、新規取得・認証・外部通信を行わない。C-01のPython/NumPy/SciPyを使い、ecCodes、DuckDB、NetCDFの復号依存は不要である。

```powershell
$taskOutputRoot = Join-Path $env:TEMP ('balloon-jra3q-ground-' + [guid]::NewGuid().ToString('N'))
$taskWeatherPath = 'references/flight_fixture/jra3q-weather.json.gz'
$taskFlightDir = Join-Path $taskOutputRoot 'flight'

& $taskPython -B -m balloon_sim inspect $taskWeatherPath
if ($LASTEXITCODE -ne 0) { throw '保存場の検査に失敗。simulateへ進まず原因を確認してください。' }
& $taskPython -B -m balloon_sim simulate examples/jra3q-ground-flight.json --weather $taskWeatherPath --output $taskFlightDir
$taskFlightExit = $LASTEXITCODE
$taskFlightExit
if ($taskFlightExit -eq 1) { throw '入力・依存または保存処理のエラーです。stopped結果とは区別してください。' }
$taskResult = Get-Content -LiteralPath (Join-Path $taskFlightDir 'result.json') -Raw | ConvertFrom-Json
$taskResult | Select-Object status, complete, summary
$taskResult.events | Format-Table type, elapsed_s, altitude_m
$taskResult.records | Select-Object -Last 1 | Format-List elapsed_s, phase, altitude_m, ground_altitude_m, height_agl_m, weather_quality
$taskProvenance = Get-Content -LiteralPath (Join-Path $taskFlightDir 'provenance.json') -Raw | ConvertFrom-Json
$taskProvenance.weather_bundle.metadata | Format-List schema, product, reconstruction_policy, join_model_levels, native_wind_not_used_model_levels, scope
```

固定例の期待する終端は終了0、`landed / complete:true`、破裂と着地イベント、最後の`height_agl_m`が0付近である。終了2なら`stop_reason`と最後の有効点を読み、着地へ書き換えない。`inspect`ではpolicy、元解析UTC、原物の来歴を確認する。inspect成功は指定飛行の全支持や科学精度の証明ではない。UTCの原文字列とPowerShellの日時変換の区別はC-10と同じである。

`report.html`、`result.json`、`trajectory.csv / trajectory.geojson`、`provenance.json / manifest.json`が一組になる。同じ設定・場・source・数値依存を保持して再実行し、別条件は新しい出力先へ置く。気象bundleを新しいファイルへ差し替えて旧結果の由来を更新しない。処理費用を比較するときは場の読込と飛行を分け、CLI全体の経過時間を純積分時間と呼ばない。

今回の着地はJRAのモデル地形との交差である。T/qの2m以下・風の10m以下は定値、風は10mからlevel2へ接続してlevel1を使わず、上空でも水平→鉛直の順序がstrictと異なる。Bの近似・品質/欠測は[実装ノート](IMPLEMENTATION_NOTES.md#IM-JRA-SURFACE)へ戻る。この例が全飛行を通ること、刻み変更で近い結果になること、実気球の着地精度や季節確率の受入は分ける。任意過去窓をUIで選んだり、多年の気象窓集合を計算する操作はまだない。実取得・対照比較・費用の記録は[S36](../BOOTSTRAP_RUNBOOK.html#s36-plan520)を読む。

<!-- LOGIC:COMMANDS-CORE:END -->
