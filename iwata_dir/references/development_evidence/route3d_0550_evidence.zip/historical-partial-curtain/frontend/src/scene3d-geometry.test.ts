import {describe,it,expect,vi,afterEach} from 'vitest';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import * as C from 'cesium';
import {FLIGHT_ALPHA,groundNodes,groundKey,routeSections,routeDefinitions} from '../scene3d/src/route-geometry.js';
import {createRouteLayer} from '../scene3d/src/route-layer.js';
const nodes=[[141,43,100],[141.001,43,200],[141.002,43,150],[141.003,43,0]];
describe('elevated display retains source altitude and ground gaps',()=>{
 it('converts ASL with the positive geoid offset and leaves source untouched',()=>{
  const before=structuredClone(nodes),ground=new Map(nodes.map(p=>[groundKey(p),20]));
  const value=routeSections(nodes,'absolute',()=>35,ground);
  expect(value.flight[0].map((p:any)=>p[2])).toEqual([135,235,185,35]);expect(value.walls[0].map((p:any)=>p.low)).toEqual([20,20,20,20]);expect(nodes).toEqual(before);
 });
 it('never bridges an unknown ground height or reverses a below-mesh curtain',()=>{
  const ground=new Map([[groundKey(nodes[0]),20],[groundKey(nodes[1]),25],[groundKey(nodes[3]),100]]);
  const real=routeSections(nodes,'absolute',()=>0,ground);expect(real.flight[0]).toHaveLength(4);expect(real.walls).toHaveLength(1);expect(real.walls[0]).toHaveLength(2);
  const toy=routeSections(nodes,'relativeToGround',null,ground);expect(toy.flight).toHaveLength(1);expect(toy.flight[0].map((p:any)=>p[2])).toEqual([120,225]);
 });
 it('keeps positive and negative geoid/ASL values without adding correction to mesh',()=>{
  const points=[[141,43,-10],[141.01,43,10]],ground=new Map(points.map(p=>[groundKey(p),-30]));
  expect(routeSections(points,'absolute',()=>-5,ground).walls[0].map((p:any)=>p.position[2])).toEqual([-15,5]);
  expect(routeSections(points,'relativeToGround',()=>99,ground).flight[0].map((p:any)=>p[2])).toEqual([-40,-20]);
 });
 it('subdivides across the date line through the short path and refuses an unbounded mesh workload',()=>{
  const rows=groundNodes([[179.999,0,0],[-179.999,0,100]],100);expect(rows).toHaveLength(4);expect(rows.every(p=>Math.abs(p[0])>179.9)).toBe(true);expect(rows.at(-1)?.[2]).toBe(100);
  expect(()=>groundNodes([[0,0,0],[10,0,100]],10,100)).toThrow(RangeError);
 });
 it('uses translucent, depth-tested elevated lines and outline-free walls',()=>{
  const ground=new Map(nodes.map(p=>[groundKey(p),0]));const routes=[{properties:{kind:'flight-route',color:'#1472b9',altitudeMode:'absolute'},geometry:{coordinates:nodes},index:0,nodes,fillOpacity:.22}];
  const d=routeDefinitions(C,routes,()=>0,ground);const line=d.entities.find(e=>e.polyline),wall=d.entities.find(e=>e.wall);
  expect(C.Color.floatToByte(FLIGHT_ALPHA)).toBe(253);expect(C.Color.floatToByte(.999)).toBe(255);expect(line?.polyline?.clampToGround).toBe(false);expect(line?.polyline?.arcType).toBe(C.ArcType.NONE);expect(wall?.wall?.outline).toBe(false);expect(wall?.wall?.minimumHeights).toEqual([0,0,0,0]);
 });
});
afterEach(()=>vi.useRealTimers());
function harness(){
 const states:any[]=[];let ready=true;
 const scene={requestRender:vi.fn(),sampleHeight:vi.fn(()=>10)};
 const viewer:any={scene,dataSources:new C.DataSourceCollection(),dataSourceDisplay:{ready:true},camera:{positionWC:C.Cartesian3.ZERO,directionWC:C.Cartesian3.UNIT_Z,upWC:C.Cartesian3.UNIT_Y,frustum:{computeCullingVolume:()=>({computeVisibility:()=>C.Intersect.INSIDE})}}};
 const session={read:async(fn:any,{signal}:any)=>{if(signal.aborted)throw new DOMException('abort','AbortError');return fn();},afterScreenPick:vi.fn()};
 const layer=createRouteLayer(C,viewer,{session,exclusions:()=>[],canSample:()=>ready,onState:(s:any)=>states.push(s)});
 const payload={geojson:{features:[{properties:{kind:'flight-route',phase:'up',candidateId:'a',resultId:'r',altitudeMode:'relativeToGround',color:'#1472b9'},geometry:{coordinates:nodes}}]}};
 return {layer,scene,states,payload,session,setReady:(v:boolean)=>ready=v};
}
describe('route layer owns finite queries and their cancellation',()=>{
 it('performs one pass per request and retains acquired heights when mesh is unloaded',async()=>{
  vi.useFakeTimers();const h=harness();await h.layer.setPayload(h.payload);await vi.runAllTimersAsync();expect(h.scene.sampleHeight).toHaveBeenCalledTimes(4);expect(h.session.afterScreenPick).toHaveBeenCalledTimes(4);expect(h.states.at(-1).resolved).toBe(4);
  h.scene.sampleHeight.mockReturnValue(undefined as any);h.layer.changed();await vi.runAllTimersAsync();expect(h.scene.sampleHeight).toHaveBeenCalledTimes(8);expect(h.states.at(-1).resolved).toBe(4);h.layer.destroy();
 });
 it('cancels before sampling when hidden and resumes once shown; toggles the two line layers as a group',async()=>{
  vi.useFakeTimers();const h=harness();await h.layer.setPayload(h.payload);h.layer.visibility(false,true);await vi.runAllTimersAsync();expect(h.scene.sampleHeight).not.toHaveBeenCalled();h.layer.visibility(true,true);await vi.runAllTimersAsync();expect(h.scene.sampleHeight).toHaveBeenCalledTimes(4);h.layer.visibility(true,false);expect(h.layer.entities.filter((e:any)=>e.wall).every((e:any)=>!e.show)).toBe(true);expect(h.layer.entities.filter((e:any)=>e.polyline).every((e:any)=>e.show)).toBe(true);h.layer.destroy();
 });
 it('destroyed and superseded payloads cannot publish an old mesh pass',async()=>{
  vi.useFakeTimers();const h=harness();await h.layer.setPayload(h.payload);await h.layer.setPayload({geojson:{features:[]}});await vi.runAllTimersAsync();expect(h.scene.sampleHeight).not.toHaveBeenCalled();expect(h.layer.entities).toHaveLength(0);h.layer.destroy();
 });
 it('restores acquired ground and elevated geometry without resampling after a failed presentation',async()=>{
  vi.useFakeTimers();const h=harness();await h.layer.setPayload(h.payload);await vi.runAllTimersAsync();const old=h.layer.checkpoint(),count=h.layer.entities.length;
  await h.layer.setPayload({geojson:{features:[]}});h.setReady(false);h.layer.restore(old);expect(h.layer.entities).toHaveLength(count);expect(h.states.at(-1).resolved).toBe(4);await vi.runAllTimersAsync();expect(h.scene.sampleHeight).toHaveBeenCalledTimes(4);h.layer.destroy();
 });
 it('reaches later valid points even when the first budget window is entirely missing',async()=>{
  vi.useFakeTimers();const h=harness();h.payload.geojson.features[0].geometry.coordinates=Array.from({length:700},(_,i)=>[141+i*.0001,43,100]);let index=0;
  h.scene.sampleHeight.mockImplementation(()=>++index>512?20:undefined as any);
  await h.layer.setPayload(h.payload);await vi.runAllTimersAsync();expect(index).toBe(512);expect(h.states.at(-1).resolved).toBe(0);
  h.layer.refresh();await vi.runAllTimersAsync();expect(index).toBe(1024);expect(h.states.at(-1).resolved).toBe(512);h.layer.destroy();
 });
 it('resumes a dirty job once a normal ready frame arrives without polling while not ready',async()=>{
  vi.useFakeTimers();const h=harness();h.setReady(false);await h.layer.setPayload(h.payload);await vi.runAllTimersAsync();expect(h.scene.sampleHeight).not.toHaveBeenCalled();expect(vi.getTimerCount()).toBe(0);
  h.setReady(true);h.layer.ready();await vi.runAllTimersAsync();expect(h.scene.sampleHeight).toHaveBeenCalledTimes(4);h.layer.destroy();
 });
});

// Execute the host's actual transaction functions with a deferred route layer.
// This tests their async boundary without a browser, GPU, or provider request.
function presentationHarness(){
 const source=readFileSync(new URL('../scene3d/src/main.js',import.meta.url),'utf8');
 const functions=source.slice(source.indexOf('async function installPresentation('),source.indexOf('async function recordRenderedGeometry('));
 let release!:()=>void,entered!:()=>void;
 const pending=new Promise<void>(resolve=>{release=resolve;}),waiting=new Promise<void>(resolve=>{entered=resolve;});
 const nodes=new Map<string,any>();
 const next={snapshotId:'new',geojson:{features:[]}},prior={snapshotId:'old',geojson:{features:[]}};
 const renderer={overlayEntities:()=>[],PRESENTATION_REVISION:'test'},catalog={catalogView:()=>({}),PRESENTATION_REVISION:'test'};
 const state:any={
  C:{},parent:{},window:{},structuredClone,
  $:(id:string)=>{if(!nodes.has(id))nodes.set(id,{checked:true,childNodes:[],replaceChildren:vi.fn(),textContent:''});return nodes.get(id);},
  document:{getElementById:()=>null},hover:{invalidate:vi.fn()},
  viewer:{scene:{requestRender:vi.fn()}},overlayStore:{items:[],prepare:async()=>({items:[]}),commit:vi.fn(),rollback:vi.fn(()=>true),discard:vi.fn()},
  routeLayer:{checkpoint:()=>({}),setPayload:vi.fn(()=>{entered();return pending;}),restore:vi.fn(),visibility:vi.fn()},
  payload:next,renderedPayload:prior,renderRevision:0,previousPresentation:null,presentationError:null,entityItems:[],intentPending:null,
  overlayModule:renderer,catalogModule:catalog,diag:{snapshot:{snapshotId:'old'},renderedSnapshotId:'old'},
  sendIntent:vi.fn(),visibilityFor:()=>true,updateSummary:vi.fn(),clearReadout:vi.fn(),receipt:()=>({featureCounts:{}}),recordRenderedGeometry:vi.fn(),
  updateViewMemoryUI:vi.fn(),updateCatalog:vi.fn(),applyVisibility:vi.fn(),status:vi.fn(),resetCamera:vi.fn(),
 };
 const host=runInNewContext(`${functions}\n({installPresentation,restorePreviousPresentation});`,state);
 return {state,host,next,prior,waiting,release,start:()=>host.installPresentation(next,renderer,catalog,null,true)};
}

describe('presentation waits for the current elevated route transaction',()=>{
 it('reports success and resets the camera only after the current route is ready',async()=>{
  const h=presentationHarness(),work=h.start();await h.waiting;
  expect(h.state.resetCamera).not.toHaveBeenCalled();h.release();expect(await work).toBe(true);
  expect(h.state.renderedPayload).toBe(h.next);expect(h.state.routeLayer.visibility).toHaveBeenCalledOnce();expect(h.state.resetCamera).toHaveBeenCalledOnce();
  expect(h.state.status).toHaveBeenLastCalledWith('同じ結果を表示：0表示要素。');
 });
 it('invalidates an in-flight install when rollback restores the previous presentation',async()=>{
  const h=presentationHarness(),work=h.start();await h.waiting;const revision=h.state.renderRevision;
  expect(h.host.restorePreviousPresentation()).toBe(true);expect(h.state.renderRevision).toBe(revision+1);
  h.release();expect(await work).toBe(false);expect(h.state.renderedPayload).toBe(h.prior);expect(h.state.routeLayer.restore).toHaveBeenCalledOnce();
  expect(h.state.routeLayer.visibility).not.toHaveBeenCalled();expect(h.state.resetCamera).not.toHaveBeenCalled();expect(h.state.presentationError).toBeTruthy();
  expect(h.state.status.mock.calls.some(([text]:[string])=>text.startsWith('同じ結果を表示：'))).toBe(false);
 });
 it('does not complete successfully when rendering fails without a rollback target',async()=>{
  const h=presentationHarness(),work=h.start();await h.waiting;h.state.previousPresentation=null;h.state.presentationError='render failed';
  expect(h.host.restorePreviousPresentation()).toBe(false);h.release();expect(await work).toBe(false);
  expect(h.state.routeLayer.visibility).not.toHaveBeenCalled();expect(h.state.resetCamera).not.toHaveBeenCalled();
 });
});
