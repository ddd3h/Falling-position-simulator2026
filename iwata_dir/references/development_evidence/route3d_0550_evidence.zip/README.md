# 0.55 空中軌道・連続カーテンの有限検証

基準は PR31 b9d960c858e886666167e841dee240801fcfd2a4、main M550 06936856ee0deab2fe0b3f3b04220d60652ffba6。採否は repo D-195、行動とGit実績は S36 route3d-implementation/results。これは今回の表示機能の証拠束であり、飛行精度の保証ではない。

ユーザーの目的は、空中の軌道と地上投影の垂直な対応を全経路で読むことだった。初稿は地形高取得済み区間だけ幕を描いたため、テスト成功にもかかわらず用途不適合となった。historical-partial-curtain/ は撤回案。現役 source は repo または index/pass04/source/。実ASLは地物照会なし、表示下端への幕を写真meshが遮蔽する。人工AGLだけは上端を決めるため取得に依存し、全体保留する。

validation/ に最終270試験・主担当の実写真観察・独立批評の処置・配布時の保存状態不変を分けた。UI観察はキーなしの記述・件数のみ。APIキー、Google写真、タイル、ブラウザ記録、保存計画全文は含めない。

index/pass04/ は223 sourceの入力票、構文抽出、正例1+反例10、適用票、生成/検算/適用helper。別parserの独立検査ではなく、全動的依存や機能の証明でもない。helperの固定外側pathは元実行所在であり、再実行時はcheckoutとこの束の展開先へ置き換える。datum/ は公式格子と独立サンプル審査の来歴。初期格子READMEのhashは初期票であり、現役hashはindexの最終入力票に戻る。

再実行: frontendのlockで依存を整え npm test / npm run build。表示反例は scene3d-routes.test.ts (34), scene3d-datum.test.ts (31), scene3d-geometry.test.ts (23)。EGM96データは同梱DACからローカル読取。docs/BUILD.md のTeX環境で tools/build_guides.py を実行し、生成後は別途視覚確認する。今回guides/票は PROGRAM30/THEORY25頁の生成と目視で、全ての旧科学記述を新たに採用したことではない。

実Google画面の再確認は本人の明示接続が必要。試験だけで面ホバー・地物深度・全端末を受入しない。実写真がない場所の幕余長、人工AGL長経路、科学精度は限界として残る。Git保存の最終自己SHAは再帰的に収録せずPR本文と外側受領票へ置く。
