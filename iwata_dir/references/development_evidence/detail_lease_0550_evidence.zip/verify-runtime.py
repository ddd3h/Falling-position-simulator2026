from pathlib import Path
import json,urllib.request,hashlib
P=Path(__file__).resolve().parent
observed={}
for name in ('health','project','runs','ensembles'):
    with urllib.request.urlopen('http://127.0.0.1:8550/api/v1/'+name,timeout=30) as r: data=r.read()
    old=(P/('before01-'+name+'.json')).read_bytes()
    (P/('after-ui-'+name+'.json')).write_bytes(data)
    observed[name]={'bytes_unchanged':old==data,'sha256':hashlib.sha256(data).hexdigest()}
assert all(v['bytes_unchanged'] for v in observed.values()),observed
(P/'runtime-preservation.json').write_text(json.dumps(observed,indent=2),encoding='utf8')
print(json.dumps(observed,indent=2))
