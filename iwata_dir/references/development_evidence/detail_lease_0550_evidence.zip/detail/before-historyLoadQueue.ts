import type {CaseResult,EnsembleAnalysis} from '../../ensembleDomain';

export type HistoryTask={snapshotId:string;trialId:string};
export type HistoryLoadContext={key:string;tasks:HistoryTask[]};
const taskKey=(task:HistoryTask)=>JSON.stringify([task.snapshotId,task.trialId]);

/** The caller obtains analysis through its snapshot/case/region-bound cache. */
export function historyLoadContext(input:{enabled:boolean;collection:CaseResult;selectedIds:string[];analysis:EnsembleAnalysis|null|undefined;loadedIds:string[];bindingKey:string}):HistoryLoadContext|null{
 const {collection,analysis,selectedIds,loadedIds,bindingKey}=input;
 if(!input.enabled||!analysis?.history||analysis.history.unavailable_reason)return null;
 const selected=[...selectedIds].sort(),analyzed=[...analysis.selected_trial_ids].sort();
 const known=new Set(collection.trials.map(row=>row.trial_id));
 if(new Set(selected).size!==selected.length||selected.some(id=>!known.has(id))||analysis.selected_count!==selected.length||JSON.stringify(selected)!==JSON.stringify(analyzed))return null;
 const selectedSet=new Set(selected),loaded=new Set(loadedIds);
 return {key:JSON.stringify([collection.snapshot_id,collection.case_id,selected,bindingKey]),tasks:collection.trials.filter(row=>selectedSet.has(row.trial_id)&&row.result_available&&!loaded.has(row.trial_id)).map(row=>({snapshotId:collection.snapshot_id,trialId:row.trial_id}))};
}

/** One bounded queue for the screen. Changing selection replaces unsent work. */
export function createHistoryLoadQueue(options:{context:()=>HistoryLoadContext|null;read:(task:HistoryTask)=>Promise<unknown>;failed:(error:unknown,task:HistoryTask)=>void}){
 const running=new Map<string,{contextKey:string;started:boolean}>(),completed=new Set<string>(),failed=new Set<string>();
 let disposed=false,pumping=false;
 function relevant(context:HistoryLoadContext|null,key:string,contextKey:string){return context?.key===contextKey&&context.tasks.some(task=>taskKey(task)===key);}
 function sync(){
  if(disposed||pumping)return;pumping=true;
  try{
   while(running.size<4){
    const context=options.context();if(!context)break;
    const task=context.tasks.find(row=>{const key=taskKey(row);return !running.has(key)&&!completed.has(key)&&!failed.has(key);});if(!task)break;
    const key=taskKey(task),entry={contextKey:context.key,started:false};running.set(key,entry);
    void Promise.resolve().then(()=>{
     if(disposed||!relevant(options.context(),key,entry.contextKey))return;
     entry.started=true;return options.read(task);
    }).then(()=>{if(entry.started&&!disposed)completed.add(key);}).catch(error=>{
     if(disposed)return;failed.add(key);if(relevant(options.context(),key,entry.contextKey))options.failed(error,task);
    }).finally(()=>{if(running.get(key)===entry)running.delete(key);sync();});
   }
  }finally{pumping=false;}
 }
 // Explicit retry reopens only failures. Successful and in-flight reads remain deduplicated.
 function retry(){failed.clear();sync();}
 function dispose(){disposed=true;completed.clear();failed.clear();}
 return {sync,retry,dispose};
}
