# detail 修復の限定引渡し

基準は主担当固定 `ee051f506a94e2178c697b97684eba700da1769a`（335実体）。この担当のrepo編集はreceiptの5pathだけ。元のcontroller/historyQueue/testをbeforeファイルへ、新しい5pathをsource-finalへ保存した。

- 全試行の固定analysisは、集合の全ID・分析側ID・selected_countが一致し領域上書きなしの場合だけ再利用。部分集合、重複、不明ID、異なる領域へ流用しない。
- 原履歴はsnapshot/trial GETで、選択中かつresult_availableの未読試行を最大4並列で読む。集計完了、容量上限、送信権を前提にしない。未送信旧選択の取消、成功重複排除、失敗の明示再試行を維持。
- 新analysisLoadStateはready/pending/blocked/failedを保持。保存analysisIdのGETはreaderでも許容し、blockedの後に参照が到着した場合もGETへ移る。POSTは送信権をdispatch直前にも検査し、未送信blockedだけをowner遷移で解除。送信後の不明応答/失敗をowner遷移だけで自動再送しない。
- controllerは履歴パネルに集計状態と原履歴の読込/失敗状態を持続表示。再試行は現選択の失敗集計と原履歴に限定する。到着analysisはsnapshot/case/IDs/領域一致を検査し、現選択と領域が変わった場合その保存参照を後着で上書きしない。
- disposeでlease observerと各storeを解除。3D iframeの生成・remount・視点を変更する処理は追加していない。

検査は `vitest-final.json/txt` の3file31case pass。型検査は初稿修正後のrun01がexit0、最終の全体runは並行編集された所有外 `write-lease.test.ts` 27–28行のTS7034/TS7005によりexit1（`typecheck-final.txt`）。主担当へ報告し、当該pathは変更していない。最初のVitestはsandboxのspawn EPERMで起動前停止し、同一のローカル試験を通常権限で実行した。初回型検査のtest mock引数型1件を修正後に再検査した。新しい解析store11case、履歴queue8case、既存screen-contract12case。実ブラウザ/実通信/科学受入/保存Gitは本票では未実施。主担当の送信権本体改修と統合受入は別票。
