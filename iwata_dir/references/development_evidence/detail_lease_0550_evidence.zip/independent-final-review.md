# 詳細閲覧と送信担当引継ぎの最終批評

記録日: 2026-10-02 JST。基準は主担当が固定した PR31 ee051f506a94e2178c697b97684eba700da1769a / main 06936856ee0deab2fe0b3f3b04220d60652ffba6 と、その後の現作業source。Git再照会は実施していない。

## 結論

今回読んだ範囲に追加の重大阻害点は見つからなかった。「保存結果を読みたいだけなのに送信担当を要求される」「担当取得を押しても理由が分からず進めない」という利用目的上の不適合に対し、原履歴の独立読取、既存全件分析の再利用、明示的な安全な引継ぎという修正が対応している。

## sourceで確認した点

- `screens/forecast/analysisLoadState.ts:7` は固定caseの全trial IDと件数が一致し、領域指定がない場合だけ概要を再利用する。部分群・領域群に全体統計を流用しない。`historyLoadQueue.ts:8` と `controller.js:104` は原履歴GETを分析POSTの成否や送信権から切り離す。読込失敗・未実行trialを成功結果へ置き換えない。
- `controller.js:82-124` と分析状態管理は未送信のblocked、送信後のfailed、GETで復元可能な分析を区別する。blockedは担当取得後の現在の表示要求だけ再評価し、失敗や受付不明を取得だけで再送しない。永続説明と原履歴件数がある。明示再試行も `useEnsembleWorkspace.ts` の未確認分析台帳判定を通り、受付不明のPOSTを勝手に再発行しない。
- `writeLease.ts` は起動時の空き確認と利用者による引継ぎ要求を分ける。Web Lockを強奪せず、旧ownerはoperationが残っていればbusyを返し、空いた場合にreaderへ移行して実lockを解放する。8秒終了時の世代無効化は遅い取得を抑え、旧担当が自動で取り返す経路もない。
- `api.ts:23-79` と外側operationの組合せで、送信・応答・台帳後処理を保護する。60秒の応答待ち終了は受付拒否や取消とは扱わず、遅延応答をUI・台帳へ採用しない。画面disposeは論理readerへ移るが、残存operation完了まで実lockを保つ。
- `useWorkspace.ts:195-202,260-296` は取得時に単便queueと保存intentを再読し、現在の草案・表示を保存済みprojectで上書きしない。ensembleも取得時にintent/未確認要求を読み直す。復元した単便の自動再送はせず、計算のGET観測はreaderでも続ける。非同期後処理を含むguardは recordedMutation / singleSubmission / useEnsembleWorkspace / WeatherPreparation / HistoricalPreparation にある。

## 証拠と担当の区別

本巡はsource・試験本文・既存記録を読んだ。UI、画像、Google接続、APIには操作していない。guard部分は私自身が前巡で実装・試験したため、全差分を未関与者が審査したという意味ではない。

主担当報告と `ui-review.md` は、新tab14 readerで16件の履歴・グラフ・風・slider、部分2件の原履歴とblocked説明、legacy tab9の8秒timeout、保存済み検査tab9を閉じた後の取得、modern tab14/15間の双方向引継ぎと選択維持を記録している。全23suite / 296 PASS、tsc 0、build01も主担当報告であり、本巡では再実行していない。私の前巡のguard10件と関連63件の実行範囲は `operation-guard-review-receipt.json` を参照。

`before01-{health,project,runs,ensembles}.json` と `after-ui-*.json` のSHA256は本巡でファイルから独立に計算し、4組すべて一致し `runtime-preservation.json` と整合した。これは当該4応答の保全であり、派生分析の新規生成まで否定する証明ではない。

## 未確認・運用上の境界

旧tab13の草案とGoogle接続は主担当報告では保持され、更新・移行は行われていない。新tab14は保存済みprojectを開いた修正版の確認先であり、旧tab13をその場で修正したとは扱わない。旧版がownerなら協調通信を実装していないため、保全後の更新または閉鎖と明示再取得が必要。今回3Dの再描画・root通信件数を私が確認した事実はない。

busy中の引継ぎ、同時要求、遅延grant、dispose、台帳失敗は有限の自動試験の範囲であり、新たな実計算や実ブラウザ全種類で再現確認したものではない。同originの協調画面という送信権の範囲を、別origin・外部クライアント全体の排他保証へ拡大しない。科学的精度の受入も本修復の対象外。