# Detail and sender handoff: observed UI, 2026-10-02 JST

Basis: private PR31 ee051f506a94e2178c697b97684eba700da1769a. Main 06936856ee0deab2fe0b3f3b04220d60652ffba6. Review uses existing saved GFS results at localhost8551; no new weather acquisition or flight run.

## Reproduction

- Existing user-facing tab13: candidate2 (+30 min), selection16/16, original histories0/16, empty history chart. Sender acquisition click returned the same reader message. Saving had also been rejected by the lease.
- Inventory exposed earlier verification tab9 as owner; its UI said saved, no unsaved draft. Tabs8/12/13 were readers. This background verification tab was an agent-side cause; the user should not have to locate it to use the current screen.
- Code: acquisition was only ifAvailable, without handoff. Full-set detail demanded a new analysis POST despite a saved equivalent overview, and original-history GET waited on that derived analysis. Denial entered a persistent failed cache.

## Updated screen (tab14)

- As a reader: open full-set candidate1 detail; histories progressed0→16/16. History mean/bands were visible. Fit map, wind view and time slider (Home→0) worked. No new group analysis needed for the complete unchanged selection.
- Select interference:2/16. A persistent notice described the unsent aggregate waiting for sender ownership; the original histories2/2 and wind charts remained usable. The full-set history was not presented as the subset.
- Click sender acquisition while legacy tab9 held it: in-progress label and disabled button, then explicit8-second nonresponse message. No forced lock seizure.
- After the timeout, closed only the obsolete saved verification tab9 and clicked acquisition again in14. Kept tabs12/13, without reload or reading any key. This second explicit acquisition completed; tab14 became owner and its previously unsent2-trial analysis completed. The subset wind and time-history plots were visibly present.
- Opened temporary modern tab15: reader initially. Its explicit acquisition changed14→reader and15→owner. The reverse explicit acquisition changed15→reader and14→owner. Selection2/16, time0 and wind view survived. Temporary15 was closed after verifying14 ownership.
- Returned to shared map, selected candidate2 (+30 min), opened detail: histories16/16, full-set history graph, map and16 flying positions available. Changed vertical axis to altitude and moved time slider to15.15min; the map stayed present, current position and vertical cursor moved. A viewport screenshot was visually inspected through CUA.

## Preservation and limits

Runtime health, project, runs and ensembles responses are byte-identical before/after checks; see runtime-preservation.json. Only requested derived subset analysis was generated. Backend not restarted. Original Google-connected tab13 retained its iframe and was not reloaded; a hidden iframe route-receipt lookup timed out, so no new assertion about current3D render/root-request count is made. No key was read, copied, or saved, and the new tab did not connect to Google.

The new UI loaded the server's saved project. Existing unsaved edits remain in old tab13; they were not overwritten by the test. Final updated tab14 is the delivery target; this is not an in-place hot update of the old tab.

Testing limits: cooperative handoff was exercised in actual same-origin tabs. Busy requests, simultaneous claims, late grants, unmount and ledger cleanup were covered by automated finite tests, not fresh flight execution. This is not a scientific-accuracy or cross-browser acceptance claim.

## Judgment

The repair separates reading an existing result from sending a new operation. The earlier implementation forced knowledge of invisible tab coordination onto the user and made a secondary derived artifact block primary records. The revised flow lets the user inspect available data immediately, explains genuinely unavailable aggregates, and performs an explicit safe handoff without discarding current work. It closes the reported interaction failure; it does not make every preview tab the same version or move API keys between them.
