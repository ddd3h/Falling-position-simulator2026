from pathlib import Path
import json,hashlib,urllib.request,shutil
P=Path('C:/Users/genia/AppData/Local/Temp/balloon-seasonal-550/detail-lease-repair550'); D=P.parent/'repair-background550/dist02';N=P/'dist01'
def get(path):
 with urllib.request.urlopen('http://127.0.0.1:8550'+path,timeout=30) as r:return r.read()
before={n:get('/api/v1/'+n) for n in ['health','project','runs','ensembles']}
assert get('/')==(D/'index.html').read_bytes()
for n,b in before.items():(P/('before01-'+n+'.json')).write_bytes(b)
changed=[]
for f in N.rglob('*'):
 if not f.is_file() or f.relative_to(N).as_posix()=='index.html':continue
 rel=f.relative_to(N);dst=D/rel
 if dst.exists() and dst.read_bytes()==f.read_bytes():continue
 if dst.exists():
  old=P/'served-before01'/rel;old.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(dst,old)
 dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_name(dst.name+'.route-next');shutil.copyfile(f,tmp);tmp.replace(dst);changed.append(rel.as_posix())
(P/'served-before01/index.html').write_bytes((D/'index.html').read_bytes())
tmp=D/'index-route-next';shutil.copyfile(N/'index.html',tmp);tmp.replace(D/'index.html')
assert get('/')==(N/'index.html').read_bytes()
after={n:get('/api/v1/'+n) for n in before};assert before==after
receipt={'state_bytes_identical':True,'changed_assets':changed,'backend_restarted':False,'index_sha256':hashlib.sha256(get('/')).hexdigest(),'instance':json.loads(before['health'])['instance_id']}
(P/'preview-publication01.json').write_text(json.dumps(receipt,indent=2),encoding='utf8');print(json.dumps({'changed_assets':len(changed),'state_preserved':True,'backend_restarted':False}))

