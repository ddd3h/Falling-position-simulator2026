# 0.50 operational continuity evidence

This is a bounded evidence packet, not a copy of the repository or runtime.
Read `manifest.json` for exact bytes, origins and purposes. Historical candidate
receipts keep their original scope; later repairs do not turn their earlier
failures into successes. `evidence/restoration-analysis-side-effect-review500.json`
corrects the older review's broad no-POST reading: the saved 64-trial analysis
was fetched successfully, while a separate unnecessary 28-hit analysis was made.
The later local demand guard stops unused detail/hidden extents. Necessary
overview aggregation is not promised to be GET-only.
The final named frontend pass is review06; review05 records the preceding
sandbox process-spawn denial. Review03/04 remain stage evidence. Backend
tests500-02 records 98 passes and one explicit opt-in skip, not 99 passes.

## Reproduction inputs, without another provider request

`external-inputs.json` maps every raw replay/profile input to an exact member
and SHA-256 in existing Git evidence. Obtain both archives at those hashes:
- operational_weather490.zip contains the extended seven-lead source and the
  profiled trial inputs/results.
- ensemble_connection480.zip contains the earlier completed six-lead donor;
  it is an explicit dependency recorded by the 0.49 archive's previous_bytes.
The 0.49 archive alone is not sufficient. No original raw or saved trial is
replaced by a made-up record. Those large archives are not nested again here.

The root scripts retain their captured local layout. In a NEW scratch directory,
restore only the listed prior members into `balloon-operational-490/state-measure`
and use this packet as sibling `balloon-operational-500`. Never overlay a running
state. Recreate basis-repo from the fixed 0.49 C2 in the manifest. For raw replay,
create raw-candidate/test-repo from that basis and apply the four captured source
files; their hashes must match the replay receipt. Use recorded dependency/runtime
versions. The replay replaces only the missing f027 transport with local recorded
bytes and uses the real decoder. It does not query NOAA or measure network speed.
Move captured output evidence aside to an independent reference directory before
running scripts that refuse pre-existing outputs. Compare newly generated outputs
to the receipts; do not overwrite this packet or claim a new replay was run by
packaging. API/runtime startup and credentials are not required for these two
offline scripts.

Both profile result JSONs are preserved. Derived HTML/CSV/GeoJSON display files
are deliberately omitted; original manifests still describe the full original
run outputs, so the reduced profile directories are not complete committed API
result directories. Generate displays from original JSON/provenance if needed.
The recorded pstats is interpreter-specific and profiled timing includes overhead.

## Scope and exclusions

No state-review, SQLite/WAL, basis checkout, node_modules, virtualenv, Git object,
tiles, API key/session, giant older archive, or general metadata/save-authoring
collection is included. The copy/clone manifest is provenance, not the cloned DB.
PROGRAM PDF/text and seven changed-page images plus two before images support the
named visual review; this packet does not assert a new all-page review by root.
No new scientific accuracy/Monte-Carlo calibration, historical four-dimensional
field implementation, Google/3D or actual-mouse acceptance follows from this ZIP.
The root UI receipt defines the finite browser sequence, source version and
external-image CSP limits. It does not invent screenshots absent from that work.

Packaging checks known credential patterns plus root's declared bounded content
review. They cannot prove absence of arbitrary encoded secrets. Every packaged
member is read back and hashed. The final manifest excludes its own recursive
hash; the external readback receipt binds the archive and manifest. Final Git
save/management receipts occur later and are not self-inserted into this archive.
