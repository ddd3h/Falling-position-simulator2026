"""Build a bounded, explicitly listed 0.50 evidence candidate outside the repo.

No network, Git, service, database, or original-source mutation. Freeze first;
root binds that exact plan and the finite UI/credential review before build.
"""
import argparse
import gzip
import hashlib
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

P = Path(__file__).resolve().parent
SELF = Path(__file__).resolve()
BASIS = '22799fe2c20627321e9c60367e974b92e16497cf'
DESTINATION = 'references/development_evidence/operational_continuity500.zip'
PLAN = P / 'evidence-package500-plan.json'
OUTPUT = P / 'operational-continuity500.zip'
RECEIPT = P / 'evidence-package500-readback.json'
MAX_INPUT = 16 * 1024 * 1024
MAX_ZIP = 12 * 1024 * 1024
ARCHIVES = {
    'references/development_evidence/operational_weather490.zip':
        '7e3b5c02b757e9a841348aae219a66f6ada9d56452af061775c8ee9c8a3a74ae',
    'references/development_evidence/ensemble_connection480.zip':
        '551d3b1c59c0f660589a40dec8beae9f725829f1f2329347111b9dda889c8412',
}

# Exact names only. No directory walk or automatic collection of future files.
GROUPS = {
    'raw': '''verify_real_raw500.py
real-raw500/receipt.json
real-raw500/extended/request.json
real-raw500/extended/decoder.json
real-raw500/extended/provenance.json
real-raw500/extended/receipt.json
real-raw500/extended/weather.json.gz
raw-candidate/basis.json
raw-candidate/REVIEW.md
raw-candidate/raw-reuse500.json
raw-candidate/raw-reuse500.patch
raw-candidate/run_tests.py
raw-candidate/tests-02.json
raw-candidate/tests-03.json
raw-candidate/core-new-02.stderr
raw-candidate/core-new-03.stderr
raw-candidate/core-existing-03.stderr
raw-candidate/service-new-03.stdout
raw-candidate/source/balloon_sim/environment/gfs.py
raw-candidate/source/backend/weather/service.py
raw-candidate/source/tests/test_gfs_raw_reuse.py
raw-candidate/source/backend/tests/test_weather_raw_reuse.py
raw-applied500.json
raw-cache-independent-review500.json
raw-independent-review.json''',
    'profile': '''profile_run500.py
profile-run500/receipt.json
profile-run500/profile.pstats
profile-run500/timed/input.json
profile-run500/timed/manifest.json
profile-run500/timed/provenance.json
profile-run500/timed/result.json
profile-run500/profiled/input.json
profile-run500/profiled/manifest.json
profile-run500/profiled/provenance.json
profile-run500/profiled/result.json''',
    'restoration': '''ui-candidate/design500.md
ui-candidate/basis.json
ui-candidate/manifest500.json
ui-candidate/restoration500.patch
ui-candidate/candidate/frontend/src/screens/forecast/controller.js
ui-candidate/tests-final.stdout
ui-candidate/typecheck500.json
ui-candidate/build500.json
ui-restore-export-counterexample500.cjs
ui-restore-export-counterexample500.json
ui-restoration-independent-review500.cjs
ui-restoration-independent-review500.json
ui-pending-candidate/manifest500-v2.json
ui-pending-candidate/pending500.patch
ui-pending-candidate/before-permitted.log
ui-pending-candidate/after.log
ui-time-candidate/manifest500.json
ui-time-candidate/time-display500.patch
ui-time-candidate/probe.cjs
ui-time-candidate/probe-receipt.json
ui-time-candidate/basis-controller.js
ui-time-candidate/candidate/frontend/src/screens/forecast/controller.js
ui-analysis-demand-candidate/manifest500.json
ui-analysis-demand-candidate/analysis-demand500.patch
ui-analysis-demand-candidate/probe-binding500.json
ui-analysis-demand-candidate/COMMANDS-proposal.md
ui-analysis-demand-candidate/candidate/frontend/src/screens/forecast/controller.js
ui-placeholder-candidate/manifest500.json
ui-placeholder-candidate/placeholder500.patch
ui-placeholder-candidate/probe.cjs
ui-placeholder-candidate/probe-receipt.json
ui-placeholder-candidate/basis-controller.js
ui-placeholder-candidate/candidate/frontend/src/screens/forecast/controller.js
restoration-analysis-side-effect-probe500.cjs
restoration-analysis-side-effect-probe500.json
restoration-analysis-side-effect-review500.json
restoration-analysis-project500.json
restoration-fixed-analysis500.json
restoration-extra-analysis500.json
ui-applied500.json
pending-applied500.json
time-applied500.json
demand-applied500.json
placeholder-applied500.json''',
    'validation': '''backend-tests500.xml
backend-tests500-02.xml
frontend-tests500-review.stderr
frontend-validation500-review03.json
frontend-validation500-review04.json
frontend-tests500-review04.json
frontend-types500-review04.stdout
frontend-types500-review04.stderr
frontend-build500-review04.stdout
frontend-build500-review04.stderr
frontend-validation500-review05.json
frontend-tests500-review05.stderr
frontend-types500-review05.stdout
frontend-types500-review05.stderr
frontend-validation500-review06.json
frontend-tests500-review06.json
frontend-tests500-review06.stdout
frontend-tests500-review06.stderr
frontend-types500-review06.stdout
frontend-types500-review06.stderr
frontend-build500-review06.stdout
frontend-build500-review06.stderr''',
    'documents': '''program-doc-candidate/program-doc500.patch
program-doc-candidate/program-doc500.json
program-doc-candidate/program-doc-review500.json
program-doc-candidate/REVIEW.md
history-doc-candidate/history-doc500.patch
history-doc-candidate/proposal500.json
history-doc-candidate/README.md
historical-route-review.json
narrative-doc-candidate/manifest500.json
narrative-doc-candidate/docs__DECISIONS.md.patch
narrative-doc-candidate/BOOTSTRAP_RUNBOOK.html.patch
combined-docs500.json
combined-docs500/docs/PROGRAM_GUIDE.tex
build_program500.py
program-build500-02/build.json
program-build500-02/PROGRAM_GUIDE.pdf
program-build500-02/PROGRAM_GUIDE.txt
program-build500-02/PROGRAM_GUIDE.log
program-visual-independent500-01.json
program-visual-independent500-02.json
program-build500/page-01.png
program-build500/page-08.png
program-build500-02/page-01.png
program-build500-02/page-04.png
program-build500-02/page-06.png
program-build500-02/page-08.png
program-build500-02/page-11.png
program-build500-02/page-15.png
program-build500-02/page-24.png
docs-published500.json''',
    'ui': '''ui-review500.json
proxy500-final.jsonl
review_proxy500.py
clone_state500.py
state-clone500.json''',
}
REASONS = {
    'raw': 'Registered donor, exact raw identity, independent-copy/readback failures, actual recorded GRIB decode and provenance.',
    'profile': 'One saved physical trial: timed and instrumented runs, original result JSON and profiler output; not ensemble/UI performance.',
    'restoration': 'Failure/counterexample to repair chain, fixed reference identity, selection/time preservation and unwanted aggregate side effect.',
    'validation': 'Finite final FE/BE receipts plus earlier failures; skip is preserved, no claim that every test ran.',
    'documents': 'Local comparisons, future historical-field design, structural guide generation and precisely scoped visual review.',
    'ui': 'Root finite UI observations and stable request log; no invented screenshot or live state DB is included.',
}
README = '''# 0.50 operational continuity evidence

This is a bounded evidence packet, not a copy of the repository or runtime.
Read `manifest.json` for exact bytes, origins and purposes. Historical candidate
receipts keep their original scope; later repairs do not turn their earlier
failures into successes. `evidence/restoration-analysis-side-effect-review500.json`
corrects the older review's broad no-POST reading: the saved 64-trial analysis
was fetched successfully, while a separate unnecessary 28-hit analysis was made.
The later local demand guard stops unused detail/hidden extents. Necessary
overview aggregation is not promised to be GET-only.
The final named frontend pass is review06; review05 records the preceding
sandbox process-spawn denial. Review03/04 remain stage evidence. Backend
tests500-02 records 98 passes and one explicit opt-in skip, not 99 passes.

## Reproduction inputs, without another provider request

`external-inputs.json` maps every raw replay/profile input to an exact member
and SHA-256 in existing Git evidence. Obtain both archives at those hashes:
- operational_weather490.zip contains the extended seven-lead source and the
  profiled trial inputs/results.
- ensemble_connection480.zip contains the earlier completed six-lead donor;
  it is an explicit dependency recorded by the 0.49 archive's previous_bytes.
The 0.49 archive alone is not sufficient. No original raw or saved trial is
replaced by a made-up record. Those large archives are not nested again here.

The root scripts retain their captured local layout. In a NEW scratch directory,
restore only the listed prior members into `balloon-operational-490/state-measure`
and use this packet as sibling `balloon-operational-500`. Never overlay a running
state. Recreate basis-repo from the fixed 0.49 C2 in the manifest. For raw replay,
create raw-candidate/test-repo from that basis and apply the four captured source
files; their hashes must match the replay receipt. Use recorded dependency/runtime
versions. The replay replaces only the missing f027 transport with local recorded
bytes and uses the real decoder. It does not query NOAA or measure network speed.
Move captured output evidence aside to an independent reference directory before
running scripts that refuse pre-existing outputs. Compare newly generated outputs
to the receipts; do not overwrite this packet or claim a new replay was run by
packaging. API/runtime startup and credentials are not required for these two
offline scripts.

Both profile result JSONs are preserved. Derived HTML/CSV/GeoJSON display files
are deliberately omitted; original manifests still describe the full original
run outputs, so the reduced profile directories are not complete committed API
result directories. Generate displays from original JSON/provenance if needed.
The recorded pstats is interpreter-specific and profiled timing includes overhead.

## Scope and exclusions

No state-review, SQLite/WAL, basis checkout, node_modules, virtualenv, Git object,
tiles, API key/session, giant older archive, or general metadata/save-authoring
collection is included. The copy/clone manifest is provenance, not the cloned DB.
PROGRAM PDF/text and seven changed-page images plus two before images support the
named visual review; this packet does not assert a new all-page review by root.
No new scientific accuracy/Monte-Carlo calibration, historical four-dimensional
field implementation, Google/3D or actual-mouse acceptance follows from this ZIP.
The root UI receipt defines the finite browser sequence, source version and
external-image CSP limits. It does not invent screenshots absent from that work.

Packaging checks known credential patterns plus root's declared bounded content
review. They cannot prove absence of arbitrary encoded secrets. Every packaged
member is read back and hashed. The final manifest excludes its own recursive
hash; the external readback receipt binds the archive and manifest. Final Git
save/management receipts occur later and are not self-inserted into this archive.
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def exclusive_json(path, value):
    with path.open('xb') as out:
        out.write(dump(value))


def relative(name):
    q = PurePosixPath(name)
    if q.is_absolute() or '..' in q.parts or '\\' in name or ':' in name:
        raise ValueError('Unsafe relative path')
    return q


def local(name):
    q = relative(name)
    source = P.joinpath(*q.parts)
    if source.is_symlink() or not source.resolve().is_relative_to(P):
        raise ValueError('Source outside scratch root')
    if any(part in {'state-review', 'basis-repo', 'venv', 'node_modules', '.git'} for part in q.parts):
        raise ValueError('Excluded source')
    return source


def listed():
    rows = []
    for group, names in GROUPS.items():
        for name in names.splitlines():
            source = local(name)
            rows.append({'path': name, 'member': 'evidence/' + name,
                         'group': group, 'purpose': REASONS[group],
                         'exists': source.is_file(),
                         'bytes': source.stat().st_size if source.is_file() else None,
                         'sha256': file_sha(source) if source.is_file() else None})
    if len({r['member'] for r in rows}) != len(rows):
        raise ValueError('Duplicate allowlist member')
    return rows


def scan(name, data):
    # Finite patterns. Do not dump candidate values into diagnostics.
    patterns = {
        'google_api_key': rb'AIza[0-9A-Za-z_-]{35}',
        'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
        'github_token': rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})',
        'aws_access_id': rb'AKIA[0-9A-Z]{16}',
        'bearer_value': rb'(?i)authorization[\"\s:]+bearer\s+[A-Za-z0-9._~-]{20,}',
    }
    found = [label for label, pattern in patterns.items() if re.search(pattern, data)]
    if found:
        raise ValueError('Credential-pattern review required: ' + name + ' [' + ','.join(found) + ']')
    if name.endswith('.gz'):
        import io
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as compressed:
            decoded = compressed.read(32 * 1024 * 1024 + 1)
        if len(decoded) > 32 * 1024 * 1024:
            raise ValueError('Compressed evidence exceeds bounded scan size')
        scan(name[:-3], decoded)


def externals(repo):
    for name, digest in ARCHIVES.items():
        if file_sha(repo / name) != digest:
            raise ValueError('Prior evidence archive hash mismatch: ' + name)
    first = next(iter(ARCHIVES))
    with zipfile.ZipFile(repo / first) as archive:
        previous = json.loads(archive.read('manifest.json'))['previous_bytes']
        names = set(archive.namelist())
    prior = {row['path']: row for row in previous}
    demands = {}
    replay = json.loads((P / 'real-raw500/receipt.json').read_bytes())
    for directory, files in replay['input_sha256'].items():
        for name, digest in files.items():
            full = (directory.replace('\\', '/') + '/' + name).split('/state-measure/', 1)[1]
            demands[full] = digest
    profile = json.loads((P / 'profile-run500/receipt.json').read_bytes())
    for full, digest in profile['input_sha256'].items():
        name = full.replace('\\', '/').split('/state-measure/', 1)[1]
        if name in demands and demands[name] != digest:
            raise ValueError('Input hash conflict')
        demands[name] = digest
    out = []
    for name, digest in sorted(demands.items()):
        relative(name)
        if name in prior:
            source = prior[name]
            archive_name, member = source['archive'], source['member']
            if source['archive_sha256'] != ARCHIVES.get(archive_name) or source['sha256'] != digest:
                raise ValueError('Previous-bytes mapping mismatch')
        else:
            archive_name, member = first, 'saved-input-results/' + name
            if member not in names:
                raise ValueError('Required prior member absent: ' + name)
        with zipfile.ZipFile(repo / archive_name) as archive:
            data = archive.read(member)
        if sha(data) != digest:
            raise ValueError('Prior member hash mismatch: ' + name)
        out.append({'restore_path': name, 'archive': archive_name,
                    'archive_sha256': ARCHIVES[archive_name], 'member': member,
                    'bytes': len(data), 'sha256': digest})
    return {'archives': ARCHIVES, 'inputs': out,
            'limits': 'Exact prior archive member verification, not a new replay or complete runtime restoration.'}


def freeze(repo):
    if PLAN.exists():
        raise FileExistsError('Frozen plan exists; do not overwrite')
    rows = listed()
    missing = [r['path'] for r in rows if not r['exists']]
    if missing:
        raise ValueError('Required evidence not yet fixed: ' + ', '.join(missing))
    if sum(r['bytes'] for r in rows) > MAX_INPUT:
        raise ValueError('Evidence exceeds declared small-packet budget')
    for row in rows:
        data = local(row['path']).read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Evidence changed during freeze: ' + row['path'])
        scan(row['path'], data)
    plan = {'schema': 'evidence500-frozen-plan/1', 'basis_commit': BASIS,
            'destination': DESTINATION, 'script_sha256': file_sha(SELF),
            'frozen_at_utc': datetime.now(timezone.utc).isoformat(), 'entries': rows,
            'external_inputs': externals(repo), 'readme_sha256': sha(README.encode()),
            'credential_scan': {'known_pattern_matches': 0,
                                'limits': 'Finite patterns only. Root bounded content review is required before build.'},
            'omissions': ['live state/SQLite', 'whole checkout', 'installed dependencies',
                          'older archives', 'raw files already bound in older archives',
                          'derived profile displays', 'general metadata/Git-save authoring']}
    exclusive_json(PLAN, plan)
    return {'plan': str(PLAN), 'sha256': file_sha(PLAN), 'entries': len(rows),
            'bytes': sum(r['bytes'] for r in rows), 'external_members': len(plan['external_inputs']['inputs'])}


def build(repo, plan_sha, binding_path, binding_sha):
    if not re.fullmatch('[0-9a-f]{64}', plan_sha or '') or not re.fullmatch('[0-9a-f]{64}', binding_sha or ''):
        raise ValueError('Explicit plan and root binding SHA required')
    plan_bytes = PLAN.read_bytes()
    binding_bytes = binding_path.read_bytes()
    script_bytes = SELF.read_bytes()
    if sha(plan_bytes) != plan_sha or sha(binding_bytes) != binding_sha:
        raise ValueError('Plan/binding hash mismatch')
    plan = json.loads(plan_bytes)
    binding = json.loads(binding_bytes)
    if len(binding_bytes) > 128 * 1024:
        raise ValueError('Root binding exceeds bounded size')
    if plan['schema'] != 'evidence500-frozen-plan/1' or plan['basis_commit'] != BASIS:
        raise ValueError('Unexpected plan')
    if plan['script_sha256'] != sha(script_bytes) or plan['readme_sha256'] != sha(README.encode()):
        raise ValueError('Packager changed after freeze')
    required = {'schema': 'evidence500-root-binding/1', 'plan_sha256': plan_sha,
                'script_sha256': sha(script_bytes), 'bounded_content_reviewed': True,
                'binary_content_reviewed': True, 'no_credentials_observed': True,
                'finite_ui_scope_reviewed': True, 'candidate_only': True}
    if any(binding.get(k) != v for k, v in required.items()) or not binding.get('review_scope') or not binding.get('binary_review_scope'):
        raise ValueError('Root finite review binding is incomplete')
    rows = listed()
    if rows != plan['entries'] or externals(repo) != plan['external_inputs']:
        raise ValueError('Evidence changed after freeze')
    for name in ('ui-review500.json', 'proxy500-final.jsonl', 'docs-published500.json'):
        if binding.get('root_evidence_sha256', {}).get(name) != file_sha(local(name)):
            raise ValueError('Root evidence not bound: ' + name)
    partial = OUTPUT.with_suffix('.partial.zip')
    if any(path.exists() for path in (OUTPUT, partial, RECEIPT)):
        raise FileExistsError('Candidate, partial or receipt already exists; no overwrite')
    payloads = {}
    for row in rows:
        data = local(row['path']).read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Captured payload differs from freeze: ' + row['path'])
        payloads[row['member']] = data
    payloads.update({'README.md': README.encode(), 'external-inputs.json': dump(plan['external_inputs']),
                     'evidence-package500.py': script_bytes,
                     'frozen-plan.json': plan_bytes, 'root-binding.json': binding_bytes})
    for name, data in payloads.items():
        scan(name, data)
    manifest = {'schema': 'evidence500-member-manifest/1', 'basis_commit': BASIS,
                'intended_repository_path': DESTINATION, 'frozen_plan_sha256': plan_sha,
                'root_binding_sha256': binding_sha, 'members': [
                    {'path': name, 'bytes': len(data), 'sha256': sha(data)}
                    for name, data in sorted(payloads.items())],
                'limits': 'Own manifest hash is external; no circular hash, new simulation or publication assertion.'}
    payloads['manifest.json'] = dump(manifest)
    with zipfile.ZipFile(partial, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payloads.items()):
            relative(name)
            info = zipfile.ZipInfo(name, (2026, 9, 30, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    if partial.stat().st_size > MAX_ZIP:
        raise ValueError('Candidate exceeds compressed budget; partial retained')
    with zipfile.ZipFile(partial) as archive:
        if len(archive.namelist()) != len(payloads) or set(archive.namelist()) != set(payloads):
            raise ValueError('ZIP member set mismatch')
        for name, data in payloads.items():
            actual = archive.read(name)
            if len(actual) != len(data) or sha(actual) != sha(data):
                raise ValueError('ZIP full readback failed: ' + name)
    if listed() != rows or file_sha(SELF) != sha(script_bytes) or file_sha(PLAN) != plan_sha or file_sha(binding_path) != binding_sha:
        raise ValueError('Source changed during packaging; partial retained')
    partial.rename(OUTPUT)  # Windows refuses an existing destination.
    receipt = {'schema': 'evidence500-package-readback/1', 'archive': str(OUTPUT),
               'bytes': OUTPUT.stat().st_size, 'sha256': file_sha(OUTPUT),
               'members_verified': len(payloads), 'manifest_sha256': sha(payloads['manifest.json']),
               'plan_sha256': plan_sha, 'binding_sha256': binding_sha,
               'status': 'external_candidate_all_member_readback',
               'repository_write': False, 'network': False,
               'limits': 'Packaging only. Root review/copy/registration and Git closure are separate.'}
    exclusive_json(RECEIPT, receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('inspect', 'freeze', 'build'))
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--plan-sha')
    parser.add_argument('--binding', type=Path)
    parser.add_argument('--binding-sha')
    args = parser.parse_args()
    if args.mode == 'inspect':
        rows = listed()
        result = {'entries': len(rows), 'bytes_present': sum(r['bytes'] or 0 for r in rows),
                  'missing': [r['path'] for r in rows if not r['exists']],
                  'groups': {k: sum(r['group'] == k for r in rows) for k in GROUPS},
                  'status': 'proposal_only_no_freeze_no_zip'}
    elif args.mode == 'freeze':
        result = freeze(args.repo.resolve())
    else:
        if not args.binding:
            raise ValueError('Root binding file required')
        result = build(args.repo.resolve(), args.plan_sha, args.binding.resolve(), args.binding_sha)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
