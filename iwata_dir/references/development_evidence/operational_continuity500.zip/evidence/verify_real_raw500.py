"""Replay recorded real NOAA GRIB: six registered leads plus one local transport.

No fresh HTTP, inventory or new forecast observation is claimed by this check.
"""
import hashlib, json, shutil, sys, time
from pathlib import Path
from datetime import datetime, timezone

P=Path(__file__).resolve().parent
OLD=P.parent/'balloon-operational-490/state-measure/weather/acquisitions'
OUT=P/'real-raw500'
CODE=P/'raw-candidate/test-repo'
sys.path.insert(0,str(CODE))
from backend.weather.service import WeatherService
from balloon_sim.environment import gfs
from balloon_sim.environment.storage import read_json
from balloon_sim.environment.bundle import WeatherField

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(p):return {q.relative_to(p).as_posix():sha(q) for q in p.rglob('*') if q.is_file()}

assert not OUT.exists(), 'new evidence directory required'
OUT.mkdir()
six=OLD/'15949041-7116-4604-ab98-df3953367c3c'
seven=OLD/'f76da29e-e0ad-4fb1-aa21-30a19fe5bab8'
before={str(p):inventory(p) for p in (six,seven)}
source_before={s:sha(CODE/s) for s in ('balloon_sim/environment/gfs.py','backend/weather/service.py')}
state=OUT/'state'
donor=state/'weather/acquisitions'/six.name
shutil.copytree(six,donor)
marker=read_json(donor/'ASSET.json')
asset={'acquisition_id':six.name,'cache_key':marker['cache_key'],
       'snapshot':marker['snapshot'],'marker_sha256':sha(donor/'ASSET.json')}
request=read_json(seven/'request.json');request.pop('lead_hours')
observed=read_json(seven/'provenance.json')
calls=[];progress=[];timings={}
original_download=gfs._download
original_decode=gfs.decode_gfs
def local_transport(url,path,remaining,**kwargs):
    # This only replaces the transport. Real product decoding stays in place.
    assert path.name=='f027.grib2',path.name
    row=next(row for row in observed if row['file']==path.name)
    assert row['url']==url
    data=(seven/path.name).read_bytes()
    assert len(data)<=remaining and sha(seven/path.name)==row['sha256']
    path.write_bytes(data);calls.append({'url':url,'file':path.name,'bytes':len(data)})
    return row.copy()
def decode(*args,**kwargs):
    start=time.perf_counter()
    try:return original_decode(*args,**kwargs)
    finally:timings['real_decode_seconds']=time.perf_counter()-start
gfs._download=local_transport;gfs.decode_gfs=decode
weather=WeatherService(state,source_guard=lambda:None).start()
try:
    with weather._guard,weather.db:weather._insert('asset',asset['snapshot']['id'],asset)
    start=time.perf_counter()
    target=gfs.acquire_gfs(request,OUT/'extended',raw_provider=weather._raw_donors,
                           progress=lambda update:progress.append({**update,'at_s':time.perf_counter()-start}))
    timings['total_seconds']=time.perf_counter()-start
    actual=read_json(target);expected=read_json(seven/'weather.json.gz')
    comparisons={key:actual[key]==expected[key] for key in ('axes','fields','surface')}
    assert all(comparisons.values()), comparisons
    WeatherField(actual)
    provenance=read_json(OUT/'extended/provenance.json')
    assert len(calls)==1 and len(provenance)==7
    for row in provenance[:6]:
        assert row['reuse_history'][-1]['asset_id']==asset['snapshot']['id']
        assert {k:v for k,v in row.items() if k!='reuse_history'}==next(r for r in marker['snapshot']['metadata']['provenance'] if r['file']==row['file'])
        assert sha(OUT/'extended'/row['file'])==sha(six/row['file'])
    assert sha(OUT/'extended/f027.grib2')==sha(seven/'f027.grib2')
    assert inventory(donor)==before[str(six)]
    receipt=read_json(OUT/'extended/receipt.json')
    assert receipt['downloaded_bytes']==calls[0]['bytes']
    assert receipt['reused_bytes']==sum(row['bytes'] for row in provenance[:6])
    assert receipt['retained_partial_bytes']==0
    assert all(inventory(p)==before[str(p)] for p in (six,seven))
    assert source_before=={s:sha(CODE/s) for s in source_before}
    result={'schema':'real-grib-reuse500/1','at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':source_before,'input_sha256':before,'transport':'recorded real f027 local replacement; zero network',
        'request':request,'new_transport_calls':calls,'progress':progress,'timings':timings,
        'receipt':receipt,'equal_categories':comparisons,'donor_unchanged':True,'original_inputs_unchanged':True,
        'current_decoder_full_validation':True,'bundle_sha256':sha(target),
        'limits':'Transport-count/decoded-values experiment, not fresh NOAA availability, wall-speed benchmark, or scientific validity.'}
    (OUT/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('timings','receipt','equal_categories','donor_unchanged')},indent=2))
finally:
    weather.close();gfs._download=original_download;gfs.decode_gfs=original_decode
