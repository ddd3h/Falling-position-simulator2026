from pathlib import Path
import sqlite3,hashlib,json,urllib.request,datetime
P=Path(__file__).resolve().parent
src=P.parent/'balloon-operational-490/state-measure';dst=P/'state-review'
assert not dst.exists(),'Never overwrite existing state'
with urllib.request.urlopen('http://127.0.0.1:8491/api/v1/ensembles',timeout=30) as r:jobs=json.load(r)['ensembles']
assert not any(j['state'] in ('queued','running','cancelling') for j in jobs)
rows=[]
for path in sorted(src.rglob('*')):
    if not path.is_file() or path.name=='service.lock' or path.name.endswith(('-wal','-shm')):continue
    rel=path.relative_to(src);target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True)
    if path.name.endswith('.sqlite3'):
        with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as a,sqlite3.connect(target) as b:a.backup(b)
        rows.append({'path':rel.as_posix(),'method':'SQLite online backup'})
    else:
        raw=path.read_bytes();target.write_bytes(raw);h=hashlib.sha256(raw).hexdigest()
        assert hashlib.sha256(path.read_bytes()).hexdigest()==h
        rows.append({'path':rel.as_posix(),'bytes':len(raw),'sha256':h})
(P/'state-clone500.json').write_text(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':str(src),'target':str(dst),'files':rows,'ensemble_states':[j['state'] for j in jobs]},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'files':len(rows),'bytes':sum(r.get('bytes',0) for r in rows)}))
