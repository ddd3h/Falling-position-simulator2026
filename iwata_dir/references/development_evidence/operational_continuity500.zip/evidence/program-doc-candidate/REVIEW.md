# 0.50 構造・操作・処理説明の候補

正本未変更。対象は PROGRAM_GUIDE.tex / COMMANDS.md / IMPLEMENTATION_NOTES.md の3実体だけ。差分は `program-doc500.patch`、元/候補のhashは `program-doc500.json`、読解範囲とsource照合は `program-doc-review500.json` にある。

構造ガイドは既存のページ/階層/矢印を保持し、frontendの横断helper `fixedResultRead` と3hook、backend登録asset→raw_provider→gfsの原本照合/独立copyの分担、新しい3試験の所在を短く追加する。詳細仕様はNOTES、操作名と失敗時の次行動はCOMMANDSへ分けた。科学式・THEORYは変更しない。

PROGRAM_GUIDE.txtはPDFからの検索テキストなので手編集しない。この候補はPDFを生成しておらず、未表示の改訂テキストを公開txtに見せない。後続の生成ではWEB-FRONTEND、WEB-CLIMATE-FRONTEND、WEB-ENSEMBLE-FRONTEND、WEB-WEATHER、WEATHER-ACQUIRE、PROGRAM-TESTSの文字量/カード間隔を特に確認し、PDFとtxtを同じTeXから作る。現ページアンカー順は保持されている。

元の確認印0.49は候補でも保持。0.50の確認印・版題名は、主担当が本文受入と生成確認の範囲に応じて最終適用する。過去の科学全再受入、実運用全状態/全端末保証、実通信性能改善はこの文書候補に含めていない。

NOTESはscreens担当の `history-doc-candidate` と同じ0.49を比較元としており、差分は別箇所。統合時は両patchを合わせ、一方の全ファイルcopyで他方を消さない。
