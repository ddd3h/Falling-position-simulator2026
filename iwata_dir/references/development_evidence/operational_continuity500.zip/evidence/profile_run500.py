"""Finite offline cost breakdown of one saved run; no server, provider or old output writes."""
from pathlib import Path
import sys,json,hashlib,time,cProfile,pstats,copy,datetime
P=Path(__file__).parent;B=P/'basis-repo';S=P.parent/'balloon-operational-490/state-measure'
sys.path.insert(0,str(B))
from backend import worker
identity='29dcf73d-61d6-4121-b6f2-863e139dd1bd'
spec_path=S/'specs'/identity/'run.json';config=S/'specs'/identity/'config.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=json.loads(spec_path.read_text(encoding='utf-8'));weather=S/'weather/acquisitions'/spec['weather_snapshot']['acquisition_id']/'weather.json.gz'
original_result=S/'results'/identity/'result.json'
assert original_result.is_file()
paths=[spec_path,config,weather,original_result];before={str(p):sha(p) for p in paths}
current=worker.source_snapshot();spec=copy.deepcopy(spec);spec['source_snapshot']=current
out=P/'profile-run500';out.mkdir(exist_ok=False)
metrics=[];originals={name:getattr(worker,name) for name in ('source_snapshot','file_hash','load_weather','simulate','export_result')}
stages={}
for name,fn in originals.items():
 def wrap(*args,_name=name,_fn=fn,**kwargs):
  start=time.perf_counter()
  try:return _fn(*args,**kwargs)
  finally:
   item=stages.setdefault(_name,dict(seconds=0,calls=0));item['seconds']+=time.perf_counter()-start;item['calls']+=1
 setattr(worker,name,wrap)
reference=json.loads(original_result.read_text(encoding='utf-8'))
for label,profile in (('timed',False),('profiled',True)):
 stages.clear();destination=out/label;timer=time.perf_counter();prof=cProfile.Profile()
 if profile:prof.enable()
 result=worker.execute_run(spec,weather,config,destination)
 if profile:prof.disable();prof.dump_stats(str(out/'profile.pstats'))
 elapsed=time.perf_counter()-timer;actual=json.loads((destination/'result.json').read_text(encoding='utf-8'));assert actual==reference,'physical result changed'
 metrics.append(dict(label=label,wall_seconds=elapsed,stages=copy.deepcopy(stages),status=result['status'],records=len(actual['records']),result_json_equal=True,result_sha256=sha(destination/'result.json')))
stats=pstats.Stats(str(out/'profile.pstats'));rows=[]
for (file,line,fn),(primitive,total,self_s,cum_s,callers) in stats.stats.items():
 if '/balloon_sim/' in file.replace('\\','/') or '/backend/' in file.replace('\\','/'):
  rows.append(dict(file=file,line=line,function=fn,calls=total,self_seconds=self_s,cumulative_seconds=cum_s))
rows.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
assert before=={str(p):sha(p) for p in paths}
receipt=dict(schema='offline-run-profile500/1',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),basis='22799fe2c20627321e9c60367e974b92e16497cf',run_id=identity,input_sha256=before,source_snapshot=current,metrics=metrics,hotspots=rows[:30],limits='One saved run, sequential timing then cProfile in one process with un-cleared caches. Profiling adds overhead. No parallel workers, queue/server/browser/ensemble aggregation or provider acquisition measured. Old saved inputs/result unchanged; equality is this input only, not scientific accuracy.')
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(metrics=metrics,hotspots=rows[:8]),ensure_ascii=False,indent=2))
