from pathlib import Path
import subprocess,json,hashlib,datetime
p=Path(__file__).parent
python=r'C:/Users/genia/AppData/Local/Temp/balloon-implementation-470/backend-venv/Scripts/python.exe'
paths=sorted(str(x.relative_to(p/'source')).replace('\\','/') for x in (p/'source').rglob('*.py'))
def fingerprint():return {name:hashlib.sha256((p/'source'/name).read_bytes()).hexdigest() for name in paths}
before=fingerprint();rows=[]
for name,arguments in [('core-new',['-m','unittest','discover','-s','tests','-p','test_gfs_raw_reuse.py','-v']),('core-existing',['-m','unittest','discover','-s','tests','-p','test_gfs_acquisition.py','-v']),('service-new',['-m','pytest','backend/tests/test_weather_raw_reuse.py','-q','-p','no:cacheprovider'])]:
 command=[python,'-X','utf8','-B',*arguments]
 result=subprocess.run(command,cwd=p/'test-repo',capture_output=True)
 (p/(name+'-03.stdout')).write_bytes(result.stdout);(p/(name+'-03.stderr')).write_bytes(result.stderr)
 rows.append({'name':name,'argv':command,'exit':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
 print(name,result.returncode,flush=True)
after=fingerprint()
(p/'tests-03.json').write_text(json.dumps({'schema':'raw-candidate-offline-tests/1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows,'before':before,'after':after,'source_changes':[k for k in before if before[k]!=after[k]],'limits':['No original repository/runtime state/Git was edited.','Fake download and decoder; actual recorded GRIB equivalence is a separate root-owned check.','No elapsed-time or memory performance claim from this test run.']},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raise SystemExit(max(row['exit'] for row in rows))