# 0.50 raw再利用候補の根拠と有限検査

基準はprivate PR30の0.49記録C2 `22799fe2c20627321e9c60367e974b92e16497cf`。原版8 sourceは`basis.json`へ固定し、正本を編集せず`source/`だけに変更候補を置いた。最終候補は`raw-reuse500.json`と`raw-reuse500.patch`で識別する。`make_patch.py`は初稿の作成記録であり、後続の批評修正を含まないため適用に使わない。

## 問いと修正の範囲

利用者が同じ予報周期・同じ領域で必要時間を広げると、全窓をキーにする完成場の再利用も、同directoryと同requestのprefixだけを使う再開も成立しない。その結果、既知6枚を含む7枚すべてが再取得される。今回の目的はこの重複だけを減らすことであり、予報の最新性、別領域への切出し、気象誤差、過去場や一般cache基盤の設計を同時採用しない。

完成場そのものの再利用は従来どおり維持する。部分rawを流用して新窓を作る場合の`job.reused`はfalseであり、現在decoderで全窓を復号し、従来のbundle/receipt/ASSET/registry順で新場を公開する。元assetと既存結果は変更しない。provenanceが増えるのでgzip bundleのbyte同一を要求せず、axes/fields/surfaceと由来の正しさを別々に確認する。

## 実構造へ置く最小境界

- `WeatherService._raw_donors(spec, missing_leads)`が、同じserviceに正規登録された完成assetだけを候補にする。登録一覧をguard内でcopyし、同run/正規化矩形/不足lead/完全URLに絞ってからguard外で既存markerと圧縮bundle hashを検証する。未登録・active・失敗・孤児directoryは供給元にしない。
- `acquire_gfs(..., raw_provider=None)`は既存prefixを検証した後に不足leadだけを内部供給関数へ渡す。HTTPからpath/URLを受ける入口は追加しない。注入acquirerの既存signatureを保ち、default acquirerにだけ供給関数を渡す。
- 完全URLはrun/lead/全selector/正規化矩形を含み、別selector等は再利用しない。ただし同じ要求は同じprovider bytesを保証しないため、同URLに異なる検証済みbytes/hashがあれば曖昧として停止する。最初の1候補を黙って採用しない。
- 現在decoder identityはrawのidentityと別に扱う。旧rawを使っても、新計画のdecoder/source guard・全窓検証は省略しない。

## コピーと費用の意味

供給元をbytes/SHA256/GRIB/header/statで検算してから、新jobへ独立partialとしてコピーする。コピー完了後のflush/fsyncだけでは保存先の一致を証明できないというroot批評を採り、宛先partialを別streamで再読してbytes/SHAを検算後にrenameする。元HTTPのheaders/開始・完了時刻を保持し、`reuse_history`へ供給assetとcopy日時・元provenance hashを追記する。hardlinkは使わない。

全既知再利用rawのbytesを先に容量予約する。新規HTTPはその予約を差し引いたremainingで行い、再利用・HTTP・保全partialの合計に既存上限を適用する。完成bundleへの早期returnでも保全partial超過を見逃さない位置へ上限確認を移した。

copy途中の`.reuse.partial`は保存容量へ数え、新規通信量へは数えない。`bytes_reused`は検証copyを完了したbytes、`bytes_downloaded`は新規HTTPとそのpartialである。旧最終名を孤児として退避した場合、退避後のfilenameだけからcopy/HTTPの由来を完全追跡できるわけではないが、初期partial量として再開前に差し引くので新規通信へは誤加算しない。この限界は独立批評で再確認した。

追加progress phaseは`checking_saved_raw`と`reusing_raw`。既存のbytes/completed_files/total_filesを使用し新しい公開fieldは追加しない。UIの『転送上限』とphase表記の整合はrootが別途担当する。

## 反例と根拠

`tests-03.json`は新core13・既存取得8・新service5の計26件成功、候補sourceの前後hash一致を記録する。根拠は以下の行程に絞る。

|反例|確認した結果|
|---|---|
|登録済み6枚から7枚へ窓を拡張|不足1枚だけfake HTTP、6枚の再利用bytes、全7枚の現在decoder入力、元assetの全file不変|
|raw未登録/孤児directory|再利用元に入らず、通常取得へ進む|
|完全URL差、run差、矩形差|別要求のrawを代用しない|
|raw改竄・marker改竄・同URL別bytes|新規HTTP前に拒否、元bytesを勝手に補修しない|
|known copyだけで上限超過/後続copyを残す前方HTTP|HTTP前拒否、またはcopy予約を差し引いた上限を使用|
|copy途中取消、元rawの検算後変更、宛先破損|公開しない。copy partialは容量に残り通信量0、元rawを保つ|
|rename後provenance書込み前停止|孤児を保全し、receiptのない最終名を信用しない|
|旧prefixだけで揃う明示再開|無関係donorを走査せず、現在のprefix/decoder検証を使用|
|現在decoderが失敗|新assetを公開しない。旧rawを現在decoder結果と混同しない|

初回は実行cwdを誤りtestsが見つからず、その訂正後はTemp作成/片付けのWinError5で11件24 ERRORになった。許可された実行環境で同sourceの11件が成功した。その後、root指摘の宛先readback反例と容量早期return反例を追加し、最終26件を実行した。環境失敗を実装成功へ読み替えていない。

## 未確認と後続の判定

テストはローカル偽通信・偽復号を用いた。実保存7GRIBを現在ecCodesで再復号し、候補の6再利用＋1供給と全7供給のaxes/fields/surfaceを比較する検査はroot担当であり、本票では実施したとしない。実HTTP、API操作、Git、稼働runtime DBの読取りや変更は行っていない。

matching assetをすべて走査するため、asset数に比例した圧縮bundle hash・raw検算の費用がある。既存`_verify_asset`は圧縮bundleをhashするが、候補選定時にはbundle全体の展開を行わない。初回の目的は重複HTTPと転送量を減らすことであり、経過時間/RSS改善は未測定。取消はchunk間と境界で協調的に行い、既存のbundle hash readやOS filesystem操作を強制中断する保証はない。

候補は完成asset由来の完全な同要求rawだけを扱う。共有blob倉庫、回収/eviction、別領域切出し、未観測周期の新計画、複数providerや気象誤差モデルを一般化して実装していない。