const fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const p='C:/Users/genia/AppData/Local/Temp/balloon-operational-500/ui-candidate/candidate/frontend/src/screens/forecast/controller.js';
const source=fs.readFileSync(p,'utf8'),line=name=>source.split(/\r?\n/).find(x=>x.includes('function '+name+'('));
const nodes={exportTarget:{options:[]},exportPNG:{disabled:false},exportSVG:{disabled:false}};
const c={disposed:false,state:{detail:true,active:'A',selected:['trial1'],groups:[],tabs:[],time:60},$:id=>nodes[id],activeGroup:()=>null,activeTab:()=>({id:'A',result:null,resultRead:{state:'loading'}})};
vm.createContext(c); vm.runInContext(line('exportAvailability')+'\n'+line('graphSnapshot'),c);
vm.runInContext('exportAvailability()',c);let error=null;try{vm.runInContext('graphSnapshot("historyChart")',c)}catch(e){error=e.name+': '+e.message;}
const out={method:'Extracted unchanged actual functions in Node VM; DOM stubs only; no browser/API.',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),waiting_state:'Saved detail selected=[trial1], result=null, resultRead=loading',png_disabled:nodes.exportPNG.disabled,svg_disabled:nodes.exportSVG.disabled,snapshot_error:error,limits:'No full React mount or browser executed. App keyed mode remount was read; earlier mode-ref concern withdrawn.'};
fs.writeFileSync('C:/Users/genia/AppData/Local/Temp/balloon-operational-500/ui-restore-export-counterexample500.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
