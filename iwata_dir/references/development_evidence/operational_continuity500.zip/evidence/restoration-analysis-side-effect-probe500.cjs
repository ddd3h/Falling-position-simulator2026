const fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const P='C:/Users/genia/AppData/Local/Temp/balloon-operational-500/';
const R=process.cwd();
const file='frontend/src/screens/forecast/controller.js',sceneFile='frontend/src/screens/forecast/scene-document.js';
const source=fs.readFileSync(R+'/'+file,'utf8'),baseline=fs.readFileSync(P+'basis-repo/'+file,'utf8'),scene=fs.readFileSync(R+'/'+sceneFile,'utf8');
const extract=s=>s.slice(s.indexOf('function analysisDocument('),s.indexOf('\n}',s.indexOf('function analysisDocument('))+2);
const original=extract(source),old=extract(baseline);
const target="extent:t.result?.kind==='ensemble'&&cls.hits.length?analysisFor(t,cls.hits,";
if(!original.includes(target)||!old.includes(target))throw Error('expected expression absent');
const hypothetical=original.replace(target,"extent:!detail&&state.showHits&&(allObjects||visible)&&t.result?.kind==='ensemble'&&cls.hits.length?analysisFor(t,cls.hits,");
function probe(fn,detail,showHits,visible,allObjects=false){
 const calls=[],t={id:'A',name:'main',visible,result:{id:'s:c',kind:'ensemble',collection:{snapshot_id:'s',case_id:'c'},conditions:{origin:[33,136]}},draft:{origin:[33,136]}};
 const c={scope:{window:{BJP_STYLE:{bandLevels:[.5,.9,.95],bands:()=>[],close:r=>r}},document:{}},state:{detail,active:'A',tabs:[t],selected:['all'],zoneVersion:1,showHits,levels:[],bands:[.5,.9,.95],time:145,metric:'h',view:'position'},bridge:{real:true,supports:()=>[]},activeTab:()=>t,selectedSamples:()=>[],ledgerIds:()=>['all'],classification:()=>({hits:['hit'],hitDetails:{},total:64,landed:64,stopped:[],unknown:[]}),allSamples:()=>[],landed:()=>[],seriesColor:()=> '#123',dirty:()=>false,conditionsText:()=>'',analysisFor:(...args)=>{calls.push(args[1]);return{landing:{extent:{type:'Point',coordinates:[136,33]}}}},ellipses:()=>[],mean:()=>0,meanPathGeometry:()=>[],scopeBounds:()=>[[33,136],[34,137]],zonePresentation:()=>[],regions:()=>[],delayLabel:()=>''};
 vm.createContext(c);vm.runInContext(scene.replace('export function install','function install')+'\ninstall(scope);',c);c.BJP_SCENE_DOCUMENT=c.scope.window.BJP_SCENE_DOCUMENT;vm.runInContext(fn,c);const result=vm.runInContext('analysisDocument({allObjects:'+allObjects+'})',c);
 return{detail,showHits,visible,allObjects,analysis_calls:calls.length,extent_features:result.features.filter(f=>f.properties.kind==='interference-extent').length};
}
const conditions=[[true,true,true],[false,false,true],[false,true,true],[false,true,false],[false,true,false,true]];
const tests=conditions.map(args=>({input:args,current:probe(original,...args),basis:probe(old,...args),hypothetical_guard:probe(hypothetical,...args)}));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const report={schema:'analysis-document-side-effect-probe/1',source:{path:file,sha256:hash(source),basis_sha256:hash(baseline),scene_sha256:hash(scene)},method:'Extract actual analysisDocument and install actual scene-document in Node VM; stub data/classifier/renderer dependencies and count analysisFor calls. No HTTP or browser.',tests,limits:['Hypothetical guard tested in memory only; repository unchanged.','Stubbed data do not verify classifier geometry, API integration, timing, or new browser acceptance.']};
fs.writeFileSync(P+'restoration-analysis-side-effect-probe500.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(tests));
