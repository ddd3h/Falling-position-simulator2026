"""External QA fault proxy. Never ships in product. Blocks third-party images.

control500.json: mode=pass/fail/missing and delay_s applies only saved GETs.
"""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import urllib.request,urllib.error,json,time,threading
P=Path(__file__).resolve().parent;lock=threading.Lock()
class Handler(BaseHTTPRequestHandler):
    def forward(self):
        start=time.monotonic();status=500
        target=self.command=='GET' and ('/cases/' in self.path or '/climate-analyses/' in self.path or self.path.endswith('/result'))
        settings=json.loads((P/'control500.json').read_text('utf-8'));mode=settings.get('mode','pass') if target else 'pass'
        if target:time.sleep(min(20,max(0,settings.get('delay_s',0))))
        try:
            if mode in ('fail','missing'):
                status=503 if mode=='fail' else 404
                data=json.dumps({'error':{'code':'QA_GET_UNAVAILABLE' if mode=='fail' else 'NOT_FOUND','message':'QA: saved GET response intentionally unavailable; source retained.'}}).encode()
                ctype='application/json'
            else:
                body=self.rfile.read(int(self.headers.get('Content-Length','0'))) or None
                req=urllib.request.Request('http://127.0.0.1:8500'+self.path,data=body,method=self.command,
                    headers={'Content-Type':self.headers.get('Content-Type','application/json')})
                try:res=urllib.request.urlopen(req,timeout=60)
                except urllib.error.HTTPError as error:res=error
                with res:data=res.read();status=res.status;ctype=res.headers.get('Content-Type','application/octet-stream')
            self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(data)))
            self.send_header('Content-Security-Policy',"img-src 'self' data: blob:; connect-src 'self'")
            self.end_headers();self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
        finally:
            with lock:
                with (P/'proxy500.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'method':self.command,'path':self.path,'status':status,'mode':mode,'seconds':time.monotonic()-start})+'\n')
    do_GET=forward
    do_POST=forward
    do_PUT=forward
    def log_message(self,*args):pass
if __name__=='__main__':
    print('QA 8501 -> 8500, external images blocked; saved GET faults from control500.json',flush=True)
    ThreadingHTTPServer(('127.0.0.1',8501),Handler).serve_forever()
