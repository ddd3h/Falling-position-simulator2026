from pathlib import Path
import subprocess,os,sys,json,hashlib
P=Path(__file__).resolve().parent
R=Path(r'C:/Users/genia/OneDrive/ドキュメント/00 よく使う/n_名古屋大学/06_Chart/バルーン/Balloon_Sim/2026_Sep_/space-balloon-simulator-jp')
S=P/'combined-docs500';O=P/('program-build500'+('-'+sys.argv[1] if len(sys.argv)>1 else ''))
env=dict(os.environ);env['PATH']=r'C:/Users/genia/.local/share/balloon-docs/TinyTeX/bin/windows'+';'+env['PATH'];env['FONTCONFIG_FILE']=r'C:/Users/genia/.local/share/balloon-docs/fonts.conf';env['PYTHONUTF8']='1'
cmd=[sys.executable,'-B',str(R/'tools/build_guides.py'),str(S),'--output-dir',str(O),'--guide','PROGRAM_GUIDE']
r=subprocess.run(cmd,env=env,cwd=R,capture_output=True)
(P/(O.name+'-driver.stdout')).write_bytes(r.stdout);(P/(O.name+'-driver.stderr')).write_bytes(r.stderr)
assert r.returncode==0,'build failed; inspect logs'
renderer=r'C:/Users/genia/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
r=subprocess.run([renderer,'-r','100','-png',str(O/'PROGRAM_GUIDE.pdf'),str(O/'page')],capture_output=True)
assert r.returncode==0,r.stderr
print('PROGRAM built and rendered',len(list(O.glob('page-*.png'))),'pages')
