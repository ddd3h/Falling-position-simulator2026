# 0.58 操作・構造・理論資料の有限監査

基準: 0.58 C2 `95f09d2fc0ae076def05eb76df996b9f2c3b0ef4`。主担当が全365実体の同一性を確認した `basis580` を読取対象とした。今回この担当はGit/稼働サービス/状態DB/外部気象/ブラウザ/Googleを操作していない。本文修正やPDF再生成もしていない。記録のみ本P590へ保存した。

## 判断

0.58の中心的な区別――原標本の年間48区分、従来の半月/月/季節、月の中央値とp10–p90、地域平均、点の風配、固定結果と草案、旧保存図の再読――は、下記で読んだ現行本文・実装・PDFページで概ね整合する。選択ページに判読を妨げる重なりや欠けは見つからなかった。ただし、構造図に責務の混入が1件、所在が曖昧な記述が1件、挿入後の案内の残りが2件あり、backendの入口は0.58への案内が不足する。「全ドキュメントは正しく更新済み」とは判定しない。

本担当は0.58 archive/periods と索引更新に先行作業で関与した。同じ作者から独立した数値監査ではなく、固定版の本文・ソース・ページを再読して指摘する有限な照合である。今回の監査で数値計算/単体試験/取得を再実行していない。

## 資料の意義と分担

| 資料 | 読者が達成すること | 本文で確認できた分担と評価 |
|---|---|---|
| COMMANDS | 入力・環境・副作用を理解して起動、分析、保存、再開する | C-09の実操作と停止/再送を具体化。0.58年間48と元格子点、面操作の固定結果/草案区別は具体的。実績をS36へ返す責務も妥当。ただし先頭の版別注記と巨大なC-09を通過する負荷がある。 |
| backend/README | backend開発者が起動・HTTP・保存境界の入口を得る | 物理核を動かさずadapter/worker/storeを置く関係、GET再読とPOST固定の責務は明瞭。表題と現行紹介が0.57に留まり、追加48の所在へ導けていない。 |
| IMPLEMENTATION_NOTES | 構造図を読んだ後で処理順、DTO、寿命、失敗時の契約を追う | 27行でPROGRAM/THEORY/COMMANDS/WEATHERとの分担を宣言。原標本と旧集計DB、artifactとruntime cacheの区別は良い。大段落が複数の契約を抱え、変更影響の読取りは重い。 |
| PROGRAM_GUIDE | 変更すべき実体、上下流、状態境界を構造から探す | 図の階層・矢印種別と逆引きが機能する。p7の責務/所在2点は、この資料の本来の「どこを直すか」を妨げるため局所是正を推奨。 |
| THEORY_GUIDE | 母集団・重み・式・読み違えを理解する | 選択した気象統計章では、平均速度/平均ベクトル、重み付き経験分位、静穏を含む風配分母、ISA基準と実高度を区別。科学的採用の未確認を残している。 |
| IMPLEMENTATION_INDEX | 実体・関数・行・依存を検索し本文へ戻る | 現行structureの245パス/380指紋参照は固定実体と一致。過去版extractionに旧指紋が残るのは履歴であり、不整合とは扱わない。JSONは意味本文の代用品にはならない。 |
| BUILD | 再生成に必要な依存と生成境界を理解する | source/lock/runtimeを分け、専用環境と新出力先、publish境界を説明。run_checksとFE/backend検査の別実行を明示している。現行レシピと古い生成実績の往復を減らせる。 |

判断基準はDOCUMENT_CONTROLのDC-JUDGMENT、DC-ASSET構造契約、DC-INDEX、DC-NARRATIVE-BASE/DC-FRACTAL、DC-CLOSE、DC-CHANGE/DC-STABILITYを本文で読んだ。機械的な指紋充足を内容理解へ広げず、資料の役割に戻して評価した。現状は新しい資料や検査層を増やすより、既存責務内の局所修正が適切である。

## 実物に照合可能な指摘

### G1 — PROGRAMのexport箱が関心handoffまで担当するように読める

- 所在: `docs/PROGRAM_GUIDE.tex:138`、PROGRAM PDF物理p7、WEB-CLIMATE-FRONTEND。
- 記述: `weather/export.ts`の箱内に「半月/月/季節の関心はhandoffへ。年間48区分は渡さない」。
- 根拠: `frontend/src/screens/weather/export.ts:1–30` はSVG/メタデータの生成担当で、同ファイルにhandoff経路はない。関心を作って送るのは `frontend/src/ClimateFlightHandoff.tsx:1–11`、表示は `frontend/src/screens/WeatherScreen.tsx:34`。PROGRAMの別頁（TeX214行）は既にこの実担当を示す。
- 影響: 「保存の変更」と「飛行関心の変更」の修正先を同じhelperだと誤認し得る。年間48を渡さないという意味自体は正しい。
- 具体案: 138行のhandoff文をhost箱か別の短い参照へ移し、`ClimateFlightHandoff.tsx → App`を担当として名指す。export箱は図・条件・来歴の固定とSVG出力に限定する。実装分割の変更は不要。

### G2 — PROGRAMのディレクトリ箱内でmonthlyProfilesの所在が曖昧

- 所在: `docs/PROGRAM_GUIDE.tex:134`、PROGRAM PDF物理p7。
- 根拠: `weather/sources/`というFile箱内に `monthlyProfiles.ts` を置くが、実体は `frontend/src/screens/weather/monthlyProfiles.ts`。同頁137行では正しいweather直下の図担当に置かれている。
- 影響: sources配下の実体と、そこから参照する共有検査を視覚上区別できない。機能説明の間違いではなく、構造図の包含関係が曖昧。
- 具体案: 134行を「原標本分位の検査は `../monthlyProfiles.ts` を参照」等にする、または重複文を削って137行へ参照矢印を付ける。既存箱・IDを保つ。

### G3 — THEORYの「次頁」が挿入後の頁構成と合わない

- 所在: `docs/THEORY_GUIDE.tex:799`、THEORY PDF物理p22（印字p21）。
- 記述: 「次頁の地域平均へ進む」。実際の次頁p23は月分位/風配、地域平均はp24。
- 具体案: 頁相対語を「後述の地域平均」または節labelへの参照に置き換える。式(時間pool)や地域重みの変更は不要。

### G4 — NOTESの取得状況への案内に「未了」が残る

- 所在: `docs/IMPLEMENTATION_NOTES.md:301`。
- 記述: 「有限2probeの意味と取得未了はWEATHER/S36」。同段末尾はfreeze10当時の契約読解に範囲を限定している。
- 根拠: `backend/README.md:3`等は2024全12月取得後の保存/有限実績を案内する。freeze10の読解印を全取得成功へ広げないことは正しいが、この案内語を現在の状態として読むと未完と誤解する。
- 具体案: 「有限2probeの意味と、その後の取得状況・完了実績はWEATHER/S36」へ。本文の当時の読解範囲と、全U/Vサービス間一致を認定しない留保は保持する。

## 更新不足・編集改善（上記の事実誤記とは区別）

### U1 — backend入口に0.58の短い差分案内が必要

`backend/README.md:1` は0.57 candidate、3行の現行紹介、401行のSaved climate analyses見出し、407行のOriginal-UTC archivesはいずれも0.57まで。本文にannual_quartersと0.58の不変年間集計再利用がない。一方、現 `backend/climate/archive.py:216–271` は同一bounds/hours内の重い不変結果を再利用し、`annual_quarters`を別フィールドに返す。旧半月/月/季節を変えたとは書かれておらず、旧記載が科学的に誤りという指摘ではない。

案: 冒頭を現在のadapter入口へし、短い0.58段落で「原標本sourceのみannual_quarters追加・half/month/season保持・空間行/飛行関心へのquarter追加なし・結果GET不変」とNOTES/COMMANDSの所在を記す。詳細式・性能実績は複写せず既存正本へ返す。0.57の取得成功とその時点の受入範囲は歴史として保持する。

### U2 — 現行の手順へ着くまでの版注記を整理できる

COMMANDS14–26、NOTES13–27は複数版の確認範囲を先に並べ、BUILD13以降も現行の生成方法と0.50/0.55等の実績が交互に現れる。時点を明記しているので、過去の「未実施」を現在の未実施と断定してはならない。ただし読者は最新操作を見つける前に多数の履歴を解釈する必要がある。

案: 既存の資料IDと歴史を保ち、冒頭の役割→現在の目的別入口→版別実績の参照という短い道筋を強くする。COMMANDS C-09/BUILDの現行レシピを参照元とし、古い操作結果の全文を再複写しない。これは大規模再編の採用を意味せず、実際に移すならDC-CHANGEに従う固定旧本文比較が必要。

### U3 — NOTESのcache説明を責務ごとに区切る

NOTES327/329はartifact固定、adapter4母集団cache、面依存spatial/rose、出口deepcopy、FE6面LRU、待機/後着/復帰まで大段落で説明している。内容は照合範囲で妥当。API/永続保存、サーバ計算再利用、ブラウザ要求列の3小段落に区切ると、再起動や面操作を直す読者が変更範囲を選びやすい。新しい文書/重複規範は不要。

## 0.58対応を確認した箇所

- `archive.py:99–152,216–271` と `periods.py:1–39`: quarterはUTC原日付1–7/8–15/16–22/23–末を直接maskし、従来halfの計算順とは分離。48は年間専用。cacheは同sourceインスタンスのbounds+hours、出口deepcopyと前後source guardを維持。数値一致の再計算は今回していない。
- NOTES311/327、THEORY811–835、COMMANDS389–393: 年間48を細かい期間の経験平均として説明し、月分位や飛行用瞬時場の代替にしていない。原標本2024と旧2016–2025 DB、人工type7と実weighted inverted_cdfを区別。
- COMMANDS471: 全件分析reuse、原履歴GET独立、未送信だけownerで再開という区別を保持。503–507: real ASL連続幕と人工AGLの支持待ち、地下floorの表示上の意味を区別。ただし今回UIや3Dコード全体を再受入していない。
- BUILD23および `tools/run_checks.py:145–152`: run_checksはstate/health/core unittest/前後byte確認であり、Vitest/backend pytestを含まない。COMMANDS C-09の別実行記載と合う。
- `frontend/package.json`、`vite.config.ts`、`backend/requirements.lock`、`tools/build_guides.py`: loopback/明示port、型検査後build、asset同origin配布、依存版lock、生成先新規・選択guide/publishの境界を本文と照合。これらを今回実行成功したとはしない。
- INDEX: 現行structure内380指紋参照、重複を除く245sourceが固定コピーと一致。過去extractionの旧hashをcurrent source不一致と数えない。34公開APIの意味/全行/全依存を再抽出・再レビューしていない。

## PDF視認と有限読取範囲

PDFを固定原本からPopplerで1600px画像へ描画し、以下13頁を実際に視認した。PROGRAMは物理p1,2,7,12,15,17,32、THEORYは物理p1,21,22,23,24,25。各頁の役割、箱/矢印、文字、表/式、余白と段のつながりを読んだ。この集合で重なり・欠け・判読不能を発見しなかった。全32/27頁の視認成功とはしない。リンククリック/印刷機/アクセシビリティ/ブラウザ上PDFは未確認。

画像と原PDF hash: `guide-visual590/render-receipt.json`、同フォルダーの13PNG。索引照合: `guide-index-hash590.json`。範囲・対象hash: `guide-audit590-scope.json`。

本文の有限読取（見出し検索やJSON全parseだけの範囲とは区別）:

- COMMANDS: 1–70,219–270,285–316,380–552。
- backend README: 1–110,381–435。
- NOTES: 1–34,279–347。
- PROGRAM TeX: 127–145,202–225,239–283,461–477、ほか選択PDF本文に相当する表紙/入口/7/12/15/17/32頁。冒頭1–94の一部は取得出力が省略されたため全行読取とはしない。
- THEORY TeX: 746–840,940–985、および選択PDF21–25頁で中間の地域平均/重み/適用限界を視認。物理モデル旧章の式・参照原典の再検証は未実施。
- BUILD: 1–94,463–504。95–462の大半は見出し/必要語検索のみ。
- INDEX: JSONを全parseしcurrent structureのhashを列挙。0.58抽出来歴・climate flow・追加test entryを選択して意味読取。28,409行全本文、245source全実装、34public API全契約の意味照合は未実施。
- DOCUMENT_CONTROL: 26–70,139–178,220–235,280–333,336–396。

今回の差分を過去の全版に遡る遷移監査にはしていない。root担当の入口/規範/全体役割と他批評役の結果を合わせて最終採否する必要がある。指摘を直しても、未読物理章/他画面契約/全取得証拠/科学妥当性まで確認印を広げない。
