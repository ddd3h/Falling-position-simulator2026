# build02: 有限確認印の同期と変更頁確認

主担当の採用に基づき、PROGRAM-CORE/THEORY-COREの最初の管理コメントの確認を0.59へ、REV参照をREV-590-GUIDE-PROGRAM/THEORYへ揃えた。THEORY表紙にも同じ確認印を表示した。ほかの過去印・科学式・本文はbuild01から変更していない。独立source02を作り、source/build01/旧review票は保持した。

既存生成器の3passでbuild02の両PDF/txtを生成。Overfull/Missing-characterは0。PROGRAM32頁の全てとTHEORY27頁中2–27頁は、同Poppler/1100pxのRGB全ピクセルがbuild01と完全一致。頁別抽出textも一致する。THEORY表紙だけが変更し、差分bboxは1100pxで[212,422,220,434]、確認数字8→9の位置。1700pxの表紙を再視認し、確認0.59と文書0.59/実装0.58、有限読取の限界が明瞭であることを確認した。

全頁を再度精読したとはしない。既に実施した全頁配置/変更頁読取を、他頁の描画・text同一性で継承する。科学式全体の再検証、コード試験や実UI受入は追加していない。

新正本候補: source02/docs/*.tex、build02/*.{pdf,txt}。原生成票build02/build.json、描画比較visual02/comparison.json、最終確認review02-receipt.json。repoとPLANは未変更。metadata helperはこのsource_hashesをguardし、TeX本文を再変更しないことが今回の採用条件である。
