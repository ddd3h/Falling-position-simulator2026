# 文書0.59 / 実装0.58 ガイド生成・視認

既存tools/build_guides.pyを固定0.58から独立sourceへコピーし、採用された局所修正と表紙/導入の文書版区別だけを加えた。repoやPLANへは書き込んでいない。生成器を改変せず、TinyTeX/FONTCONFIG_FILEは実行process内だけに設定。各TeXを3pass生成し、PDFとpypdf検索textを得た。

結果: PROGRAM32頁、THEORY27頁。Overfull/Missing-character検出は両方0。全59頁の配置を15枚の4頁シートで確認し、変更したPROGRAM1/7/13、THEORY1/22を1700pxで個別視認した。重なり、欠け、豆腐、見出し/式/本文とheader/footerの衝突は観察しなかった。THEORY最終頁は参考節の継続で余白が多いが、旧版同様で今回の改訂による余分な空白頁ではない。

PROGRAMはWeatherScreenから関心担当へ戻り、export箱はSVGに限定、sources箱の外部helper参照を読める。THEORYの相対頁語を節名に直し、表紙は文書0.59と実装0.58を区別。既存確認0.58を保持し、全面科学再検証のstampは加えていない。原版と式environmentおよび既存label/target集合が同じことも有限に照合した。

入力/出力SHA・警告・頁ごとの視認範囲はreview-receipt.json、既存生成器の原票はbuild01/build.json、pass stdout/stderr/logはbuild01、描画はvisual01。採用済draftから表紙への追加差分は*-cover.diff。基準からの全差分は*-basis.diff。

限界: 配置確認は全科学本文の読解/実装の全試験/ブラウザ/印刷機/支援技術検証ではない。今回の有限監査scopeをguide-audit590.mdから広げない。rootが文書側の管理印を確定する場合は、この内容候補との関係を別に扱う。
